﻿package tw.com.skl.exp.web.config;

import java.util.Map;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;

import tw.com.skl.common.model6.web.jsf.utils.FacesUtils;
import tw.com.skl.exp.kernel.model6.common.ErrorCode;
import tw.com.skl.exp.kernel.model6.common.exception.ExpRuntimeException;
import tw.com.skl.exp.kernel.model6.common.util.StringUtils;

/**
 * 設定CrystalReport每個檔案路徑的參數ManagedBean
 * 
 * 
 */
public class CrystalReportConfigManagedBean {

	/**
	 * 因為報表參數值不可為NULL，當傳入此值時，代表該參數為空
	 */
	public static final String DUMMY_WITH_QUOTATION = "'DUMMY_STRING'";
	public static final String DUMMY_WITHOUT_QUOTATION = "DUMMY_STRING";

	// 參數的根目錄
	private String reportRootPath;

	// 以下為每個參數檔案，即每一個Crystal Report報表

	// B
	// RE201700500_B1.11新增報表 CU3178 2017/2/13 START
	/** B1.11匯款查詢(單位) */
	private String paymentQueryDetail;
	// RE201700500_B1.11新增報表 CU3178 2017/2/13 END

	/** B 2.1 費用申請單送件表 */
	private String expapplBReportName;

	/** B 2.1 費用申請單送件表 for 組織發展費(中分類810) */
	private String expapplBOrganizeDevelopeReportName;

	/** B2.5 辦公費送件日計表 */
	private String genDailyStmtOfficeReportName;

	/** B2.5 辦公費送件日計表(傳遞dto) */
	private String officeDailyStateByPassPojoReportName;

	/** B2.5 辦公費周轉金日計表 */
	private String genDailyStmtAdvpayReportName;

	/** B2.5 辦公費支票件日計表 */
	private String genDailyStmtAccountReportName;

	/** B2.5 列印退件表 */
	private String genDailyStmtRejectReportName;

	/** B2.5 名冊檢核報表 */
	private String rosterDetailCheckReportName;

	/** B3.1 獎金領取人名單 */
	private String bonusRosterReportName;

	/** B3.1 獎品領取人名單 */
	private String prizesRosterReportName;

	/** B4.1 周轉金明細表 */
	private String advpayDetailReportName;

	/** B4.1 檢核所得報表 */
	private String chkTaxReportName;

	/** B4.1 檢核二代健保報表 */
	/** @Chang No:RE201201260 [Start] **/
	private String chkHealthReportName;
	/** @Chang No:RE201201260 [End] **/

	/** B4.1 送匯核帳明細表 */
	private String remitChkDetailReportName;

	/** B4.1 日結單代傳票 */
	private String subpoenakReportName;

	/** B4.2 辦公費開票明細表 */
	private String chequeReportName;

	/** B4.2 審計辦公費匯款明細表 */
	private String remitReportName;

	/** B5.3 周轉金資料查詢 */
	private String turnOverDataReportName;

	// C
	/**
	 * C 1.2.4考試報名費維護
	 */
	private String registerRosterReport;
	/**
	 * C 1.3.2電話費用轉入維護
	 */
	private String phoneExpReportName;
	/**
	 * C 1.5.9輸入廠商費用核銷申請資料
	 */
	private String vendorExpReportName;
	/**
	 * C1.6.6調查費、業務稽查費用申請記錄表
	 */
	private String investExpApplReportName;
	/**
	 * C1.6.7 一般送件日計表
	 */
	private String deliverDaylistGenReportName;
	/**
	 * C1.6.7 廠商送件日計表
	 */
	private String deliverDaylistVenReportName;
	/**
	 * C1.6.7 旅費送件日計表
	 */
	private String deliverDaylistTrvlReportName;
	// RE201400552_新增國外出差匯款對象與匯款日期 modify by michael in 2014/03/11 start
	/**
	 * C1.6.7 旅費送件日計表(國外)
	 */
	private String deliverDaylistTrvlOvsaReportName;

	// RE201400552_新增國外出差匯款對象與匯款日期 modify by michael in 2014/03/11 end
	/**
	 * C1.6.8 旅費退件送件表
	 */
	private String returnDeliverDaylistTravelReportName;
	/**
	 * C1.6.8 廠商退件送件表
	 */
	private String returnDeliverDaylistVendorReportName;
	/**
	 * C1.6.8 一般退件送件表
	 */
	private String returnDeliverDaylistGeneralReportName;
	/**
	 * C1.6.10 出差報告表
	 */
	private String trvlExpApplSearchReportName;
	// RE201500189_國內出差申請作業流程簡化 EC0416 2015/04/07 start
	private String newTrvlExpApplSearchReportName;
	// RE201500189_國內出差申請作業流程簡化 EC0416 2015/04/07 end
	/**
	 * C3.3.1 旅費日計表
	 */
	private String daylistPrintTrvlReportName;
	/**
	 * C3.3.1 廠商日計表
	 */
	private String daylistPrintVenReportName;
	/**
	 * C3.3.1 一般日計表
	 */
	private String daylistPrintGenReportName;
	/**
	 * C3.3.1 醫檢日計表
	 */
	private String daylistPrintMedicalReportName;
	/**
	 * C3.3.1 退件表
	 */
	private String returnDailyStatementReportName;

	// RE201402595_汽機車切結管理檔案與費用勾稽作業 CU3178 2014/09/19 START
	/**
	 * C3.3.1 列印汽機車未切結報表
	 */
	private String dailyCaraffidavitReportName;
	// RE201402595_汽機車切結管理檔案與費用勾稽作業 CU3178 2014/09/19 END

	/**
	 * C4.1.1 檢核所得
	 */
	private String checkTaxReportName;

	/**
	 * C4.1.1 檢核二代健保
	 */
	/** @Chang No:RE201201260 [Start] **/
	private String checkHealthReportName;
	/** @Chang No:RE201201260 [End] **/

	/**
	 * 7.1.5 研修教材扣抵辦公費分攤檔案
	 */
	private String lrnCompensateOfficeExpFileGenReportName;

	/**
	 * C8.3.1 商務卡扣款帳戶明細表
	 */
	private String bizCardExpChargeDetailReportName;

	/**
	 * C10.6.3朱太太洗車明細維護
	 */
	private String mrsZhuWashCarDetailMaintainReportName;

	// RE201402595_汽機車切結管理檔案與費用勾稽作業 CU3178 2014/09/19 START
	/**
	 * C10.9.3 列印汽機車未切結報表
	 */
	private String caraffidavitReportName;
	// RE201402595_汽機車切結管理檔案與費用勾稽作業 CU3178 2014/09/19 END

	/**
	 * C11.1.1醫檢費核銷結果查詢
	 */
	private String medicalExpApproveResultQueryReportName;

	/**
	 * C11.1.2 醫檢費匯款明細表
	 */
	private String medicalExpRemitDetailReportName;

	/**
	 * C11.2.1研修差旅費用核銷查詢(研修部、人資部)
	 */
	private String trvlExpApproveQueryReportName;
	/**
	 * C11.2.3國內出差(研修)旅費申請總表
	 */
	private String bizTripReportName;
	
	//RE201702991_國外出差系統優化作業 EC0416 2017/11/13 start
	/**
	 * C11.2.4 國外出差(研修)旅費申請總表
	 */
	private String ovsaTripReportName;
	//RE201702991_國外出差系統優化作業 EC0416 2017/11/13 end
	
	/**
	 * C11.3.1 電話費費用排行表查詢
	 */
	private String phoneFeeRankingQueryReportName;

	/**
	 * C11.3.2電話費用表(表一)
	 */
	private String phoneFeeListReportName;

	/**
	 * C11.3.3電話使用人明細表
	 */
	private String phoneUserDetailReportName;

	// RE201403462_預算修改 CU3178 2014/10/24 START
	private String phone103yearDetailReportName;
	// RE201403462_預算修改 CU3178 2014/10/24 END

	/**
	 * C11.4.1 租賃合約到期查詢
	 */
	private String rentContractExpireReportName;

	/**
	 * C11.4.2 應繳租金查詢
	 */
	private String shouldPayRentQueryReportName;

	/**
	 * C11.5.1公務車投保明細表
	 */
	private String pubAffCarInsuranceReportName;

	/**
	 * C11.5.2公務車車籍資料查詢
	 */
	private String pubAffCarRegisterQueryReportName;

	/**
	 * C11.5.3公務車月底統計報表
	 */
	private String pubAffCarEndMonthStatisticsReportName;

	/**
	 * C11.5.4 須檢驗車輛查詢
	 */
	private String mustExamineCarQueryReportName;

	/**
	 * C11.5.5 車輛保險續保查詢
	 */
	private String carInsuranceRenewsQueryReportName;

	/**
	 * C11.5.6汽油費、修繕費排行榜
	 */
	private String fuelAndRepairExpRankingReportName;

	/**
	 * C11.5.7 公務車基本資料列印
	 */
	private String pubAffCarInfoReportName;

	/**
	 * C11.5.8公務車費用總表
	 */
	private String pubAffCarExpReportName;

	/**
	 * C11.5.9協理階公務車費用明細
	 */
	private String pubAffCarAssociateReportName;

	/**
	 * C11.5.10公務車費用明細查詢功能
	 */
	private String pubAffCarExpApplQueryReportName;

	/**
	 * C11.6.1權責調整費用明細表
	 */
	private String responsibilityAdjustExpListReportName;

	/**
	 * C11.6.2廠商費用明細表
	 */
	private String vendorExpDetailReportName;

	/**
	 * C11.6.4廠商請款排行表
	 * <p>
	 * C110604_VendorInvitesFundsRanking_All.rpt
	 */
	private String vendorInvitesFundsRankingAllReportName;

	/**
	 * C11.6.4廠商請款排行表
	 * <p>
	 * C110604_VendorInvitesFundsRanking_PART.rpt
	 */
	private String vendorInvitesFundsRankingPartReportName;

	/**
	 * C11.6.5付款累積檔查詢
	 */
	private String paymentAccumulateQueryReportName;

	/**
	 * C 11.6.6 應付費用明細表
	 */
	private String accruedExpensesDetailReportName;

	/**
	 * C11.6.7每月25日支付廠商費用明細表(開票件)
	 */
	private String vendorExpBankDepositOfTicketListReportName;

	/**
	 * C11.6.8每月25日支付廠商費用明細表(匯款件)
	 */
	private String vendorExpBankDepositOfRemitListReportName;

	/**
	 * C11.6.9廠商合約列印
	 */
	private String vendorContractPrintReportName;

	/**
	 * C11.6.10印刷品查詢
	 */
	private String vendorExpPrintedMatterReportName;

	/**
	 * C11.6.11廠商經辦請款明細表
	 */
	private String vendorInvoiceReportName;

	/**
	 * C11.7.1 匯回款項明細表列印_匯款
	 */
	private String remitMoneyReportName;

	/**
	 * C11.7.1 匯回款項明細表列印_支票
	 */
	private String remitMoneyReportNameCheck;

	/**
	 * C11.7.3 日結單代傳票
	 */
	private String subpoenaBReportName;

	private String subpoenaDReportName;

	/**
	 * C11.7.7 預算實支查詢
	 */
	private String budgetActualExpReportName;

	/**
	 * UC11.7.8 超支明細表
	 */

	// RE201403338_配合預算實支控管103年規定 CU3178 2014/10/12 START
	/**
	 * UC11.7.11 103年預算狀況實支表
	 */
	private String budget103yearRemainAmtReportName;
	// RE201403338_配合預算實支控管103年規定 CU3178 2014/10/12 END

	// RE201403176_C11項下載新增預算實支查詢 EC0416 2015/03/05 start
	private String budgetExpExecuteReportName;
	private String subbudgetExpExecuteReportName;
	private String budgetExpReportName;
	private String mealSocialBudgetReportName;
	// RE201403176_C11項下載新增預算實支查詢 EC0416 2015/03/05 end

	// RE201504772_年度組織控管 CU3178 2016/2/25 START
	private String yearBudgetExpExecuteReportName;
	private String yearSubbudgetExpExecuteReportName;
	private String yearBudgetExpReportName;
	private String yearMealSocialBudgetReportName;
	// RE201504772_年度組織控管 CU3178 2016/2/25 END

	// RE201404290_系統寄發預算實支表&線上填寫實支異常說明 EC0416 2015/8/20 start
	private String budExpOverrunReportName;
	private String subbudExpOverrunReportName;

	private String mailLogReportName;
	// RE201404290_系統寄發預算實支表&線上填寫實支異常說明 EC0416 2015/8/20 end

	// RE201701547_費用系統預算優化第二階段 EC0416 2017/4/7 start
	private String lecturerFeesReportName;
	private String LecturerFeesYearDepReportName;
	private String deferredAmortizationReportName;
	private String deferredAmortizationYearDepReportName;
	private String prepaidAmortizationReportName;
	private String prepaidAmortizationYearDepReportName;
	// RE201701547_費用系統預算優化第二階段 EC0416 2017/4/7 end
	
	//RE201701039 國外出差系統優化作業第二階段 EC0416 201706016 start
	private String trvlExpApplSearchOvsaReportName;
	private String trvlExpApplSearchOvsaSubReportName;
	private String ovsaDailyWorkReportName;
	//RE201701039 國外出差系統優化作業第二階段 EC0416 201706016 end

	/**
	 * UC11.7.12 國外出差匯款功能查詢
	 */
	// RE201500189_國內出差申請作業流程簡化 EC0416 2015/04/07 START
	private String ovsaTrvlRemitQueryReportName;
	// RE201500189_國內出差申請作業流程簡化 EC0416 2015/04/07 end
	
	//RE201702775_預算實支追蹤表單_費用系統  ec0416 2017/9/29 start
	private String budExpOverrunDetailReportName;
	private String budExpOverrunDetailTotalReportName;
	//RE201702775_預算實支追蹤表單_費用系統  ec0416 2017/9/29  end
	
	private String overBudgetDetailReportName;
	// D
	private String glDeliverListReportName;
	/** D1.1 攤銷預付費用列印傳票 */
	private String amortizationPrepaidExpSubpoenaReportName;
	/** D1.1 攤銷預付費用列印報表 */
	private String amortizationPrepaidExpReportName;
	/** D1.2 查詢預付費用攤銷明細報表 */
	private String queryPrepaidExpReportName;
	/** D2.1 遞延資產明細報表 */
	private String deferredExpReportName;
	/** D4.3 部門提列應付費用列印明細表 */
	private String depAccexpReportName;

	// RE201602231_廠商應付費用提列 CU3178 2016/9/7 START
	/** D4.7 廠商應付未付合約明細表 */
	private String vendorContractDetailReportName;
	/** D4.8 廠商應付未付明細表 */
	private String closeMonthTurnAccruedReportName;
	/** D04.09 查詢廠商應付費用明細 */
	private String vendorMonthDetailReportName;
	// RE201602231_廠商應付費用提列 CU3178 2016/9/7 END

	/** D7.5 沖轉部門提列應付費用 */
	private String changeAccruedExpApplDeliverListReportName;
	/** D9.1.1 總費用明細表 */
	private String generalExpReportName;
	/** D9.1.2 業務費用明細表 */
	private String businessExpReportName;
	/** D9.1.3 三階展業費用明細表 */
	private String stratum3ExpandBizReportName;
	/** D9.1.4 二階展業費用明細表 */
	private String stratum2ExpandBizReportName;
	/** D9.1.5 外務企劃部展業費用明細表 */
	private String externalBizPlanningReportName;
	/** D9.1.6 交叉行銷展業費用明細表 */
	private String crossMarketingReportName;
	/** D9.1.7 通路展業費用明細表 */
	private String channelExpandBizReportName;
	/** D9.1.8 團險展業費用明細表 */
	private String groupInsuranceExpandReportName;
	/** D9.1.9 外務人事部展業費用明細表 */
	private String externalBizPersonnelReportName;
	/** D9.1.10 機場展業費用明細表 */
	private String airportExpandBizReportName;
	/** D9.1.11 PRO展業費用明細表 */
	private String proExpandBizReportName;
	/** D9.1.12 國際聯保展業費用明細表 */
	private String internationalExpandBizReportName;
	/** D9.1.13業務分攤展業費用明細表 */
	private String externalBizPersonnel2ReportName;
	/** D9.1.14 新契約費用明細表 */
	private String newContractExpReportName;
	/** D9.1.15 收金費用明細表 */
	private String incomeExpReportName;
	/** D9.1.16 總務部費用明細表 */
	private String generalAffairsReportName;
	/** D9.1.17研修部展費用明細表 */
	private String trainingExpReportName;
	/** D9.1.18年度總費用明細表 */
	private String annualGeneralExpReportName;
	/** D9.1.19年度業務費用明細表 */
	private String annualBizExpReportName;
	/** D9.1.20訓練費總明細報表 */
	private String trainingExpDetailReportName;
	// RE201502770_費用系統新增OIU帳冊 CU3178 2015/8/11 START
	/** D9.1.21市場行銷部展業明細表 */
	private String marketSalesExpReportName;
	/** D9.1.22國際保險業務分公司明細表 */
	private String oIUExpReportName;
	// RE201502770_費用系統新增OIU帳冊 CU3178 2015/8/11 END
	/** D9.2.1 預算執行明細表 */
	private String budgetExecuteReportName;
	/** D9.2.2 本部預算執行報告表 */
	private String hqBudgeExecuteReportReportName;
	/** D9.2.3 預算執行總明細表 */
	private String budgetExecuteGeneralDetailReportName;
	/** D9.2.4 經策會報表 */
	private String economyInstituteReportName;
	/** D9.2.5 總管理處預算執行明細表 */
	private String generalBudgeExecuteReportName;
	/** D9.2.6 經策會預算執行總明細表 */
	private String economyInstituteBudgeExecuteReportName;
	/** D9.4 應付費用每日明細核帳 */
	private String accexpDailyDetailReportName;
	/** D9.4 應付費用每日明細核帳-無輸入會計科目查詢 */
	private String accexpDailyDetailNoAcctReportName;
	/** D9.5 費用明細分類帳 */
	private String expDetailReportName;
	/** D9.5 費用明細分類帳(沒有輸入成本單位代號的報表) */
	private String expDetailWithoutCostUnitCodeReportName;
	/** D9.6 應付費用明細分類帳 */
	private String accexpDetailAssortReportName;
	/** D9.7 營業費用明細表 */
	private String bizExpDetailReportName;
	/** D9.8 單位每萬換算報表 */
	private String unitPerMillionReportName;
	/** D9.10 部室計程車資明細表 */
	private String departmentTaxiExpReportName;
	/** D9.11 員工計程車資明細表 */
	private String employeeTaxiExpReportName;
	/** D9.12 餐費重複申請查核表 */
	private String repastExpRedundancyApplyReportName;
	/** D9.14 各類所得明細表 */
	private String allTaxDetailReportName;
	/** D9.16 專案、獎勵查詢 */
	private String projectEncouragementQueryReportName;
	/** D9.17 資本支出、非資本支出查詢 */
	private String capitalNonCapitalQueryReportName;
	/** D9.18 資本支出表 */
	private String capitalDefrayReportName;
	/** D9.19 非資本支出表 */
	private String nonCapitalDefrayReportName;
	/** D9.20 關係人交易明細表 */
	private String relationTradeDetailReportName;
	/** D9.21 修繕查詢 */
	private String fixUpQueryReportName;
	/** D9.22 各大樓費用明細表 */
	private String buildingExpDetailReportName;
	/** D9.24 講師費報表 */
	private String lecturerExpReportName;
	/** D9.27 業務單位KPI統計表 */
	private String bizUnitKPIStatisticReportName;
	/** D9.28 費用明細帳 */
	private String queryVoucherReport;

	/* RE201201260_二代健保 cm9539 2013/02/01 start */
	/** C11.7.9 列印扣繳健保補充保費 */
	private String printSupHealPremiumReportName;
	/* RE201201260_二代健保 cm9539 2013/02/01 end */
	/* RE201201260_二代健保 cm9539 2013/03/26 start */
	/** B7.19 匯出健保補充保費明細申報檔 */
	private String monthlyHealthPremiumReportName;
	/* RE201201260_二代健保 cm9539 2013/03/26 end */
	/* RE201201260_列印補充保費扣費證明 2013/10/28 start */
	/** B7.20 列印補充保費證明 */
	private String printHealPremiumIncomeReportName;
	/* RE201201260_列印補充保費扣費證明 2013/10/28 end */
	/* RE201301890_年底併薪報表列印 2013/10/30 start */
	/** D10.4業推發組發年度未核銷併薪 */
	private String printMergeSalary;
	/* RE201301890_年底併薪報表列印 2013/10/30 end */

	// RE201401133_修改員工訓練費 CU3178 2014/4/22 START
	/** D10.2結轉員工訓練費 */
	private String printTuitionFeeSummary;

	// RE201401133_修改員工訓練費 CU3178 2014/4/22 END
	
	//RE2017 辦公費核定表提列應付費用 CU3178 2017/11/8 START
	/** D10.06 核定表應付費用明細表 */
	private String yyclsDetail;
	//RE2017 辦公費核定表提列應付費用 CU3178 2017/11/8 END

	// RE201603570_預算暨費用系統_共用功能與模組整合 CU3178 2016/10/14 START
	/** E3.1人預算審查-總公司 */
	private String auditBudgetForHeadquarter;

	/** E03.02預算審查-服務中心、營業部室本部、營業部室外埠二階、營業部室外埠三階 */
	private String auditBudgetForServiceCenter;

	/** E03.03預算審查-經管會 */
	private String auditBudgetForAdministration;

	/** E4.1人力配置暨辦公費 */
	private String humanAllocationAndOfficeFee;

	/** E4.2工作目標與費用預算計劃表 */
	private String workTargetAndExpenseReport;

	/** E4.3 專案計畫預算報告書 */
	private String projectPlanBudgetReport;

	/** E4.4 資本支出計劃表 */
	private String capitalExpenditurePlanReport;

	/** E4.5 預算審查彙總報表 */
	private String auditBudgetCollectReport;

	/** E4.5 預算審查彙總報表 */
	private String summaryReport;

	/** E4.6 經管會預算表 */
	private String administrationReport;

	/** E4.7 月預算報表 */
	private String monthBudgetReport;

	/** E4.8 事業費用報表 */
	private String operatingDataReport;

	/** E4.9 事業費用分析差異表 */
	private String OperatingDiffDataReport;

	// RE201603570_預算暨費用系統_共用功能與模組整合 CU3178 2016/10/14 END

	// RE201700820_事業費用預算報表新增 CU3178 2017/4/17 START
	/** E04.10 事業費用預算項目屬性報表 */
	private String operatingBudgetItemReport;

	/** E4.11事業費用預算項目屬性年度差異分析報表 */
	private String operatingDifferBudgetItemReport;

	/** E4.12事業費用預算類別報表 */
	private String operatingBudgetTypeReport;

	/** E4.13事業費用預算類別年度差異分析報表 */
	private String operatingDifferBudgetTypeReport;

	/** E4.14事業費用預算部室屬性類別報表 */
	private String operatingDepPropReport;
	
	//RE201702476_事業費用預算實支報表 CU3178 2017/8/23 START
	/** E4.14事業費用預算部室屬性類別報表 -實支報表Pojo*/
	private String operatingDepPropReportPojo;
	//RE201702476_事業費用預算實支報表 CU3178 2017/8/23 END

	/** E4.15事業費用預算部室屬性類別年度差異分析報表 */
	private String operatingDifferDepPropReport;

	// RE201700820_事業費用預算報表新增 CU3178 2017/4/17 END

	public String getReportRootPath() {
		return reportRootPath;
	}

	public void setReportRootPath(String reportRootPath) {
		this.reportRootPath = reportRootPath;
	}

	/**
	 * 產生報表
	 * <p>
	 * 檢查rptName變數不可為空值
	 * 
	 * @param params
	 */
	public static void generateReport(Map<String, Object> params) {
		ExternalContext extCtx = FacesContext.getCurrentInstance().getExternalContext();
		HttpSession mySession = (HttpSession) extCtx.getSession(true);
		if (null == params || params.size() <= 0) {
			throw new ExpRuntimeException(ErrorCode.A30001);
		}
		// 檢查rptName變數不可為空值
		if (null == params.get("rptName") || StringUtils.isBlank((String) params.get("rptName"))) {
			throw new ExpRuntimeException(ErrorCode.A10007, new String[] { "rptName" });
		}
		mySession.setAttribute("params", params);
		// 清掉報表暫存。
		FacesUtils.getHttpSession().setAttribute("Report1", null);

	}

	/**
	 * 取得Session內的managedBean
	 * 
	 * @return
	 */
	public static CrystalReportConfigManagedBean getManagedBean() {
		return (CrystalReportConfigManagedBean) FacesUtils.getManagedBean("crystalReportConfigManagedBean");
	}

	// RE201700500_B1.11新增報表 CU3178 2017/2/13 START
	/**
	 * B1.11匯款查詢(單位)
	 * 
	 * @return
	 */
	public String getPaymentQueryDetail() {
		return paymentQueryDetail;
	}

	public void setPaymentQueryDetail(String paymentQueryDetail) {
		this.paymentQueryDetail = paymentQueryDetail;
	}

	// RE201700500_B1.11新增報表 CU3178 2017/2/13 END

	/**
	 * B 2.1 費用申請單送件表
	 * 
	 * @return
	 */
	public String getExpapplBReportName() {
		return this.expapplBReportName;
	}

	/**
	 * B 2.1 費用申請單送件表
	 * 
	 * @param expapplBReportName
	 */
	public void setExpapplBReportName(String expapplBReportName) {
		this.expapplBReportName = this.getReportRootPath() + expapplBReportName;
	}

	/**
	 * B5.3 周轉金資料查詢
	 * 
	 * @return
	 */
	public String getTurnOverDataReportName() {
		return turnOverDataReportName;
	}

	public void setTurnOverDataReportName(String turnOverDataReportName) {
		this.turnOverDataReportName = this.getReportRootPath() + turnOverDataReportName;
	}

	/**
	 * C1.6.7 一般送件日計表
	 */
	public String getDeliverDaylistGenReportName() {
		return deliverDaylistGenReportName;
	}

	/**
	 * C1.6.7 一般送件日計表
	 */
	public void setDeliverDaylistGenReportName(String deliverDaylistGenReportName) {
		this.deliverDaylistGenReportName = this.getReportRootPath() + deliverDaylistGenReportName;
	}

	/**
	 * C1.6.7 廠商送件日計表
	 */
	public String getDeliverDaylistVenReportName() {
		return deliverDaylistVenReportName;
	}

	/**
	 * C1.6.7 廠商送件日計表
	 */
	public void setDeliverDaylistVenReportName(String deliverDaylistVenReportName) {
		this.deliverDaylistVenReportName = this.getReportRootPath() + deliverDaylistVenReportName;
	}

	/**
	 * C1.6.7 旅費送件日計表
	 */
	public String getDeliverDaylistTrvlReportName() {
		return deliverDaylistTrvlReportName;
	}

	/**
	 * C1.6.7 旅費送件日計表
	 */
	public void setDeliverDaylistTrvlReportName(String deliverDaylistTrvlReportName) {
		this.deliverDaylistTrvlReportName = this.getReportRootPath() + deliverDaylistTrvlReportName;
	}

	/**
	 * B2.5 辦公費送件日計表
	 * 
	 * @return
	 */
	public String getGenDailyStmtOfficeReportName() {
		return genDailyStmtOfficeReportName;
	}

	public void setGenDailyStmtOfficeReportName(String genDailyStmtOfficeReportName) {
		this.genDailyStmtOfficeReportName = this.getReportRootPath() + genDailyStmtOfficeReportName;
	}

	/**
	 * B2.5 辦公費周轉金日計表
	 * 
	 * @return
	 */
	public String getGenDailyStmtAdvpayReportName() {
		return genDailyStmtAdvpayReportName;
	}

	public void setGenDailyStmtAdvpayReportName(String genDailyStmtAdvpayReportName) {
		this.genDailyStmtAdvpayReportName = this.getReportRootPath() + genDailyStmtAdvpayReportName;
	}

	/**
	 * B2.5 辦公費支票件日計表
	 * 
	 * @return
	 */
	public String getGenDailyStmtAccountReportName() {
		return genDailyStmtAccountReportName;
	}

	public void setGenDailyStmtAccountReportName(String genDailyStmtAccountReportName) {
		this.genDailyStmtAccountReportName = this.getReportRootPath() + genDailyStmtAccountReportName;
	}

	/**
	 * B2.5 列印退件表
	 * 
	 * @return
	 */
	public String getGenDailyStmtRejectReportName() {
		return genDailyStmtRejectReportName;
	}

	public void setGenDailyStmtRejectReportName(String genDailyStmtRejectReportName) {
		this.genDailyStmtRejectReportName = this.getReportRootPath() + genDailyStmtRejectReportName;
	}

	/**
	 * C3.3.1 旅費日計表
	 * 
	 * @return
	 */
	public String getDaylistPrintTrvlReportName() {
		return daylistPrintTrvlReportName;
	}

	public void setDaylistPrintTrvlReportName(String daylistPrintTrvlReportName) {
		this.daylistPrintTrvlReportName = this.getReportRootPath() + daylistPrintTrvlReportName;
	}

	/**
	 * C3.3.1 廠商日計表
	 * 
	 * @return
	 */
	public String getDaylistPrintVenReportName() {
		return daylistPrintVenReportName;
	}

	public void setDaylistPrintVenReportName(String daylistPrintVenReportName) {
		this.daylistPrintVenReportName = this.getReportRootPath() + daylistPrintVenReportName;
	}

	/**
	 * C3.3.1 一般日計表
	 * 
	 * @return
	 */
	public String getDaylistPrintGenReportName() {
		return daylistPrintGenReportName;
	}

	public void setDaylistPrintGenReportName(String daylistPrintGenReportName) {
		this.daylistPrintGenReportName = this.getReportRootPath() + daylistPrintGenReportName;
	}

	/**
	 * C11.7.3 日結單代傳票
	 * 
	 * @return
	 */
	public void setSubpoenaBReportName(String subpoenaBReportName) {
		this.subpoenaBReportName = this.getReportRootPath() + subpoenaBReportName;
	}

	public String getSubpoenaBReportName() {
		return subpoenaBReportName;
	}

	/**
	 * UC11.7.7 預算實支查詢
	 * 
	 * @return
	 */
	public String getBudgetActualExpReportName() {
		return budgetActualExpReportName;
	}

	public void setBudgetActualExpReportName(String budgetActualExpReportName) {
		this.budgetActualExpReportName = this.getReportRootPath() + budgetActualExpReportName;
	}

	public String getOverBudgetDetailReportName() {
		return overBudgetDetailReportName;
	}

	public void setOverBudgetDetailReportName(String overBudgetDetailReportName) {
		this.overBudgetDetailReportName = this.getReportRootPath() + overBudgetDetailReportName;
	}

	public void setSubpoenaDReportName(String subpoenaDReportName) {
		this.subpoenaDReportName = this.getReportRootPath() + subpoenaDReportName;
	}

	public String getSubpoenaDReportName() {
		return subpoenaDReportName;
	}

	/**
	 * C3.3.1 退件表
	 * 
	 * @return
	 */
	public String getReturnDailyStatementReportName() {
		return returnDailyStatementReportName;
	}

	public void setReturnDailyStatementReportName(String returnDailyStatementReportName) {
		this.returnDailyStatementReportName = this.getReportRootPath() + returnDailyStatementReportName;
	}

	/**
	 * C1.6.8 旅費退件送件表
	 * 
	 * @return
	 */
	public String getReturnDeliverDaylistTravelReportName() {
		return returnDeliverDaylistTravelReportName;
	}

	public void setReturnDeliverDaylistTravelReportName(String returnDeliverDaylistTravelReportName) {
		this.returnDeliverDaylistTravelReportName = this.getReportRootPath() + returnDeliverDaylistTravelReportName;
	}

	/**
	 * C1.6.8 廠商退件送件表
	 * 
	 * @return
	 */
	public String getReturnDeliverDaylistVendorReportName() {
		return returnDeliverDaylistVendorReportName;
	}

	public void setReturnDeliverDaylistVendorReportName(String returnDeliverDaylistVendorReportName) {
		this.returnDeliverDaylistVendorReportName = this.getReportRootPath() + returnDeliverDaylistVendorReportName;
	}

	/**
	 * C1.6.8 一般退件送件表
	 * 
	 * @return
	 */
	public String getReturnDeliverDaylistGeneralReportName() {
		return returnDeliverDaylistGeneralReportName;
	}

	public void setReturnDeliverDaylistGeneralReportName(String returnDeliverDaylistGeneralReportName) {
		this.returnDeliverDaylistGeneralReportName = this.getReportRootPath() + returnDeliverDaylistGeneralReportName;
	}

	public String getGlDeliverListReportName() {
		return glDeliverListReportName;
	}

	public void setGlDeliverListReportName(String glDeliverListReportName) {
		this.glDeliverListReportName = this.getReportRootPath() + glDeliverListReportName;
	}

	/**
	 * D1.1 攤銷預付費用列印傳票
	 * 
	 * @return
	 */
	public String getAmortizationPrepaidExpSubpoenaReportName() {
		return amortizationPrepaidExpSubpoenaReportName;
	}

	public void setAmortizationPrepaidExpSubpoenaReportName(String amortizationPrepaidExpSubpoenaReportName) {
		this.amortizationPrepaidExpSubpoenaReportName = this.getReportRootPath() + amortizationPrepaidExpSubpoenaReportName;
	}

	/**
	 * D1.1 攤銷預付費用列印報表
	 * 
	 * @return
	 */
	public String getAmortizationPrepaidExpReportName() {
		return amortizationPrepaidExpReportName;
	}

	public void setAmortizationPrepaidExpReportName(String amortizationPrepaidExpReportName) {
		this.amortizationPrepaidExpReportName = this.getReportRootPath() + amortizationPrepaidExpReportName;
	}

	/**
	 * D1.2 查詢預付費用攤銷明細報表
	 * 
	 * @return
	 */
	public String getQueryPrepaidExpReportName() {
		return queryPrepaidExpReportName;
	}

	public void setQueryPrepaidExpReportName(String queryPrepaidExpReportName) {
		this.queryPrepaidExpReportName = this.getReportRootPath() + queryPrepaidExpReportName;
	}

	public String getDeferredExpReportName() {
		return deferredExpReportName;
	}

	public void setDeferredExpReportName(String deferredExpReportName) {
		this.deferredExpReportName = this.getReportRootPath() + deferredExpReportName;
	}

	/**
	 * D9.5 費用明細分類帳
	 * 
	 * @return
	 */
	public String getExpDetailReportName() {
		return expDetailReportName;
	}

	/**
	 * D9.5 費用明細分類帳
	 * 
	 * @param expDetailReportName
	 */
	public void setExpDetailReportName(String expDetailReportName) {
		this.expDetailReportName = this.getReportRootPath() + expDetailReportName;
	}

	/**
	 * D9.5 費用明細分類帳(沒有輸入成本單位代號的報表)
	 * 
	 * @return
	 */
	public String getExpDetailWithoutCostUnitCodeReportName() {
		return expDetailWithoutCostUnitCodeReportName;
	}

	/**
	 * D9.5 費用明細分類帳(沒有輸入成本單位代號的報表)
	 * 
	 * @param expDetailReportNameWithoutCostUnitCode
	 */
	public void setExpDetailWithoutCostUnitCodeReportName(String expDetailWithoutCostUnitCodeReportName) {
		this.expDetailWithoutCostUnitCodeReportName = this.getReportRootPath() + expDetailWithoutCostUnitCodeReportName;
	}

	/**
	 * D9.14 各類所得明細表
	 * 
	 * @return
	 */
	public String getAllTaxDetailReportName() {
		return allTaxDetailReportName;
	}

	public void setAllTaxDetailReportName(String allTaxDetailReportName) {
		this.allTaxDetailReportName = this.getReportRootPath() + allTaxDetailReportName;
	}

	/**
	 * C3.3.1 醫檢日計表
	 * 
	 * @return
	 */
	public String getDaylistPrintMedicalReportName() {
		return daylistPrintMedicalReportName;
	}

	public void setDaylistPrintMedicalReportName(String daylistPrintMedicalReportName) {
		this.daylistPrintMedicalReportName = this.getReportRootPath() + daylistPrintMedicalReportName;
	}

	/**
	 * C 11.6.6 應付費用明細表
	 * 
	 * @return
	 */
	public String getAccruedExpensesDetailReportName() {
		return accruedExpensesDetailReportName;
	}

	/**
	 * @param
	 */
	public void setAccruedExpensesDetailReportName(String accruedExpensesDetailReportName) {
		this.accruedExpensesDetailReportName = this.getReportRootPath() + accruedExpensesDetailReportName;
	}

	/**
	 * C11.6.7每月25日支付廠商費用明細表(開票件)
	 * 
	 * @return
	 */
	public String getVendorExpBankDepositOfTicketListReportName() {
		return vendorExpBankDepositOfTicketListReportName;
	}

	public void setVendorExpBankDepositOfTicketListReportName(String vendorExpBankDepositOfTicketListReportName) {
		this.vendorExpBankDepositOfTicketListReportName = this.getReportRootPath() + vendorExpBankDepositOfTicketListReportName;
	}

	/**
	 * C11.6.8每月25日支付廠商費用明細表(匯款件)
	 * 
	 * @return
	 */
	public String getVendorExpBankDepositOfRemitListReportName() {
		return vendorExpBankDepositOfRemitListReportName;
	}

	public void setVendorExpBankDepositOfRemitListReportName(String vendorExpBankDepositOfRemitListReportName) {
		this.vendorExpBankDepositOfRemitListReportName = this.getReportRootPath() + vendorExpBankDepositOfRemitListReportName;
	}

	/**
	 * C11.6.9廠商合約列印
	 * 
	 * @return
	 */
	public String getVendorContractPrintReportName() {
		return vendorContractPrintReportName;
	}

	public void setVendorContractPrintReportName(String vendorContractPrintReportName) {
		this.vendorContractPrintReportName = this.getReportRootPath() + vendorContractPrintReportName;
	}

	/**
	 * C11.6.10印刷品查詢
	 * 
	 * @return
	 */
	public String getVendorExpPrintedMatterReportName() {
		return vendorExpPrintedMatterReportName;
	}

	public void setVendorExpPrintedMatterReportName(String vendorExpPrintedMatterReportName) {
		this.vendorExpPrintedMatterReportName = this.getReportRootPath() + vendorExpPrintedMatterReportName;
	}

	/**
	 * C1.6.6調查費、業務稽查費用申請記錄表
	 * 
	 * @return
	 */
	public String getInvestExpApplReportName() {
		return investExpApplReportName;
	}

	/**
	 * @param
	 */
	public void setInvestExpApplReportName(String investExpApplReportName) {
		this.investExpApplReportName = this.getReportRootPath() + investExpApplReportName;
	}

	/**
	 * C 1.5.9輸入廠商費用核銷申請資料
	 * 
	 * @return
	 */
	public String getVendorExpReportName() {
		return vendorExpReportName;
	}

	/**
	 * @param
	 */
	public void setVendorExpReportName(String vendorExpReportName) {
		this.vendorExpReportName = this.getReportRootPath() + vendorExpReportName;
	}

	/**
	 * B 2.5 辦公費送件日計表(傳遞dto)
	 * 
	 * @return
	 */
	public String getOfficeDailyStateByPassPojoReportName() {
		return officeDailyStateByPassPojoReportName;
	}

	public void setOfficeDailyStateByPassPojoReportName(String officeDailyStateByPassPojoReportName) {
		this.officeDailyStateByPassPojoReportName = this.getReportRootPath() + officeDailyStateByPassPojoReportName;
	}

	/**
	 * B 2.5 名冊檢核報表
	 * 
	 * @return
	 */
	public String getRosterDetailCheckReportName() {
		return rosterDetailCheckReportName;
	}

	public void setRosterDetailCheckReportName(String rosterDetailCheckReportName) {
		this.rosterDetailCheckReportName = this.getReportRootPath() + rosterDetailCheckReportName;
	}

	/**
	 * C11.7.1 匯回款項明細表列印_匯款
	 * 
	 * @return
	 */
	public String getRemitMoneyReportName() {
		return remitMoneyReportName;
	}

	public void setRemitMoneyReportName(String remitMoneyReportName) {
		this.remitMoneyReportName = this.getReportRootPath() + remitMoneyReportName;
	}

	/**
	 * C8.3.1 商務卡扣款帳戶明細表
	 * 
	 * @return
	 */
	public String getBizCardExpChargeDetailReportName() {
		return bizCardExpChargeDetailReportName;
	}

	public void setBizCardExpChargeDetailReportName(String bizCardExpChargeDetailReportName) {
		this.bizCardExpChargeDetailReportName = this.getReportRootPath() + bizCardExpChargeDetailReportName;
	}

	/**
	 * C10.6.3朱太太洗車明細維護
	 * 
	 * @return
	 */
	public String getMrsZhuWashCarDetailMaintainReportName() {
		return mrsZhuWashCarDetailMaintainReportName;
	}

	public void setMrsZhuWashCarDetailMaintainReportName(String mrsZhuWashCarDetailMaintainReportName) {
		this.mrsZhuWashCarDetailMaintainReportName = this.getReportRootPath() + mrsZhuWashCarDetailMaintainReportName;
	}

	/**
	 * C11.1.1醫檢費核銷結果查詢
	 * 
	 * @return
	 */
	public String getMedicalExpApproveResultQueryReportName() {
		return medicalExpApproveResultQueryReportName;
	}

	public void setMedicalExpApproveResultQueryReportName(String medicalExpApproveResultQueryReportName) {
		this.medicalExpApproveResultQueryReportName = this.getReportRootPath() + medicalExpApproveResultQueryReportName;
	}

	/**
	 * C11.1.2 醫檢費匯款明細表
	 * 
	 * @return
	 */
	public String getMedicalExpRemitDetailReportName() {
		return medicalExpRemitDetailReportName;
	}

	public void setMedicalExpRemitDetailReportName(String medicalExpRemitDetailReportName) {
		this.medicalExpRemitDetailReportName = this.getReportRootPath() + medicalExpRemitDetailReportName;
	}

	/**
	 * D4.3 部門提列應付費用列印明細表
	 * 
	 * @return
	 */
	public String getDepAccexpReportName() {
		return depAccexpReportName;
	}

	public void setDepAccexpReportName(String depAccexpReportName) {
		this.depAccexpReportName = this.getReportRootPath() + depAccexpReportName;
	}

	/**
	 * C11.2.1研修差旅費用核銷查詢(研修部、人資部)
	 * 
	 * @return
	 */
	public String getTrvlExpApproveQueryReportName() {
		return trvlExpApproveQueryReportName;
	}

	public void setTrvlExpApproveQueryReportName(String trvlExpApproveQueryReportName) {
		this.trvlExpApproveQueryReportName = this.getReportRootPath() + trvlExpApproveQueryReportName;
	}

	/**
	 * C11.3.2電話費用表(表一)
	 * 
	 * @return
	 */
	public String getPhoneFeeListReportName() {
		return phoneFeeListReportName;
	}

	public void setPhoneFeeListReportName(String phoneFeeListReportName) {
		this.phoneFeeListReportName = this.getReportRootPath() + phoneFeeListReportName;
	}

	/**
	 * C11.3.3電話使用人明細表
	 * 
	 * @return
	 */
	public String getPhoneUserDetailReportName() {
		return phoneUserDetailReportName;
	}

	public void setPhoneUserDetailReportName(String phoneUserDetailReportName) {
		this.phoneUserDetailReportName = this.getReportRootPath() + phoneUserDetailReportName;
	}

	// RE201403462_預算修改 CU3178 2014/10/24 START
	/**
	 * C11.3.4電話使用人明細表
	 * 
	 * @return
	 */
	public String getPhone103yearDetailReportName() {
		return phone103yearDetailReportName;
	}

	public void setPhone103yearDetailReportName(String phone103yearDetailReportName) {
		this.phone103yearDetailReportName = this.getReportRootPath() + phone103yearDetailReportName;
	}

	// RE201403462_預算修改 CU3178 2014/10/24 END

	/**
	 * C11.5.6汽油費、修繕費排行榜
	 * 
	 * @return
	 */
	public String getFuelAndRepairExpRankingReportName() {
		return fuelAndRepairExpRankingReportName;
	}

	public void setFuelAndRepairExpRankingReportName(String fuelAndRepairExpRankingReportName) {
		this.fuelAndRepairExpRankingReportName = this.getReportRootPath() + fuelAndRepairExpRankingReportName;
	}

	/**
	 * C11.5.8公務車費用總表
	 * 
	 * @return
	 */
	public String getPubAffCarExpReportName() {
		return pubAffCarExpReportName;
	}

	public void setPubAffCarExpReportName(String pubAffCarExpReportName) {
		this.pubAffCarExpReportName = this.getReportRootPath() + pubAffCarExpReportName;
	}

	/**
	 * C11.6.1權責調整費用明細表
	 * 
	 * @return
	 */
	public String getResponsibilityAdjustExpListReportName() {
		return responsibilityAdjustExpListReportName;
	}

	public void setResponsibilityAdjustExpListReportName(String responsibilityAdjustExpListReportName) {
		this.responsibilityAdjustExpListReportName = this.getReportRootPath() + responsibilityAdjustExpListReportName;
	}

	/**
	 * C11.6.2廠商費用明細表
	 * 
	 * @return
	 */
	public String getVendorExpDetailReportName() {
		return vendorExpDetailReportName;
	}

	public void setVendorExpDetailReportName(String vendorExpDetailReportName) {
		this.vendorExpDetailReportName = this.getReportRootPath() + vendorExpDetailReportName;
	}

	/**
	 * C11.6.4廠商請款排行表
	 * <p>
	 * C110604_VendorInvitesFundsRanking_All.rpt
	 * 
	 * @return
	 */
	public String getVendorInvitesFundsRankingAllReportName() {
		return vendorInvitesFundsRankingAllReportName;
	}

	public void setVendorInvitesFundsRankingAllReportName(String vendorInvitesFundsRankingAllReportName) {
		this.vendorInvitesFundsRankingAllReportName = this.getReportRootPath() + vendorInvitesFundsRankingAllReportName;
	}

	/**
	 * C11.6.4廠商請款排行表
	 * <p>
	 * C110604_VendorInvitesFundsRanking_PART.rpt
	 * 
	 * @return
	 */
	public String getVendorInvitesFundsRankingPartReportName() {
		return vendorInvitesFundsRankingPartReportName;
	}

	public void setVendorInvitesFundsRankingPartReportName(String vendorInvitesFundsRankingPartReportName) {
		this.vendorInvitesFundsRankingPartReportName = this.getReportRootPath() + vendorInvitesFundsRankingPartReportName;
	}

	/**
	 * C11.6.5付款累積檔查詢
	 * 
	 * @return
	 */
	public String getPaymentAccumulateQueryReportName() {
		return paymentAccumulateQueryReportName;
	}

	public void setPaymentAccumulateQueryReportName(String paymentAccumulateQueryReportName) {
		this.paymentAccumulateQueryReportName = this.getReportRootPath() + paymentAccumulateQueryReportName;
	}

	/**
	 * C11.7.1 匯回款項明細表列印_支票
	 * 
	 * @return
	 */
	public String getRemitMoneyReportNameCheck() {
		return remitMoneyReportNameCheck;
	}

	public void setRemitMoneyReportNameCheck(String remitMoneyReportNameCheck) {
		this.remitMoneyReportNameCheck = this.getReportRootPath() + remitMoneyReportNameCheck;
	}

	// RE201403338_配合預算實支控管103年規定 CU3178 2014/10/12 START
	/**
	 * C11.7.11 103年預算狀況實支表
	 * 
	 * @return
	 */
	public String getBudget103yearRemainAmtReportName() {
		return budget103yearRemainAmtReportName;
	}

	public void setBudget103yearRemainAmtReportName(String budget103yearRemainAmtReportName) {
		this.budget103yearRemainAmtReportName = this.getReportRootPath() + budget103yearRemainAmtReportName;
	}

	// RE201403338_配合預算實支控管103年規定 CU3178 2014/10/12 END

	/**
	 * D7.5 沖轉部門提列應付費用
	 * 
	 * @return
	 */
	public String getChangeAccruedExpApplDeliverListReportName() {
		return changeAccruedExpApplDeliverListReportName;
	}

	public void setChangeAccruedExpApplDeliverListReportName(String changeAccruedExpApplDeliverListReportName) {
		this.changeAccruedExpApplDeliverListReportName = this.getReportRootPath() + changeAccruedExpApplDeliverListReportName;
	}

	/**
	 * D9.1.10 機場展業費用明細表
	 * 
	 * return
	 */
	public String getAirportExpandBizReportName() {
		return airportExpandBizReportName;
	}

	public void setAirportExpandBizReportName(String airportExpandBizReportName) {
		this.airportExpandBizReportName = airportExpandBizReportName;
	}

	/**
	 * D 9.1.11 PRO展業費用明細表
	 * 
	 * @return
	 */
	public String getProExpandBizReportName() {
		return proExpandBizReportName;
	}

	public void setProExpandBizReportName(String proExpandBizReportName) {
		this.proExpandBizReportName = proExpandBizReportName;
	}

	/**
	 * D 9.1.12 國際聯保展業費用明細表
	 * 
	 * @return
	 */
	public String getInternationalExpandBizReportName() {
		return internationalExpandBizReportName;
	}

	public void setInternationalExpandBizReportName(String internationalExpandBizReportName) {
		this.internationalExpandBizReportName = internationalExpandBizReportName;
	}

	/**
	 * D9.1.13業務分攤展業費用明細表
	 * 
	 * @return
	 */
	public String getExternalBizPersonnel2ReportName() {
		return externalBizPersonnel2ReportName;
	}

	public void setExternalBizPersonnel2ReportName(String externalBizPersonnel2ReportName) {
		this.externalBizPersonnel2ReportName = this.getReportRootPath() + externalBizPersonnel2ReportName;
	}

	/**
	 * D 9.1.14 新契約費用明細表
	 * 
	 * @return
	 */
	public String getNewContractExpReportName() {
		return newContractExpReportName;
	}

	public void setNewContractExpReportName(String newContractExpReportName) {
		this.newContractExpReportName = newContractExpReportName;
	}

	/**
	 * D 9.1.15 收金費用明細表
	 * 
	 * @return
	 */
	public String getIncomeExpReportName() {
		return incomeExpReportName;
	}

	public void setIncomeExpReportName(String incomeExpReportName) {
		this.incomeExpReportName = incomeExpReportName;
	}

	/**
	 * D9.1.16 總務部費用明細表
	 * 
	 * @return
	 */
	public String getGeneralAffairsReportName() {
		return generalAffairsReportName;
	}

	public void setGeneralAffairsReportName(String generalAffairsReportName) {
		this.generalAffairsReportName = this.getReportRootPath() + generalAffairsReportName;
	}

	/**
	 * D9.1.17研修部展費用明細表
	 * 
	 * @return
	 */
	public String getTrainingExpReportName() {
		return trainingExpReportName;
	}

	public void setTrainingExpReportName(String trainingExpReportName) {
		this.trainingExpReportName = this.getReportRootPath() + trainingExpReportName;
	}

	/**
	 * D9.1.18年度總費用明細表
	 * 
	 * @return
	 */
	public String getAnnualGeneralExpReportName() {
		return annualGeneralExpReportName;
	}

	public void setAnnualGeneralExpReportName(String annualGeneralExpReportName) {
		this.annualGeneralExpReportName = this.getReportRootPath() + annualGeneralExpReportName;
	}

	/**
	 * D9.1.19年度業務費用明細表
	 * 
	 * @return
	 */
	public String getAnnualBizExpReportName() {
		return annualBizExpReportName;
	}

	public void setAnnualBizExpReportName(String annualBizExpReportName) {
		this.annualBizExpReportName = this.getReportRootPath() + annualBizExpReportName;
	}

	/**
	 * D9.1.20訓練費總明細報表
	 * 
	 * @return
	 */
	public String getTrainingExpDetailReportName() {
		return trainingExpDetailReportName;
	}

	public void setTrainingExpDetailReportName(String trainingExpDetailReportName) {
		this.trainingExpDetailReportName = this.getReportRootPath() + trainingExpDetailReportName;
	}

	// RE201502770_費用系統新增OIU帳冊 CU3178 2015/8/11 START
	/**
	 * D9.1.21市場行銷部展業明細表
	 * 
	 * @return
	 */
	public String getMarketSalesExpReportName() {
		return marketSalesExpReportName;
	}

	public void setMarketSalesExpReportName(String marketSalesExpReportName) {
		this.marketSalesExpReportName = marketSalesExpReportName;
	}

	/**
	 * D9.1.22國際保險業務分公司明細表
	 * 
	 * @return
	 */
	public String getoIUExpReportName() {
		return oIUExpReportName;
	}

	public void setoIUExpReportName(String oIUExpReportName) {
		this.oIUExpReportName = oIUExpReportName;
	}

	// RE201502770_費用系統新增OIU帳冊 CU3178 2015/8/11 END

	/**
	 * D 9.2.1 預算執行明細表
	 * 
	 * @return
	 */
	public String getBudgetExecuteReportName() {
		return budgetExecuteReportName;
	}

	public void setBudgetExecuteReportName(String budgetExecuteReportName) {
		this.budgetExecuteReportName = budgetExecuteReportName;
	}

	/**
	 * D 9.2.2 本部預算執行報告表
	 * 
	 * @return
	 */
	public String getHqBudgeExecuteReportReportName() {
		return hqBudgeExecuteReportReportName;
	}

	public void setHqBudgeExecuteReportReportName(String hqBudgeExecuteReportReportName) {
		this.hqBudgeExecuteReportReportName = hqBudgeExecuteReportReportName;
	}

	/**
	 * D 9.2.3 預算執行總明細表
	 * 
	 * @return
	 */
	public String getBudgetExecuteGeneralDetailReportName() {
		return budgetExecuteGeneralDetailReportName;
	}

	public void setBudgetExecuteGeneralDetailReportName(String budgetExecuteGeneralDetailReportName) {
		this.budgetExecuteGeneralDetailReportName = budgetExecuteGeneralDetailReportName;
	}

	/**
	 * D 9.2.4 經策會報表
	 * 
	 * @return
	 */
	public String getEconomyInstituteReportName() {
		return economyInstituteReportName;
	}

	public void setEconomyInstituteReportName(String economyInstituteReportName) {
		this.economyInstituteReportName = economyInstituteReportName;
	}

	/**
	 * D 9.2.5 總管理處預算執行明細表
	 * 
	 * @return
	 */
	public String getGeneralBudgeExecuteReportName() {
		return generalBudgeExecuteReportName;
	}

	public void setGeneralBudgeExecuteReportName(String generalBudgeExecuteReportName) {
		this.generalBudgeExecuteReportName = generalBudgeExecuteReportName;
	}

	/**
	 * D 9.2.6 經策會預算執行總明細表
	 * 
	 * @return
	 */
	public String getEconomyInstituteBudgeExecuteReportName() {
		return economyInstituteBudgeExecuteReportName;
	}

	public void setEconomyInstituteBudgeExecuteReportName(String economyInstituteBudgeExecuteReportName) {
		this.economyInstituteBudgeExecuteReportName = economyInstituteBudgeExecuteReportName;
	}

	/**
	 * D9.4 應付費用每日明細核帳
	 * 
	 * @return
	 */
	public String getAccexpDailyDetailReportName() {
		return accexpDailyDetailReportName;
	}

	public void setAccexpDailyDetailReportName(String accexpDailyDetailReportName) {
		this.accexpDailyDetailReportName = accexpDailyDetailReportName;
	}

	/**
	 * D9.4 應付費用每日明細核帳-無輸入會計科目查詢
	 * 
	 * @return
	 */
	public String getAccexpDailyDetailNoAcctReportName() {
		return accexpDailyDetailNoAcctReportName;
	}

	public void setAccexpDailyDetailNoAcctReportName(String accexpDailyDetailNoAcctReportName) {
		this.accexpDailyDetailNoAcctReportName = accexpDailyDetailNoAcctReportName;
	}

	/**
	 * D9.6 應付費用明細分類帳
	 * 
	 * @return
	 */
	public String getAccexpDetailAssortReportName() {
		return accexpDetailAssortReportName;
	}

	public void setAccexpDetailAssortReportName(String accexpDetailAssortReportName) {
		this.accexpDetailAssortReportName = accexpDetailAssortReportName;
	}

	/**
	 * D9.7 營業費用明細表
	 * 
	 * @return
	 */
	public String getBizExpDetailReportName() {
		return bizExpDetailReportName;
	}

	public void setBizExpDetailReportName(String bizExpDetailReportName) {
		this.bizExpDetailReportName = bizExpDetailReportName;
	}

	/**
	 * D9.8 單位每萬換算報表
	 * 
	 * @return
	 */
	public String getUnitPerMillionReportName() {
		return unitPerMillionReportName;
	}

	public void setUnitPerMillionReportName(String unitPerMillionReportName) {
		this.unitPerMillionReportName = unitPerMillionReportName;
	}

	/**
	 * D9.10 部室計程車資明細表
	 * 
	 * @return
	 */
	public String getDepartmentTaxiExpReportName() {
		return departmentTaxiExpReportName;
	}

	public void setDepartmentTaxiExpReportName(String departmentTaxiExpReportName) {
		this.departmentTaxiExpReportName = departmentTaxiExpReportName;
	}

	/**
	 * D9.11 員工計程車資明細表
	 * 
	 * @return
	 */
	public String getEmployeeTaxiExpReportName() {
		return employeeTaxiExpReportName;
	}

	public void setEmployeeTaxiExpReportName(String employeeTaxiExpReportName) {
		this.employeeTaxiExpReportName = employeeTaxiExpReportName;
	}

	/**
	 * D9.12 餐費重複申請查核表
	 * 
	 * @return
	 */
	public String getRepastExpRedundancyApplyReportName() {
		return repastExpRedundancyApplyReportName;
	}

	public void setRepastExpRedundancyApplyReportName(String repastExpRedundancyApplyReportName) {
		this.repastExpRedundancyApplyReportName = repastExpRedundancyApplyReportName;
	}

	/**
	 * C 1.3.2電話費用轉入維護
	 * 
	 * @return
	 */
	public String getPhoneExpReportName() {
		return phoneExpReportName;
	}

	public void setPhoneExpReportName(String phoneExpReportName) {
		this.phoneExpReportName = this.getReportRootPath() + phoneExpReportName;
	}

	/**
	 * C11.5.1公務車投保明細表
	 * 
	 * @return
	 */
	public String getPubAffCarInsuranceReportName() {
		return pubAffCarInsuranceReportName;
	}

	public void setPubAffCarInsuranceReportName(String pubAffCarInsuranceReportName) {
		this.pubAffCarInsuranceReportName = this.getReportRootPath() + pubAffCarInsuranceReportName;
	}

	/**
	 * C11.5.2公務車車籍資料查詢
	 * 
	 * @return
	 */
	public String getPubAffCarRegisterQueryReportName() {
		return pubAffCarRegisterQueryReportName;
	}

	public void setPubAffCarRegisterQueryReportName(String pubAffCarRegisterQueryReportName) {
		this.pubAffCarRegisterQueryReportName = this.getReportRootPath() + pubAffCarRegisterQueryReportName;
	}

	/**
	 * C11.5.3公務車月底統計報表
	 * 
	 * @return
	 */
	public String getPubAffCarEndMonthStatisticsReportName() {
		return pubAffCarEndMonthStatisticsReportName;
	}

	public void setPubAffCarEndMonthStatisticsReportName(String pubAffCarEndMonthStatisticsReportName) {
		this.pubAffCarEndMonthStatisticsReportName = this.getReportRootPath() + pubAffCarEndMonthStatisticsReportName;
	}

	/**
	 * C11.5.9 協理階公務車費用明細
	 * 
	 * @return
	 */
	public String getPubAffCarAssociateReportName() {
		return pubAffCarAssociateReportName;
	}

	public void setPubAffCarAssociateReportName(String pubAffCarAssociateReportName) {
		this.pubAffCarAssociateReportName = this.getReportRootPath() + pubAffCarAssociateReportName;
	}

	/**
	 * C11.5.4 須檢驗車輛查詢
	 * 
	 * @return
	 */
	public String getMustExamineCarQueryReportName() {
		return mustExamineCarQueryReportName;
	}

	public void setMustExamineCarQueryReportName(String mustExamineCarQueryReportName) {
		this.mustExamineCarQueryReportName = this.getReportRootPath() + mustExamineCarQueryReportName;
	}

	/**
	 * C11.5.5 車輛保險續保查詢
	 * 
	 * @return
	 */
	public String getCarInsuranceRenewsQueryReportName() {
		return carInsuranceRenewsQueryReportName;
	}

	public void setCarInsuranceRenewsQueryReportName(String carInsuranceRenewsQueryReportName) {
		this.carInsuranceRenewsQueryReportName = this.getReportRootPath() + carInsuranceRenewsQueryReportName;
	}

	/**
	 * 7.1.5 研修教材扣抵辦公費分攤檔案
	 * 
	 * @return
	 */
	public String getLrnCompensateOfficeExpFileGenReportName() {
		return lrnCompensateOfficeExpFileGenReportName;
	}

	public void setLrnCompensateOfficeExpFileGenReportName(String lrnCompensateOfficeExpFileGenReportName) {
		this.lrnCompensateOfficeExpFileGenReportName = this.getReportRootPath() + lrnCompensateOfficeExpFileGenReportName;
	}

	public void setBonusRosterReportName(String bonusRosterReportName) {
		this.bonusRosterReportName = bonusRosterReportName;
	}

	public String getBonusRosterReportName() {
		return bonusRosterReportName;
	}

	public void setPrizesRosterReportName(String prizesRosterReportName) {
		this.prizesRosterReportName = prizesRosterReportName;
	}

	public String getPrizesRosterReportName() {
		return prizesRosterReportName;
	}

	public void setAdvpayDetailReportName(String advpayDetailReportName) {
		this.advpayDetailReportName = advpayDetailReportName;
	}

	public String getAdvpayDetailReportName() {
		return advpayDetailReportName;
	}

	public void setChkTaxReportName(String chkTaxReportName) {
		this.chkTaxReportName = chkTaxReportName;
	}

	/** @Chang No:RE201201260 [Start] **/
	public void setChkHealthReportName(String chkHealthReportName) {
		this.chkHealthReportName = chkHealthReportName;
	}

	/** @Chang No:RE201201260 [End] **/

	public String getChkTaxReportName() {
		return chkTaxReportName;
	}

	/** @Chang No:RE201201260 [Start] **/
	public String getChkHealthReportName() {
		return chkHealthReportName;
	}

	/** @Chang No:RE201201260 [End] **/

	public void setRemitChkDetailReportName(String remitChkDetailReportName) {
		this.remitChkDetailReportName = remitChkDetailReportName;
	}

	public String getRemitChkDetailReportName() {
		return remitChkDetailReportName;
	}

	public void setSubpoenakReportName(String subpoenakReportName) {
		this.subpoenakReportName = subpoenakReportName;
	}

	public String getSubpoenakReportName() {
		return subpoenakReportName;
	}

	public void setChequeReportName(String chequeReportName) {
		this.chequeReportName = chequeReportName;
	}

	public String getChequeReportName() {
		return chequeReportName;
	}

	public void setRemitReportName(String remitReportName) {
		this.remitReportName = remitReportName;
	}

	public String getRemitReportName() {
		return remitReportName;
	}

	/**
	 * C11.5.7 公務車基本資料列印
	 * 
	 * @return
	 */
	public String getPubAffCarInfoReportName() {
		return pubAffCarInfoReportName;
	}

	public void setPubAffCarInfoReportName(String pubAffCarInfoReportName) {
		this.pubAffCarInfoReportName = this.getReportRootPath() + pubAffCarInfoReportName;
	}

	public void setGeneralExpReportName(String generalExpReportName) {
		this.generalExpReportName = generalExpReportName;
	}

	public String getGeneralExpReportName() {
		return generalExpReportName;
	}

	public void setBusinessExpReportName(String businessExpReportName) {
		this.businessExpReportName = businessExpReportName;
	}

	public String getBusinessExpReportName() {
		return businessExpReportName;
	}

	public void setChannelExpandBizReportName(String channelExpandBizReportName) {
		this.channelExpandBizReportName = channelExpandBizReportName;
	}

	public String getChannelExpandBizReportName() {
		return channelExpandBizReportName;
	}

	public void setCrossMarketingReportName(String crossMarketingReportName) {
		this.crossMarketingReportName = crossMarketingReportName;
	}

	public String getCrossMarketingReportName() {
		return crossMarketingReportName;
	}

	public void setExternalBizPersonnelReportName(String externalBizPersonnelReportName) {
		this.externalBizPersonnelReportName = externalBizPersonnelReportName;
	}

	public String getExternalBizPersonnelReportName() {
		return externalBizPersonnelReportName;
	}

	public void setExternalBizPlanningReportName(String externalBizPlanningReportName) {
		this.externalBizPlanningReportName = externalBizPlanningReportName;
	}

	public String getExternalBizPlanningReportName() {
		return externalBizPlanningReportName;
	}

	public void setGroupInsuranceExpandReportName(String groupInsuranceExpandReportName) {
		this.groupInsuranceExpandReportName = groupInsuranceExpandReportName;
	}

	/**
	 * C11.4.1 租賃合約到期查詢
	 * 
	 * @return
	 */
	public String getRentContractExpireReportName() {
		return rentContractExpireReportName;
	}

	public void setRentContractExpireReportName(String rentContractExpireReportName) {
		this.rentContractExpireReportName = this.getReportRootPath() + rentContractExpireReportName;
	}

	public String getGroupInsuranceExpandReportName() {
		return groupInsuranceExpandReportName;
	}

	public void setStratum2ExpandBizReportName(String stratum2ExpandBizReportName) {
		this.stratum2ExpandBizReportName = stratum2ExpandBizReportName;
	}

	public String getStratum2ExpandBizReportName() {
		return stratum2ExpandBizReportName;
	}

	public void setStratum3ExpandBizReportName(String stratum3ExpandBizReportName) {
		this.stratum3ExpandBizReportName = stratum3ExpandBizReportName;
	}

	public String getStratum3ExpandBizReportName() {
		return stratum3ExpandBizReportName;
	}

	/**
	 * C11.3.1 電話費費用排行表查詢
	 * 
	 * @return
	 */
	public String getPhoneFeeRankingQueryReportName() {
		return phoneFeeRankingQueryReportName;
	}

	public void setPhoneFeeRankingQueryReportName(String phoneFeeRankingQueryReportName) {
		this.phoneFeeRankingQueryReportName = this.getReportRootPath() + phoneFeeRankingQueryReportName;
	}

	/**
	 * C11.4.2 應繳租金查詢
	 * 
	 * @return
	 */
	public String getShouldPayRentQueryReportName() {
		return shouldPayRentQueryReportName;
	}

	public void setShouldPayRentQueryReportName(String shouldPayRentQueryReportName) {
		this.shouldPayRentQueryReportName = this.getReportRootPath() + shouldPayRentQueryReportName;
	}

	/**
	 * C4.1.1 檢核所得
	 * 
	 * @return
	 */
	public String getCheckTaxReportName() {
		return checkTaxReportName;
	}

	public void setCheckTaxReportName(String checkTaxReportName) {
		this.checkTaxReportName = this.getReportRootPath() + checkTaxReportName;
	}

	/**
	 * C4.1.1 檢核二代健保
	 * 
	 * @return
	 */
	/** @Chang No:RE201201260 [Start] **/
	public String getCheckHealthReportName() {
		return checkHealthReportName;
	}

	public void setCheckHealthReportName(String checkHealthReportName) {
		this.checkHealthReportName = this.getReportRootPath() + checkHealthReportName;
	}

	/** @Chang No:RE201201260 [End] **/

	public void setProjectEncouragementQueryReportName(String projectEncouragementQueryReportName) {
		this.projectEncouragementQueryReportName = projectEncouragementQueryReportName;
	}

	public String getProjectEncouragementQueryReportName() {
		return projectEncouragementQueryReportName;
	}

	public static String getParamWithQuotation(String param) {
		return StringUtils.isBlank(param) ? CrystalReportConfigManagedBean.DUMMY_WITH_QUOTATION : "'" + param + "'";
	}

	public static String getParamWithoutQuotation(String param) {
		return StringUtils.isBlank(param) ? CrystalReportConfigManagedBean.DUMMY_WITHOUT_QUOTATION : param;
	}

	public void setCapitalNonCapitalQueryReportName(String capitalNonCapitalQueryReportName) {
		this.capitalNonCapitalQueryReportName = capitalNonCapitalQueryReportName;
	}

	public String getCapitalNonCapitalQueryReportName() {
		return capitalNonCapitalQueryReportName;
	}

	public void setCapitalDefrayReportName(String capitalDefrayReportName) {
		this.capitalDefrayReportName = capitalDefrayReportName;
	}

	public String getCapitalDefrayReportName() {
		return capitalDefrayReportName;
	}

	/**
	 * D9.24 講師費報表
	 * 
	 * @return
	 */
	public String getLecturerExpReportName() {
		return lecturerExpReportName;
	}

	public void setLecturerExpReportName(String lecturerExpReportName) {
		this.lecturerExpReportName = lecturerExpReportName;
	}

	public void setNonCapitalDefrayReportName(String nonCapitalDefrayReportName) {
		this.nonCapitalDefrayReportName = nonCapitalDefrayReportName;
	}

	public String getNonCapitalDefrayReportName() {
		return nonCapitalDefrayReportName;
	}

	public void setRelationTradeDetailReportName(String relationTradeDetailReportName) {
		this.relationTradeDetailReportName = relationTradeDetailReportName;
	}

	public String getRelationTradeDetailReportName() {
		return relationTradeDetailReportName;
	}

	public void setFixUpQueryReportName(String fixUpQueryReportName) {
		this.fixUpQueryReportName = fixUpQueryReportName;
	}

	public String getFixUpQueryReportName() {
		return fixUpQueryReportName;
	}

	public void setBuildingExpDetailReportName(String buildingExpDetailReportName) {
		this.buildingExpDetailReportName = buildingExpDetailReportName;
	}

	public String getBuildingExpDetailReportName() {
		return buildingExpDetailReportName;
	}

	public void setBizUnitKPIStatisticReportName(String bizUnitKPIStatisticReportName) {
		this.bizUnitKPIStatisticReportName = bizUnitKPIStatisticReportName;
	}

	public String getBizUnitKPIStatisticReportName() {
		return bizUnitKPIStatisticReportName;
	}

	public String getTrvlExpApplSearchReportName() {
		return trvlExpApplSearchReportName;
	}

	public void setTrvlExpApplSearchReportName(String trvlExpApplSearchReportName) {
		this.trvlExpApplSearchReportName = this.getReportRootPath() + trvlExpApplSearchReportName;
	}

	// RE201500189_國內出差申請作業流程簡化 EC0416 2015/04/07 start
	public String getNewTrvlExpApplSearchReportName() {
		return newTrvlExpApplSearchReportName;
	}

	public void setNewTrvlExpApplSearchReportName(String newTrvlExpApplSearchReportName) {
		this.newTrvlExpApplSearchReportName = this.getReportRootPath() + newTrvlExpApplSearchReportName;
	}

	// RE201500189_國內出差申請作業流程簡化 EC0416 2015/04/07 end

	public String getBizTripReportName() {
		return bizTripReportName;
	}

	public void setBizTripReportName(String bizTripReportName) {
		this.bizTripReportName = this.getReportRootPath() + bizTripReportName;
	}

	public String getQueryVoucherReport() {
		return queryVoucherReport;
	}

	public void setQueryVoucherReport(String queryVoucherReport) {
		this.queryVoucherReport = this.getReportRootPath() + queryVoucherReport;
	}

	public String getRegisterRosterReport() {
		return registerRosterReport;
	}

	public void setRegisterRosterReport(String registerRosterReport) {
		this.registerRosterReport = this.getReportRootPath() + registerRosterReport;
	}

	/** B 2.1 費用申請單送件表 for 組織發展費(中分類810) */
	public String getExpapplBOrganizeDevelopeReportName() {
		return expapplBOrganizeDevelopeReportName;
	}

	public void setExpapplBOrganizeDevelopeReportName(String expapplBOrganizeDevelopeReportName) {
		this.expapplBOrganizeDevelopeReportName = this.getReportRootPath() + expapplBOrganizeDevelopeReportName;
	}

	/**
	 * C11.5.10公務車費用明細查詢功能
	 * 
	 * @return
	 */
	public String getPubAffCarExpApplQueryReportName() {
		return pubAffCarExpApplQueryReportName;
	}

	public void setPubAffCarExpApplQueryReportName(String pubAffCarExpApplQueryReportName) {
		this.pubAffCarExpApplQueryReportName = this.getReportRootPath() + pubAffCarExpApplQueryReportName;

	}

	/* RE201201260_二代健保 cm9539 2013/02/01 start */
	/**
	 * C11.7.9 列印扣繳健保補充保費
	 * 
	 * @return
	 */
	public String getPrintSupHealPremiumReportName() {
		return printSupHealPremiumReportName;
	}

	public void setPrintSupHealPremiumReportName(String printSupHealPremiumReportName) {
		this.printSupHealPremiumReportName = this.getReportRootPath() + printSupHealPremiumReportName;
	}

	/* RE201201260_二代健保 cm9539 2013/02/01 end */

	/* RE201201260_二代健保 cm9539 2013/03/26 start */
	/** B7.19 匯出健保補充保費明細申報檔 */
	public String getMonthlyHealthPremiumReportName() {
		return monthlyHealthPremiumReportName;
	}

	public void setMonthlyHealthPremiumReportName(String monthlyHealthPremiumReportName) {
		this.monthlyHealthPremiumReportName = this.getReportRootPath() + monthlyHealthPremiumReportName;
	}

	/* RE201201260_二代健保 cm9539 2013/03/26 end */

	/* RE201201260_列印補充保費扣費證明 2013/10/28 start */
	/** B7.20列印補充保費證明 */
	public String getPrintHealPremiumIncomeReportName() {
		return printHealPremiumIncomeReportName;
	}

	public void setPrintHealPremiumIncomeReportName(String printHealPremiumIncomeReportName) {
		this.printHealPremiumIncomeReportName = this.getReportRootPath() + printHealPremiumIncomeReportName;
	}

	/* RE201201260_列印補充保費扣費證明 2013/10/28 end */
	/* RE201301890_年底併薪報表列印 2013/10/30 start */
	/** D10.4業推發組發年度未核銷併薪 */
	public String getPrintMergeSalary() {
		return printMergeSalary;
	}

	public void setPrintMergeSalary(String printMergeSalary) {
		this.printMergeSalary = this.getReportRootPath() + printMergeSalary;
	}

	public String getDeliverDaylistTrvlOvsaReportName() {
		return deliverDaylistTrvlOvsaReportName;
	}

	public void setDeliverDaylistTrvlOvsaReportName(String deliverDaylistTrvlOvsaReportName) {
		this.deliverDaylistTrvlOvsaReportName = this.getReportRootPath() + deliverDaylistTrvlOvsaReportName;
	}

	/** D10.2結轉員工訓練費 */
	public String getPrintTuitionFeeSummary() {
		return printTuitionFeeSummary;
	}

	public void setPrintTuitionFeeSummary(String printTuitionFeeSummary) {
		this.printTuitionFeeSummary = this.getReportRootPath() + printTuitionFeeSummary;
	}

	public String getVendorInvoiceReportName() {
		return vendorInvoiceReportName;
	}

	public void setVendorInvoiceReportName(String vendorInvoiceReportName) {
		this.vendorInvoiceReportName = getReportRootPath() + vendorInvoiceReportName;
	}

	// RE201402595_汽機車切結管理檔案與費用勾稽作業 CU3178 2014/09/19 START
	/**
	 * C3.3.1 列印汽機車未切結報表
	 */
	public String getDailyCaraffidavitReportName() {
		return dailyCaraffidavitReportName;
	}

	public void setDailyCaraffidavitReportName(String dailyCaraffidavitReportName) {
		this.dailyCaraffidavitReportName = this.getReportRootPath() + dailyCaraffidavitReportName;
	}

	/**
	 * C10.9.3 列印汽機車未切結報表
	 */
	public String getCaraffidavitReportName() {
		return caraffidavitReportName;
	}

	public void setCaraffidavitReportName(String caraffidavitReportName) {
		this.caraffidavitReportName = this.getReportRootPath() + caraffidavitReportName;
	}

	// RE201402595_汽機車切結管理檔案與費用勾稽作業 CU3178 2014/09/19 END
	// RE201403176_C11項下載新增預算實支查詢 EC0416 2015/03/05 START
	public String getbudgetExpExecuteReportName() {
		return budgetExpExecuteReportName;
	}

	public void setBudgetExpExecuteReportName(String budgetExpExecuteReportName) {
		this.budgetExpExecuteReportName = this.getReportRootPath() + budgetExpExecuteReportName;
	}

	public String getsubbudgetExpExecuteReportName() {
		return subbudgetExpExecuteReportName;
	}

	public void setSubbudgetExpExecuteReportName(String subbudgetExpExecuteReportName) {
		this.subbudgetExpExecuteReportName = this.getReportRootPath() + subbudgetExpExecuteReportName;
	}

	public String getbudgetExpReportName() {
		return budgetExpReportName;
	}

	public void setBudgetExpReportName(String budgetExpReportName) {
		this.budgetExpReportName = this.getReportRootPath() + budgetExpReportName;
	}

	public String getmealSocialBudgetReportName() {
		return mealSocialBudgetReportName;
	}

	public void setMealSocialBudgetReportName(String mealSocialBudgetReportName) {
		this.mealSocialBudgetReportName = this.getReportRootPath() + mealSocialBudgetReportName;
	}

	// RE201403176_C11項下載新增預算實支查詢 EC0416 2015/03/05 END

	// RE201500189_國內出差申請作業流程簡化 EC0416 2015/04/07 START
	/**
	 * C11.7.12 國外出差匯款功能查詢
	 */
	public String getovsaTrvlRemitQueryReportName() {
		return ovsaTrvlRemitQueryReportName;
	}

	public void setOvsaTrvlRemitQueryReportName(String ovsaTrvlRemitQueryReportName) {
		this.ovsaTrvlRemitQueryReportName = this.getReportRootPath() + ovsaTrvlRemitQueryReportName;
	}

	// RE201500189_國內出差申請作業流程簡化 EC0416 2015/04/07 end

	// RE201404290_系統寄發預算實支表&線上填寫實支異常說明 EC0416 2015/8/20 start
	public String getBudExpOverrunReportName() {
		return budExpOverrunReportName;
	}

	public void setBudExpOverrunReportName(String budExpOverrunReportName) {
		this.budExpOverrunReportName = this.getReportRootPath() + budExpOverrunReportName;
	}

	public String getSubbudExpOverrunReportName() {
		return subbudExpOverrunReportName;
	}

	public void setSubbudExpOverrunReportName(String subbudExpOverrunReportName) {
		this.subbudExpOverrunReportName = subbudExpOverrunReportName;
	}

	public String getMailLogReportName() {
		return mailLogReportName;
	}

	public void setMailLogReportName(String mailLogReportName) {
		this.mailLogReportName = mailLogReportName;
	}

	// RE201404290_系統寄發預算實支表&線上填寫實支異常說明 EC0416 2015/8/20 end

	// RE201602231_廠商應付費用提列 CU3178 2016/9/7 START
	/**
	 * D4.7 廠商應付未付合約明細表
	 * 
	 * @return
	 */
	public String getVendorContractDetailReportName() {
		return vendorContractDetailReportName;
	}

	public void setVendorContractDetailReportName(String vendorContractDetailReportName) {
		this.vendorContractDetailReportName = this.getReportRootPath() + vendorContractDetailReportName;
	}

	/**
	 * D4.8 廠商應付未付明細表
	 * 
	 * @return
	 */
	public String getCloseMonthTurnAccruedReportName() {
		return closeMonthTurnAccruedReportName;
	}

	public void setCloseMonthTurnAccruedReportName(String closeMonthTurnAccruedReportName) {
		this.closeMonthTurnAccruedReportName = closeMonthTurnAccruedReportName;
	}

	/**
	 * D04.09 查詢廠商應付費用明細
	 * 
	 * @return
	 */
	public String getVendorMonthDetailReportName() {
		return vendorMonthDetailReportName;
	}

	public void setVendorMonthDetailReportName(String vendorMonthDetailReportName) {
		this.vendorMonthDetailReportName = vendorMonthDetailReportName;
	}

	// RE201602231_廠商應付費用提列 CU3178 2016/9/7 END

	// RE201504772_年度組織控管 CU3178 2016/2/25 START
	public String getYearBudgetExpExecuteReportName() {
		return yearBudgetExpExecuteReportName;
	}

	public void setYearBudgetExpExecuteReportName(String yearBudgetExpExecuteReportName) {
		this.yearBudgetExpExecuteReportName = this.getReportRootPath() + yearBudgetExpExecuteReportName;
	}

	public String getYearSubbudgetExpExecuteReportName() {
		return yearSubbudgetExpExecuteReportName;
	}

	public void setYearSubbudgetExpExecuteReportName(String yearSubbudgetExpExecuteReportName) {
		this.yearSubbudgetExpExecuteReportName = this.getReportRootPath() + yearSubbudgetExpExecuteReportName;
	}

	public String getYearBudgetExpReportName() {
		return yearBudgetExpReportName;
	}

	public void setYearBudgetExpReportName(String yearBudgetExpReportName) {
		this.yearBudgetExpReportName = this.getReportRootPath() + yearBudgetExpReportName;
	}

	public String getYearMealSocialBudgetReportName() {
		return yearMealSocialBudgetReportName;
	}

	public void setYearMealSocialBudgetReportName(String yearMealSocialBudgetReportName) {
		this.yearMealSocialBudgetReportName = this.getReportRootPath() + yearMealSocialBudgetReportName;
	}

	// RE201504772_年度組織控管 CU3178 2016/2/25 END

	// RE201603570_預算暨費用系統_共用功能與模組整合 CU3178 2016/10/14 START
	/**
	 * E3.1人預算審查-總公司
	 * 
	 * @return
	 */
	public String getAuditBudgetForHeadquarter() {
		return auditBudgetForHeadquarter;
	}

	public void setAuditBudgetForHeadquarter(String auditBudgetForHeadquarter) {
		this.auditBudgetForHeadquarter = auditBudgetForHeadquarter;
	}

	/**
	 * E03.02 預算審查-服務中心、營業部室本部、營業部室外埠二階、營業部室外埠三階
	 * 
	 * @return
	 */
	public String getAuditBudgetForServiceCenter() {
		return auditBudgetForServiceCenter;
	}

	public void setAuditBudgetForServiceCenter(String auditBudgetForServiceCenter) {
		this.auditBudgetForServiceCenter = auditBudgetForServiceCenter;
	}

	/**
	 * E03.03 預算審查-經管會
	 * 
	 * @return
	 */
	public String getAuditBudgetForAdministration() {
		return auditBudgetForAdministration;
	}

	public void setAuditBudgetForAdministration(String auditBudgetForAdministration) {
		this.auditBudgetForAdministration = auditBudgetForAdministration;
	}

	/**
	 * E4.1人力配置暨辦公費
	 * 
	 * @return
	 */
	public String getHumanAllocationAndOfficeFee() {
		return humanAllocationAndOfficeFee;
	}

	public void setHumanAllocationAndOfficeFee(String humanAllocationAndOfficeFee) {
		this.humanAllocationAndOfficeFee = humanAllocationAndOfficeFee;
	}

	/**
	 * E4.2工作目標與費用預算計劃表
	 * 
	 * @return
	 */
	public String getWorkTargetAndExpenseReport() {
		return workTargetAndExpenseReport;
	}

	public void setWorkTargetAndExpenseReport(String workTargetAndExpenseReport) {
		this.workTargetAndExpenseReport = workTargetAndExpenseReport;
	}

	/**
	 * E4.3 專案計畫預算報告書
	 * 
	 * @return
	 */
	public String getProjectPlanBudgetReport() {
		return projectPlanBudgetReport;
	}

	public void setProjectPlanBudgetReport(String projectPlanBudgetReport) {
		this.projectPlanBudgetReport = projectPlanBudgetReport;
	}

	/**
	 * E4.4 資本支出計劃表
	 * 
	 * @return
	 */
	public String getCapitalExpenditurePlanReport() {
		return capitalExpenditurePlanReport;
	}

	public void setCapitalExpenditurePlanReport(String capitalExpenditurePlanReport) {
		this.capitalExpenditurePlanReport = capitalExpenditurePlanReport;
	}

	/**
	 * E4.5 預算審查彙總報表
	 * 
	 * @return
	 */
	public String getAuditBudgetCollectReport() {
		return auditBudgetCollectReport;
	}

	public void setAuditBudgetCollectReport(String auditBudgetCollectReport) {
		this.auditBudgetCollectReport = auditBudgetCollectReport;
	}

	/**
	 * E4.5 預算審查彙總報表
	 * 
	 * @return
	 */
	public String getSummaryReport() {
		return summaryReport;
	}

	public void setSummaryReport(String summaryReport) {
		this.summaryReport = summaryReport;
	}

	/**
	 * E4.6 經管會預算表
	 * 
	 * @return
	 */
	public String getAdministrationReport() {
		return administrationReport;
	}

	public void setAdministrationReport(String administrationReport) {
		this.administrationReport = administrationReport;
	}

	/**
	 * E4.7月預算報表
	 * 
	 * @return
	 */
	public String getMonthBudgetReport() {
		return monthBudgetReport;
	}

	public void setMonthBudgetReport(String monthBudgetReport) {
		this.monthBudgetReport = monthBudgetReport;
	}

	/**
	 * E4.8事業費用報表
	 * 
	 * @return
	 */
	public String getOperatingDataReport() {
		return operatingDataReport;
	}

	public void setOperatingDataReport(String operatingDataReport) {
		this.operatingDataReport = operatingDataReport;
	}

	/**
	 * E4.9事業費用分析差異表
	 * 
	 * @return
	 */
	public String getOperatingDiffDataReport() {
		return OperatingDiffDataReport;
	}

	public void setOperatingDiffDataReport(String operatingDiffDataReport) {
		OperatingDiffDataReport = operatingDiffDataReport;
	}

	// RE201603570_預算暨費用系統_共用功能與模組整合 CU3178 2016/10/14 END

	// RE201700820_事業費用預算報表新增 CU3178 2017/4/17 START
	/**
	 * E04.10 事業費用預算項目屬性報表
	 * 
	 * @return
	 */
	public String getOperatingBudgetItemReport() {
		return operatingBudgetItemReport;
	}

	public void setOperatingBudgetItemReport(String operatingBudgetItemReport) {
		this.operatingBudgetItemReport = operatingBudgetItemReport;
	}

	/**
	 * E4.11事業費用預算項目屬性年度差異分析報表
	 * 
	 * @return
	 */
	public String getOperatingDifferBudgetItemReport() {
		return operatingDifferBudgetItemReport;
	}

	public void setOperatingDifferBudgetItemReport(String operatingDifferBudgetItemReport) {
		this.operatingDifferBudgetItemReport = operatingDifferBudgetItemReport;
	}

	/**
	 * E4.12事業費用預算類別報表
	 * 
	 * @return
	 */
	public String getOperatingBudgetTypeReport() {
		return operatingBudgetTypeReport;
	}

	public void setOperatingBudgetTypeReport(String operatingBudgetTypeReport) {
		this.operatingBudgetTypeReport = operatingBudgetTypeReport;
	}

	/**
	 * E4.13事業費用預算類別年度差異分析報表
	 * 
	 * @return
	 */
	public String getOperatingDifferBudgetTypeReport() {
		return operatingDifferBudgetTypeReport;
	}

	public void setOperatingDifferBudgetTypeReport(String operatingDifferBudgetTypeReport) {
		this.operatingDifferBudgetTypeReport = operatingDifferBudgetTypeReport;
	}

	/**
	 * E4.14事業費用預算部室屬性類別報表
	 * 
	 * @return
	 */
	public String getOperatingDepPropReport() {
		return operatingDepPropReport;
	}

	public void setOperatingDepPropReport(String operatingDepPropReport) {
		this.operatingDepPropReport = operatingDepPropReport;
	}

	/**
	 * E4.15事業費用預算部室屬性類別年度差異分析報表
	 * 
	 * @return
	 */
	public String getOperatingDifferDepPropReport() {
		return operatingDifferDepPropReport;
	}

	public void setOperatingDifferDepPropReport(String operatingDifferDepPropReport) {
		this.operatingDifferDepPropReport = operatingDifferDepPropReport;
	}

	// RE201700820_事業費用預算報表新增 CU3178 2017/4/17 END

	// RE201701547_費用系統預算優化第二階段 EC0416 2017/4/7 START
	public String getLecturerFeesReportName() {
		return lecturerFeesReportName;
	}

	public void setLecturerFeesReportName(String lecturerFeesReportName) {
		this.lecturerFeesReportName = this.getReportRootPath() + lecturerFeesReportName;
	}

	public String getLecturerFeesYearDepReportName() {
		return LecturerFeesYearDepReportName;
	}

	public void setLecturerFeesYearDepReportName(String lecturerFeesYearDepReportName) {
		this.LecturerFeesYearDepReportName = this.getReportRootPath() + lecturerFeesYearDepReportName;
	}

	public String getDeferredAmortizationReportName() {
		return deferredAmortizationReportName;
	}

	public void setDeferredAmortizationReportName(String deferredAmortizationReportName) {
		this.deferredAmortizationReportName = this.getReportRootPath() + deferredAmortizationReportName;
	}

	public String getDeferredAmortizationYearDepReportName() {
		return deferredAmortizationYearDepReportName;
	}

	public void setDeferredAmortizationYearDepReportName(String deferredAmortizationYearDepReportName) {
		this.deferredAmortizationYearDepReportName = this.getReportRootPath() + deferredAmortizationYearDepReportName;
	}

	public String getPrepaidAmortizationReportName() {
		return prepaidAmortizationReportName;
	}

	public void setPrepaidAmortizationReportName(String prepaidAmortizationReportName) {
		this.prepaidAmortizationReportName = this.getReportRootPath() + prepaidAmortizationReportName;
	}

	public String getPrepaidAmortizationYearDepReportName() {
		return prepaidAmortizationYearDepReportName;
	}

	public void setPrepaidAmortizationYearDepReportName(String prepaidAmortizationYearDepReportName) {
		this.prepaidAmortizationYearDepReportName = this.getReportRootPath() + prepaidAmortizationYearDepReportName;
	}
	// RE201701547_費用系統預算優化第二階段 EC0416 2017/4/7 end

	// RE201701039 國外出差系統優化作業第二階段 EC0416 201706016 start
	public String getTrvlExpApplSearchOvsaReportName() {
		return trvlExpApplSearchOvsaReportName;
	}

	public void setTrvlExpApplSearchOvsaReportName(String trvlExpApplSearchOvsaReportName) {
		this.trvlExpApplSearchOvsaReportName = this.getReportRootPath() + trvlExpApplSearchOvsaReportName;
	}

	public String getTrvlExpApplSearchOvsaSubReportName() {
		return trvlExpApplSearchOvsaSubReportName;
	}

	public void setTrvlExpApplSearchOvsaSubReportName(String trvlExpApplSearchOvsaSubReportName) {
		this.trvlExpApplSearchOvsaSubReportName = this.getReportRootPath() + trvlExpApplSearchOvsaSubReportName;
	}
	/*
	 * C01.05.06國外出差工作日報表
	 */
	public String getOvsaDailyWorkReportName() {
		return ovsaDailyWorkReportName;
	}

	public void setOvsaDailyWorkReportName(String ovsaDailyWorkReportName) {
		this.ovsaDailyWorkReportName =  this.getReportRootPath() +ovsaDailyWorkReportName;
	}
    //RE201701039 國外出差系統優化作業第二階段 EC0416 201706016 end
	
	//RE201702476_事業費用預算實支報表 CU3178 2017/8/23 START
	/**
	 * E4.14事業費用預算部室屬性類別報表 -實支報表Pojo
	 * @return
	 */
	public String getOperatingDepPropReportPojo() {
		return operatingDepPropReportPojo;
	}

	/**
	 * E4.14事業費用預算部室屬性類別報表 -實支報表Pojo
	 * @param operatingDepPropReportPojo
	 */
	public void setOperatingDepPropReportPojo(String operatingDepPropReportPojo) {
		this.operatingDepPropReportPojo = operatingDepPropReportPojo;
	}
	//RE201702476_事業費用預算實支報表 CU3178 2017/8/23 END
	
	//RE201702775_預算實支追蹤表單_費用系統  ec0416 2017/9/29 start
	public String getBudExpOverrunDetailReportName() {
		return budExpOverrunDetailReportName;
	}

	public void setBudExpOverrunDetailReportName(String budExpOverrunDetailReportName) {
		this.budExpOverrunDetailReportName =this.getReportRootPath() + budExpOverrunDetailReportName;
	}

	public String getBudExpOverrunDetailTotalReportName() {
		return budExpOverrunDetailTotalReportName;
	}

	public void setBudExpOverrunDetailTotalReportName(String budExpOverrunDetailTotalReportName) {
		this.budExpOverrunDetailTotalReportName =this.getReportRootPath() + budExpOverrunDetailTotalReportName;
	}
	//RE201702775_預算實支追蹤表單_費用系統  ec0416 2017/9/29 end

	//RE2017 辦公費核定表提列應付費用 CU3178 2017/11/8 START
	/**
	 * D10.06 核定表應付費用明細表
	 * @return
	 */
	public String getYyclsDetail() {
		return yyclsDetail;
	}

	/**
	 * D10.06 核定表應付費用明細表
	 * @param yyclsDetail
	 */
	public void setYyclsDetail(String yyclsDetail) {
		this.yyclsDetail = yyclsDetail;
	}
	//RE2017 辦公費核定表提列應付費用 CU3178 2017/11/8 END
	
	//RE201702991_國外出差系統優化作業 EC0416 2017/11/13 start
	/**
	 * C11.2.4 國外出差(研修)旅費申請總表
	 * @return
	 */
	public String getOvsaTripReportName() {
		return ovsaTripReportName;
	}

	public void setOvsaTripReportName(String ovsaTripReportName) {
		this.ovsaTripReportName = getReportRootPath() + ovsaTripReportName;
	}
	//RE201702991_國外出差系統優化作業 EC0416 2017/11/13 end
}
