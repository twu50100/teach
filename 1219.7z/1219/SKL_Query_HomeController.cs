﻿using System;
using System.Web.Http;
using Gemfor.Mvc;
using System.Data;
using Gemfor.Util;
using System.IO;
using System.Xml;
using System.Collections.Generic;
using System.Linq;


namespace SKL_LOAN.Controllers.Api.eLoan.Query.Common
{
    /// <summary>
    /// 清單頁面
    /// </summary>
    public class SKL_Query_HomeController : BasePageController
    {
        /// <summary>
        /// 清單頁面
        /// </summary>
        /// <param name="cmd">
        /// LocationPath 清單頁面路徑 &#13;
        /// ex. /eLoan/Manage/House/ &#13;
        /// EnterPageName 清單頁面名稱 &#13;
        /// ex. SKL_1_0_Maintain_HouseHome.html &#13;
        /// </param>
        /// <returns>清單 資料</returns>
        [HttpPost]
        public StdRet init_Home_List([FromBody]QueryList_Cmd cmd)
        {
            StdRet ret = new StdRet();
            if (cmd == null)
            {
                ret.setRc(StdRet.RC.INTERNAL_ERR, "請輸入參數值！");
                return ret;
            }
            try
            {
                HashMap hmapOut = new HashMap();
                hmapOut.Put("Table", getFileList(cmd));

                ret.data = hmapOut;
            }
            catch (Exception e)
            {
                ret.setRc(StdRet.RC.INTERNAL_ERR, e.Message);
            }

            return ret;
        }
        private DataTable getFileList(QueryList_Cmd cmd)
        {
            String strWebPagePath = cmd.LocationPath.Replace(cmd.EnterPageName, "");
            strWebPagePath = (cmd.LocationPath.IndexOf("/") == 0)? strWebPagePath.Substring(1): strWebPagePath;

            string strFileExt = cmd.EnterPageName.Substring (cmd.EnterPageName.LastIndexOf("."));
            string strDomainBase = AppDomain.CurrentDomain.BaseDirectory;

            string strFilePath = string.Format("{0}{1}", strDomainBase, strWebPagePath.Replace(@"/", @"\"));

            Logger.Debug(">>> " + strFilePath);

            DataTable dtFileInfo = new DataTable();
            var dtColns = dtFileInfo.Columns;
            dtColns.Add("ID", typeof(System.Int32)).AllowDBNull = false;
            dtColns.Add("TitleName", typeof(System.String));
            dtColns.Add("PgName", typeof(System.String));
            dtColns.Add("Url", typeof(System.String));
            dtColns["ID"].Unique = true;
            dtColns["ID"].AutoIncrement = true;
            dtColns["ID"].AutoIncrementSeed = 1;

            cmd.FilePath = strFilePath;
            cmd.WebPagePath = strWebPagePath;
            cmd.FileExt = strFileExt;

            FindFiles(ref dtFileInfo, cmd);

            return dtFileInfo;
        }

        private void FindFiles(ref DataTable dt, QueryList_Cmd cmd)//, string g_strHidePageName=null)
        {
            string[] strFiles = Directory.GetFiles(cmd.FilePath, string.Format("*{0}", cmd.FileExt));

            //string[] m_strHidePageNameArray = g_strHidePageName.Split(';');

            //RE201903385_每日產製借款人核撥及財務收入等相關個資資訊提供核保作業勾稽 EC0416 20191219 START
            //例外清單
            var IgnoreFileList = GetIgnoreFile();
            //RE201903385_每日產製借款人核撥及財務收入等相關個資資訊提供核保作業勾稽 EC0416 20191219 END


            for (int i = 0; i <= strFiles.Length - 1; i++)
            {
                string strFileData = strFiles[i];

                    string[] aryFileName = strFiles[i].Split('\\');
                    string strFileName = aryFileName[aryFileName.Length - 1];
                    Logger.Debug(">>>>> " + strFileName);

                    bool isOk = true;
                    if (cmd.EnterPageName.Equals(strFileName)) isOk = false;
                //RE201903385_每日產製借款人核撥及財務收入等相關個資資訊提供核保作業勾稽 EC0416 20191219 START
                //比對例外清單
                if (IgnoreFileList.Any(strFileName.Contains))
                    isOk = false;
                //RE201903385_每日產製借款人核撥及財務收入等相關個資資訊提供核保作業勾稽 EC0416 20191219 END

                foreach (String excludePageName in cmd.excludePageName)
                    {
                        if (excludePageName.Equals(strFileName))
                            isOk = false;
                    //RE201903385_每日產製借款人核撥及財務收入等相關個資資訊提供核保作業勾稽 EC0416 START
                    if (IgnoreFileList.Any(excludePageName.Contains))
                        isOk = false;
                    //RE201903385_每日產製借款人核撥及財務收入等相關個資資訊提供核保作業勾稽 EC0416 END
                }

                if (isOk)
                    {
                        DataRow dr = dt.NewRow();
                        dr["TitleName"] = getTitle(strFileData);
                        dr["PgName"] = strFileName;
                        dr["Url"] = cmd.WebPagePath.Replace("\\", "/");
                        Logger.Debug(">>>>> " + dr["Url"].ToString());
                        dt.Rows.Add(dr);
                    }

            }
        }

        private string getTitle(string filepath)
        {
            string result = "";
            StreamReader reader = new StreamReader(filepath, System.Text.Encoding.GetEncoding("utf-8"));
            while (!reader.EndOfStream)
            {
                string strLineData = reader.ReadLine();
                if (strLineData.IndexOf("<title>") > 0)
                {
                    XmlDocument xmlparse = new XmlDocument();
                    xmlparse.LoadXml(strLineData);

                    XmlNodeList elemlist = xmlparse.GetElementsByTagName("title");

                    result = elemlist[0].InnerXml;

                }
            }
            reader.Close();
            Logger.Debug(result);
            return result;
        }


        /// <summary>
        /// 清單頁面 維護...
        /// 傳入參數
        /// </summary>
        public class QueryList_Cmd
        {
            public String LocationPath;
            public String EnterPageName;
            public String[] excludePageName = new String[] {
                "SKL_3_2_Download_CSSRecord.html",
                "SKL_10_2_Query_RiskHouse.html"
            };
            public String FilePath;
            public String WebPagePath;
            public String FileExt;
        }

        //RE201903385_每日產製借款人核撥及財務收入等相關個資資訊提供核保作業勾稽 EC0416 20191219 START
        /// <summary>
        /// 例外清單
        /// </summary>
        /// <returns></returns>
        private List<string> GetIgnoreFile()
        {
            var RoleNo = g_clsSessionSecurity.RoleNo;
            var IgnoreFL = new List<string>();

            switch (RoleNo)
            {
                case "83":
                    //沒擋
                    break;
                default:
                    //核保作業勾稽資料查詢
                    IgnoreFL.Add("SKL_1_4_House_InsCheckData.html");
                    break;
            }
            return IgnoreFL;
        }
        //RE201903385_每日產製借款人核撥及財務收入等相關個資資訊提供核保作業勾稽 EC0416 20191219 END
    }
}
