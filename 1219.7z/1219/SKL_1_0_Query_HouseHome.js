﻿var PAGE_SIZE = 10;
var EDIT_DATA = new Array();
var G_DATA = new Array();


genData = function (G_DATA) {
    //console.log(G_DATA);
    var G_DATA = G_DATA.data["Table"];

    var tableArg = {
        theadValue: [[
            { Text: "" },
            { Text: "功能名稱" }

        ]],
        tbodyValue: {
            Value: ["ID",
                    {
                        h: function (e) {                    
                            return "<a href='" + e["PgName"] + "'>" + e["TitleName"] + "</a>";
                        }
                    }
            ],
            Style: []

        },
        Data: G_DATA,
        Style: {
            tbody_odd: "rowodd",
            tbody_even: "roweven"
        }
        //資料全取的分頁方式
        , PageSetting: {
            ShowPageCtrl: true,
            PageSize: PAGE_SIZE,
        }
    };

    $("#scDataView").find("input").off('click');
    $("#scDataView").find("thead,tbody").remove();
    $("#scDataView").SexyTable(tableArg);
};


$(document).ready(function () {


        var DataArgs =
        {
            method: "post",
            url: "SKL_Query_Home/init_Home_List",
            data: {
                "LocationPath": "/eLoan/Query/House/",
                "EnterPageName": "SKL_1_0_Query_HouseHome.html"
            },
            oMethod: genData
        };
        docCore.ajax(DataArgs, true, true);


});