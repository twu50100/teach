﻿using System;
using System.Web.Http;
using Gemfor.Mvc;
using System.Data;
using Gemfor.Util;
using System.IO;
using System.Xml;
using System.Collections.Generic;
using System.Linq;

namespace SKL_LOAN.Controllers.Api.eLoan.Manage.House
{
    /// <summary>
    /// 房貸清單頁面  
    /// </summary>
    public class SKL_1_0_Maintain_HouseHomeController : BasePageController
    {
        /// <summary>
        /// 房貸清單頁面  
        /// </summary>
        /// <param name="cmd">
        /// LocationPath 房貸清單頁面路徑 &#13;
        /// ex. /eLoan/Manage/House/ &#13;
        /// EnterPageName 房貸清單頁面名稱 &#13;
        /// ex. SKL_1_0_Maintain_HouseHome.html &#13;
        /// </param>
        /// <returns>房貸清單 資料</returns>
        [HttpPost]
        public StdRet init_HouseHome_List([FromBody]HouseHomeList_Cmd cmd)
        {
            StdRet ret = new StdRet();
            try
            {
                HashMap hmapOut = new HashMap();
                hmapOut.Put("Table", getFileList(cmd));

                ret.data = hmapOut;
            }
            catch (Exception e)
            {
                ret.setRc(StdRet.RC.INTERNAL_ERR, e.Message);
            }

            return ret;
        }
        private DataTable getFileList(HouseHomeList_Cmd cmd)
        {
            //Logger.Debug(cmd.LocationPath.IndexOf("/"));
            String strWebPagePath = cmd.LocationPath.Replace(cmd.EnterPageName, "");//@"eLoan/Manage/House/";
            strWebPagePath = (cmd.LocationPath.IndexOf("/") == 0) ? strWebPagePath.Substring(1) : strWebPagePath;

            string strFileExt = cmd.EnterPageName.Substring(cmd.EnterPageName.LastIndexOf("."));
            //String g_strHidePageName = "35_0_HouseList.aspx;35_2_Maintain_Relation_Type.aspx;35_2_Maintain_Restrict_Alter.aspx;35_2_Maintain_Restrict_Refund.aspx";
            string strDomainBase = AppDomain.CurrentDomain.BaseDirectory;
            //D:\Proj\GemFor\SVN\A04系統開發\程式\Web\LOAN_MVC\SKL_LOAN\
            // /eLoan/Manage/House/SKL_1_1_Maintain_CountCode.html

            string strFilePath = string.Format("{0}{1}", strDomainBase, strWebPagePath.Replace(@"/", @"\"));

            Logger.Debug(">>> " + strFilePath);

            DataTable dtFileInfo = new DataTable();
            var dtColns = dtFileInfo.Columns;
            dtColns.Add("ID", typeof(System.Int32)).AllowDBNull = false;
            dtColns.Add("TitleName", typeof(System.String));
            dtColns.Add("PgName", typeof(System.String));
            dtColns.Add("Url", typeof(System.String));
            dtColns["ID"].Unique = true;
            dtColns["ID"].AutoIncrement = true;
            dtColns["ID"].AutoIncrementSeed = 1;

            cmd.FilePath = strFilePath;
            cmd.WebPagePath = strWebPagePath;
            cmd.FileExt = strFileExt;

            FindFiles(ref dtFileInfo, cmd);

            return dtFileInfo;
        }

        private void FindFiles(ref DataTable dt, HouseHomeList_Cmd cmd)//, string g_strHidePageName=null)
        {
            string[] strFiles = Directory.GetFiles(cmd.FilePath, string.Format("*{0}", cmd.FileExt));

            //string[] m_strHidePageNameArray = g_strHidePageName.Split(';');

            //例外清單
            var IgnoreFileList = GetIgnoreFile();

            for (int i = 0; i <= strFiles.Length - 1; i++)
            {
                string strFileData = strFiles[i];

                string[] aryFileName = strFiles[i].Split('\\');
                string strFileName = aryFileName[aryFileName.Length - 1];
                Logger.Debug(">>>>> " + strFileName);

                bool isOk = true;
                if (cmd.EnterPageName.Equals(strFileName)) isOk = false;
                //比對例外清單
                if (IgnoreFileList.Any(strFileName.Contains))
                    isOk = false;

                foreach (String sexcludePageName in cmd.excludePageName)
                {
                    if (sexcludePageName.Equals(strFileName)) isOk = false;
                    //比對例外清單
                    if (IgnoreFileList.Any(sexcludePageName.Contains))
                        isOk = false;
                }


                if (isOk)
                {
                    DataRow dr = dt.NewRow();
                    dr["TitleName"] = getTitle(strFileData);
                    dr["PgName"] = strFileName;
                    dr["Url"] = cmd.WebPagePath.Replace("\\", "/");
                    Logger.Debug(">>>>> " + dr["Url"].ToString());
                    dt.Rows.Add(dr);
                }

            }
        }

        private string getTitle(string filepath)
        {
            string result = "";
            StreamReader reader = new StreamReader(filepath, System.Text.Encoding.GetEncoding("utf-8"));
            while (!reader.EndOfStream)
            {
                string strLineData = reader.ReadLine();
                if (strLineData.IndexOf("<title>") > 0)
                {
                    XmlDocument xmlparse = new XmlDocument();
                    xmlparse.LoadXml(strLineData);

                    XmlNodeList elemlist = xmlparse.GetElementsByTagName("title");

                    result = elemlist[0].InnerXml;

                }
            }
            reader.Close();
            Logger.Debug(result);
            return result;
        }


        /// <summary>
        /// 房貸清單頁面 維護... 
        /// 傳入參數
        /// </summary>
        public class HouseHomeList_Cmd
        {
            //public String LanguageType = "zh-TW";
            public String EmpNo = "621164";      // LastUpdate_EmpID ..... 員編
            public String RoleNo = "sa";       // LastUpdate_EmpRole ... 角色
            public String BranchNo = "M001";     // LastUpdate_BranchID .. 單位
                                                 // LastUpdate_Date ...... 最後更新日期時間
            public String LocationPath = "/eLoan/Query/House/SKL_1_0_Maintain_HouseHome.html";
            public String EnterPageName = "SKL_1_0_Maintain_HouseHome.html";
            public String[] excludePageName = new String[] { "SKL_1_1_Maintain_Interest_Project_Breach.html" };
            public String FilePath;
            public String WebPagePath;
            public String FileExt;
        }
        
        /// <summary>
        /// 例外清單
        /// </summary>
        /// <returns></returns>
        private List<string> GetIgnoreFile()
        {
            var RoleNo = g_clsSessionSecurity.RoleNo;
            var IgnoreFL = new List<string>();

            switch (RoleNo)
            {
                case "83":
                case "93":
                    //核准額度維護
                    IgnoreFL.Add("SKL_1_15_Maintain_Approve_Account.html");
                    break;
                case "80":
                case "90":
                    //指標利率維護
                    IgnoreFL.Add("SKL_1_1_Maintain_Interest_Point.html");
                    //職業 / 行業維護
                    IgnoreFL.Add("SKL_1_2_Maintain_AML_Job.html");
                    break;
                default:
                    break;
            }
            return IgnoreFL;
        }
    }
}
