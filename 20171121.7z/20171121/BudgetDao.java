﻿package tw.com.skl.exp.kernel.model6.dao;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import tw.com.skl.common.model6.dao.BaseDao;
import tw.com.skl.exp.kernel.model6.bo.BfmBudgetItem;
import tw.com.skl.exp.kernel.model6.bo.BfmDepartment;
import tw.com.skl.exp.kernel.model6.bo.Budget;
import tw.com.skl.exp.kernel.model6.bo.BudgetYear;
import tw.com.skl.exp.kernel.model6.bo.DepartmentLargeType;
import tw.com.skl.exp.kernel.model6.bo.ProjectBudget;





public interface BudgetDao extends BaseDao<Budget, String> {

	/**
	 * @author 淑華 FUN1.1
	 * @param parentBudget
	 * @return
	 */
	// Budget updateChildrenBudgetsBudgetStateType(final Budget parentBudget);

	/**
	 * Fun 2.1,Fun2.2
	 * @author 偉哲
	 * 依據傳入的預算，來查詢預算，主要是查詢到是否允許編列的資料	 * 
	 * 
	 * @param budget
	 * @return
	 */
	Budget readBudgetByBudget(Budget budget);
	
	//RE201702668 start
	Budget readBudgetByYear(BudgetYear budgetYear);
	//RE201702668 end
	
	/**
	 * Fun2.2,Fun3.3 or 需要子項預算的功能 當子項預算之前未被讀取出來時，則使用此函式初始化讀取子項預算 p.s會遞迴讀取所有子項預算
	 * 
	 * @author 偉哲
	 * @param parentBudget
	 */
	Budget readInitializeChildrenBudgets(Budget parentBudget);

	/**
	 * Fun2.3 部室人力配置
	 * 
	 * @author 芷筠 依據部門和年份, 傳回Budget dropped=false
	 * @param department
	 * @param year
	 */
	Budget readByDepartmentAndYear(BfmDepartment department, int year);

	/**
	 * Fun2.3 部室人力配置
	 * 
	 * @author 芷筠 依據部門和年份, 傳回該部門及其子層部門Budget 
	 * dropped=false
	 * @param department
	 * @param year
	 */
	List<Budget> readByDepartmentAndYearIncludeChildren(BfmDepartment department,
			int year);
	
	/**
	 * Fun2.3 部室人力配置
	 * 
	 * @author 芷筠 依據部門和年份, 傳回該部門及但不包含子層部門Budget 
	 * dropped=false
	 * @param department
	 * @param year
	 */
	List<Budget> readByDepartmentAndYearWithoutChildren(BfmDepartment department,
			int year);	

	/**
	 * FUN3.2
	 * 找出同一DepartmentLargeType的Budget
	 */
	List<Budget> readBudgetByTheSameDepLargeType(DepartmentLargeType depLarType);
	
	/**
	 * Fun5.1 
	 * 1.依年度查詢出可上傳的預算 
	 * 2.BudgetStateType=(5、6、10、12)
	 * 3.Department的是否上傳大電腦為true 
	 * 4.Department為部級
	 * 5.預算表的dropped必須為false
	 * 6.編列單位未被裁撤且編列單位的裁撤日為null 或 預算的年度小於等於編列單位裁撤日的年度
	 * 7.預算表的年度=查詢年度
	 * 8.departmentLargeType in (1, 2, 3, 6)
	 * 
	 * @偉哲
	 * @param year
	 * @return
	 */
	List<Budget> readCouldUploadBudgetByYear(final BudgetYear budgetYear);

	/**
	 * Fun5.1 
	 * 1.依年度查詢出不可上傳的預算 
	 * 2.Department的是否上傳大電腦為false 
	 * 3.Department為部級
	 * 4.預算表的dropped必須為false
	 * 5.編列單位未被裁撤且編列單位的裁撤日為null 或 預算的年度小於等於編列單位裁撤日的年度
	 * 6.預算表的年度=查詢年度
	 * 
	 * @偉哲
	 * @param year
	 * @return
	 */
	List<Budget> readCouldNotUploadBudgetByYear(final BudgetYear budgetYear);

	/**
	 * FUN 6.2 依據 年度查詢全部單位預算追加減 2008.4.29新增 BY文珊
	 *  1.已考量編列單位裁 
	 *  2.包含子層編列單位
	 * @param department
	 * @param budgetYear
	 * @return
	 */
	List readBudgetChangeSummartByYear(final BudgetYear budgetYear);
	
	/**
	 * FUN 6.2 依據 年度、單位名稱 查詢預算追加減 1.已考量編列單位裁 2.包含子層編列單位
	 * 
	 * @param department
	 * @param budgetYear
	 * @return
	 */
	List readBudgetChangeSummartByDepAndYear(
			final BfmDepartment department, final BudgetYear budgetYear);

	/**
	 * FUN 7.3 依據預算項目、年度、單位名稱查詢單位預算 1.包含預算追加減、人件費 2.已考量編列單位裁撤與重編製 3.包含子層編列單位
	 * 
	 * @param budgetItem
	 * @param department
	 * @param budgetYear
	 * @return
	 */
	List readBudgetItemSummaryByBudgetItemAndDepAndYear(
			final BfmBudgetItem budgetItem, final BfmDepartment department,
			final BudgetYear budgetYear);

	/**
	 * FUN 7.3 依據 預算項目、年度 查詢預算 1.包含預算追加減、人件費 2.已考量編列單位裁撤與重編製 3.包含子層編列單位
	 * 
	 * @param budgetItem
	 * @param budgetYear
	 * @return
	 */
	List readBudgetItemSummaryByBudgetItemAndYear(
			final BfmBudgetItem budgetItem, final BudgetYear budgetYear);

	/**
	 * FUN 7.4 依據 專案、年度、單位名稱 查詢專案預算項目 1.包含預算追加減 2.已考量編列單位裁撤與重編製 3.包含子層編列單位
	 * 
	 * @param projectBudget
	 * @param department
	 * @param budgetYear
	 * @return
	 */
	List readProjectBudgetSummaryByProjectBudgetAndDepAndYear(
			final ProjectBudget projectBudget, final BfmDepartment department,
			final BudgetYear budgetYear);

	/**
	 * FUN 7.5 依據編列單位ID、年份依據年份查詢編列單位預算 1.包含預算追加減、人件費 2.已考量編列單位裁撤與重編製 3.包含子層編列單位
	 * 
	 * @param department
	 * @param budgetYear
	 * @return
	 */
	List readBudgetSummaryByDepartmentAndYearForSearchBudget(
			final BfmDepartment department, final BudgetYear budgetYear);

	/**
	 * FUN 7.5 依據年份查詢公司所有編列單位預算 1.包含預算追加減、人件費 2.已考量編列單位裁撤與重編製
	 * 
	 * @param budgetYear
	 * @return
	 */
	List readBudgetSummaryByYearForSearchBudget(
			final BudgetYear budgetYear);

	/**
	 * Fun7.7.0 依據年度查詢未丟棄的預算 BudgetStateType=(6、10、12) dropped=false
	 * method要load cLastYearBudgets, monthBudgets,
	 * humanAllocations(包含其下的humanAllocationItems), 和
	 * projectBudgets(包含其下的projectBudgetItems, budgetChanges和budgetChangeItems)
	 * 
	 * @param budgetYear
	 * @return
	 */
	List<Budget> readBudgetByDepartmentAndYearForRebudget(BudgetYear budgetYear);

	/**
	 * Fun7.8 事業費用(檢核金額)輸入
	 * 
	 * @author 芷筠 依據年份, 傳回該年份尚未達到5預算狀態的預算表的數目
	 * @param year
	 * @return
	 */
	int readCountByBudgetYearForOperatingData(final int year);

	/**
	 * Fun7.8 事業費用(檢核金額)輸入
	 * 
	 * @author 芷筠 依據年份, 傳回所有預算表用以進行更新預算狀態為6
	 * @param year
	 * @return
	 */
	List<Budget> readByBudgetYearForOperatingData(final int year);

	/**
	 * Fun7.9.2
	 * 
	 * @author 文珊
	 * @param budgetYear
	 * @return
	 */
	List<Budget> readOverTimeForSectionDepartment(final int budgetYear);

	/**
	 * Fun7.9.2
	 * 
	 * @author 文珊
	 * @param budgetYear
	 * @return
	 */
	int readCountByOverTimeBudget(final int budgetYear);


	/**
	 * Fun7.12 彙總查詢
	 * 
	 * @author 芷筠 依據年份, 回傳所有部級單位名稱, 辦公費, 人件費
	 * @param year
	 * @return
	 */
	List readByBudgetYearForBudgetSummary(final int year);

	/**
	 * Fun7.12 彙總查詢
	 * 
	 * @author 芷筠 依據年份,部門, 回傳該單位之單位名稱, 辦公費, 人件費
	 * @param year
	 * @return
	 */
	List readByBudgetYearAndDepartmentForBudgetSummary(
			final int year, final BfmDepartment department);

	/**
	 * Fun7.13 狀態查詢 
	 * 傳入預算年度, 回傳budget
	 * @author 芷筠
	 * @param firstResult
	 * @param maxResults
	 * @param budgetYear
	 */
	List<Budget> readByBudgetYearForBudgetState(final int firstResult,
			final int maxResults, final int budgetYear);

	/**
	 * Fun7.13 狀態查詢 
	 * 傳入預算年度, 回傳budget數目
	 * @author 芷筠
	 * @param firstResult
	 * @param maxResults
	 * @param budgetYear
	 */
	int readCountByBudgetYearForBudgetState(final int budgetYear);

	/**
	 * Fun7.13 狀態查詢 
	 * 傳入預算年度和預算狀態Id, 回傳budget
	 * @author 芷筠
	 * @param firstResult
	 * @param maxResults
	 * @param budgetYear
	 * @param budgetStateTypeId
	 */
	List<Budget> readByBudgetYearAndBudgetStateTypeForBudgetState(final int firstResult,
			final int maxResults, final int budgetYear, final int budgetStateTypeId);

	/**
	 * Fun7.13 狀態查詢 
	 * 傳入預算年度和預算狀態Id, 回傳budget數目
	 * @author 芷筠
	 * @param firstResult
	 * @param maxResults
	 * @param budgetYear
	 * @param budgetStateTypeId
	 */
	int readCountByBudgetYearAndBudgetStateTypeForBudgetState(final int budgetYear, final int budgetStateTypeId);

	/**
	 * Fun7.14 建立年度預算表
	 * 依據部門與年度查詢出預算表資料，Fetch ProjectBudget,ProjectBudgetItem
	 * @author 偉哲
	 * @param department
	 * @param budgetYear
	 * @return
	 */
	Budget readBudgetByDepartmentAndBudgetYear(BfmDepartment department, BudgetYear budgetYear);

	/**
	 * Fun 4.1 編列月預算
	 * 
	 * @author 芷筠 依據年份, 部門, 回傳該單位的budget
	 * @param year
	 * @param department
	 * @return
	 */
	List<Budget> readByBudgetYearAndDepartmentForMonthBudget(final int year,
			final BfmDepartment department);

	/**
	 * Fun7.2.2 單位裁撤
	 * 
	 * @author 芷筠 依據部門與年度, 回傳預算 dropped=false
	 * @param department
	 * @param year
	 * @return
	 */
	List<Budget> readByDepartmentAndYearForDepartmentChange(
			final BfmDepartment department, final int year);

	/**
	 * Fun7.2.2 單位裁撤
	 * 
	 * @author 芷筠 依據部門與年度, 回傳預算 method包括父子層的projectBudget, projectBudgetItem,
	 *         budgetChange, budgetChangeItem, dropped=false
	 * @param department
	 * @param year
	 * @return
	 */
	List<Budget> readByDepartmentAndYearForCopyForDepartmentChange(
			final BfmDepartment department, final int year);

	
	/**
	 * 需要預算狀態的功能 當預算狀態之前未被讀取出來時，則使用此函式初始化讀取預算狀態
	 * 
	 * @author 偉哲
	 * @param parentBudget
	 */
	Budget readInitializeBudgetStateType(Budget budget);

	/**
	 * 需要一般行政或專案的功能 當預一般行政或專案之前未被讀取出來時，則使用此函式初始化讀取一般行政或專案
	 * 
	 * @author 偉哲
	 * @param budget
	 */
	Budget readInitializeProjectBudgets(Budget budget);

	/**
	 * 需要編列單位的功能 當預編列單位之前未被讀取出來時，則使用此函式初始化讀取編列單位
	 * 
	 * @author 偉哲
	 * @param budget
	 */
	Budget readInitializeDepartment(Budget budget);

	/**
	 * 需要編列單位的功能 當預編列單位之前未被讀取出來時，則使用此函式初始化讀取編列單位
	 * 
	 * @author 芷筠
	 * @param budget
	 */
	Budget readInitializeParentBudget(Budget budget);
	
	/**
	 * 需要初始化上一年度預算實支的功能 當需要初始化上一年度預算實支的功能未被讀取出來時，則使用此函式初始化上一年度預算實支的功能
	 * 
	 * @author 偉哲
	 * @param budget
	 */
	Budget readInitializeConfirmLastYearBudgets(Budget budget);
	
   	/**
   	 * 需要初始化月預算的功能
   	 * 當需要初始化月預算的功能未被讀取出來時，則使用此函式初始化月預算的功能
   	 * 
   	 * @author 偉哲
   	 * @param budget
   	 */
   	Budget readInitializeMonthBudgets(Budget budget);
   	
   	/**
   	 * 需要初始化人件費的功能
   	 * 當需要初始化人件費的功能未被讀取出來時，則使用此函式初始化人件費的功能
   	 * 
   	 * @author 偉哲
   	 * @param budget
   	 */
   	Budget readInitializeHumanFees(Budget budget);
   	
   	/**
   	 * 需要初始化人力配置的功能
   	 * 當需要初始化人力配置的功能未被讀取出來時，則使用此函式初始化人力配置的功能
   	 * 
   	 * @author 偉哲
   	 * @param budget
   	 */
   	Budget readInitializeHumanAllocations(Budget budget);
   	
   	/**
   	 * 需要初始化重編制新預算表的功能
   	 * 當需要初始化人力配置的功能未被讀取出來時，則使用此函式初始化人力配置的功能
   	 * 
   	 * @author 文珊
   	 * @param budget
   	 */
	Budget readInitializeNewRebudgetChanges(Budget budget);

	/**
   	 * 需要初始化重編制舊預算表的功能
   	 * 當需要初始化人力配置的功能未被讀取出來時，則使用此函式初始化人力配置的功能
   	 * 
   	 * @author 文珊
   	 * @param budget
   	 */
	Budget readInitializeOldRebudgetChanges(Budget budget);
	
	// RE201301619_新增各部室年度預算下載功能 modify by michael in 2014/02/24 start
	public Budget readByYearAndDepartment(int year, BfmDepartment department);

	// RE201301619_新增各部室年度預算下載功能 modify by michael in 2014/02/24 end
	
	//defect4593_無寫入create(update) user,date問題 CU3178 2017/8/21 START
	/**
	 * 依據傳入年度刪除預算資料表
	 * @param year
	 * @return
	 */
	int deleteBudgetByYear(int year);
	//defect4593_無寫入create(update) user,date問題 CU3178 2017/8/21 END

}
