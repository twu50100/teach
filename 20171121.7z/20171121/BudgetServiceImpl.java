﻿package tw.com.skl.exp.kernel.model6.logic.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import tw.com.skl.common.model6.logic.impl.BaseServiceImpl;
import tw.com.skl.exp.kernel.model6.bo.BfmBudgetItem;
import tw.com.skl.exp.kernel.model6.bo.BfmDepartment;
import tw.com.skl.exp.kernel.model6.bo.Budget;
import tw.com.skl.exp.kernel.model6.bo.BudgetStateType;
import tw.com.skl.exp.kernel.model6.bo.BudgetYear;
import tw.com.skl.exp.kernel.model6.bo.DepartmentLargeType;
import tw.com.skl.exp.kernel.model6.bo.PreparingChange;
import tw.com.skl.exp.kernel.model6.bo.PreparingChangeType;
import tw.com.skl.exp.kernel.model6.bo.ProjectBudget;
import tw.com.skl.exp.kernel.model6.bo.RebudgetChange;
import tw.com.skl.exp.kernel.model6.dao.BudgetDao;
import tw.com.skl.exp.kernel.model6.logic.BudgetChangeItemService;
import tw.com.skl.exp.kernel.model6.logic.BudgetService;
import tw.com.skl.exp.kernel.model6.logic.BudgetYearService;
import tw.com.skl.exp.kernel.model6.logic.PreparingChangeService;
import tw.com.skl.exp.kernel.model6.logic.ProjectBudgetItemService;
import tw.com.skl.exp.kernel.model6.logic.RebudgetChangeService;
import tw.com.skl.exp.kernel.model6.logic.to.BudgetChangeSearchTo;
import tw.com.skl.exp.kernel.model6.logic.to.BudgetItemSearchTo;
import tw.com.skl.exp.kernel.model6.logic.to.BudgetSearchTo;
import tw.com.skl.exp.kernel.model6.logic.to.BudgetSummaryTo;
import tw.com.skl.exp.kernel.model6.logic.to.ProjectBudgetTo;

public class BudgetServiceImpl extends BaseServiceImpl<Budget, String, BudgetDao> implements BudgetService {

	@SuppressWarnings("unused")
	private final static Log LOG = LogFactory.getLog(BudgetServiceImpl.class);
	private RebudgetChangeService rebudgetChangeService;
	private ProjectBudgetItemService projectBudgetItemService;
	private BudgetChangeItemService budgetChangeItemService;
	private PreparingChangeService preparingChangeService;

	private BudgetYearService budgetYearService;

	/*
	 * // 如果要 create or update 時, 要檢查 filed value 是否 duplicat, 請放在這邊 protected
	 * void checkDuplicateFields(Budget budget) {
	 * super.checkDuplicateFieldsByList(budget, new String[]{"field1",
	 * "field2"}, this.getDao().readByField1_Field2(budget.getField1(),
	 * budget.getField2())); }
	 */

	/*
	 * FUN1.1
	 * 
	 * @author:淑華 (non-Javadoc)
	 * 
	 * @see tw.com.skl.bfm.kernel.model5.logic.BudgetService#
	 * updateChildrenParentBudgetsBudgetStateType
	 * (tw.com.skl.bfm.kernel.model5.bo.Budget)
	 */
	public Budget updateChildrenParentBudgetsBudgetStateType(Budget parentBudget) {
		Set<Budget> childrenBudgetList = new HashSet<Budget>();
		parentBudget = this.getDao().findByPK(parentBudget.getId());
		parentBudget.setBudgetStateType(BudgetStateType.MAKE_BUDGET);
		childrenBudgetList.add(this.updateChildrenBudgetsBudgetStateType(parentBudget));
		parentBudget.setChildrenBudgets(childrenBudgetList);
		return this.getDao().update(parentBudget);
	}

	private Budget updateChildrenBudgetsBudgetStateType(final Budget parentBudget) {

		if (parentBudget.getChildrenBudgets().size() > 0) {
			for (Budget childrenBudget : parentBudget.getChildrenBudgets()) {
				childrenBudget.setBudgetStateType(BudgetStateType.MAKE_BUDGET);
				childrenBudget = this.updateChildrenBudgetsBudgetStateType(childrenBudget);
			}
		}
		return parentBudget;
	}

	/**
	 * Fun 2.1,Fun2.2
	 * 
	 * @author 偉哲 依據傳入的預算，來查詢預算，主要是查詢到是否允許編列的資料 *
	 * 
	 * @param budget
	 * @return
	 */
	public Budget readBudgetByBudget(Budget budget) {

		return this.getDao().readBudgetByBudget(budget);
	}

	// RE201702268 start
	public Budget readBudgetByYear(BudgetYear budgetYear) {

		return this.getDao().readBudgetByYear(budgetYear);
	}
	// RE201702268 end
	
	/**
	 * Fun2.3 部室人力配置
	 * 
	 * @author 芷筠 依據部門和年份, 傳回Budget dropped=false
	 * @param department
	 * @param year
	 */
	public Budget readBudgetByDepartmentAndYear(BfmDepartment department, int year) {
		return this.getDao().readByDepartmentAndYear(department, year);
	}

	/**
	 * Fun2.3 部室人力配置
	 * 
	 * @author 芷筠 依據部門和年份, 如果不是經管會, 傳回該部門及其子層部門Budget 如果是經管會, 傳回該部門但無子層部門Budget
	 *         dropped=false
	 * @param department
	 * @param year
	 */
	public List<Budget> readBudgetsByDepartmentAndYear(BfmDepartment department, int year) {
		if (department.getName().compareTo("經管會") == 0) {
			return this.getDao().readByDepartmentAndYearWithoutChildren(department, year);
		} else {
			return this.getDao().readByDepartmentAndYearIncludeChildren(department, year);
		}

	}

	/**
	 * Fun2.3 部室人力配置
	 * 
	 * @author 芷筠 更新加班費預算金額
	 * @param parentBudget
	 */
	public void updateOvertimeBudgetAmountForHumanAllocation(Budget parentBudget) {
		this.getDao().update(parentBudget);
	}

	/**
	 * FUN3.2 1.找出同一DepartmentLargeType,預算狀態為3 or 8的Budget
	 * 2.依核定or退回進行對應的update動作
	 */
	public void readAndUpdateBudgetByTheSameDepLargeType(DepartmentLargeType depLarType, String actionType) {
		List<Budget> budgetList = new ArrayList<Budget>();
		budgetList = this.getDao().readBudgetByTheSameDepLargeType(depLarType);

		if (budgetList.size() > 0) {
			// Initial BudgetStateType並更新之
			for (Budget bo : budgetList) {
				BudgetStateType selectBudgetStateType = null;
				// 退回
				if (actionType == "reject") {
					if (bo.getBudgetStateType().getId().compareTo(BudgetStateType.AUDIT_BUDGET.getId()) == 0) {
						selectBudgetStateType = BudgetStateType.MAKE_BUDGET;
					} else if (bo.getBudgetStateType().getId().compareTo(BudgetStateType.REAUDIT_BUDGET.getId()) == 0) {
						selectBudgetStateType = BudgetStateType.REMAKE_BUDGET;
					}

					// 核定
				} else if (actionType == "audit") {
					if (bo.getBudgetStateType().getId().compareTo(BudgetStateType.AUDIT_BUDGET.getId()) == 0) {
						selectBudgetStateType = BudgetStateType.APPROVE_BUDGET;
					} else if (bo.getBudgetStateType().getId().compareTo(BudgetStateType.REAUDIT_BUDGET.getId()) == 0) {
						// 舊預算表
						long oldProjectBudgetAmount = 0;
						// 舊預算表追加減金額
						long oldBudgetChangeAmount = 0;
						// 舊預算表在開放重編制時所退回的預備金
						long rebudgetAmount = 0;
						// 新預算表
						long newProjectBudgetAmount = 0;
						// 差額
						long auditRebudgetAmount = 0;

						// 1.取得新預算表金額(包含子項)
						newProjectBudgetAmount = this.getProjectBudgetItemService().readProjectBudgetItemAmountByBudget(bo);

						// 取得RebudgetChange
						// 理論上取得的RebudgetChange(auditRebudget=false)與budget為OneToOne關係,但仍用List來接
						List<RebudgetChange> rebudgetChangeList = this.getRebudgetChangeService().readRebudgetChangeByBudget(bo);

						for (RebudgetChange rebudgetChange : rebudgetChangeList) {
							// 2.取得舊預算表在開放重編制時所退回的預備金
							rebudgetAmount = rebudgetChange.getRebudgetAmount();

							// 3.取得舊預算表金額(包含子項)
							oldProjectBudgetAmount = this.getProjectBudgetItemService().readProjectBudgetItemAmountByBudget(rebudgetChange.getOldBudget());

							// 4.取得舊預算表追加減金額
							oldBudgetChangeAmount = this.getBudgetChangeItemService().readBudgetChangeItemAmountByOldBudget(rebudgetChange.getOldBudget());

							// 5.計算差額(3+4)-1-2
							auditRebudgetAmount = (oldProjectBudgetAmount + oldBudgetChangeAmount) - newProjectBudgetAmount - rebudgetAmount;

							System.out.println("   ===============new Amount: " + newProjectBudgetAmount);
							System.out.println("   ===============rebudgetAmount: " + rebudgetAmount);
							System.out.println("   ===============old Amount: " + oldProjectBudgetAmount);
							System.out.println("   ===============old Amount: " + oldBudgetChangeAmount);

							// 寫入rebudgetChange
							rebudgetChange.setAuditRebudgetAmount(auditRebudgetAmount);
							rebudgetChange.setAuditRebudget(true);
							this.getRebudgetChangeService().update(rebudgetChange);

							// 紀錄preparingChange
							PreparingChange preparingChange = new PreparingChange();
							preparingChange.setRebudgetChange(rebudgetChange);
							preparingChange.setNotation("重編制審查");
							preparingChange.setPreparingChangeType(PreparingChangeType.REBUDGET_CHANGE_TYPE);

							this.getPreparingChangeService().create(preparingChange);

							// 設定狀態為"重編制預算核定"
							selectBudgetStateType = BudgetStateType.REAPPROVE_BUDGET;
						}
					}
				}
				// 修改父項及子項的預算狀態
				if (selectBudgetStateType != null) {
					this.updateSelfAndChildrenBudgetState(bo, selectBudgetStateType);
				}
			}
		}
	}

	/**
	 * Fun3.3 or 需要子項預算的功能
	 * 
	 * 當子項預算之前未被讀取出來時，則使用此函式初始化讀取子項預算 p.s會遞迴讀取所有子項預算
	 * 
	 * @author 偉哲
	 * @param parentBudget
	 */
	public Budget readInitializeChildrenBudgets(Budget parentBudget) {
		return this.getDao().readInitializeChildrenBudgets(parentBudget);

	}

	/**
	 * Fun 4.1 編列月預算
	 * 
	 * @author 芷筠 依據年份, 部門, 回傳該單位的budget
	 * @param year
	 * @param department
	 * @return
	 */
	public Budget readByBudgetYearAndDepartmentForMonthBudget(final int year, final BfmDepartment department) {

		List<Budget> budgetList = this.getDao().readByBudgetYearAndDepartmentForMonthBudget(year, department);

		Set<Budget> budgetSet = new LinkedHashSet<Budget>();
		for (Budget budget : budgetList) {
			budgetSet.add(budget);
		}
		budgetList.clear();
		budgetList = null;
		budgetList = new ArrayList<Budget>();
		for (Budget budget : budgetSet) {
			budgetList.add(budget);
		}

		budgetSet.clear();
		budgetSet = null;
		Iterator<Budget> iter = budgetList.iterator();

		if (iter.hasNext()) {
			return iter.next();
		} else {
			return null;
		}

	}

	/**
	 * Fun5.1 1.依年度查詢出可上傳的預算 2.BudgetStateType=(5、6、10、12)
	 * 3.Department的是否上傳大電腦為true 4.Department為部級 5.預算表的dropped必須為false
	 * 6.編列單位未被裁撤且編列單位的裁撤日為null 或 預算的年度小於等於編列單位裁撤日的年度 7.預算表的年度=查詢年度
	 * 8.departmentLargeType in (1, 2, 3, 6)
	 * 
	 * @偉哲
	 * @param year
	 * @return
	 */
	public List<Budget> readCouldUploadBudgetByYear(final BudgetYear budgetYear) {

		List<Budget> budgetList = this.getDao().readCouldUploadBudgetByYear(budgetYear);
		Set<Budget> budgetSet = new LinkedHashSet<Budget>(budgetList);

		budgetList.clear();
		budgetList = new ArrayList<Budget>(budgetSet);

		return budgetList;
	}

	/**
	 * Fun5.1 1.依年度查詢出不可上傳的預算 2.Department的是否上傳大電腦為false 3.Department為部級
	 * 4.預算表的dropped必須為false 5.編列單位未被裁撤且編列單位的裁撤日為null 或 預算的年度小於等於編列單位裁撤日的年度
	 * 6.預算表的年度=查詢年度
	 * 
	 * @偉哲
	 * @param year
	 * @return
	 */
	public List<Budget> readCouldNotUploadBudgetByYear(final BudgetYear budgetYear) {
		List<Budget> budgetList = this.getDao().readCouldNotUploadBudgetByYear(budgetYear);
		Set<Budget> budgetSet = new LinkedHashSet<Budget>(budgetList);

		budgetList.clear();
		budgetList = new ArrayList<Budget>(budgetSet);
		return budgetList;
	}

	/**
	 * Fun3.2,Fun3.3,Fun5.2 依據父層編製單位的預算表，將自身的預算表與子層單位的預算表，更新為傳入的預算狀態
	 * 
	 * @author 偉哲
	 * @param parentBudget
	 * @param budgetStateType
	 * 
	 */
	public void updateSelfAndChildrenBudgetState(Budget parentBudget, final BudgetStateType budgetStateType) {

		parentBudget = this.getDao().readInitializeChildrenBudgets(parentBudget);
		parentBudget = Budget.updateBudgetStateTypeIncludeChildrenBudgets(parentBudget, budgetStateType);

		// System.out.println("budget.id="+parentBudget.getId());
		// System.out.println("budget.childrenBudgets.size="+parentBudget.getChildrenBudgets().size());
		// System.out.println("budget.budgetStateType="+parentBudget.getBudgetStateType().getName());
		// for(Budget childrenBudget : parentBudget.getChildrenBudgets()){
		// System.out.println("budget.id="+parentBudget.getId());
		// System.out.println("childrenBudget.budgetStateType="+childrenBudget.getBudgetStateType().getName());

		// }
		// System.out.println("End");
		this.getDao().update(parentBudget);
	}

	/**
	 * FUN 6.2 依據 年度查詢全部單位預算追加減 2008.4.29新增 BY文珊 1.已考量編列單位裁 2.包含子層編列單位
	 * 
	 * @param department
	 * @param budgetYear
	 * @return
	 */
	public List<BudgetChangeSearchTo> readBudgetChangeSummartByYear(final BudgetYear budgetYear) {
		List result = this.getDao().readBudgetChangeSummartByYear(budgetYear);
		List<BudgetChangeSearchTo> budgetChangeSearchToList = new ArrayList<BudgetChangeSearchTo>();
		for (Object object : result) {
			BudgetChangeSearchTo budgetchangeSearchTo = new BudgetChangeSearchTo();
			Object[] results = (Object[]) object;
			budgetchangeSearchTo.setBudgetChangeId(results[0] == null ? 0l : Long.parseLong(results[0].toString()));
			budgetchangeSearchTo.setCode(results[1].toString());
			budgetchangeSearchTo.setUploadFileAddress(results[2] == null ? "---" : results[2].toString());
			budgetchangeSearchTo.setDepartmentName(results[3].toString());
			budgetChangeSearchToList.add(budgetchangeSearchTo);
		}
		return budgetChangeSearchToList;
	}

	/**
	 * FUN 6.2 依據 年度、單位名稱 查詢預算追加減 1.已考量編列單位裁 2.包含子層編列單位
	 * 
	 * @param department
	 * @param budgetYear
	 * @return
	 */
	public List<BudgetChangeSearchTo> readBudgetChangeSummartByDepAndYear(final BfmDepartment department, final BudgetYear budgetYear) {
		List result = this.getDao().readBudgetChangeSummartByDepAndYear(department, budgetYear);
		List<BudgetChangeSearchTo> budgetChangeSearchToList = new ArrayList<BudgetChangeSearchTo>();
		for (Object object : result) {
			BudgetChangeSearchTo budgetchangeSearchTo = new BudgetChangeSearchTo();
			Object[] results = (Object[]) object;
			budgetchangeSearchTo.setBudgetChangeId(results[0] == null ? 0l : Long.parseLong(results[0].toString()));
			budgetchangeSearchTo.setCode(results[1].toString());
			budgetchangeSearchTo.setUploadFileAddress(results[2] == null ? "---" : results[2].toString());
			budgetchangeSearchTo.setDepartmentName(results[3].toString());
			budgetChangeSearchToList.add(budgetchangeSearchTo);
		}
		return budgetChangeSearchToList;
	}

	/**
	 * FUN 7.3 依據預算項目、年度、單位名稱查詢單位預算 1.包含預算追加減、人件費 2.已考量編列單位裁撤與重編製 3.包含子層編列單位
	 * 4.2008.5.7以部門為單位檢視各預算項目的金額 BY.文珊
	 * 
	 * @author 文珊
	 * @param budgetItem
	 * @param department
	 * @param budgetYear
	 * @return
	 */
	public List<BudgetItemSearchTo> readBudgetItemSummaryByBudgetItemAndDepAndYear(final BfmBudgetItem budgetItem, final BfmDepartment department, final BudgetYear budgetYear) {
		List result = this.getDao().readBudgetItemSummaryByBudgetItemAndDepAndYear(budgetItem, department, budgetYear);
		List<BudgetItemSearchTo> budgetItemSearchToList = new ArrayList<BudgetItemSearchTo>();
		for (Object object : result) {
			BudgetItemSearchTo budgetItemSearchTo = new BudgetItemSearchTo();
			Object[] results = (Object[]) object;
			budgetItemSearchTo.setBudgetItemName(results[0].toString());
			budgetItemSearchTo.setTotalYearBudget(results[1] == null ? 0l : Long.parseLong(results[1].toString()));
			budgetItemSearchTo.setDepartmentName(department.getName());
			budgetItemSearchToList.add(budgetItemSearchTo);
		}
		return budgetItemSearchToList;
	}

	/**
	 * FUN 7.3 依據 預算項目、年度 查詢預算 1.包含預算追加減、人件費 2.已考量編列單位裁撤與重編製 3.包含子層編列單位
	 * 4.2008.5.7以部門為單位檢視各預算項目的金額 BY.文珊 5.order by department.id
	 * 
	 * @param budgetItem
	 * @param budgetYear
	 * @return
	 */
	public List<BudgetItemSearchTo> readBudgetItemSummaryByBudgetItemAndYear(final BfmBudgetItem budgetItem, final BudgetYear budgetYear) {
		List result = this.getDao().readBudgetItemSummaryByBudgetItemAndYear(budgetItem, budgetYear);
		List<BudgetItemSearchTo> budgetItemSearchToList = new ArrayList<BudgetItemSearchTo>();
		Map<String, BudgetItemSearchTo> resultMap = new TreeMap<String, BudgetItemSearchTo>();
		for (Object object : result) {
			Object[] results = (Object[]) object;
			long totalYearBudget = results[1] == null ? 0l : Long.parseLong(results[1].toString());
			// 整合重複編列預算的單位，加總其預算金額
			if (!resultMap.containsKey(results[2].toString())) {
				BudgetItemSearchTo budgetItemSearchTo = new BudgetItemSearchTo();
				budgetItemSearchTo.setBudgetItemName(results[0].toString());
				budgetItemSearchTo.setTotalYearBudget(totalYearBudget);
				budgetItemSearchTo.setDepartmentName(results[2].toString());

				resultMap.put(results[2].toString(), budgetItemSearchTo);
			} else {
				BudgetItemSearchTo budgetItemSearchTo = resultMap.get(results[2].toString());
				totalYearBudget = budgetItemSearchTo.getTotalYearBudget() + totalYearBudget;
				budgetItemSearchTo.setTotalYearBudget(totalYearBudget);
			}
		}

		Iterator iter = resultMap.entrySet().iterator();
		while (iter.hasNext()) {
			Map.Entry entry = (Map.Entry) iter.next();
			budgetItemSearchToList.add((BudgetItemSearchTo) entry.getValue());
		}

		return budgetItemSearchToList;
	}

	/**
	 * FUN 7.4 依據 專案、年度、單位名稱 查詢專案預算項目 1.包含預算追加減 2.已考量編列單位裁撤與重編製 3.包含子層編列單位
	 * 
	 * @param projectBudget
	 * @param department
	 * @param budgetYear
	 * @return
	 */
	public List<ProjectBudgetTo> readProjectBudgetSummaryByProjectBudgetAndDepAndYear(final ProjectBudget projectBudget, final BfmDepartment department, final BudgetYear budgetYear) {
		List result = this.getDao().readProjectBudgetSummaryByProjectBudgetAndDepAndYear(projectBudget, department, budgetYear);

		List<ProjectBudgetTo> projectBudgetToList = new ArrayList<ProjectBudgetTo>();
		for (Object object : result) {
			ProjectBudgetTo projectBudgetTo = new ProjectBudgetTo();
			Object[] results = (Object[]) object;
			projectBudgetTo.setBudgetItemName(results[0].toString());
			projectBudgetTo.setTotalYearBudget(results[1] == null ? 0l : Long.parseLong(results[1].toString()));
			projectBudgetToList.add(projectBudgetTo);
		}
		return projectBudgetToList;
	}

	/**
	 * FUN 7.5 依據編列單位ID、年份依據年份查詢編列單位預算 1.包含預算追加減、人件費 2.已考量編列單位裁撤與重編製 3.包含子層編列單位
	 * 
	 * @param department
	 * @param budgetYear
	 * @return
	 */
	public List<BudgetSearchTo> readBudgetSummaryByDepartmentAndYearForSearchBudget(final BfmDepartment department, final BudgetYear budgetYear) {
		List results = this.getDao().readBudgetSummaryByDepartmentAndYearForSearchBudget(department, budgetYear);

		List<BudgetSearchTo> budgetSearchToList = new ArrayList<BudgetSearchTo>();
		for (Object object : results) {

			Object[] eachRow = (Object[]) object;
			BudgetSearchTo budgetSearchTo = new BudgetSearchTo(Long.parseLong(eachRow[1] == null ? "0" : eachRow[0].toString()), eachRow[1].toString(), Long.parseLong(eachRow[2] == null ? "0" : eachRow[2].toString()), Long.parseLong(eachRow[3] == null ? "0" : eachRow[3].toString()), Long.parseLong(eachRow[4] == null ? "0" : eachRow[4].toString()), Long.parseLong(eachRow[5] == null ? "0" : eachRow[5].toString()), Long.parseLong(eachRow[6] == null ? "0" : eachRow[6].toString()), Long.parseLong(eachRow[7] == null ? "0" : eachRow[7].toString()), Long.parseLong(eachRow[8] == null ? "0" : eachRow[8].toString()), eachRow[9].toString(), Long.parseLong(eachRow[10] == null ? "0" : eachRow[10].toString()), eachRow[11].toString()

			);

			budgetSearchToList.add(budgetSearchTo);
		}
		return budgetSearchToList;

	}

	/**
	 * FUN 7.5 依據年份查詢公司所有編列單位預算 1.包含預算追加減、人件費 2.已考量編列單位裁撤與重編製
	 * 
	 * @param budgetYear
	 * @return
	 */
	public List<BudgetSearchTo> readBudgetSummaryByYearForSearchBudget(final BudgetYear budgetYear) {
		List results = this.getDao().readBudgetSummaryByYearForSearchBudget(budgetYear);

		List<BudgetSearchTo> budgetSearchToList = new ArrayList<BudgetSearchTo>();
		for (Object object : results) {

			Object[] eachRow = (Object[]) object;
			BudgetSearchTo budgetSearchTo = new BudgetSearchTo(Long.parseLong(eachRow[1] == null ? "0" : eachRow[0].toString()), eachRow[1].toString(), Long.parseLong(eachRow[2] == null ? "0" : eachRow[2].toString()), Long.parseLong(eachRow[3] == null ? "0" : eachRow[3].toString()), Long.parseLong(eachRow[4] == null ? "0" : eachRow[4].toString()), Long.parseLong(eachRow[5] == null ? "0" : eachRow[5].toString()), Long.parseLong(eachRow[6] == null ? "0" : eachRow[6].toString()), Long.parseLong(eachRow[7] == null ? "0" : eachRow[7].toString()), Long.parseLong(eachRow[8] == null ? "0" : eachRow[8].toString()), eachRow[9].toString(), Long.parseLong(eachRow[10] == null ? "0" : eachRow[10].toString()), eachRow[11].toString()

			);

			budgetSearchToList.add(budgetSearchTo);
		}
		return budgetSearchToList;
	}

	/**
	 * Fun7.7.0 依據部門與年度查詢未丟棄的預算 BudgetStateType=(6、10、12) dropped=false
	 * method要load cLastYearBudgets, monthBudgets,
	 * humanAllocations(包含其下的humanAllocationItems), 和
	 * projectBudgets(包含其下的projectBudgetItems, budgetChanges和budgetChangeItems)
	 * 
	 * 
	 * @param budgetYear
	 * @return
	 */
	public List<Budget> readBudgetByDepartmentAndYearForRebudget(BudgetYear budgetyear) {
		return this.getDao().readBudgetByDepartmentAndYearForRebudget(budgetyear);

	}

	/**
	 * Fun7.7.0 依據父層編製單位的預算表，將自身的預算表與子層單位的預算表，更新為預算狀態7和預算已丟棄
	 * 
	 * @param parentBudget
	 */
	public void updateSelfAndChildrenBudgetStateAndDropped(Budget parentBudget) {

	}

	/**
	 * Fun7.7.0 依據父層編製單位的預算表，複製出新的自身預算表,子層單位預算表 及其相關的資料表(monthBudgets,
	 * humanAllocations, projectBudgets) 並更新預算狀態為7,歸零各月預算從重編製操作日當月到12月的預算金額,
	 * 專案預算的rebuilded要設成true(不可刪除)
	 * 
	 * @param parentBudget
	 */
	public void creaetNewBudgetForRebudget(Budget parentBudget) {

	}

	/**
	 * Fun7.2.2 單位裁撤
	 * 
	 * @author 芷筠 依據父層編製單位的預算表，將自身的預算表與子層單位的預算表，dropped設成true
	 * @param parentBudget
	 */
	public void updateSelfAndChildrenBudgetDropped(Budget parentBudget) {

		parentBudget = this.getDao().readInitializeChildrenBudgets(parentBudget);
		parentBudget = Budget.updateDroppedIncludeChildrenBudgets(parentBudget, true);

		this.getDao().update(parentBudget);
	}

	/**
	 * Fun7.2.2 單位裁撤
	 * 
	 * @author 芷筠 依據部門與年度, 回傳預算 dropped=false method要load monthBudgets
	 * @param department
	 * @param year
	 * @return
	 */
	public Budget readBudgetByDepartmentAndYearForDepartmentChange(final BfmDepartment department, final int year) {
		List<Budget> budgetList = this.getDao().readByDepartmentAndYearForDepartmentChange(department, year);
		Set<Budget> budgetSet = new LinkedHashSet<Budget>(budgetList);
		budgetList.clear();
		budgetList = new ArrayList<Budget>(budgetSet);

		if (budgetList.size() > 0) {
			return budgetList.get(0);
		} else {
			return null;
		}

	}

	/**
	 * Fun7.2.2 單位裁撤
	 * 
	 * @author 芷筠 依據部門與年度, 回傳預算 method包括父子層的projectBudget, projectBudgetItem,
	 *         budgetChange, budgetChangeItem, dropped=false
	 * @param department
	 * @param year
	 * @return
	 */
	public Budget readBudgetByDepartmentAndYearForCopyForDepartmentChange(final BfmDepartment department, final int year) {
		List<Budget> budgetList = this.getDao().readByDepartmentAndYearForCopyForDepartmentChange(department, year);
		Set<Budget> budgetSet = new LinkedHashSet<Budget>(budgetList);
		budgetList.clear();
		budgetList = new ArrayList<Budget>(budgetSet);

		if (budgetList.size() > 0) {
			return budgetList.get(0);
		} else {
			return null;
		}

	}

	/**
	 * Fun7.8 事業費用輸入
	 * 
	 * @author 芷筠 更改今年所有未丟棄的預算的預算狀態成為6
	 * @param year
	 */
	public void updateBudgetStateForOperatingData(final int year) {
		List<Budget> budgetList = this.getDao().readByBudgetYearForOperatingData(year);
		for (Budget budget : budgetList) {
			budget.setBudgetStateType(BudgetStateType.BUSINESS_FEE);
			this.update(budget);
		}
	}

	/**
	 * Fun7.8 事業費用(檢核金額)輸入
	 * 
	 * @author 芷筠 依據年份, 傳回該年份尚未達到5預算狀態的預算表的數目
	 * @param year
	 * @return
	 */
	public int readCountByBudgetYearForOperatingData(final int year) {
		return this.getDao().readCountByBudgetYearForOperatingData(year);
	}

	/**
	 * Fun7.9.2 編列單位加班費用查詢
	 * 
	 * @author 文珊
	 * @param budgetYear
	 * @return
	 */
	public List<Budget> readOverTimeForSectionDepartment(final int budgetYear) {
		List<Budget> budgetList = new ArrayList<Budget>();
		budgetList = this.getDao().readOverTimeForSectionDepartment(budgetYear);
		return budgetList;
	}

	/**
	 * Fun7.9.2 編列單位加班費用查詢
	 * 
	 * @author 文珊
	 * @param budgetYear
	 * @return
	 */
	public int readCountByOverTimeBudget(final int budgetYear) {
		int i = this.getDao().readCountByOverTimeBudget(budgetYear);
		return i;
	}

	/**
	 * Fun7.12 彙總查詢
	 * 
	 * @author 芷筠 依據年份, 回傳所有部級單位名稱, 辦公費, 人件費
	 * @param year
	 * @return
	 */
	public List<BudgetSummaryTo> readByBudgetYearForBudgetSummary(final int year) {
		List result = this.getDao().readByBudgetYearForBudgetSummary(year);

		List<BudgetSummaryTo> budgetSummaryList = new ArrayList<BudgetSummaryTo>();
		for (Object object : result) {
			BudgetSummaryTo budgetSummaryTo = new BudgetSummaryTo();
			Object[] results = (Object[]) object;
			budgetSummaryTo.setName(results[0].toString());
			budgetSummaryTo.setOfficeFee(results[1] == null ? 0l : Long.parseLong(results[1].toString()));
			budgetSummaryTo.setHumanFee(results[2] == null ? 0l : Long.parseLong(results[2].toString()));
			budgetSummaryList.add(budgetSummaryTo);
		}
		return budgetSummaryList;
	}

	/**
	 * Fun7.12 彙總查詢
	 * 
	 * @author 芷筠 依據年份,部門, 回傳該單位之單位名稱, 辦公費, 人件費
	 * @param year
	 * @return
	 */
	public List<BudgetSummaryTo> readByBudgetYearAndDepartmentForBudgetSummary(final int year, final BfmDepartment department) {
		List result = this.getDao().readByBudgetYearAndDepartmentForBudgetSummary(year, department);
		List<BudgetSummaryTo> budgetSummaryList = new ArrayList<BudgetSummaryTo>();
		for (Object object : result) {
			BudgetSummaryTo budgetSummaryTo = new BudgetSummaryTo();
			Object[] results = (Object[]) object;
			budgetSummaryTo.setName(results[0].toString());
			budgetSummaryTo.setOfficeFee(results[1] == null ? 0l : Long.parseLong(results[1].toString()));
			budgetSummaryTo.setHumanFee(results[2] == null ? 0l : Long.parseLong(results[2].toString()));
			budgetSummaryList.add(budgetSummaryTo);
		}
		return budgetSummaryList;
	}

	/**
	 * Fun7.13 狀態查詢 傳入預算年度和預算狀態Id, 回傳budget 如果預算狀態Id為0, 則是全部的預算狀態都要撈出
	 * 
	 * @author 芷筠
	 * @param firstResult
	 * @param maxResults
	 * @param budgetYear
	 * @param budgetStateTypeId
	 */
	public List<Budget> readByBudgetYearAndBudgetStateTypeForBudgetState(final int firstResult, final int maxResults, final int budgetYear, final int budgetStateTypeId) {

		List<Budget> budgetList = null;
		if (budgetStateTypeId == 0) {
			budgetList = this.getDao().readByBudgetYearForBudgetState(firstResult, maxResults, budgetYear);
		} else {
			budgetList = this.getDao().readByBudgetYearAndBudgetStateTypeForBudgetState(firstResult, maxResults, budgetYear, budgetStateTypeId);
		}
		Set<Budget> budgetSet = new LinkedHashSet<Budget>();
		for (Budget budget : budgetList) {
			budgetSet.add(budget);
		}
		budgetList.clear();
		budgetList = null;
		budgetList = new ArrayList<Budget>();
		for (Budget budget : budgetSet) {
			budgetList.add(budget);
		}
		budgetSet.clear();
		budgetSet = null;
		return budgetList;
	}

	/**
	 * Fun7.13 狀態查詢 傳入預算年度和預算狀態Id, 回傳budget數目 如果預算狀態Id為0, 則是全部的預算狀態都要撈出
	 * 
	 * @author 芷筠
	 * @param firstResult
	 * @param maxResults
	 * @param budgetYear
	 * @param budgetStateTypeId
	 */
	public int readCountByBudgetYearAndBudgetStateTypeForBudgetState(final int budgetYear, final int budgetStateTypeId) {
		if (budgetStateTypeId == 0) {
			return this.getDao().readCountByBudgetYearForBudgetState(budgetYear);
		} else {
			return this.getDao().readCountByBudgetYearAndBudgetStateTypeForBudgetState(budgetYear, budgetStateTypeId);
		}
	}

	/**
	 * Fun7.14 建立年度預算表 依據部門與年度查詢出預算表資料，Fetch ProjectBudget,ProjectBudgetItem
	 * 
	 * @author 偉哲
	 * @param department
	 * @param budgetYear
	 * @return
	 */
	public Budget readBudgetByDepartmentAndBudgetYear(BfmDepartment department, BudgetYear budgetYear) {
		return this.getDao().readBudgetByDepartmentAndBudgetYear(department, budgetYear);
	}

	/**
	 * 需要預算狀態的功能 當預算狀態之前未被讀取出來時，則使用此函式初始化讀取預算狀態
	 * 
	 * @author 偉哲
	 * @param budget
	 */
	public Budget readInitializeBudgetStateType(Budget budget) {
		return this.getDao().readInitializeBudgetStateType(budget);
	}

	/**
	 * 需要一般行政或專案的功能 當預一般行政或專案之前未被讀取出來時，則使用此函式初始化讀取一般行政或專案
	 * 
	 * @author 偉哲
	 * @param budget
	 */
	public Budget readInitializeProjectBudgets(Budget budget) {
		return this.getDao().readInitializeProjectBudgets(budget);
	}

	/**
	 * 需要編列單位的功能 當預編列單位之前未被讀取出來時，則使用此函式初始化讀取編列單位
	 * 
	 * @author 偉哲
	 * @param budget
	 */
	public Budget readInitializeDepartment(Budget budget) {
		return this.getDao().readInitializeDepartment(budget);
	}

	/**
	 * 需要編列單位的功能 當預編列單位之前未被讀取出來時，則使用此函式初始化讀取編列單位
	 * 
	 * @author 芷筠
	 * @param budget
	 */
	public Budget readInitializeParentBudget(Budget budget) {
		return this.getDao().readInitializeParentBudget(budget);
	}

	/**
	 * 需要初始化上一年度預算實支的功能 當需要初始化上一年度預算實支的功能未被讀取出來時，則使用此函式初始化上一年度預算實支的功能
	 * 
	 * @author 偉哲
	 * @param budget
	 */
	public Budget readInitializeConfirmLastYearBudgets(Budget budget) {
		return this.getDao().readInitializeConfirmLastYearBudgets(budget);
	}

	/**
	 * 需要初始化月預算的功能 當需要初始化月預算的功能未被讀取出來時，則使用此函式初始化月預算的功能
	 * 
	 * @author 偉哲
	 * @param budget
	 */
	public Budget readInitializeMonthBudgets(Budget budget) {
		return this.getDao().readInitializeMonthBudgets(budget);
	}

	/**
	 * 需要初始化人件費的功能 當需要初始化人件費的功能未被讀取出來時，則使用此函式初始化人件費的功能
	 * 
	 * @author 偉哲
	 * @param budget
	 */
	public Budget readInitializeHumanFees(Budget budget) {
		return this.getDao().readInitializeHumanFees(budget);
	}

	/**
	 * 需要初始化人力配置的功能 當需要初始化人力配置的功能未被讀取出來時，則使用此函式初始化人力配置的功能
	 * 
	 * @author 偉哲
	 * @param budget
	 */
	public Budget readInitializeHumanAllocations(Budget budget) {
		return this.getDao().readInitializeHumanAllocations(budget);

	}

	public RebudgetChangeService getRebudgetChangeService() {
		return rebudgetChangeService;
	}

	public void setRebudgetChangeService(RebudgetChangeService rebudgetChangeService) {
		this.rebudgetChangeService = rebudgetChangeService;
	}

	public ProjectBudgetItemService getProjectBudgetItemService() {
		return projectBudgetItemService;
	}

	public void setProjectBudgetItemService(ProjectBudgetItemService projectBudgetItemService) {
		this.projectBudgetItemService = projectBudgetItemService;
	}

	public BudgetChangeItemService getBudgetChangeItemService() {
		return budgetChangeItemService;
	}

	public void setBudgetChangeItemService(BudgetChangeItemService budgetChangeItemService) {
		this.budgetChangeItemService = budgetChangeItemService;
	}

	public PreparingChangeService getPreparingChangeService() {
		return preparingChangeService;
	}

	public void setPreparingChangeService(PreparingChangeService preparingChangeService) {
		this.preparingChangeService = preparingChangeService;
	}

	// RE201301619_新增各部室年度預算下載功能 modify by michael in 2014/02/24 start
	public void updateBudget(Long budgetId, BudgetStateType budgetStateType) {

		Budget budget = this.getDao().findByPK(budgetId.toString());

		budget.setBudgetStateType(budgetStateType);
		this.update(budget);
	}

	public Budget getLastYearBudgetByDepartment(BfmDepartment dep) {

		BudgetYear lastBudgetYear = getBudgetYearService().readTheLastYear();

		return getDao().readByYearAndDepartment(lastBudgetYear.getYear(), dep);
	}

	public BudgetYearService getBudgetYearService() {
		return budgetYearService;
	}

	public void setBudgetYearService(BudgetYearService budgetYearService) {
		this.budgetYearService = budgetYearService;
	}

	// RE201301619_新增各部室年度預算下載功能 modify by michael in 2014/02/24 end

	// defect4593_無寫入create(update) user,date問題 CU3178 2017/8/21 START
	/**
	 * 依據傳入年度刪除預算資料表
	 * 
	 * @param year
	 * @return
	 */
	public int deleteBudgetByYear(int year) {
		return getDao().deleteBudgetByYear(year);
	}
	// defect4593_無寫入create(update) user,date問題 CU3178 2017/8/21 END
}
