;with ApproveDate as (
	--�ֶU��	LoanCloseStatus = 1(����)�BLoanCloseDecision = 51(�֭�)
	select Loankey,CaseNO,LastFlowUpdateDate from SKL_LOAN.dbo.Flow_House 
	where LoanCloseStatus = '1' and LoanCloseDecision = '51'
),ApproveAmount as (
	--�֭���B
	--House_AccountChief	�f�ֵ��G��J		���̫�֭㨤��(LastUpdateRoleNo)�����B
	--House_AccountChange	�«H�����ܧ�f�֪�	���̫�֭㨤��(LastUpdateRoleNo)�����B
	select Loankey,sum(Amount) ApproveAmount,LastUpdateRoleNo from (
		select ROW_NUMBER() over (partition by Loankey,Ukey order by convert(int,LastUpdateRoleNo) desc) SeqNo
		,LoanKey,Ukey,Amount,LastUpdateRoleNo 
		from SKL_LOAN.dbo.House_AccountChief 
	) T1 where SeqNo = '1' group by Loankey,LastUpdateRoleNo 
	union
	select Loankey,sum(Amount) ApproveAmount,LastUpdateRoleNo from (
		select ROW_NUMBER() over (partition by Loankey,Ukey order by convert(int,LastUpdateRoleNo) desc) SeqNo
		,LoanKey,Ukey,Amount,LastUpdateRoleNo 
		from SKL_LOAN.dbo.House_AccountChange 
	) T2 where SeqNo = '1' group by Loankey,LastUpdateRoleNo 
),Summary as (
	select 
		ApproveDate.LoanKey
		,ApproveDate.CaseNO
		,ApproveDate.LastFlowUpdateDate ApproveDate
		,ApproveAmount.ApproveAmount
	from ApproveDate 
	inner join ApproveAmount 
	on ApproveDate.LoanKey = ApproveAmount.LoanKey
)

select * from Summary 
--where CaseNO = '2170726'