	    declare @SourceDB1 varchar(50)  select top 1 @SourceDB1=SourceDB FROM [SKL_CORE].[dbo].[Core_QueryItem] 
		declare @cmd1 nvarchar(MAX) set @cmd1=''
		--當天資料
		declare @GetDate1 varchar(10) set @GetDate1 = convert(varchar(8),dateadd(m,0,getdate()),112)		
		
		create table #TempLNLMSP(
		 LMSLLD varchar(8)   --撥款日
		,LMSFLA varchar(15)  --撥款金額
		,LMSACN varchar(20)  --戶號
		,LMSAPN varchar(3)   --額度
		)

		set @cmd1 = N''+
		' insert into #TempLNLMSP'+
		' select * from openquery(AS400,'' select LMSLLD,LMSFLA,LMSACN,LMSAPN from '+@SourceDB1+'.LA$LMSP'
		+' where LMSLLD = '+  +@GetDate1+''')'
		print @cmd1
	    exec(@cmd1)
	
		insert into skl_loan.dbo.house_insCheckData 
		select
		CONVERT(varchar(8),GETDATE(),112)  as DataDate --資料日期(年月日)
		,a.LoanKey
		,a.CustNo--借款人戶號
		,a.CustName--借款人姓名
		,a.CaseNO--放款案號
		,CONVERT(varchar(8), max(a.ApproveDate),112) as ApproveDate--核貸日
		,(CASE When m.CheckAmount is NULL Then ba.amount Else m.CheckAmount End )AS CheckAmount		--核貸金額				
		,MAX(#TempLNLMSP.LMSLLD) as LMSLLD  --撥款日
		,SUM(CAST(#TempLNLMSP.LMSFLA  as float))as LMSFLA 
		,FLOOR(i.IncomeSalary/10000) as IncomeSalary
		,FLOOR(i.IncomeWork/10000) as IncomeWork
		,FLOOR(i.IncomeBusiness/10000) as IncomeBusiness
		,FLOOR(i.IncomeRant/10000)  as IncomeRant 
		,FLOOR(i.IncomeInterest/10000) as IncomeInterest
		,FLOOR(i.IncomeOther/10000) as IncomeOther
		,FLOOR(i.IncomeYear/10000) as IncomeYear
		,FLOOR((i.EstimateCust+i.EstimateMate+i.EstimateOther)/10000) as Estimate
		,t.AngentEmpName as AngentEmpName  --介紹人
		,t.AngentEmpNo as AngentEmpNo  --員工代號
		,t.AngentUnitNo as AngentUnitNo  --單位代號			
		, getdate()as LastUpdateDate--產製時間
		from 
		#TempLNLMSP			
		inner join skl_loan.dbo.Temp_House_CustMain m on m.CustNo=#TempLNLMSP.LMSACN
		inner join (
		select
		 CONVERT(varchar(8), max(main.ApproveDate),112) as ApproveDate
		,house.LoanKey
		,house.CaseNO
		,main.CustNo--借款人戶號
		,main.CustName--借款人姓名
		,max(main.CheckAmount) as CheckAmount
		from Temp_Flow_House house
		inner join Temp_House_CustMain main on house.LoanKey=main.LoanKey 
		where house. LoanCloseDecision='51'
		group by
		 house.LoanKey
		,main.ApproveDate
		,house.CaseNO
		,main.CustNo
		,main.CustName
		,main.CheckAmount        
		)a on a.CustNo=#TempLNLMSP.LMSACN
		inner join skl_loan.dbo.temp_Book_Account ba on  ba.AccNo=#TempLNLMSP.LMSAPN	
		inner join skl_loan.dbo.Temp_House_CustIncome i on m.LoanKey=i.LoanKey
		inner join skl_loan.dbo.Temp_House_Introduce t on t.LoanKey=m.LoanKey		
        group by 
		#TempLNLMSP.LMSACN
		,#TempLNLMSP.LMSAPN
		,a.LoanKey
		,a.CustNo
		,a.CustName
		,a.CaseNO
		,a.ApproveDate
		,m.CheckAmount
		,ba.Amount
		,i.IncomeSalary
		,i.IncomeWork
		,i.IncomeBusiness
		,i.IncomeRant
		,i.IncomeInterest
		,i.IncomeOther
		,i.IncomeYear
		,i.EstimateCust
		,i.EstimateMate
		,i.EstimateOther
		,t.AngentEmpName
		,t.AngentEmpNo
		,t.AngentUnitNo		
	    union
		select
		CONVERT(varchar(8),GETDATE(),112)  as DataDate --資料日期(年月日)
		,a.LoanKey
		,a.CustNo--借款人戶號
		,a.CustName--借款人姓名
		,f.CaseNO--放款案號
		,max(a.ApproveDate) as ApproveDate--核貸日
	    --,a.CheckAmount AS CheckAmount		--核貸金額		
		,(CASE When a.CheckAmount IS NULL Then ba.amount Else a.CheckAmount End )AS CheckAmount		--核貸金額			
		,''--核貸日
		,'' --核貸金額
		,FLOOR(i.IncomeSalary/10000) as IncomeSalary
		,FLOOR(i.IncomeWork/10000) as IncomeWork
		,FLOOR(i.IncomeBusiness/10000) as IncomeBusiness
		,FLOOR(i.IncomeRant/10000)  as IncomeRant 
		,FLOOR(i.IncomeInterest/10000) as IncomeInterest
		,FLOOR(i.IncomeOther/10000) as IncomeOther
		,FLOOR(i.IncomeYear/10000) as IncomeYear
		,FLOOR((i.EstimateCust+i.EstimateMate+i.EstimateOther)/10000) as Estimate
		,t.AngentEmpName as AngentEmpName  --介紹人
		,t.AngentEmpNo as AngentEmpNo  --員工代號
		,t.AngentUnitNo as AngentUnitNo  --單位代號			
		, getdate() as LastUpdateDate--產製時間
		from skl_loan.dbo.Temp_Flow_House f 
		inner join (
		select
		 CONVERT(varchar(8), max(main.ApproveDate),112) as ApproveDate
		,main.LoanKey
		,house.CaseNO
		,main.CustNo--借款人戶號
		,main.CustName--借款人姓名
		,main.CheckAmount
		from Temp_Flow_House house
		inner join Temp_House_CustMain main on house.LoanKey=main.LoanKey 
		where house. LoanCloseDecision='51' --and house.CaseNO='2181609' 
		group by 
		 main.LoanKey
		,main.ApproveDate
		,house.CaseNO
		,main.CustNo
		,main.CustName
		,main.CheckAmount
		)a on a.CaseNO=f.CaseNO
		inner join skl_loan.dbo.Temp_House_CustIncome i on f.LoanKey=i.LoanKey
		inner join skl_loan.dbo.Temp_House_Introduce t on t.LoanKey=f.LoanKey
		inner join skl_loan.dbo.temp_Book_Account ba on ba.LoanKey=f.LoanKey
			where  f.CaseNO='2181609' 
		group by 
		 a.LoanKey
		,a.CustNo
		,a.CustName
		,f.CaseNO
		,ba.amount
		,a.CheckAmount
		,i.IncomeSalary
		,i.IncomeWork
		,i.IncomeBusiness
		,i.IncomeRant
		,i.IncomeInterest
		,i.IncomeOther
		,i.IncomeYear
		,i.EstimateCust
		,i.EstimateMate
		,i.EstimateOther
		,t.AngentEmpName
		,t.AngentEmpNo
		,t.AngentUnitNo