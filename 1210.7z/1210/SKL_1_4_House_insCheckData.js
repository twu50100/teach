﻿var G_PAGE_SIZE = 10;
var G_LOAD_Waitting_Msg;
var G_List = {};
var G_data = [pls];
var G_Search = {};
var G_CreateBranchNo = new Array();
//var G_AppraiseGroup = new Array();
//var G_AppraiseType = new Array();
//var G_BussinessType = new Array();
//var G_FlowBranchNo = new Array();
var G_CaseStatus = new Array();
var G_ValueCompare = new Array();
var G_Var = {};

var Init = function () {

    var AjaxInputObj =
      {
      	url: "SKL_1_4_House_insCheckData/Init",
          oMethod: genData,
      };

    //call ajax
    docCore.ajax(AjaxInputObj, true, true, G_LOAD_Waitting_Msg);
    // 添加匯出excel add by jessie 2019/3/5
    $("#exExcel").click(function () {
        var jsonObj = $.valToJson("QryAccessBox");
        var ajaxDL = {
        	url: "SKL_1_4_House_insCheckData/Export_Excel",
            data: jsonObj
        };
        docCore.ajaxDownload(ajaxDL);
    })
}


// 格式化千分位
var formatNumber = function (number, currency) {
    if (number < 1) {
        return number;
    }
    var arr = number.split(".");
    var re = /(\d{1,3})(?=(\d{3})+$)/g;
    return currency + arr[0].replace(re, "$1,") + (arr.length == 2 ? "." + arr[1] : "");
}

var genData = function (Data) {
    console.log(Data);
    G_Var.IsHeadOffice = Data.data.IsHeadOffice;
    G_List.House_LoanWay = G_Convert.list("House_LoanWay");
    G_List.House_LoanWay.unshift(pls);
    G_CreateBranchNo = Data.data["CreateBranchNo"];
    //G_BussinessType = Data.data["BussinessType"];
    G_FlowBranchNo = Data.data["FlowBranchNo"];
    G_CaseStatus = G_Convert.list("Common_CaseStatus");
    G_ValueCompare = G_Convert.list("Imm_ValueCompare");
    G_CaseStatus.unshift(pls);
    G_ValueCompare.unshift(pls);

    QryAccessBox(Data.data["CreateBranchNo"], G_data, Data.data["FlowBranchNo"])
}

//var QryAccessBox = function (CreateBranchNo, BussinessType, FlowBranchNo) {
var QryAccessBox = function (CreateBranchNo, FlowBranchNo) {
    $("#QryAccessBox").SexyBox({
        boxCtrl: [{
            ID: "QryAccess",
            HeadForm: "QryAccessForm",
            Head: [
                {
                    Row: "caption",
                    Ctrl: [
                        { Type: "Label", Data: "查詢條件" }
                    ]
                }
            ],
            BodyForm: "QryAccessForm",
            Body: [
                 {
                     Row: "2col",
                     ColumnClass: ["align_right", ""],
                     Ctrl: [
                         "資料日期",
                         [
                             { Type: "datepicker", Name: "p_CreateDate_S", ID: "txtp_CreateDate_S" },
                             "至",
                             { Type: "datepicker", Name: "p_CreateDate_E", ID: "txtp_CreateDate_E" },
                         ]
                     ]
                 },
               
				{
					Row: "2col",
					ColumnClass: ["align_right", ""],
					Ctrl: ["放款案號", { Type: "text", Name: "p_CaseNo", ID: "txtp_CaseNo" }]
				},
                {
                    Row: "2col",
                    ColumnClass: ["align_right", ""],
                    Ctrl: ["介紹人員工編號", { Type: "text", Name: "p_CreateEmpNo", ID: "txtp_CreateEmpNo" }]
                },
            ],
            Foot: [
                {
                    Row: "",
                    RowClass: "align_center",
                    Ctrl: [{ Type: "a", Data: "查詢", Class: "button add", Event: Data_Search }]
                }
            ],
            Data: []
        }]
    });
};

var Data_Search = function () {
    var jsonObj = $.valToJson("QryAccessBox");
    G_Search = jsonObj;
    jsonObj["p_Row_S"] = "1";
    jsonObj["p_Row_E"] = "10";

    var AjaxInputObj =
    {
    	url: "SKL_1_4_House_insCheckData/DataQry",
        data: jsonObj,
        oMethod: function (res) {
            QryAccessTable(res);
        }
    };
    //call ajax
    docCore.ajax(AjaxInputObj, true, true, G_LOAD_Waitting_Msg);
};

var QryAccessTable = function (Arg) {

    var tableArg = {
        theadValue: [
            [
               { Text: "", Style: { "display": "none" } },
                { Text: "資料日期" },
                { Text: "借款人戶號" },
                { Text: "借款人姓名" },
                { Text: "放款案號" },
                { Text: "核貸日" },
                { Text: "核貸金額(單位:元)" },
                { Text: "撥款日" },
                { Text: "撥款金額(單位:元)" },
                { Text: "薪資收入(單位:萬元)" },
                { Text: "執行業務收入(單位:萬元)" },
                { Text: "營業收入(單位:萬元)" },
                { Text: "租金收入(單位:萬元)" },
                { Text: "利息收入(單位:萬元)" },
				{ Text: "其他收入(單位:萬元)" },
				{ Text: "借款人年收入(單位:萬元)" },
				{ Text: "本案推估年收入(單位:萬元)" },
			    { Text: "介紹人" },
			     { Text: "員工代號" },
				{ Text: "單位代號" }
            ]
        ],
        tbodyValue: {
            Value: [
                {
                    je: function (col) {
                        var td = $("<td></td>");
                        td.SexyCtrl({ Type: "hidden", ID: "LoanKey", Name: "LoanKey" }, col["LoanKey"]);                     
                        td.SexyCtrl({ Type: "hidden", ID: "CreateDate", Name: "CreateDate" }, col["CreateDate"]);
                        td.SexyCtrl({ Type: "hidden", ID: "CaseNo", Name: "CaseNo" }, col["CaseNO"]);
                        td.SexyCtrl({ Type: "hidden", ID: "CreateEmpNo", Name: "CreateEmpNo" }, col["CreateEmpNo"]);
                        return td;
                    }
                },
                {
                    je: function (col) {
                        var td = $("<td></td>");
                        td.SexyCtrl({ Type: "a", Style: "cursor:pointer" }, col["CaseNO"], Case_Appraise);
                        return td
                    }
                },
                {
                    t: function (col) {
                        return G_Convert.list("House_LoanWay", col["LoanWay"]);
                    }
                },
                {
                    t: function (col) {
                        return G_Convert.list("Common_CustType", col["CustType"]);
                    }
                },
                "CustId",
                "CustName",
                "NewDate",
                {
                    t: function (col) {
                        return col["OriginBranchNo"] + col["CreateBranchName"];
                    }
                },
                {
                    t: function (col) {
                        return col["CreateEmpNo"] + col["CreateEmpName"];
                    }
                },

                "FlowPreviousDecisionDesc",
                "CaseStatus",
                {
                    t: function (col) {
                        return col["FlowDuration"] + "天"
                    }
                },
                {
                    t: function (col) {
                        if (col["ApplyAmount"] != null && col["ApplyAmount"] + "" != "") {
                            var a = (col["ApplyAmount"]) / 1000;
                            //var Amount = $.setThousandsSymbolToNumber(a + "");
                            if (a > 0)
                                return formatNumber(col["NewAmt"], '') + "仟元";
                        }
                    }
                }
            ],
            Style: [{ "display": "none" }]
        },
        Data: Arg.data.QryAccess,
        NoData: true,
        //只取部份資料的分頁方式
        PageSetting: {
            MaxPageSize: Arg.data.QryAccess.length > 0 ? Arg.data.QryAccess[0].TotalNum : 0,
            PageSize: G_PAGE_SIZE,
            Event: genPageChg,
            ShowPageCtrl: true
        }
    };
    //顯示 匯出按鈕 add by jessie 2019/3/5
    if (G_Var.IsHeadOffice) {
        $("#exExcel").parent().removeClass("hide")
    }
    $("#scDataView").find("input").off('click');
    $("#scDataView").empty();
    $("#scDataView").SexyTable(tableArg);
};

//只取部份資料的分頁方式 才需要寫分頁切換Event
var genPageChg = function (pageIdx) {
    console.log(pageIdx);
    IndexSearch(pageIdx);
};

var IndexSearch = function (pageIdx) {
    var jsonObj = G_Search;
    jsonObj["p_Row_S"] = (pageIdx * G_PAGE_SIZE) - (G_PAGE_SIZE - 1);
    jsonObj["p_Row_E"] = pageIdx * G_PAGE_SIZE;

    var AjaxInputObj =
    {
        url: "SKL_8_3_QryAccess_Book/DataQry",
        data: jsonObj,
        oMethod: function (res) {
            QryAccessTable(res);
        },
    };
    //call ajax
    docCore.ajax(AjaxInputObj, true, true, G_LOAD_Waitting_Msg);
}

var Case_Appraise = function () {
    var ptElm = $.valToJson($(this).closest("tr"));
    console.log(ptElm, $(this));

    var AjaxInputObj =
    {
        url: "SKL_8_3_QryAccess_Book/Insert_Session",
        data: ptElm,
        oMethod: function (res) {
            parent.genTreeAndMarkData("SKL_8_3_QryAccess_Book", res.data.Tree, res.data.TreeDefaultPage);
        },
    };
    //call ajax
    docCore.ajax(AjaxInputObj, true, true, G_LOAD_Waitting_Msg);
};



$(document).ready(function () {
    Init();
});