package tw.com.skl.exp.web.jsf.managed.gae.query.queryaccount;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.event.ValueChangeEvent;
import org.apache.commons.lang.StringUtils;
import org.apache.myfaces.trinidad.component.core.data.CoreTable;
import org.apache.myfaces.trinidad.model.CollectionModel;
import org.apache.myfaces.trinidad.model.SortableModel;
import org.apache.myfaces.trinidad.model.UploadedFile;

import org.apache.commons.collections.CollectionUtils;
import tw.com.skl.common.model6.web.jsf.managedbean.impl.TemplateDataTableManagedBean;
import tw.com.skl.common.model6.web.util.ApplicationLocator;
import tw.com.skl.common.model6.web.util.MessageManager;
import tw.com.skl.common.model6.web.vo.ValueObject;
import tw.com.skl.exp.kernel.model6.bo.BudgetIn;
import tw.com.skl.exp.kernel.model6.bo.Department;
import tw.com.skl.exp.kernel.model6.bo.ExpMain;
import tw.com.skl.exp.kernel.model6.bo.ExpapplB;
import tw.com.skl.exp.kernel.model6.bo.ExpapplC;
import tw.com.skl.exp.kernel.model6.bo.GeneralExp;
import tw.com.skl.exp.kernel.model6.bo.LecturerDetail;
import tw.com.skl.exp.kernel.model6.bo.PapersNo;
import tw.com.skl.exp.kernel.model6.bo.Proof;
import tw.com.skl.exp.kernel.model6.bo.RelationMaintain;
import tw.com.skl.exp.kernel.model6.bo.Function.FunctionCode;
import tw.com.skl.exp.kernel.model6.bo.ExpMain;
import tw.com.skl.exp.kernel.model6.bo.User;
import tw.com.skl.exp.kernel.model6.common.ErrorCode;
import tw.com.skl.exp.kernel.model6.common.exception.ExpRuntimeException;
import tw.com.skl.exp.kernel.model6.common.util.AAUtils;
import tw.com.skl.exp.kernel.model6.common.util.MessageUtils;
import tw.com.skl.exp.kernel.model6.dto.ApplStateFlowDto;
import tw.com.skl.exp.kernel.model6.facade.BudExpOverrunExplainFacade;
import tw.com.skl.exp.kernel.model6.facade.DeliverDaylistFacade;
import tw.com.skl.exp.kernel.model6.facade.ExpMainFacade;
import tw.com.skl.exp.kernel.model6.facade.ExpapplBFacade;
import tw.com.skl.exp.kernel.model6.facade.ExpapplCFacade;
import tw.com.skl.exp.kernel.model6.facade.GeneralExpFacade;

import tw.com.skl.exp.kernel.model6.fileio.logic.dto.ImportLecturerDto;
import tw.com.skl.exp.kernel.model6.logic.ExpMainService;
import tw.com.skl.exp.kernel.model6.logic.ExpapplBService;
import tw.com.skl.exp.kernel.model6.logic.ExpapplCService;
import tw.com.skl.exp.kernel.model6.logic.LecturerDetailService;
import tw.com.skl.exp.kernel.model6.logic.ExpMainService;
import tw.com.skl.exp.web.jsf.managed.FunctionCodeAware;

/**
 * C11.7.13申請單狀態及簽核流程查詢的 managed bean 。
 * 
 * @author EC0416
 * @version 1.0, 2016/02/02
 */
public class ApplStateFlowManagedBean extends TemplateDataTableManagedBean<ExpMain, ExpMainService>
        implements FunctionCodeAware {

    private CoreTable resultDataTable;
    private CollectionModel resultDataModel;
    private List<ApplStateFlowDto> dtoList;
    
    
    public ApplStateFlowManagedBean(){
    	//設定查詢條件
    	this.initFindCriteriaMap();
    }
    
    
    @Override
    protected void initFindCriteriaMap() {
    	Map<String, Object> findCriteriaMap = new HashMap<String, Object>();		
		findCriteriaMap.put("expappls", null);   // 費用申請單
		
		this.setFindCriteriaMap(findCriteriaMap);
    	
    }

    @Override
    protected void initCreatingData() {
    }

    @Override
    protected void initUpdatingData(ValueObject<ExpMain> updatingData) {
    }

    @Override
    protected void setupUpdatingData() {
    }

    /*
     * 執行查詢功能
     */
	public String doFindAction() {
	    Map map = getFindCriteriaMap();
	    initPage();
		// 判斷查詢條件
		List<ApplStateFlowDto> list = findData(); // 查詢
		if (CollectionUtils.isEmpty(list)) {
			throw new ExpRuntimeException(ErrorCode.C10028);
		}
		else {
			// set 查詢資料 
			this.setDtoList(list);
			}


		return super.doFindAction();
	}
	
	//初始化頁面
    public void initPage(){
	    setResultDataModel(null);
	    setDtoList(null);
	    
	    
    } 	 
 	protected List<ApplStateFlowDto> findData() {
		List<ApplStateFlowDto> list = new ArrayList<ApplStateFlowDto>();
		Map map = getFindCriteriaMap();
		String  expappls = (String)map.get("expappls");//申請單號
	
		list = getService().findData(expappls);
		return list;
 	}  

    public void setResultDataTable(CoreTable resultDataTable) {
        this.resultDataTable = resultDataTable;
    }

    public CoreTable getResultDataTable() {
        return resultDataTable;
    }

    public void setResultDataModel(CollectionModel resultDataModel) {
        this.resultDataModel = resultDataModel;
    }

    public CollectionModel getResultDataModel() {
        if (resultDataModel == null) {
            resultDataModel = new SortableModel();
            resultDataModel.setWrappedData(getDtoList());
        }
        return resultDataModel;
    }



    public FunctionCode getFunctionCode() {
        return FunctionCode.C_11_7_13;
    }


	public List<ApplStateFlowDto> getDtoList() {
		return dtoList;
	}


	public void setDtoList(List<ApplStateFlowDto> dtoList) {
		this.dtoList = dtoList;
	}
	
	private String result ="";
	
	public void doFindProof(){
		Map map = getFindCriteriaMap();
		String  expappls = (String)map.get("expappls");//申請單號
		Map<String, Object> criteriaMap = new HashMap<String, Object>();
        ExpapplB expapplB = null;
        criteriaMap.put("expApplNo", expappls);
        expapplB = getExpapplBService().findByCriteriaMapReturnUnique(criteriaMap);
        setResult("");
        List<Proof> proofs = expapplB.getProofs();
        if (!CollectionUtils.isEmpty(proofs)) {
        	setResult("有資料");
        }else{
        	setResult("-----無資料-----");
        }
	}
	
	public void doFindTax(){
		Map map = getFindCriteriaMap();
		String  expappls = (String)map.get("expappls");//申請單號
		Map<String, Object> criteriaMap = new HashMap<String, Object>();
        ExpapplC expapplC = null;
        criteriaMap.put("expApplNo", expappls);
        expapplC = getExpapplCService().findByCriteriaMapReturnUnique(criteriaMap);
        setResult("");

        if (expapplC!=null) {
        	setResult("有資料");
        	getDeliverDaylistFacade().getTaxDetailService().createByExpapplC(expapplC);
        }
	}
	

	public ExpapplBService getExpapplBService() {
		return (ExpapplBService) ApplicationLocator
				.getBean("expapplBService");
	}
	
	public ExpapplCService getExpapplCService() {
		return (ExpapplCService) ApplicationLocator
				.getBean("expapplCService");
	}

	public DeliverDaylistFacade getDeliverDaylistFacade() {
		return (DeliverDaylistFacade) ApplicationLocator
				.getBean("deliverDaylistFacade");
	}


	public String getResult() {
		return result;
	}


	public void setResult(String result) {
		this.result = result;
	}


	
}
