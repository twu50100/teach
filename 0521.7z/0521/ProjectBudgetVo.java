﻿package tw.com.skl.exp.web.vo;


import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;

import tw.com.skl.common.model6.web.jsf.managedbean.impl.BatchUpdatingUnit;
import tw.com.skl.common.model6.web.jsf.utils.FacesUtils;
import tw.com.skl.common.model6.web.util.ApplicationLocator;
import tw.com.skl.common.model6.web.vo.impl.TempVoImpl;
import tw.com.skl.exp.kernel.model6.bo.BfmBudgetItem;
import tw.com.skl.exp.kernel.model6.bo.BfmBudgetType;
import tw.com.skl.exp.kernel.model6.bo.Budget;
import tw.com.skl.exp.kernel.model6.bo.ProjectBudget;
import tw.com.skl.exp.kernel.model6.bo.ProjectBudgetItem;
import tw.com.skl.exp.kernel.model6.bo.ProjectBudgetType;
import tw.com.skl.exp.kernel.model6.facade.BudgetFacade;


public class ProjectBudgetVo extends TempVoImpl<ProjectBudget>{
	
	private static final long serialVersionUID = 1L;
	
	private String selectBudgetId;
	private String selectBudgetTypeId;
	private String selectProjectBudgetTypeId;


	public ProjectBudgetVo() {
		super(new ProjectBudget());
	}

	public ProjectBudgetVo (ProjectBudget bo) {
		super(bo);
	}

	/**
	 * getBo 和 setBo 其實可以不需要, 因為 super class 已經有了
	 * 存在的目的, 只是為了讓 IDE 知道它的確切的type為何, 讓 jsf 的頁面比較好拖拉
	 */

	public ProjectBudget getBo() {
		return bo;
	}

	public void setBo(ProjectBudget bo) {
		this.bo = bo;
	}

	/**
	 * 如果要 customize CRUD 的資料, 可以修改此 method
	 *
	 */
	public BatchUpdatingUnit generateBatchUpdatingUnit() {
		BatchUpdatingUnit result = super.generateBatchUpdatingUnit();
		return result;
		
	}
	
	public String getSelectBudgetId() {
		if (this.selectBudgetId == null && this.getBo().getBudget() != null) {
			this.selectBudgetId = this.getBo().getBudget().getId().toString();
		}
		return this.selectBudgetId;
	}

	public void setSelectBudgetId(String selectBudgetId) {
		this.selectBudgetId = selectBudgetId;
		
		Map<String, Budget> map = 
			(Map<String, Budget>)FacesUtils.getSessionScope().get("budgetMap");
		if (map != null) {			
			this.getBo().setBudget(map.get(selectBudgetId));
		}
		
	}
	
	public String getSelectBudgetTypeId() {
		if (this.selectBudgetTypeId == null && this.getBo().getBudgetType() != null) {
			this.selectBudgetTypeId = this.getBo().getBudgetType().getId().toString();
		}
		return this.selectBudgetTypeId;
	}

	public void setSelectBudgetTypeId(String selectBudgetTypeId) {
		this.selectBudgetTypeId = selectBudgetTypeId;
		
		Map<String, BfmBudgetType> map = 
			(Map<String, BfmBudgetType>)FacesUtils.getSessionScope().get("budgetTypeMap");
		if (map != null) {			
			this.getBo().setBudgetType(map.get(selectBudgetTypeId));
		}
		
	}
	
	public String getSelectProjectBudgetTypeId() {
		if (this.selectProjectBudgetTypeId == null && this.getBo().getProjectBudgetType() != null) {
			this.selectProjectBudgetTypeId = this.getBo().getProjectBudgetType().getId().toString();
		}
		return this.selectProjectBudgetTypeId;
	}

	public void setSelectProjectBudgetTypeId(String selectProjectBudgetTypeId) {
		this.selectProjectBudgetTypeId = selectProjectBudgetTypeId;
		
		Map<String, ProjectBudgetType> map = 
			(Map<String, ProjectBudgetType>)FacesUtils.getSessionScope().get("projectBudgetTypeMap");
		if (map != null) {			
			this.getBo().setProjectBudgetType(map.get(selectProjectBudgetTypeId));
		}
		
	}
	
	/**
	 * Fun2.2
	 * @author 偉哲	 
	 * 取得子項專案預算項目的總金額
	 * 使用此函數時，請確認ProjectBudgetItem已經被讀取出來，以免出現null exception
	 * @return
	 */
	
	public Long getProjectBudgetItemTotalAmount() {
		//假如有子項目的話就讀子項目，沒的話就讀detailmanagedbean
		Long projectBudgetItemTotalAmount=0L;
		
		//RE201801038_預算同期差異說明 CU3178 2018/4/19 START
		if(this.isFresh()||this.isCreating()||this.isUpdating()){
			if(this.getDetailDataModel("ProjectBudgetItem")!=null){
				List<ProjectBudgetItemVo> projectBudgetItemVoList = (List)this.getDetailDataModel("ProjectBudgetItem").getWrappedData();
				for(ProjectBudgetItemVo projectBudgetItemVo : projectBudgetItemVoList){
					if(!projectBudgetItemVo.isDeleting()){
						projectBudgetItemTotalAmount = projectBudgetItemTotalAmount + projectBudgetItemVo.getBo().getAmount();
					}
		
				}
			}
		}else if (!CollectionUtils.isEmpty(bo.getBudgetDiffExplains())&&bo.getBudgetDiffExplains().get(0).getId()==null){
			for(ProjectBudgetItem projectBudgetItem : bo.getProjectBudgetItems()){
				projectBudgetItemTotalAmount = projectBudgetItemTotalAmount + projectBudgetItem.getAmount();
			}
		}else{
			//defect 修改合計金額部分抓取db資料(避免cache問題產生) CU3178 2017/9/12 START
			if(this.getBo().getProjectBudgetItems()!=null){
				int firstResult = 0;
				int maxResults =  getBudgetFacade().getProjectBudgetItemService().readCount(this.getBo());
				List<ProjectBudgetItem> projectBudgetItemList = getBudgetFacade().getProjectBudgetItemService().read(firstResult, maxResults, this.getBo());
				for(ProjectBudgetItem projectBudgetItem : projectBudgetItemList){
					projectBudgetItemTotalAmount = projectBudgetItemTotalAmount + projectBudgetItem.getAmount(); 

				}
//				for(ProjectBudgetItem projectBudgetItem : this.getBo().getProjectBudgetItems()){
//					projectBudgetItemTotalAmount = projectBudgetItemTotalAmount + projectBudgetItem.getAmount(); 
//	
//				}
			} 
			//RE201801038_預算同期差異說明 CU3178 2018/4/19 END

		}
			

		
		return projectBudgetItemTotalAmount;
	}
	
	public BudgetFacade getBudgetFacade(){
		return (BudgetFacade) ApplicationLocator.getBean("budgetFacade");
		
	}
	//defect 修改合計金額部分抓取db資料(避免cache問題產生) CU3178 2017/9/12 END

}
