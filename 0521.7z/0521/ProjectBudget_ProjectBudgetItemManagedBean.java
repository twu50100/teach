package tw.com.skl.exp.web.jsf.managed.bd.provisionbudget;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.model.DataModel;
import javax.faces.model.SelectItem;
import javax.faces.validator.ValidatorException;

import org.apache.commons.collections.CollectionUtils;

import tw.com.skl.common.model6.web.jsf.managedbean.PagedDataModel;
import tw.com.skl.common.model6.web.jsf.managedbean.PagedOperation;
import tw.com.skl.common.model6.web.jsf.managedbean.impl.PagedDataModelImpl;
import tw.com.skl.common.model6.web.jsf.managedbean.impl.PagedOperationImpl;
import tw.com.skl.common.model6.web.jsf.managedbean.impl.TempPagedDataModelImpl;
import tw.com.skl.common.model6.web.jsf.managedbean.impl.TempPagedManagedBeanImpl;
import tw.com.skl.common.model6.web.jsf.utils.FacesUtils;
import tw.com.skl.common.model6.web.util.ApplicationLocator;
import tw.com.skl.common.model6.web.vo.Selectable;
import tw.com.skl.common.model6.web.vo.ValueObject;
import tw.com.skl.common.model6.web.vo.impl.VoWrapperImpl;
import tw.com.skl.exp.kernel.model6.bo.BfmBudgetItem;
import tw.com.skl.exp.kernel.model6.bo.BudgetItemLargeType;
import tw.com.skl.exp.kernel.model6.bo.BudgetItemType;
import tw.com.skl.exp.kernel.model6.bo.ProjectBudgetItem;
import tw.com.skl.exp.kernel.model6.logic.BfmBudgetItemService;
import tw.com.skl.exp.kernel.model6.logic.ProjectBudgetItemService;
import tw.com.skl.exp.kernel.model6.logic.ProjectBudgetService;
import tw.com.skl.exp.web.util.BfmSelectFactory;
import tw.com.skl.exp.web.util.BfmSelectHelper;
import tw.com.skl.exp.web.util.BudgetItemLargeTypeSelectHelper;
import tw.com.skl.exp.web.vo.ProjectBudgetItemVo;
import tw.com.skl.exp.web.vo.ProjectBudgetVo;

public class ProjectBudget_ProjectBudgetItemManagedBean extends
		TempPagedManagedBeanImpl<ProjectBudgetItem, ProjectBudgetItemService> {

	private static final long serialVersionUID = 1L;

	private BudgetItemLargeTypeSelectHelper budgetItemLargeTypeSelectHelper = new BudgetItemLargeTypeSelectHelper();
	private Map<String, BfmBudgetItem> budgetItemMap = null;
	private List<SelectItem> budgetItemList = null;
	private Map<String, BudgetItemType> budgetItemTypeMap = null;
	private List<SelectItem> budgetItemTypeList = null;
	private Map<String, BudgetItemLargeType> budgetItemLargeTypeMap = null;
	private List<SelectItem> budgetItemLargeTypeList = null;

	public ProjectBudget_ProjectBudgetItemManagedBean() {
		this.setVoWrapper(new ProjectBudgetItemWrapper());
		this.setServiceName("projectBudgetItemService");
	}

	// detail specific begin
	@Override
	public ProjectBudgetVo getMasterVo() {
		return (ProjectBudgetVo) super.getMasterVo();
	}

	@Override
	protected void initCreatingData() {
		ProjectBudgetItemVo projectBudgetItemVo = new ProjectBudgetItemVo();
		projectBudgetItemVo.setBo(new ProjectBudgetItem());
		this.setUpdatingData(projectBudgetItemVo);

	}

	@Override
	protected String getDetailKey() {
		return "ProjectBudgetItem";
	}

	@Override
	protected PagedOperation getPagedOperation() {
		// 假如 parentData 的 bo 沒有 id, 就代表是 new 的,
		// 就不需要有 pagedOperation, 因為就不需要去 db 抓資料
		if (this.getMasterVo().getBo().getId() == null) {
			// RE201801038_預算同期差異說明 CU3178 2018/4/19 START
			// pagedDataModel = new TempPagedDataModelImpl(null ,);
			// RE201801038_預算同期差異說明 CU3178 2018/4/19 END
			this.pagedOperation = null;
		} else {
			pagedOperation = new ProjectBudgetItemPagedOperationImpl(
					this.getServiceName(), this.getMasterVo());
		}
		return this.pagedOperation;
	}

	// RE201801038_預算同期差異說明 CU3178 2018/4/19 START
	public TempPagedDataModelImpl getPagedDataModel() {
		if (this.getMasterVo().getBo().getId() == null) {
			if (!CollectionUtils.isEmpty(this.getMasterVo().getBo()
					.getBudgetDiffExplains())
					&& this.getMasterVo().getBo().getBudgetDiffExplains()
							.get(0).getId() == null) {
				if (pagedDataModel == null) {
					pagedDataModel = createPagedDataModel();
				}
				if (pagedDataModel.getRowCount() == 0) {
					for (ProjectBudgetItem bo : this.getMasterVo().getBo()
							.getProjectBudgetItems()) {
						ProjectBudgetItemVo vo = new ProjectBudgetItemVo();
						vo.setBo(bo);
						((TempPagedDataModelImpl) this.pagedDataModel)
								.addCreatingVo(vo);
					}
					return (TempPagedDataModelImpl) pagedDataModel;
				}
			}
		}
		return ((TempPagedDataModelImpl) super.getPagedDataModel());
	}

	// RE201801038_預算同期差異說明 CU3178 2018/4/19 END
	// detail specific end

	public ProjectBudgetItemVo wrap(Object object) {
		return (ProjectBudgetItemVo) this.getVoWrapper().wrap(object);
	}

	/**
	 * getUpdatingData 和 setUpdatingData 其實可以不需要, 因為 super class 已經有了 存在的目的,
	 * 只是為了讓 IDE 知道它的確切的type為何, 讓 jsf 的頁面比較好拖拉
	 */
	@Override
	public ProjectBudgetItemVo getUpdatingData() {
		return (ProjectBudgetItemVo) super.getUpdatingData();
	}

	public void setUpdatingData(ProjectBudgetItemVo vo) {
		super.setUpdatingData(vo);
	}

	@SuppressWarnings("unchecked")
	public List<SelectItem> getBudgetItemLargeTypeList() {
		this.budgetItemLargeTypeList = budgetItemLargeTypeSelectHelper
				.getBudgetItemLargeTypeSelect();
		this.budgetItemLargeTypeMap = (Map<String, BudgetItemLargeType>) FacesUtils
				.getSessionScope().get("budgetItemLargeTypeMap");
		return this.budgetItemLargeTypeList;
	}

	@SuppressWarnings("unchecked")
	public List<SelectItem> getBudgetItemTypeList() {
		this.budgetItemTypeList = budgetItemLargeTypeSelectHelper
				.getBudgetItemTypeSelect(this.getUpdatingData()
						.getSelectBudgetItemLargeTypeId());
		this.budgetItemTypeMap = (Map<String, BudgetItemType>) FacesUtils
				.getSessionScope().get("budgetItemTypeMap");
		return this.budgetItemTypeList;
	}

	// manyToOne selection menu begin
	@SuppressWarnings("unchecked")
	public List<SelectItem> getBudgetItemList() {

		if (this.budgetItemList == null) {
			this.budgetItemList = new ArrayList<SelectItem>();
			this.budgetItemList.add(BfmSelectHelper.EMPTY_SELECTITEM);
		}

		if (this.getUpdatingData().getSelectBudgetItemTypeId() != null) {
			BudgetItemType budgetItemType = ((Map<String, BudgetItemType>) FacesUtils
					.getSessionScope().get("budgetItemTypeMap")).get(this
					.getUpdatingData().getSelectBudgetItemTypeId());
			this.budgetItemMap = new HashMap<String, BfmBudgetItem>();
			this.budgetItemList = BfmSelectFactory
					.creatBudgetItemForProjectBudget(budgetItemType)
					.getSelectList();
			this.budgetItemMap = (Map<String, BfmBudgetItem>) FacesUtils
					.getSessionScope().get("budgetItemMap");

		}

		return this.budgetItemList;
	}

	public ProjectBudgetService getProjectBudgetService() {

		return (ProjectBudgetService) ApplicationLocator
				.getBean("projectBudgetService");
	}

	public BfmBudgetItemService getBudgetItemService() {

		return (BfmBudgetItemService) ApplicationLocator
				.getBean("budgetItemService");
	}

	private void setupBudgetItem() {
		if (this.getUpdatingData().getSelectBudgetItemId() != null
				&& this.budgetItemMap != null) {
			this.getUpdatingData()
					.getBo()
					.setBudgetItem(
							this.budgetItemMap.get(this.getUpdatingData()
									.getSelectBudgetItemId()));
		}
	}

	// manyToOne selection menu end

	protected void setupUpdatingData() {
		this.setupBudgetItem();
	}

	public void onSelectItemLargeTypeChange() {
		this.getUpdatingData().setSelectBudgetItemLargeTypeId(
				this.getUpdatingData().getSelectBudgetItemLargeTypeId());
		// AjaxUtils.refreshZones("zoneItemType");
	}

	public void onSelectItemTypeChange() {
		this.getUpdatingData().setSelectBudgetItemTypeId(
				this.getUpdatingData().getSelectBudgetItemTypeId());

	}

	/**
	 * Fun 2.2
	 * 
	 * @author 偉哲 驗證專案預算項目在修改新增時，該預算項是否已經存在，如存在則提出警訊
	 * 
	 * @param context
	 * @param component
	 * @param object
	 * @throws ValidatorException
	 */
	@SuppressWarnings("unchecked")
	public void validateBudgetItem(FacesContext context, UIComponent component,
			Object object) throws ValidatorException {
		// 目前的新值
		String selectBudgetItemId = (String) object;
		// 假如是新增的話vo.getUpdatingData().getSelectBudgetItemId()會是null，所以不用驗證，沒有修改選擇的預算項目的話也不用驗證
		if ((this.getUpdatingData().getSelectBudgetItemId() == null)
				|| (this.getUpdatingData().getSelectBudgetItemId()
						.compareTo(selectBudgetItemId) != 0)) {
			if (this.getPagedDataModel() != null) {
				List<ProjectBudgetItemVo> projectBudgetItemVoList = (List) this
						.getPagedDataModel().getWrappedData();
				for (ProjectBudgetItemVo projectBudgetItemVo : projectBudgetItemVoList) {
					if (selectBudgetItemId.compareTo(projectBudgetItemVo
							.getSelectBudgetItemId().toString()) == 0) {

						ResourceBundle bundle = ResourceBundle.getBundle(
								"applicationResources", FacesUtils
										.getFacesContext().getViewRoot()
										.getLocale());

						FacesMessage message = new FacesMessage(
								FacesMessage.SEVERITY_ERROR,
								bundle.getString("validate_projectBudget_already_exist"),
								bundle.getString("validate_projectBudget_already_exist"));
						throw new ValidatorException(message);
					}
				}
			}
		}
	}

	/**
	 * 由於Master的read頁面需要計算專案總金額，所以在此時點就需要將資料給加入關聯
	 */
	@Override
	public String doBtnTempCreateAction() {
		this.getMasterVo().getBo()
				.addProjectBudgetItem(this.getUpdatingData().getBo());
		return super.doBtnTempCreateAction();

	}

	/**
	 * detail項目的操作，如果以新增->暫存->修改->返回的話，會因為原本此函數的從新設定關係，而出現null，所以覆寫此函式
	 */
	@Override
	public String doBtnCancelAction() {
		if (updatingData != null && updatingData.getPrevStatus() != null
				&& updatingData.isCreating() != true) {
			// 將 updatingData 的資料, 從先前 serialization 出去的 bytes,
			// 再 serialization 一次回來
			ValueObject<ProjectBudgetItem> preVo = updatingData
					.retrievePrevStatus();
			this.pagedDataModel.replaceWrappedData(preVo);
		}

		return this.getREAD_PAGE() + this.getReturnPostFix();
	}

	@Override
	protected void initUpdatingData(ValueObject<ProjectBudgetItem> updatingData) {
		// TODO Auto-generated method stub

	}
}

class ProjectBudgetItemWrapper extends VoWrapperImpl {

	private static final long serialVersionUID = 1L;

	@Override
	public ProjectBudgetItemVo wrap(Object object) {
		return new ProjectBudgetItemVo((ProjectBudgetItem) object);
	}
}

class ProjectBudgetItemPagedOperationImpl extends PagedOperationImpl {

	private static final long serialVersionUID = 1L;

	private ProjectBudgetVo masterVo;

	ProjectBudgetItemPagedOperationImpl(String serviceName,
			ProjectBudgetVo masterVo) {
		super(serviceName);
		this.masterVo = masterVo;
	}

	public List read(int firstResult, int maxResults) {
		firstResult = 0;
		maxResults = readCount();
		if (masterVo != null) {
			return ((ProjectBudgetItemService) getPagedService()).read(
					firstResult, maxResults, masterVo.getBo());
		} else {
			return ((ProjectBudgetItemService) getPagedService()).read(
					firstResult, maxResults, null);
		}
	}

	public int readCount() {
		if (masterVo != null) {
			return ((ProjectBudgetItemService) getPagedService())
					.readCount(masterVo.getBo());
		} else {
			return ((ProjectBudgetItemService) getPagedService())
					.readCount(null);
		}
	}
}
