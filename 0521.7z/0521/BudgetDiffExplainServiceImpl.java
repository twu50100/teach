package tw.com.skl.exp.kernel.model6.logic.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.collections.CollectionUtils;
import tw.com.skl.common.model6.logic.impl.BaseServiceImpl;
import tw.com.skl.exp.kernel.model6.bo.BudgetDiffExplain;
import tw.com.skl.exp.kernel.model6.bo.ProjectBudget;
import tw.com.skl.exp.kernel.model6.dao.BudgetDiffExplainDao;
import tw.com.skl.exp.kernel.model6.dto.BudgetDiffExplainDto;
import tw.com.skl.exp.kernel.model6.logic.BudgetDiffExplainService;

/**
 * 預算差異說明ServiceImpl
 * @author CU3178
 * @version RE201801038
 */
public class BudgetDiffExplainServiceImpl extends BaseServiceImpl<BudgetDiffExplain, String, BudgetDiffExplainDao> implements BudgetDiffExplainService  {

	/**
	 * 依據上期一般行政與專案預算資料表查詢資料
	 * @param lastProjectBudget
	 * @return
	 */
    public List<BudgetDiffExplain> findBudgetByLastProjectId(ProjectBudget lastProjectBudget) {
    	return getDao().findBudgetByLastProjectId(lastProjectBudget);
    }
    
    /**
     * 依據年度(西元年)及編列單位，查詢一般辦公費預算同期差異說明資料明細
     * @param year 年度
     * @param depCode 編列單位代號
     * @return
     */
	public List<BudgetDiffExplainDto> findNormalBudgetByYearAndDep(int year, String depCode){
		//計算上一年度
		int lastYear = year-1;
		//依據年度、上一年度、單位代號查詢資料
		List list = getDao().findNormalBudgetByYearAndDep(String.valueOf(year), String.valueOf(lastYear), depCode);
	
		List<BudgetDiffExplainDto> dtoList = new ArrayList<BudgetDiffExplainDto>();
		if (!CollectionUtils.isEmpty(list)) {
			for (Object obj : list) {
				BudgetDiffExplainDto dto = new BudgetDiffExplainDto();
			    Object[] record = (Object[]) obj;
			    //預算差異說明ID
			    dto.setBudgetDiffExplainId((String)record[0]);
			    //上一年度一般行政與專案預算資料表ID
			    if(record[1]!=null){	
			    	dto.setLastProjectBudgetId((BigDecimal)record[1]);
			    }else{
			    	dto.setLastProjectBudgetId(BigDecimal.ZERO);
			    }
			    //本年度一般行政與專案預算資料表ID
			    if(record[2]!=null){	
			    	dto.setThisProjectBudgetId((BigDecimal)record[2]);
			    }else{
			    	dto.setThisProjectBudgetId(BigDecimal.ZERO);
			    }
			    //預算項目id
			    if(record[3]!=null){	
			    	dto.setBudgetItemId((BigDecimal)record[3]);
			    }else{
			    	dto.setBudgetItemId(BigDecimal.ZERO);
			    }
			    //預算項目
			    dto.setBudgetItemName((String)record[4]);
			    //上一年度一般辦公費預算金額
			    if(record[5]!=null){	
			    	dto.setLastBudgetAmt((BigDecimal)record[5]);
			    }else{
			    	dto.setLastBudgetAmt(BigDecimal.ZERO);
			    }
			    //本年度一般辦公費預算金額
			    if(record[6]!=null){	
			    	dto.setThisBudgetAmt((BigDecimal)record[6]);
			    }else{
			    	dto.setThisBudgetAmt(BigDecimal.ZERO);
			    }
			    //預算增減=本年度一般辦公費預算金額-上一年度一般辦公費預算金額
			    BigDecimal diffAmt = dto.getThisBudgetAmt().subtract(dto.getLastBudgetAmt());			    
			    dto.setDiffBudgetAmt(diffAmt);
//			    //上一年度預算說明
//			    dto.setLastBudgetExplain((String)record[7]);
//			    //本年度預算說明
//			    dto.setThisBudgetExplain((String)record[8]);
			    //差異說明
			    dto.setDiffExplain((String)record[9]);
			    dtoList.add(dto);
			}
		}
		return dtoList;
	}
	
    /**
     * 依據年度(西元年)及編列單位，查詢專案預算同期差異說明資料明細
     * @param year 年度
     * @param depCode 編列單位代號
     * @return
     */
	public List<BudgetDiffExplainDto> findProjectBudgetByYearAndDep(int year, String depCode){
		//計算上一年度
		int lastYear = year-1;
		//依據年度、上一年度、單位代號查詢資料
		List list = getDao().findProjectBudgetByYearAndDep(String.valueOf(year), String.valueOf(lastYear), depCode);
	
		List<BudgetDiffExplainDto> dtoList = new ArrayList<BudgetDiffExplainDto>();
		if (!CollectionUtils.isEmpty(list)) {
			for (Object obj : list) {
				BudgetDiffExplainDto dto = new BudgetDiffExplainDto();
			    Object[] record = (Object[]) obj;
			    //預算差異說明ID
			    dto.setBudgetDiffExplainId((String)record[0]);
			    //本年度一般行政與專案預算資料表ID
			    if(record[1]!=null){	
			    	dto.setThisProjectBudgetId((BigDecimal)record[1]);
			    }else{
			    	dto.setThisProjectBudgetId(BigDecimal.ZERO);
			    }
			    //專案名稱
			    dto.setProjectName((String)record[2]);
			    //上一年度專案預算金額
			    if(record[3]!=null){	
			    	dto.setLastBudgetAmt((BigDecimal)record[3]);
			    }else{
			    	dto.setLastBudgetAmt(BigDecimal.ZERO);
			    }
			    //本年度專案預算金額
			    if(record[4]!=null){	
			    	dto.setThisBudgetAmt((BigDecimal)record[4]);
			    }else{
			    	dto.setThisBudgetAmt(BigDecimal.ZERO);
			    }
			    //預算增減=本年度一般辦公費預算金額-上一年度一般辦公費預算金額
			    BigDecimal diffAmt = dto.getThisBudgetAmt().subtract(dto.getLastBudgetAmt());			    
			    dto.setDiffBudgetAmt(diffAmt);
			    //差異說明
			    dto.setDiffExplain((String)record[5]);
			    dtoList.add(dto);
			}
		}
		return dtoList;
	}
	
	/**
	 * 依據專案預算資料表ID查詢專案填寫說明資料
	 * @param project_ID
	 * @return
	 */
	public List<BudgetDiffExplainDto> findProjectBudgetByProjectId(BigDecimal project_ID){
		//依據專案預算資料表ID查詢資料
		List list = getDao().findProjectBudgetByProjectId(project_ID);
	
		List<BudgetDiffExplainDto> dtoList = new ArrayList<BudgetDiffExplainDto>();
		if (!CollectionUtils.isEmpty(list)) {
			for (Object obj : list) {
				BudgetDiffExplainDto dto = new BudgetDiffExplainDto();
			    Object[] record = (Object[]) obj;
			    //專案名稱
			    dto.setProjectName((String)record[0]);
			    //預算項目
			    dto.setBudgetItemName((String)record[1]);
			    //上一年度預算金額
			    if(record[2]!=null){	
			    	dto.setLastBudgetAmt((BigDecimal)record[2]);
			    }else{
			    	dto.setLastBudgetAmt(BigDecimal.ZERO);
			    }
			    //本年度預算金額
			    if(record[3]!=null){	
			    	dto.setThisBudgetAmt((BigDecimal)record[3]);
			    }else{
			    	dto.setThisBudgetAmt(BigDecimal.ZERO);
			    }
			    dtoList.add(dto);
			}
		}
		return dtoList;
	}
}
