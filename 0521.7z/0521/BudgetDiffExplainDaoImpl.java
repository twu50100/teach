package tw.com.skl.exp.kernel.model6.dao.jpa;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;

import tw.com.skl.common.model6.dao.jpa.BaseDaoImpl;
import tw.com.skl.exp.kernel.model6.bo.BfmBudgetItem;
import tw.com.skl.exp.kernel.model6.bo.BfmDepartment;
import tw.com.skl.exp.kernel.model6.bo.BudgetDiffExplain;
import tw.com.skl.exp.kernel.model6.bo.BudgetYear;
import tw.com.skl.exp.kernel.model6.bo.Department;
import tw.com.skl.exp.kernel.model6.bo.ProjectBudget;
import tw.com.skl.exp.kernel.model6.common.util.StringUtils;
import tw.com.skl.exp.kernel.model6.dao.BudgetDiffExplainDao;

/**
 * 預算差異說明DaoImpl
 * @author CU3178
 * @version RE201801038
 */
public class BudgetDiffExplainDaoImpl extends BaseDaoImpl<BudgetDiffExplain, String>  implements BudgetDiffExplainDao {
	
	/**
	 * 依據上期一般行政與專案預算資料表查詢資料
	 * @param lastProjectBudget
	 * @return
	 */
    public List<BudgetDiffExplain> findBudgetByLastProjectId(ProjectBudget lastProjectBudget) {
        StringBuffer queryString = new StringBuffer();
        queryString.append("select distinct b");
        queryString.append(" from BudgetDiffExplain b");
        
        Map<String, Object> params = new HashMap<String, Object>();
        queryString.append(" where b.lastProjectBudget.id =:lastProjectBudgetID");

        //依據上期專案代號ID當作查詢條件
        params.put("lastProjectBudgetID", lastProjectBudget.getId());

        List<BudgetDiffExplain> list = findByNamedParams(queryString.toString(), params);

        if (!CollectionUtils.isEmpty(list)) {
            return list;
        } else {
            return null;
        }
    }
        
    /**
     * 依據年度(西元年)及編列單位，查詢一般辦公費預算同期差異說明資料明細
     * @param thisYear 本年度
     * @param lastYear 上年度
     * @param depCode 編列單位代號
     * @return
     */
	public List findNormalBudgetByYearAndDep(String thisYear ,String lastYear, String depCode){
		StringBuilder queryString = new StringBuilder();
		queryString.append("     ");
		queryString.append(" SELECT  ");
		queryString.append("   BDE.ID AS BDE_ID, ");
		queryString.append("   LAST_PROJECT.PID AS LastProjectId, ");
		queryString.append("   PB.ID AS thisProjectId, ");
		queryString.append("   BI.ID AS budgetItemId, ");
		queryString.append("   BI.NAME AS budgetName, ");
		queryString.append("   LAST_PROJECT.AMT AS lastBudgetAmt, ");
		queryString.append("   PBI.AMOUNT AS thisBudgetAmt, ");
		queryString.append("   LAST_PROJECT.NOTATION AS lastBudgetExplain, ");
		queryString.append("   PBI.BUDGET_NOTATION AS thisBudgetExplain,  ");
		queryString.append("   BDE.DIFF_EXPLAIN AS diffExplain ");
		queryString.append(" FROM TBBFM_BUDGETS B ");
		queryString.append(" INNER JOIN TBBFM_DEPARTMENTS DEP ON DEP.ID=B.TBBFM_DEPARTMENTS_ID ");
		queryString.append(" INNER JOIN TBBFM_PROJECT_BUDGETS PB ON PB.TBBFM_BUDGETS_ID=B.ID ");
		queryString.append(" INNER JOIN TBBFM_BUDGET_TYPES BT ON BT.ID=PB.TBBFM_BUDGET_TYPES_ID ");
		queryString.append(" INNER JOIN TBBFM_PROJECT_BUDGET_ITEMS PBI ON PBI.TBBFM_PROJECT_BUDGETS_ID=PB.ID ");
		queryString.append(" INNER JOIN TBBFM_BUDGET_ITEMS BI ON BI.ID=PBI.TBBFM_BUDGET_ITEMS_ID ");
		queryString.append(" LEFT JOIN TBBFM_BUDGET_DIFF_EXPLAINS BDE ON BDE.TBBFM_THIS_PROJECT_BUDGETS_ID=PB.ID AND BDE.TBBFM_BUDGET_ITEMS_ID=BI.ID ");
		queryString.append(" LEFT JOIN ( ");
		queryString.append("   SELECT  ");
		queryString.append("     PB.ID AS PID, ");
		queryString.append("     BI.ID AS BID, ");
		queryString.append("     PBI.AMOUNT AS AMT, ");
		queryString.append("     PBI.BUDGET_NOTATION AS NOTATION ");
		queryString.append("   FROM TBBFM_BUDGETS B ");
		queryString.append("   INNER JOIN TBBFM_DEPARTMENTS DEP ON DEP.ID=B.TBBFM_DEPARTMENTS_ID ");
		queryString.append("   INNER JOIN TBBFM_PROJECT_BUDGETS PB ON PB.TBBFM_BUDGETS_ID=B.ID ");
		queryString.append("   INNER JOIN TBBFM_BUDGET_TYPES BT ON BT.ID=PB.TBBFM_BUDGET_TYPES_ID ");
		queryString.append("   INNER JOIN TBBFM_PROJECT_BUDGET_ITEMS PBI ON PBI.TBBFM_PROJECT_BUDGETS_ID=PB.ID ");
		queryString.append("   INNER JOIN TBBFM_BUDGET_ITEMS BI ON BI.ID=PBI.TBBFM_BUDGET_ITEMS_ID ");
		queryString.append("   WHERE BT.ID=1  ");
		queryString.append("  		 AND B.YEAR='").append(thisYear).append("' "); //本年度
		queryString.append("		 AND DEP.CODE='").append(depCode).append("' "); //編列單位
		queryString.append("   )LAST_PROJECT ON LAST_PROJECT.BID=BI.ID ");
		queryString.append(" WHERE BT.ID=1  ");
		queryString.append("  AND B.YEAR='").append(lastYear).append("'  "); //上年度
		queryString.append("  AND DEP.CODE='").append(depCode).append("'  "); //編列單位

		List<Object> parameters = new ArrayList<Object>();
		List result = findNativeSQLByParameters(queryString.toString(),
				parameters);
    	return result;    		
	}
	
    /**
     * 依據年度(西元年)及編列單位，查詢專案預算同期差異說明資料明細
     * @param thisYear 本年度
     * @param lastYear 上年度
     * @param depCode 編列單位代號
     * @return
     */
	public List findProjectBudgetByYearAndDep(String thisYear ,String lastYear, String depCode){
		StringBuilder queryString = new StringBuilder();
		queryString.append(" SELECT  ");
		queryString.append("   BDE.ID AS BDE_ID, ");
		queryString.append("   PB.ID AS thisProjectId, ");
		queryString.append("   PB.NAME AS projectName, ");
		queryString.append("   LAST_AMOUNT.AMT AS lastProjectAmt, ");
		queryString.append("   THIS_AMOUNT.AMT AS thisProjectAmt, ");
		queryString.append("   BDE.DIFF_EXPLAIN AS diffExplain ");
		queryString.append(" FROM TBBFM_BUDGETS B ");
		queryString.append(" INNER JOIN TBBFM_DEPARTMENTS DEP ON DEP.ID=B.TBBFM_DEPARTMENTS_ID ");
		queryString.append(" INNER JOIN TBBFM_PROJECT_BUDGETS PB ON PB.TBBFM_BUDGETS_ID=B.ID ");
		queryString.append(" INNER JOIN TBBFM_BUDGET_TYPES BT ON BT.ID=PB.TBBFM_BUDGET_TYPES_ID ");
		queryString.append(" INNER JOIN TBBFM_BUDGET_DIFF_EXPLAINS BDE ON BDE.TBBFM_THIS_PROJECT_BUDGETS_ID=PB.ID  ");
		queryString.append(" INNER JOIN TBBFM_PROJECT_BUDGETS LAST_PB ON BDE.TBBFM_LAST_PROJECT_BUDGETS_ID=LAST_PB.ID ");
		queryString.append(" LEFT JOIN ( ");
		queryString.append("   SELECT  ");
		queryString.append("     PB.ID AS PID, ");
		queryString.append("     SUM(PBI.AMOUNT) AS AMT ");
		queryString.append("   FROM TBBFM_BUDGETS B ");
		queryString.append("   INNER JOIN TBBFM_DEPARTMENTS DEP ON DEP.ID=B.TBBFM_DEPARTMENTS_ID ");
		queryString.append("   INNER JOIN TBBFM_PROJECT_BUDGETS PB ON PB.TBBFM_BUDGETS_ID=B.ID ");
		queryString.append("   INNER JOIN TBBFM_BUDGET_TYPES BT ON BT.ID=PB.TBBFM_BUDGET_TYPES_ID ");
		queryString.append("   INNER JOIN TBBFM_PROJECT_BUDGET_ITEMS PBI ON PBI.TBBFM_PROJECT_BUDGETS_ID=PB.ID ");
		queryString.append("   WHERE BT.ID=2 AND B.YEAR='").append(thisYear).append("' ");//本年度
		queryString.append("   		 AND DEP.CODE='").append(depCode).append("' ");//編列單位
		queryString.append("   GROUP BY PB.ID ");
		queryString.append(" )THIS_AMOUNT ON THIS_AMOUNT.PID=PB.ID ");
		queryString.append(" LEFT JOIN ( ");
		queryString.append("   SELECT  ");
		queryString.append("     PB.ID AS PID, ");
		queryString.append("     SUM(PBI.AMOUNT) AS AMT ");
		queryString.append("   FROM TBBFM_BUDGETS B ");
		queryString.append("   INNER JOIN TBBFM_DEPARTMENTS DEP ON DEP.ID=B.TBBFM_DEPARTMENTS_ID ");
		queryString.append("   INNER JOIN TBBFM_PROJECT_BUDGETS PB ON PB.TBBFM_BUDGETS_ID=B.ID ");
		queryString.append("   INNER JOIN TBBFM_BUDGET_TYPES BT ON BT.ID=PB.TBBFM_BUDGET_TYPES_ID ");
		queryString.append("   INNER JOIN TBBFM_PROJECT_BUDGET_ITEMS PBI ON PBI.TBBFM_PROJECT_BUDGETS_ID=PB.ID ");
		queryString.append("   WHERE BT.ID=2 AND B.YEAR='").append(lastYear).append("'  ");//上年度
		queryString.append("         AND DEP.CODE='").append(depCode).append("' ");//編列單位
		queryString.append("   GROUP BY PB.ID ");
		queryString.append(" )LAST_AMOUNT ON LAST_AMOUNT.PID=LAST_PB.ID ");
		queryString.append(" WHERE BT.ID=2 AND B.YEAR='").append(thisYear).append("'  ");//本年度
		queryString.append(" 	AND DEP.CODE='").append(depCode).append("'  ");//編列單位

		List<Object> parameters = new ArrayList<Object>();
		List result = findNativeSQLByParameters(queryString.toString(),
				parameters);
    	return result;    		
	}
	
	/**
	 * 依據專案預算資料表ID查詢專案填寫說明資料
	 * @param project_ID
	 * @return
	 */
	public List findProjectBudgetByProjectId(BigDecimal project_ID){
		StringBuilder queryString = new StringBuilder();

		queryString.append("  SELECT   ");
		queryString.append("    PB.NAME AS PNAME, ");
		queryString.append(" 	BI.NAME AS BNAME, ");
		queryString.append(" 	LAST_PBI.AMOUNT AS LAST_AMT, ");
		queryString.append(" 	PBI.AMOUNT AS THIS_AMT ");
		queryString.append(" FROM TBBFM_BUDGETS B 		 "); 
		queryString.append(" INNER JOIN TBBFM_PROJECT_BUDGETS PB ON PB.TBBFM_BUDGETS_ID=B.ID "); 		 
		queryString.append(" INNER JOIN TBBFM_PROJECT_BUDGET_ITEMS PBI ON PBI.TBBFM_PROJECT_BUDGETS_ID=PB.ID ");
		queryString.append(" INNER JOIN TBBFM_BUDGET_ITEMS BI ON BI.ID=PBI.TBBFM_BUDGET_ITEMS_ID ");
		queryString.append(" INNER JOIN TBBFM_BUDGET_DIFF_EXPLAINS BDE ON BDE.TBBFM_THIS_PROJECT_BUDGETS_ID=PB.ID ");
		queryString.append(" INNER JOIN TBBFM_PROJECT_BUDGETS LAST_PB ON BDE.TBBFM_LAST_PROJECT_BUDGETS_ID=LAST_PB.ID  ");
		queryString.append(" LEFT JOIN TBBFM_PROJECT_BUDGET_ITEMS LAST_PBI ON LAST_PBI.TBBFM_PROJECT_BUDGETS_ID=LAST_PB.ID "); 
		queryString.append(" 			AND LAST_PBI.TBBFM_BUDGET_ITEMS_ID=PBI.TBBFM_BUDGET_ITEMS_ID ");
		queryString.append("  WHERE PB.ID=").append(project_ID).append(" ");//專案預算資料表id

		List<Object> parameters = new ArrayList<Object>();
		List result = findNativeSQLByParameters(queryString.toString(),
				parameters);
    	return result;    		
	}

}
