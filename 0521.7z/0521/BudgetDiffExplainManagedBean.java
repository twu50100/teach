package tw.com.skl.exp.web.jsf.managed.bd.provisionbudget;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;

import org.apache.commons.lang.StringUtils;
import org.apache.myfaces.trinidad.component.core.data.CoreTable;
import org.apache.myfaces.trinidad.model.CollectionModel;
import org.apache.myfaces.trinidad.model.SortableModel;
import org.springframework.util.CollectionUtils;

import tw.com.skl.common.model6.web.jsf.managedbean.impl.TemplateDataTableManagedBean;
import tw.com.skl.common.model6.web.jsf.utils.FacesUtils;
import tw.com.skl.common.model6.web.util.MessageManager;
import tw.com.skl.common.model6.web.vo.ValueObject;
import tw.com.skl.exp.kernel.model6.bo.BfmBudgetItem;
import tw.com.skl.exp.kernel.model6.bo.BfmDepartment;
import tw.com.skl.exp.kernel.model6.bo.BudgetDiffExplain;
import tw.com.skl.exp.kernel.model6.bo.BudgetYear;
import tw.com.skl.exp.kernel.model6.bo.ProjectBudget;
import tw.com.skl.exp.kernel.model6.bo.User;
import tw.com.skl.exp.kernel.model6.common.ErrorCode;
import tw.com.skl.exp.kernel.model6.common.exception.ExpRuntimeException;
import tw.com.skl.exp.kernel.model6.common.util.AAUtils;
import tw.com.skl.exp.kernel.model6.common.util.MessageUtils;
import tw.com.skl.exp.kernel.model6.dto.BudgetDiffExplainDto;
import tw.com.skl.exp.kernel.model6.dto.SpliteBudgetItemDto;
import tw.com.skl.exp.kernel.model6.facade.BudgetDiffExplainFacade;
import tw.com.skl.exp.kernel.model6.logic.BudgetDiffExplainService;
import tw.com.skl.exp.web.util.BfmSelectFactory;

/**
 * E1.6預算同期差異說明表單
 * @author CU3178
 *
 */
public class BudgetDiffExplainManagedBean
		extends
		TemplateDataTableManagedBean<BudgetDiffExplain, BudgetDiffExplainService> {


	private BudgetDiffExplainFacade facade;
	
	/**
	 * 年度Map
	 */
	private Map<String, BudgetYear> budgetYearMap = null;
	
	/**
	 * 編列單位Map
	 */
	private Map<String, BfmDepartment> departmentMap = null;

	/**
	 * 頁面選取的年度
	 */
	private String selectBudgetYearId;

	/**
	 * 頁面選取的編列單位
	 */
	private String selectDepartmentId;

	/**
	 * 年度下拉式選單
	 */
	private List<SelectItem> budgetYearList = null;

	/**
	 * 編列單位下拉式選單
	 */
	private List<SelectItem> departmentList = null;
	
	/**
	 * 預算差異說明頁面 Table
	 */
	private CoreTable resultDataTable;

	/**
	 * 預算差異說明頁面 DataModel
	 */
	private CollectionModel resultDataModel;

	/**
	 * 預算差異說明頁面 DateList
	 */
	private List<BudgetDiffExplainDto> resultList = new ArrayList<BudgetDiffExplainDto>();
	
	/**
	 * 預算填寫說明頁面 Table
	 */
	private CoreTable createPageDataTable;

	/**
	 * 預算填寫說明頁面DataModel
	 */
	private CollectionModel createPageDataModel;

	/**
	 * 預算填寫說明頁面 DateList
	 */
	private List<BudgetDiffExplainDto> createPageList = new ArrayList<BudgetDiffExplainDto>();
	
	/**
	 * 頁面填寫預算差異說明dto
	 */
	private BudgetDiffExplainDto createBudgetDiffDto;

	public BudgetDiffExplainManagedBean() {

	}

	@Override
	protected void initFindCriteriaMap() {
		// TODO Auto-generated method stub

	}

	@Override
	protected void initCreatingData() {

	}

	@Override
	protected void initUpdatingData(ValueObject<BudgetDiffExplain> updatingData) {

	}

	@Override
	protected void setupUpdatingData() {

	}
	
	/**
	 * 初始化查詢頁面
	 */
	public void initReadPage(){
		this.setResultDataModel(null);
		this.setResultList(null);
	}
	
	/**
	 * 初始化填寫說明頁面
	 */
	public void initCreatePage(){
		this.setCreatePageDataModel(null);
		this.setCreatePageList(null);
	}
	
	
	/**
	 * [一般辦公費]查詢按鈕
	 */
	public String doFindNormalAction() {
		// 檢核頁面年度不可為空值
		if (StringUtils.isBlank(getSelectBudgetYearId())) {
			throw new ExpRuntimeException(ErrorCode.A10001,
					new String[] { MessageUtils.getAccessor().getMessage(
							"tw_com_skl_exp_kernel_model6_bo_BudgetIn_year") });
		}
		
		// 檢核頁面編列年度不可為空值
		if (StringUtils.isBlank(getSelectDepartmentId())) {
			throw new ExpRuntimeException(ErrorCode.A10001,
					new String[] { MessageUtils.getAccessor().getMessage(
							"tw_com_skl_bfm_kernel_model5_web_ProjectBudget_department") });
		}
		// 初始資料
		initReadPage();

		// 查出資料
		setResultList(findNormalData());
		if (CollectionUtils.isEmpty(getResultList())) {
			throw new ExpRuntimeException(ErrorCode.C10028);
		}
		return "normal";
	}
	
	/**
	 * [專案]查詢按鈕
	 */
	public String doFindProjectAction() {
		// 檢核頁面年度不可為空值
		if (StringUtils.isBlank(getSelectBudgetYearId())) {
			throw new ExpRuntimeException(ErrorCode.A10001,
					new String[] { MessageUtils.getAccessor().getMessage(
							"tw_com_skl_exp_kernel_model6_bo_BudgetIn_year") });
		}
		
		// 檢核頁面編列年度不可為空值
		if (StringUtils.isBlank(getSelectDepartmentId())) {
			throw new ExpRuntimeException(ErrorCode.A10001,
					new String[] { MessageUtils.getAccessor().getMessage(
							"tw_com_skl_bfm_kernel_model5_web_ProjectBudget_department") });
		}
		// 初始資料
		initReadPage();

		// 查出資料
		setResultList(findProjectData());
		if (CollectionUtils.isEmpty(getResultList())) {
			throw new ExpRuntimeException(ErrorCode.C10028);
		}
		return "project";
	}
	
	/**
	 * [返回]查詢按鈕
	 * @return
	 */
	public String doReturnAction(){
		// 初始資料
		initReadPage();
		return "read";
	}
	
	/**
	 * 查詢一般辦公費差異說明資料
	 * 
	 * @return
	 */
	private List<BudgetDiffExplainDto> findNormalData() {
		List<BudgetDiffExplainDto> dtoList = new ArrayList<BudgetDiffExplainDto>();
		//頁面年度
		BudgetYear budgetYear = budgetYearMap.get(this.getSelectBudgetYearId());
		//葉面編列單位
		BfmDepartment department=departmentMap.get(this.getSelectDepartmentId());
		// 依據頁面選擇的條件查詢資料
		dtoList = getService().findNormalBudgetByYearAndDep(budgetYear.getYear(), department.getCode());
		return dtoList;
	}
	
	/**
	 * 查詢專案差異說明資料
	 * 
	 * @return
	 */
	private List<BudgetDiffExplainDto> findProjectData() {
		List<BudgetDiffExplainDto> dtoList = new ArrayList<BudgetDiffExplainDto>();
		//頁面年度
		BudgetYear budgetYear = budgetYearMap.get(this.getSelectBudgetYearId());
		//葉面編列單位
		BfmDepartment department=departmentMap.get(this.getSelectDepartmentId());
		// 依據頁面選擇的條件查詢資料
		dtoList = getService().findProjectBudgetByYearAndDep(budgetYear.getYear(), department.getCode());
		return dtoList;
	}
	
	/**
	 * 一般辦公費[填寫說明]按鈕
	 * @return
	 */
	public String doWriteBudgetDiffExplainNormalAction(){
		//顯示抓取的資料
		BudgetDiffExplainDto dto = (BudgetDiffExplainDto) this.getResultDataTable()
				.getRowData();
		List<BudgetDiffExplainDto> listDto = new ArrayList<BudgetDiffExplainDto>();
		listDto.add(dto);
		//初始化頁面
		initCreatePage();
		// 將要修改的資料放入
		setCreatePageList(listDto);		
		//放入差異說明
		setCreateBudgetDiffDto(dto);
		return "create";
	}
	
	/**
	 * 一般辦公費填寫說明[儲存]按鈕
	 * @return
	 */
	public String doSaveCreateNormalAction(){
		// 檢核差異說明不可為空值
		if (StringUtils.isBlank(getCreateBudgetDiffDto().getDiffExplain())) {
			throw new ExpRuntimeException(ErrorCode.A10001,
					new String[] { MessageUtils.getAccessor().getMessage(
							"tw_com_skl_exp_web_budgetDiffExplain_diffExplain") });
		}
		//登入人員
		User user = (User) AAUtils.getLoggedInUser();
		
		//判斷該筆一般辦公費差異說明是否已有存在，若無則須新增一筆TBBFM_BUDGET_DIFF_EXPLAINS
		//若有則更新原本的TBBFM_BUDGET_DIFF_EXPLAINS		
		//依據該筆資料的budgetDiffExplainId判斷是否已有儲存過
		if(StringUtils.isBlank(getCreateBudgetDiffDto().getBudgetDiffExplainId())){
			//尚未儲存過，新增一筆TBBFM_BUDGET_DIFF_EXPLAINS
			BudgetDiffExplain bo = new BudgetDiffExplain();			
			//判斷上期預算資料表是否存在
			if(getCreateBudgetDiffDto().getLastProjectBudgetId().compareTo(BigDecimal.ZERO)>0){
				//放入上期預算資料表
				ProjectBudget lastProjectBudget = facade.getProjectBudgetService().findByPK(getCreateBudgetDiffDto().getLastProjectBudgetId().toString());				
				bo.setLastProjectBudget(lastProjectBudget);
			}			
			//放入本期預算資料表						
			ProjectBudget thisProjectBudget = facade.getProjectBudgetService().findByPK(getCreateBudgetDiffDto().getThisProjectBudgetId().toString());			
			bo.setThisProjectBudget(thisProjectBudget);			
			//放入預算項目
			BfmBudgetItem bi = facade.getBfmBudgetItemService().findByPK(getCreateBudgetDiffDto().getBudgetItemId().toString());
			bo.setBfmBudgetItem(bi);	
			//放入差異說明
			bo.setDiffExplain(getCreateBudgetDiffDto().getDiffExplain());			
			//建立人員
			bo.setCreateUser(user);
			//儲存資料
			getService().create(bo);						
		}else{
			//已有儲存過，更新原本TBBFM_BUDGET_DIFF_EXPLAINS
			BudgetDiffExplain bo = getService().findByPK(getCreateBudgetDiffDto().getBudgetDiffExplainId());
			//放入差異說明
			bo.setDiffExplain(getCreateBudgetDiffDto().getDiffExplain());
			//修改人員
			bo.setUpdateUser(user);
			//儲存資料
			getService().update(bo);			
		}	
		//重新查詢頁面資料
		// 初始資料
		initReadPage();
		// 查出資料
		setResultList(findNormalData());
		return "normal";
	}
	
	/**
	 * 一般辦公費填寫說明[返回]按鈕
	 * @return
	 */
	public String doReturnNormalAction(){
		// 初始資料
		initReadPage();
		// 查出資料
		setResultList(findNormalData());
		return "normal";
	}
	
	/**
	 * 專案[填寫說明]按鈕
	 * @return
	 */
	public String doWriteBudgetDiffExplainProjectAction(){
		//抓取的資料
		BudgetDiffExplainDto dto = (BudgetDiffExplainDto) this.getResultDataTable()
				.getRowData();
		//依據選取的專案id查詢資料
		List<BudgetDiffExplainDto> listDto = getService().findProjectBudgetByProjectId(dto.getThisProjectBudgetId());
		//初始化頁面
		initCreatePage();
		// 將要修改的資料放入
		setCreatePageList(listDto);		
		//放入差異說明
		setCreateBudgetDiffDto(dto);
		return "create";
	}
	
	/**
	 * 專案填寫說明[儲存]按鈕
	 * @return
	 */
	public String doSaveCreateProjectAction(){
		// 檢核差異說明不可為空值
		if (StringUtils.isBlank(getCreateBudgetDiffDto().getDiffExplain())) {
			throw new ExpRuntimeException(ErrorCode.A10001,
					new String[] { MessageUtils.getAccessor().getMessage(
							"tw_com_skl_exp_web_budgetDiffExplain_diffExplain") });
		}
		//登入人員
		User user = (User) AAUtils.getLoggedInUser();
		//已有儲存過，更新原本TBBFM_BUDGET_DIFF_EXPLAINS
		BudgetDiffExplain bo = getService().findByPK(getCreateBudgetDiffDto().getBudgetDiffExplainId());
		//放入差異說明
		bo.setDiffExplain(getCreateBudgetDiffDto().getDiffExplain());
		//修改人員
		bo.setUpdateUser(user);
		//儲存資料
		getService().update(bo);			
		
		//重新查詢頁面資料
		// 初始資料
		initReadPage();
		// 查出資料
		setResultList(findProjectData());
		return "project";
	}
	
	/**
	 * 專案填寫說明[返回]按鈕
	 * @return
	 */
	public String doReturnProjectAction(){
		// 初始資料
		initReadPage();
		// 查出資料
		setResultList(findProjectData());
		return "project";
	}
	
	/**
	 * 顯示上一年度
	 * @return
	 */
	public String getWebLastYear(){
		//頁面年度
		BudgetYear budgetYear = budgetYearMap.get(this.getSelectBudgetYearId());
		//頁面年度-1(取民國年)
		String lastYear = String.valueOf(budgetYear.getYear()-1-1911);
		return lastYear;
	}
	
	/**
	 * 顯示今年年度
	 * @return
	 */
	public String getWebThisYear(){
		//頁面年度
		BudgetYear budgetYear = budgetYearMap.get(this.getSelectBudgetYearId());
		//頁面年度(取民國年)
		String thisYear = String.valueOf(budgetYear.getYear()-1911);
		return thisYear;
	}
	
	/**
	 * 預算差異說明Facade
	 * @return
	 */
	public BudgetDiffExplainFacade getFacade() {
		return facade;
	}

	/**
	 * 預算差異說明Facade
	 * @param facade
	 */
	public void setFacade(BudgetDiffExplainFacade facade) {
		this.facade = facade;
	}
	
	/**
	 * 頁面選取的年度
	 * @return
	 */
	public String getSelectBudgetYearId() {
		return selectBudgetYearId;
	}

	/**
	 * 頁面選取的年度
	 * @param selectBudgetYearId
	 */
	public void setSelectBudgetYearId(String selectBudgetYearId) {
		this.selectBudgetYearId = selectBudgetYearId;
	}

	/**
	 * 頁面選取的編列單位
	 * @return
	 */
	public String getSelectDepartmentId() {		
		return selectDepartmentId;
	}

	/**
	 * 頁面選取的編列單位
	 * @param selectDepartmentId
	 */
	public void setSelectDepartmentId(String selectDepartmentId) {
		this.selectDepartmentId = selectDepartmentId;
	}

	/**
	 * 年度下拉式選單
	 * @return
	 */
	public List<SelectItem> getBudgetYearList() {
		if (this.budgetYearList == null) {
			//帶出前兩年度
			this.budgetYearList = BfmSelectFactory
					.creatFirstSecondYearBudgetYearOrderByYearDescSelect()
					.getSelectList();
			this.budgetYearMap = (Map<String, BudgetYear>) FacesUtils
					.getSessionScope().get("firstSecondBudgetYearMap");
		}
		return budgetYearList;
	}

	/**
	 * 年度下拉式選單
	 * @param budgetYearList
	 */
	public void setBudgetYearList(List<SelectItem> budgetYearList) {
		this.budgetYearList = budgetYearList;
	}

	/**
	 * 編列單位下拉式選單
	 * @return
	 */
	public List<SelectItem> getDepartmentList() {
		if (this.selectBudgetYearId!=null&&departmentList==null) {
			//抓取目前登入人員的資料
			User user = (User) AAUtils.getLoggedInUser();
			this.departmentList = BfmSelectFactory.creatDepartmentByYearForProjectBudgetNormalBudget(budgetYearMap.get(selectBudgetYearId), user).getSelectList();
			this.departmentMap = (Map<String, BfmDepartment>)FacesUtils.getSessionScope().get("departmentMap");
		}
		return departmentList;
	}

	/**
	 * 編列單位下拉式選單
	 * @param departmentList
	 */
	public void setDepartmentList(List<SelectItem> departmentList) {
		this.departmentList = departmentList;
	}

	/**
	 * 預算差異說明頁面 Table
	 * @return
	 */
	public CoreTable getResultDataTable() {
		return resultDataTable;
	}

	/**
	 * 預算差異說明頁面 Table
	 * @param resultDataTable
	 */
	public void setResultDataTable(CoreTable resultDataTable) {
		this.resultDataTable = resultDataTable;
	}

	/**
	 * 預算差異說明頁面 DataModel
	 * @return
	 */
	public CollectionModel getResultDataModel() {
		if (this.resultDataModel == null) {
			this.resultDataModel = new SortableModel();
			resultDataModel.setWrappedData(this.getResultList());
		}
		return resultDataModel;
	}

	/**
	 * 預算差異說明頁面 DataModel
	 * @param resultDataModel
	 */
	public void setResultDataModel(CollectionModel resultDataModel) {
		this.resultDataModel = resultDataModel;
	}

	/**
	 * 預算差異說明頁面 DateList
	 * @return
	 */
	public List<BudgetDiffExplainDto> getResultList() {
		return resultList;
	}

	/**
	 * 預算差異說明頁面 DateList
	 * @param resultList
	 */
	public void setResultList(List<BudgetDiffExplainDto> resultList) {
		this.resultList = resultList;
	}

	/**
	 * 預算填寫說明頁面DataModel
	 * @return
	 */
	public CollectionModel getCreatePageDataModel() {
		if (this.createPageDataModel == null) {
			this.createPageDataModel = new SortableModel();
			createPageDataModel.setWrappedData(this.getCreatePageList());
		}
		return createPageDataModel;
	}

	/**
	 * 預算填寫說明頁面DataModel
	 * @param createPageDataModel
	 */
	public void setCreatePageDataModel(CollectionModel createPageDataModel) {
		this.createPageDataModel = createPageDataModel;
	}

	/**
	 * 預算填寫說明頁面 DateList
	 * @return
	 */
	public List<BudgetDiffExplainDto> getCreatePageList() {
		return createPageList;
	}

	/**
	 * 預算填寫說明頁面 DateList
	 * @param createPageList
	 */
	public void setCreatePageList(List<BudgetDiffExplainDto> createPageList) {
		this.createPageList = createPageList;
	}
	

	/**
	 * 預算填寫說明頁面 Table
	 * @return
	 */
	public CoreTable getCreatePageDataTable() {
		return createPageDataTable;
	}

	/**
	 * 預算填寫說明頁面 Table
	 * @param createPageDataTable
	 */
	public void setCreatePageDataTable(CoreTable createPageDataTable) {
		this.createPageDataTable = createPageDataTable;
	}

	/**
	 * 頁面填寫預算差異說明dto
	 * @return
	 */
	public BudgetDiffExplainDto getCreateBudgetDiffDto() {
		return createBudgetDiffDto;
	}

	/**
	 * 頁面填寫預算差異說明dto
	 * @param createBudgetDiffDto
	 */
	public void setCreateBudgetDiffDto(BudgetDiffExplainDto createBudgetDiffDto) {
		this.createBudgetDiffDto = createBudgetDiffDto;
	}

}
