package tw.com.skl.exp.kernel.model6.dao;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;

import tw.com.skl.common.model6.dao.BaseDao;
import tw.com.skl.exp.kernel.model6.bo.BudgetDiffExplain;
import tw.com.skl.exp.kernel.model6.bo.ProjectBudget;

/**
 * 預算差異說明 DAO
 * @author CU3178
 * @version RE201801038
 */
public interface BudgetDiffExplainDao extends BaseDao<BudgetDiffExplain, String>  {
	
	/**
	 * 依據上期一般行政與專案預算資料表查詢資料
	 * @param lastProjectBudget
	 * @return
	 */
    List<BudgetDiffExplain> findBudgetByLastProjectId(ProjectBudget lastProjectBudget);
    
    /**
     * 依據年度(西元年)及編列單位，查詢一般辦公費預算同期差異說明資料明細
     * @param thisYear 本年度
     * @param lastYear 上年度
     * @param depCode 編列單位代號
     * @return
     */
	List findNormalBudgetByYearAndDep(String thisYear ,String lastYear, String depCode);
	
    /**
     * 依據年度(西元年)及編列單位，查詢專案預算同期差異說明資料明細
     * @param thisYear 本年度
     * @param lastYear 上年度
     * @param depCode 編列單位代號
     * @return
     */
	List findProjectBudgetByYearAndDep(String thisYear ,String lastYear, String depCode);
	
	/**
	 * 依據專案預算資料表ID查詢專案填寫說明資料
	 * @param project_ID
	 * @return
	 */
	List findProjectBudgetByProjectId(BigDecimal project_ID);
}

