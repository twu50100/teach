Imports System.Windows.Forms
Imports eLoan_Gateway
Imports System.IO

Module eLoanJcic
    Private g_objSettings As ClassLib.Settings
    Private g_strLogPath As String = Nothing
    Private g_writeLog As eLoan_Gateway.ClassLib.WriteLog
    Private Crypt As New ClassLib.Cryptography
    Private g_strDBConnString_LOAN As String = Nothing
    Private g_strDBConnString_IMP_DJCIC As String = Nothing
    Private g_strDBConnString_DJCIC As String = Nothing
    Private g_strAPI_Jcic As String = Nothing
    Private g_blnJcicEnable As Boolean = False
    Private g_strJcicTables As String = Nothing
    Private g_intJcicInterval As Integer = 0
    Private g_blnTchEnable As Boolean = False
    Private g_strTchTables As String = Nothing
    Private g_intTchInterval As Integer = 0
    Private g_blnOutSourceLog As Boolean = False
    Private g_outSourceHandler As New ArrayList()

    Sub Main()
        g_objSettings = New ClassLib.Settings(Application.StartupPath)

        Try
            '�O���ɥؿ�
            g_strLogPath = CStr(g_objSettings.ReadSetting("JcicLogPath")).TrimEnd("\") & "\"

            g_writeLog = New eLoan_Gateway.ClassLib.WriteLog(g_strLogPath)

            '��Ʈw�s������
            g_strDBConnString_LOAN = CStr(g_objSettings.ReadSetting("DBConnString_LOAN"))
            g_strDBConnString_IMP_DJCIC = CStr(g_objSettings.ReadSetting("DBConnString_IMP_DJCIC"))
            g_strDBConnString_DJCIC = CStr(g_objSettings.ReadSetting("DBConnString_DJCIC"))

            '�[�K��Ʈw�s������
            'g_strDBConnString_LOAN = g_strDBConnString_LOAN.ToString.Split(New String() {";pwd="}, StringSplitOptions.None)(0) & ";pwd=" & Crypt.Dec(g_strDBConnString_LOAN.ToString.Split(New String() {";pwd="}, StringSplitOptions.None)(1))
            'g_strDBConnString_IMP_DJCIC = g_strDBConnString_IMP_DJCIC.ToString.Split(New String() {";pwd="}, StringSplitOptions.None)(0) & ";pwd=" & Crypt.Dec(g_strDBConnString_IMP_DJCIC.ToString.Split(New String() {";pwd="}, StringSplitOptions.None)(1))
            'g_strDBConnString_DJCIC = g_strDBConnString_DJCIC.ToString.Split(New String() {";pwd="}, StringSplitOptions.None)(0) & ";pwd=" & Crypt.Dec(g_strDBConnString_DJCIC.ToString.Split(New String() {";pwd="}, StringSplitOptions.None)(1))

            '�p�x�����X������}
            'g_strAPI_Jcic = CStr(g_objSettings.ReadSetting("API_Jcic")).Trim

            '�O�_�ҥ��p�x��Ƭd��
            g_blnJcicEnable = CBool(g_objSettings.ReadSetting("JcicEnable"))
            '�p�x�ӷ���ƪ�
            g_strJcicTables = CStr(g_objSettings.ReadSetting("JcicTables"))
            '�p�x�B�z���j�ɶ�
            g_intJcicInterval = CInt(g_objSettings.ReadSetting("JcicInterval"))

            ''�O�_�ҥβ����Ƭd��
            'g_blnTchEnable = CBool(g_objSettings.ReadSetting("TchEnable"))
            ''����ӷ���ƪ�
            'g_strTchTables = CStr(g_objSettings.ReadSetting("TchTables"))
            ''����B�z���j�ɶ�
            'g_intTchInterval = CInt(g_objSettings.ReadSetting("TchInterval"))

            g_blnOutSourceLog = CBool(g_objSettings.ReadSetting("OutSourceLog"))

            Dim m_strLifeFile As String = Application.StartupPath.TrimEnd("\") & "\eLoanJcic.life"
            Try
                File.WriteAllText(m_strLifeFile, "LIFE")
            Catch ex As Exception
            End Try

            '�Ұ��p�x�d��
            If g_blnJcicEnable Then
                g_outSourceHandler.Add(New JcicHandler(g_strDBConnString_LOAN, g_strJcicTables, g_intJcicInterval, g_strLogPath, g_strDBConnString_IMP_DJCIC, g_strDBConnString_DJCIC))
            End If

            For i As Integer = 0 To g_outSourceHandler.Count - 1
                'CType(g_outSourceHandler(i), IOutSourceHandler).OutSourceLog = g_blnOutSourceLog
                CType(g_outSourceHandler(i), IOutSourceHandler).StartThread()
            Next

            g_writeLog.WriteErrorLog("Jcic:�B�z�`���w�Ұ�...")

            While File.Exists(m_strLifeFile)
                Threading.Thread.Sleep(5000)
            End While

        Catch ex As Exception
            If g_writeLog IsNot Nothing Then
                g_writeLog.WriteErrorLog("Jcic:Failed to Load Settings, " & ex.Message)
            End If
            Exit Sub
        Finally

            For i As Integer = 0 To g_outSourceHandler.Count - 1
                CType(g_outSourceHandler(i), IOutSourceHandler).StopThread()
            Next
            g_outSourceHandler.Clear()

            g_writeLog.WriteErrorLog("Jcic:�B�z�`���w����.")

        End Try
    End Sub

End Module
