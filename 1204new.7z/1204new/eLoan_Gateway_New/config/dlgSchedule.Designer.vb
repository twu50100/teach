﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class dlgSchedule
    Inherits System.Windows.Forms.Form

    'Form 覆寫 Dispose 以清除元件清單。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    '為 Windows Form 設計工具的必要項
    Private components As System.ComponentModel.IContainer

    '注意: 以下為 Windows Form 設計工具所需的程序
    '可以使用 Windows Form 設計工具進行修改。
    '請不要使用程式碼編輯器進行修改。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel
        Me.OK_Button = New System.Windows.Forms.Button
        Me.Cancel_Button = New System.Windows.Forms.Button
        Me.chkScheduleEnable = New System.Windows.Forms.CheckBox
        Me.dtpStartTime = New System.Windows.Forms.DateTimePicker
        Me.lblStartTime = New System.Windows.Forms.Label
        Me.lblDuration = New System.Windows.Forms.Label
        Me.txtDuration = New System.Windows.Forms.TextBox
        Me.cboDurationUnit = New System.Windows.Forms.ComboBox
        Me.lblWeekday = New System.Windows.Forms.Label
        Me.lblProgramPath = New System.Windows.Forms.Label
        Me.txtProgramPath = New System.Windows.Forms.TextBox
        Me.btnProgramPath = New System.Windows.Forms.Button
        Me.chkSunday = New System.Windows.Forms.CheckBox
        Me.chkMonday = New System.Windows.Forms.CheckBox
        Me.chkTuesday = New System.Windows.Forms.CheckBox
        Me.chkWednesday = New System.Windows.Forms.CheckBox
        Me.chkThusday = New System.Windows.Forms.CheckBox
        Me.chkFriday = New System.Windows.Forms.CheckBox
        Me.chkSaturday = New System.Windows.Forms.CheckBox
        Me.gboxWeekday = New System.Windows.Forms.GroupBox
        Me.lblCaption = New System.Windows.Forms.Label
        Me.txtCaption = New System.Windows.Forms.TextBox
        Me.lblDurationEnd = New System.Windows.Forms.Label
        Me.TableLayoutPanel1.SuspendLayout()
        Me.gboxWeekday.SuspendLayout()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel1.ColumnCount = 2
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.OK_Button, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Cancel_Button, 1, 0)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(47, 362)
        Me.TableLayoutPanel1.Margin = New System.Windows.Forms.Padding(4)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 1
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(195, 34)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'OK_Button
        '
        Me.OK_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.OK_Button.Location = New System.Drawing.Point(4, 4)
        Me.OK_Button.Margin = New System.Windows.Forms.Padding(4)
        Me.OK_Button.Name = "OK_Button"
        Me.OK_Button.Size = New System.Drawing.Size(89, 26)
        Me.OK_Button.TabIndex = 0
        Me.OK_Button.Text = "確定"
        '
        'Cancel_Button
        '
        Me.Cancel_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Cancel_Button.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Cancel_Button.Location = New System.Drawing.Point(101, 4)
        Me.Cancel_Button.Margin = New System.Windows.Forms.Padding(4)
        Me.Cancel_Button.Name = "Cancel_Button"
        Me.Cancel_Button.Size = New System.Drawing.Size(89, 26)
        Me.Cancel_Button.TabIndex = 1
        Me.Cancel_Button.Text = "取消"
        '
        'chkScheduleEnable
        '
        Me.chkScheduleEnable.AutoSize = True
        Me.chkScheduleEnable.ForeColor = System.Drawing.SystemColors.ControlText
        Me.chkScheduleEnable.Location = New System.Drawing.Point(25, 18)
        Me.chkScheduleEnable.Margin = New System.Windows.Forms.Padding(4)
        Me.chkScheduleEnable.Name = "chkScheduleEnable"
        Me.chkScheduleEnable.Size = New System.Drawing.Size(56, 19)
        Me.chkScheduleEnable.TabIndex = 1
        Me.chkScheduleEnable.Text = "啟用"
        Me.chkScheduleEnable.UseVisualStyleBackColor = True
        '
        'dtpStartTime
        '
        Me.dtpStartTime.CustomFormat = "HH:mm:ss"
        Me.dtpStartTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpStartTime.Location = New System.Drawing.Point(81, 109)
        Me.dtpStartTime.Name = "dtpStartTime"
        Me.dtpStartTime.ShowUpDown = True
        Me.dtpStartTime.Size = New System.Drawing.Size(105, 25)
        Me.dtpStartTime.TabIndex = 2
        '
        'lblStartTime
        '
        Me.lblStartTime.AutoSize = True
        Me.lblStartTime.ForeColor = System.Drawing.Color.Red
        Me.lblStartTime.Location = New System.Drawing.Point(12, 114)
        Me.lblStartTime.Name = "lblStartTime"
        Me.lblStartTime.Size = New System.Drawing.Size(67, 15)
        Me.lblStartTime.TabIndex = 3
        Me.lblStartTime.Text = "開始時間"
        '
        'lblDuration
        '
        Me.lblDuration.AutoSize = True
        Me.lblDuration.ForeColor = System.Drawing.Color.Red
        Me.lblDuration.Location = New System.Drawing.Point(12, 146)
        Me.lblDuration.Name = "lblDuration"
        Me.lblDuration.Size = New System.Drawing.Size(67, 15)
        Me.lblDuration.TabIndex = 4
        Me.lblDuration.Text = "持續執行"
        '
        'txtDuration
        '
        Me.txtDuration.Location = New System.Drawing.Point(81, 141)
        Me.txtDuration.Name = "txtDuration"
        Me.txtDuration.Size = New System.Drawing.Size(63, 25)
        Me.txtDuration.TabIndex = 5
        '
        'cboDurationUnit
        '
        Me.cboDurationUnit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboDurationUnit.FormattingEnabled = True
        Me.cboDurationUnit.Location = New System.Drawing.Point(144, 142)
        Me.cboDurationUnit.Name = "cboDurationUnit"
        Me.cboDurationUnit.Size = New System.Drawing.Size(42, 23)
        Me.cboDurationUnit.TabIndex = 6
        '
        'lblWeekday
        '
        Me.lblWeekday.AutoSize = True
        Me.lblWeekday.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblWeekday.Location = New System.Drawing.Point(27, 178)
        Me.lblWeekday.Name = "lblWeekday"
        Me.lblWeekday.Size = New System.Drawing.Size(52, 15)
        Me.lblWeekday.TabIndex = 8
        Me.lblWeekday.Text = "執行日"
        '
        'lblProgramPath
        '
        Me.lblProgramPath.AutoSize = True
        Me.lblProgramPath.ForeColor = System.Drawing.Color.Red
        Me.lblProgramPath.Location = New System.Drawing.Point(12, 82)
        Me.lblProgramPath.Name = "lblProgramPath"
        Me.lblProgramPath.Size = New System.Drawing.Size(67, 15)
        Me.lblProgramPath.TabIndex = 9
        Me.lblProgramPath.Text = "執行程式"
        '
        'txtProgramPath
        '
        Me.txtProgramPath.Location = New System.Drawing.Point(81, 77)
        Me.txtProgramPath.Name = "txtProgramPath"
        Me.txtProgramPath.Size = New System.Drawing.Size(162, 25)
        Me.txtProgramPath.TabIndex = 10
        '
        'btnProgramPath
        '
        Me.btnProgramPath.Location = New System.Drawing.Point(246, 78)
        Me.btnProgramPath.Name = "btnProgramPath"
        Me.btnProgramPath.Size = New System.Drawing.Size(28, 23)
        Me.btnProgramPath.TabIndex = 11
        Me.btnProgramPath.Text = "…"
        Me.btnProgramPath.UseVisualStyleBackColor = True
        '
        'chkSunday
        '
        Me.chkSunday.AutoSize = True
        Me.chkSunday.Location = New System.Drawing.Point(12, 12)
        Me.chkSunday.Name = "chkSunday"
        Me.chkSunday.Size = New System.Drawing.Size(71, 19)
        Me.chkSunday.TabIndex = 12
        Me.chkSunday.Text = "每週日"
        Me.chkSunday.UseVisualStyleBackColor = True
        '
        'chkMonday
        '
        Me.chkMonday.AutoSize = True
        Me.chkMonday.Location = New System.Drawing.Point(12, 36)
        Me.chkMonday.Name = "chkMonday"
        Me.chkMonday.Size = New System.Drawing.Size(71, 19)
        Me.chkMonday.TabIndex = 13
        Me.chkMonday.Text = "每週一"
        Me.chkMonday.UseVisualStyleBackColor = True
        '
        'chkTuesday
        '
        Me.chkTuesday.AutoSize = True
        Me.chkTuesday.Location = New System.Drawing.Point(12, 60)
        Me.chkTuesday.Name = "chkTuesday"
        Me.chkTuesday.Size = New System.Drawing.Size(71, 19)
        Me.chkTuesday.TabIndex = 14
        Me.chkTuesday.Text = "每週二"
        Me.chkTuesday.UseVisualStyleBackColor = True
        '
        'chkWednesday
        '
        Me.chkWednesday.AutoSize = True
        Me.chkWednesday.Location = New System.Drawing.Point(12, 84)
        Me.chkWednesday.Name = "chkWednesday"
        Me.chkWednesday.Size = New System.Drawing.Size(71, 19)
        Me.chkWednesday.TabIndex = 15
        Me.chkWednesday.Text = "每週三"
        Me.chkWednesday.UseVisualStyleBackColor = True
        '
        'chkThusday
        '
        Me.chkThusday.AutoSize = True
        Me.chkThusday.Location = New System.Drawing.Point(12, 108)
        Me.chkThusday.Name = "chkThusday"
        Me.chkThusday.Size = New System.Drawing.Size(71, 19)
        Me.chkThusday.TabIndex = 16
        Me.chkThusday.Text = "每週四"
        Me.chkThusday.UseVisualStyleBackColor = True
        '
        'chkFriday
        '
        Me.chkFriday.AutoSize = True
        Me.chkFriday.Location = New System.Drawing.Point(12, 132)
        Me.chkFriday.Name = "chkFriday"
        Me.chkFriday.Size = New System.Drawing.Size(71, 19)
        Me.chkFriday.TabIndex = 17
        Me.chkFriday.Text = "每週五"
        Me.chkFriday.UseVisualStyleBackColor = True
        '
        'chkSaturday
        '
        Me.chkSaturday.AutoSize = True
        Me.chkSaturday.Location = New System.Drawing.Point(12, 156)
        Me.chkSaturday.Name = "chkSaturday"
        Me.chkSaturday.Size = New System.Drawing.Size(71, 19)
        Me.chkSaturday.TabIndex = 18
        Me.chkSaturday.Text = "每週六"
        Me.chkSaturday.UseVisualStyleBackColor = True
        '
        'gboxWeekday
        '
        Me.gboxWeekday.Controls.Add(Me.chkSunday)
        Me.gboxWeekday.Controls.Add(Me.chkSaturday)
        Me.gboxWeekday.Controls.Add(Me.chkMonday)
        Me.gboxWeekday.Controls.Add(Me.chkFriday)
        Me.gboxWeekday.Controls.Add(Me.chkTuesday)
        Me.gboxWeekday.Controls.Add(Me.chkThusday)
        Me.gboxWeekday.Controls.Add(Me.chkWednesday)
        Me.gboxWeekday.Location = New System.Drawing.Point(84, 168)
        Me.gboxWeekday.Name = "gboxWeekday"
        Me.gboxWeekday.Size = New System.Drawing.Size(96, 180)
        Me.gboxWeekday.TabIndex = 19
        Me.gboxWeekday.TabStop = False
        '
        'lblCaption
        '
        Me.lblCaption.AutoSize = True
        Me.lblCaption.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblCaption.Location = New System.Drawing.Point(42, 48)
        Me.lblCaption.Name = "lblCaption"
        Me.lblCaption.Size = New System.Drawing.Size(37, 15)
        Me.lblCaption.TabIndex = 20
        Me.lblCaption.Text = "標題"
        '
        'txtCaption
        '
        Me.txtCaption.Location = New System.Drawing.Point(81, 43)
        Me.txtCaption.Name = "txtCaption"
        Me.txtCaption.Size = New System.Drawing.Size(162, 25)
        Me.txtCaption.TabIndex = 21
        '
        'lblDurationEnd
        '
        Me.lblDurationEnd.AutoSize = True
        Me.lblDurationEnd.Location = New System.Drawing.Point(186, 146)
        Me.lblDurationEnd.Name = "lblDurationEnd"
        Me.lblDurationEnd.Size = New System.Drawing.Size(82, 15)
        Me.lblDurationEnd.TabIndex = 22
        Me.lblDurationEnd.Text = "後強制結束"
        '
        'dlgSchedule
        '
        Me.AcceptButton = Me.OK_Button
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.Cancel_Button
        Me.ClientSize = New System.Drawing.Size(288, 408)
        Me.Controls.Add(Me.lblDurationEnd)
        Me.Controls.Add(Me.txtCaption)
        Me.Controls.Add(Me.lblCaption)
        Me.Controls.Add(Me.gboxWeekday)
        Me.Controls.Add(Me.btnProgramPath)
        Me.Controls.Add(Me.txtProgramPath)
        Me.Controls.Add(Me.lblProgramPath)
        Me.Controls.Add(Me.lblWeekday)
        Me.Controls.Add(Me.cboDurationUnit)
        Me.Controls.Add(Me.txtDuration)
        Me.Controls.Add(Me.lblDuration)
        Me.Controls.Add(Me.lblStartTime)
        Me.Controls.Add(Me.dtpStartTime)
        Me.Controls.Add(Me.chkScheduleEnable)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Font = New System.Drawing.Font("新細明體", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "dlgSchedule"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "作業排程"
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.gboxWeekday.ResumeLayout(False)
        Me.gboxWeekday.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents OK_Button As System.Windows.Forms.Button
    Friend WithEvents Cancel_Button As System.Windows.Forms.Button
    Friend WithEvents chkScheduleEnable As System.Windows.Forms.CheckBox
    Friend WithEvents dtpStartTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents lblStartTime As System.Windows.Forms.Label
    Friend WithEvents lblDuration As System.Windows.Forms.Label
    Friend WithEvents txtDuration As System.Windows.Forms.TextBox
    Friend WithEvents cboDurationUnit As System.Windows.Forms.ComboBox
    Friend WithEvents lblWeekday As System.Windows.Forms.Label
    Friend WithEvents lblProgramPath As System.Windows.Forms.Label
    Friend WithEvents txtProgramPath As System.Windows.Forms.TextBox
    Friend WithEvents btnProgramPath As System.Windows.Forms.Button
    Friend WithEvents chkSunday As System.Windows.Forms.CheckBox
    Friend WithEvents chkMonday As System.Windows.Forms.CheckBox
    Friend WithEvents chkTuesday As System.Windows.Forms.CheckBox
    Friend WithEvents chkWednesday As System.Windows.Forms.CheckBox
    Friend WithEvents chkThusday As System.Windows.Forms.CheckBox
    Friend WithEvents chkFriday As System.Windows.Forms.CheckBox
    Friend WithEvents chkSaturday As System.Windows.Forms.CheckBox
    Friend WithEvents gboxWeekday As System.Windows.Forms.GroupBox
    Friend WithEvents lblCaption As System.Windows.Forms.Label
    Friend WithEvents txtCaption As System.Windows.Forms.TextBox
    Friend WithEvents lblDurationEnd As System.Windows.Forms.Label

End Class
