﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmConfig
    Inherits System.Windows.Forms.Form

    'Form 覆寫 Dispose 以清除元件清單。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    '為 Windows Form 設計工具的必要項
    Private components As System.ComponentModel.IContainer

    '注意: 以下為 Windows Form 設計工具所需的程序
    '可以使用 Windows Form 設計工具進行修改。
    '請不要使用程式碼編輯器進行修改。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnWebSettingActive = New System.Windows.Forms.Button()
        Me.tabOverseasGateway = New System.Windows.Forms.TabPage()
        Me.lblOverseasConn = New System.Windows.Forms.Label()
        Me.txtOverseasConn = New System.Windows.Forms.TextBox()
        Me.btnOverseasConn = New System.Windows.Forms.Button()
        Me.lblQueueSize = New System.Windows.Forms.Label()
        Me.nudOverseasQueueSize = New System.Windows.Forms.NumericUpDown()
        Me.lblProcessorCnt = New System.Windows.Forms.Label()
        Me.nudOverseasProcessorCnt = New System.Windows.Forms.NumericUpDown()
        Me.lblOverseasListenerPort = New System.Windows.Forms.Label()
        Me.lblOverseasClientPort = New System.Windows.Forms.Label()
        Me.txtOverseasListenerPort = New System.Windows.Forms.TextBox()
        Me.txtOverseasClientPort = New System.Windows.Forms.TextBox()
        Me.chkOverseasGatewayEnabled = New System.Windows.Forms.CheckBox()
        Me.tabScheduleList = New System.Windows.Forms.TabPage()
        Me.btnAddSchedule = New System.Windows.Forms.Button()
        Me.btnRemoveSchedule = New System.Windows.Forms.Button()
        Me.btnEditSchedule = New System.Windows.Forms.Button()
        Me.dgvScheduleList = New System.Windows.Forms.DataGridView()
        Me.colSTATUS = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDURATIONUNIT = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDURATION = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEndTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colStartTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCaption = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDATA = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.tabCRM = New System.Windows.Forms.TabPage()
        Me.lblCrmFtpAddress = New System.Windows.Forms.Label()
        Me.txtCrmFtpAddress = New System.Windows.Forms.TextBox()
        Me.lblCrmFtpUser = New System.Windows.Forms.Label()
        Me.txtCrmFtpUser = New System.Windows.Forms.TextBox()
        Me.lblCrmFtpPassword = New System.Windows.Forms.Label()
        Me.txtCrmFtpPassword = New System.Windows.Forms.TextBox()
        Me.lblCrmFiles = New System.Windows.Forms.Label()
        Me.txtCrmFiles = New System.Windows.Forms.TextBox()
        Me.tabJcicTchAdm = New System.Windows.Forms.TabPage()
        Me.lblAPI_JcicTch = New System.Windows.Forms.Label()
        Me.txtAPI_JcicTch = New System.Windows.Forms.TextBox()
        Me.gboxJcic = New System.Windows.Forms.GroupBox()
        Me.lblJcicTables = New System.Windows.Forms.Label()
        Me.txtJcicTables = New System.Windows.Forms.TextBox()
        Me.nudJcicInterval = New System.Windows.Forms.NumericUpDown()
        Me.lblJcicInterval = New System.Windows.Forms.Label()
        Me.lblJcicIntervalUnit = New System.Windows.Forms.Label()
        Me.chkJcicEnable = New System.Windows.Forms.CheckBox()
        Me.gboxTch = New System.Windows.Forms.GroupBox()
        Me.nudTchInterval = New System.Windows.Forms.NumericUpDown()
        Me.txtTchTables = New System.Windows.Forms.TextBox()
        Me.lblTchInterval = New System.Windows.Forms.Label()
        Me.lblTchTables = New System.Windows.Forms.Label()
        Me.lblTchIntervalUnit = New System.Windows.Forms.Label()
        Me.chkTchEnable = New System.Windows.Forms.CheckBox()
        Me.gboxAdm = New System.Windows.Forms.GroupBox()
        Me.nudAdmInterval = New System.Windows.Forms.NumericUpDown()
        Me.txtAdmTables = New System.Windows.Forms.TextBox()
        Me.lblAdmInterval = New System.Windows.Forms.Label()
        Me.lblAdmTables = New System.Windows.Forms.Label()
        Me.lblAdmIntervalUnit = New System.Windows.Forms.Label()
        Me.lblAPI_EDOCService = New System.Windows.Forms.Label()
        Me.txtAPI_EDOCService = New System.Windows.Forms.TextBox()
        Me.chkAdmEnable = New System.Windows.Forms.CheckBox()
        Me.chkOutSourceLog = New System.Windows.Forms.CheckBox()
        Me.lblConnStr_JcicTch = New System.Windows.Forms.Label()
        Me.txtConnStr_JcicTch = New System.Windows.Forms.TextBox()
        Me.btnConnStr_JcicTch = New System.Windows.Forms.Button()
        Me.tabELoan = New System.Windows.Forms.TabPage()
        Me.gbRestartServices = New System.Windows.Forms.GroupBox()
        Me.lblRestartServicesName = New System.Windows.Forms.Label()
        Me.txtRestartServicesName = New System.Windows.Forms.TextBox()
        Me.chkRestartOnTheHour = New System.Windows.Forms.CheckBox()
        Me.txtRestartTime = New System.Windows.Forms.TextBox()
        Me.lblConnStr_Loan = New System.Windows.Forms.Label()
        Me.txtConnStr_Loan = New System.Windows.Forms.TextBox()
        Me.btnConnStr_Loan = New System.Windows.Forms.Button()
        Me.lblConnStr_Loan_History = New System.Windows.Forms.Label()
        Me.txtConnStr_Loan_History = New System.Windows.Forms.TextBox()
        Me.btnConnStr_Loan_History = New System.Windows.Forms.Button()
        Me.lblConnStr_Security = New System.Windows.Forms.Label()
        Me.txtConnStr_Security = New System.Windows.Forms.TextBox()
        Me.btnConnStr_Security = New System.Windows.Forms.Button()
        Me.gbxAPServer = New System.Windows.Forms.GroupBox()
        Me.dgvAPServerList = New System.Windows.Forms.DataGridView()
        Me.lblUpLoadFilePath = New System.Windows.Forms.Label()
        Me.txtUpLoadFilePath = New System.Windows.Forms.TextBox()
        Me.lblAdm_UpLoadFilePath = New System.Windows.Forms.Label()
        Me.txtAdm_UpLoadFilePath = New System.Windows.Forms.TextBox()
        Me.lblUpLoadUser = New System.Windows.Forms.Label()
        Me.lblUpLoadPassword = New System.Windows.Forms.Label()
        Me.txtUpLoadUser = New System.Windows.Forms.TextBox()
        Me.txtUpLoadPassword = New System.Windows.Forms.TextBox()
        Me.lblAttach_Interval = New System.Windows.Forms.Label()
        Me.nudAttach_Interval = New System.Windows.Forms.NumericUpDown()
        Me.lblAttachFilePath = New System.Windows.Forms.Label()
        Me.txtAttachFilePath = New System.Windows.Forms.TextBox()
        Me.lblAttach_Interval_Unit = New System.Windows.Forms.Label()
        Me.lblAPI_ScoringService = New System.Windows.Forms.Label()
        Me.txtAPI_ScoringService = New System.Windows.Forms.TextBox()
        Me.lblConnStr_CL = New System.Windows.Forms.Label()
        Me.txtConnStr_CL = New System.Windows.Forms.TextBox()
        Me.btnConnStr_CL = New System.Windows.Forms.Button()
        Me.lblAttachFileMode = New System.Windows.Forms.Label()
        Me.cmbAttachFileMode = New System.Windows.Forms.ComboBox()
        Me.tabCommon = New System.Windows.Forms.TabPage()
        Me.txtTmpInputPath = New System.Windows.Forms.TextBox()
        Me.lblTmpInputPath = New System.Windows.Forms.Label()
        Me.btnTmpInputPath = New System.Windows.Forms.Button()
        Me.btnTmpOutputPath = New System.Windows.Forms.Button()
        Me.txtTmpOutputPath = New System.Windows.Forms.TextBox()
        Me.lblTmpOutputPath = New System.Windows.Forms.Label()
        Me.lblLogPath = New System.Windows.Forms.Label()
        Me.gboxRemoteServerList = New System.Windows.Forms.GroupBox()
        Me.dgvRemoteServerList = New System.Windows.Forms.DataGridView()
        Me.txtLogPath = New System.Windows.Forms.TextBox()
        Me.lblLocalServerIP = New System.Windows.Forms.Label()
        Me.btnLogPath = New System.Windows.Forms.Button()
        Me.lblDBConnString = New System.Windows.Forms.Label()
        Me.txtLocalServerIP = New System.Windows.Forms.TextBox()
        Me.txtDBConnString = New System.Windows.Forms.TextBox()
        Me.gboxEmail = New System.Windows.Forms.GroupBox()
        Me.lblMailQuantity = New System.Windows.Forms.Label()
        Me.txtMailQuantity = New System.Windows.Forms.TextBox()
        Me.lblMailSMTP = New System.Windows.Forms.Label()
        Me.txtMailCC = New System.Windows.Forms.TextBox()
        Me.lblMailCC = New System.Windows.Forms.Label()
        Me.txtMailSMTP = New System.Windows.Forms.TextBox()
        Me.lblMailTo = New System.Windows.Forms.Label()
        Me.txtMailTo = New System.Windows.Forms.TextBox()
        Me.lblMailSMTPUid = New System.Windows.Forms.Label()
        Me.txtMailSMTPUid = New System.Windows.Forms.TextBox()
        Me.lblMailSMTPPwd = New System.Windows.Forms.Label()
        Me.txtMailSMTPPwd = New System.Windows.Forms.TextBox()
        Me.chkMailSMTPVerify = New System.Windows.Forms.CheckBox()
        Me.btnDBConnString = New System.Windows.Forms.Button()
        Me.lblLogFileSize = New System.Windows.Forms.Label()
        Me.chkMailEnable = New System.Windows.Forms.CheckBox()
        Me.nudLogFileSize = New System.Windows.Forms.NumericUpDown()
        Me.lblMB = New System.Windows.Forms.Label()
        Me.lblLogFileBackupCount = New System.Windows.Forms.Label()
        Me.nudLogFileBackupCount = New System.Windows.Forms.NumericUpDown()
        Me.lblELSrcPath = New System.Windows.Forms.Label()
        Me.txtELSrcPath = New System.Windows.Forms.TextBox()
        Me.btnELSrcPath = New System.Windows.Forms.Button()
        Me.lblELTagPath = New System.Windows.Forms.Label()
        Me.txtELTagPath = New System.Windows.Forms.TextBox()
        Me.btnELTagPath = New System.Windows.Forms.Button()
        Me.lblELLifeCycle = New System.Windows.Forms.Label()
        Me.txtELLifeCycle = New System.Windows.Forms.TextBox()
        Me.cmbELLifeCycleUnit = New System.Windows.Forms.ComboBox()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.tabOverseasGateway.SuspendLayout()
        CType(Me.nudOverseasQueueSize, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudOverseasProcessorCnt, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tabScheduleList.SuspendLayout()
        CType(Me.dgvScheduleList, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tabCRM.SuspendLayout()
        Me.tabJcicTchAdm.SuspendLayout()
        Me.gboxJcic.SuspendLayout()
        CType(Me.nudJcicInterval, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gboxTch.SuspendLayout()
        CType(Me.nudTchInterval, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gboxAdm.SuspendLayout()
        CType(Me.nudAdmInterval, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tabELoan.SuspendLayout()
        Me.gbRestartServices.SuspendLayout()
        Me.gbxAPServer.SuspendLayout()
        CType(Me.dgvAPServerList, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudAttach_Interval, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tabCommon.SuspendLayout()
        Me.gboxRemoteServerList.SuspendLayout()
        CType(Me.dgvRemoteServerList, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gboxEmail.SuspendLayout()
        CType(Me.nudLogFileSize, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudLogFileBackupCount, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabControl1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnSave
        '
        Me.btnSave.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSave.Location = New System.Drawing.Point(387, 687)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(75, 23)
        Me.btnSave.TabIndex = 105
        Me.btnSave.Text = "儲存"
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnExit.Location = New System.Drawing.Point(503, 687)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 110
        Me.btnExit.Text = "關閉"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnWebSettingActive
        '
        Me.btnWebSettingActive.Location = New System.Drawing.Point(15, 687)
        Me.btnWebSettingActive.Name = "btnWebSettingActive"
        Me.btnWebSettingActive.Size = New System.Drawing.Size(139, 23)
        Me.btnWebSettingActive.TabIndex = 111
        Me.btnWebSettingActive.Text = "網站設定值生效"
        Me.btnWebSettingActive.UseVisualStyleBackColor = True
        '
        'tabOverseasGateway
        '
        Me.tabOverseasGateway.Controls.Add(Me.chkOverseasGatewayEnabled)
        Me.tabOverseasGateway.Controls.Add(Me.txtOverseasClientPort)
        Me.tabOverseasGateway.Controls.Add(Me.txtOverseasListenerPort)
        Me.tabOverseasGateway.Controls.Add(Me.txtOverseasConn)
        Me.tabOverseasGateway.Controls.Add(Me.lblOverseasClientPort)
        Me.tabOverseasGateway.Controls.Add(Me.lblOverseasListenerPort)
        Me.tabOverseasGateway.Controls.Add(Me.nudOverseasProcessorCnt)
        Me.tabOverseasGateway.Controls.Add(Me.lblProcessorCnt)
        Me.tabOverseasGateway.Controls.Add(Me.nudOverseasQueueSize)
        Me.tabOverseasGateway.Controls.Add(Me.lblQueueSize)
        Me.tabOverseasGateway.Controls.Add(Me.btnOverseasConn)
        Me.tabOverseasGateway.Controls.Add(Me.lblOverseasConn)
        Me.tabOverseasGateway.Location = New System.Drawing.Point(4, 25)
        Me.tabOverseasGateway.Name = "tabOverseasGateway"
        Me.tabOverseasGateway.Size = New System.Drawing.Size(607, 642)
        Me.tabOverseasGateway.TabIndex = 5
        Me.tabOverseasGateway.Text = "海外分行Gateway"
        Me.tabOverseasGateway.UseVisualStyleBackColor = True
        '
        'lblOverseasConn
        '
        Me.lblOverseasConn.AutoSize = True
        Me.lblOverseasConn.Location = New System.Drawing.Point(8, 26)
        Me.lblOverseasConn.Name = "lblOverseasConn"
        Me.lblOverseasConn.Size = New System.Drawing.Size(142, 15)
        Me.lblOverseasConn.TabIndex = 8
        Me.lblOverseasConn.Text = "海外資料庫連接設定"
        '
        'txtOverseasConn
        '
        Me.txtOverseasConn.Location = New System.Drawing.Point(156, 23)
        Me.txtOverseasConn.Name = "txtOverseasConn"
        Me.txtOverseasConn.ReadOnly = True
        Me.txtOverseasConn.Size = New System.Drawing.Size(411, 25)
        Me.txtOverseasConn.TabIndex = 9
        '
        'btnOverseasConn
        '
        Me.btnOverseasConn.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnOverseasConn.Location = New System.Drawing.Point(576, 22)
        Me.btnOverseasConn.Name = "btnOverseasConn"
        Me.btnOverseasConn.Size = New System.Drawing.Size(28, 23)
        Me.btnOverseasConn.TabIndex = 10
        Me.btnOverseasConn.Text = "…"
        Me.btnOverseasConn.UseVisualStyleBackColor = True
        '
        'lblQueueSize
        '
        Me.lblQueueSize.AutoSize = True
        Me.lblQueueSize.Location = New System.Drawing.Point(8, 58)
        Me.lblQueueSize.Name = "lblQueueSize"
        Me.lblQueueSize.Size = New System.Drawing.Size(127, 15)
        Me.lblQueueSize.TabIndex = 11
        Me.lblQueueSize.Text = "交易暫存佇列容量"
        '
        'nudOverseasQueueSize
        '
        Me.nudOverseasQueueSize.Location = New System.Drawing.Point(156, 56)
        Me.nudOverseasQueueSize.Maximum = New Decimal(New Integer() {50, 0, 0, 0})
        Me.nudOverseasQueueSize.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.nudOverseasQueueSize.Name = "nudOverseasQueueSize"
        Me.nudOverseasQueueSize.Size = New System.Drawing.Size(120, 25)
        Me.nudOverseasQueueSize.TabIndex = 13
        Me.nudOverseasQueueSize.Value = New Decimal(New Integer() {30, 0, 0, 0})
        '
        'lblProcessorCnt
        '
        Me.lblProcessorCnt.AutoSize = True
        Me.lblProcessorCnt.Location = New System.Drawing.Point(8, 90)
        Me.lblProcessorCnt.Name = "lblProcessorCnt"
        Me.lblProcessorCnt.Size = New System.Drawing.Size(112, 15)
        Me.lblProcessorCnt.TabIndex = 14
        Me.lblProcessorCnt.Text = "交易處理序數量"
        '
        'nudOverseasProcessorCnt
        '
        Me.nudOverseasProcessorCnt.Location = New System.Drawing.Point(156, 88)
        Me.nudOverseasProcessorCnt.Maximum = New Decimal(New Integer() {30, 0, 0, 0})
        Me.nudOverseasProcessorCnt.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.nudOverseasProcessorCnt.Name = "nudOverseasProcessorCnt"
        Me.nudOverseasProcessorCnt.Size = New System.Drawing.Size(120, 25)
        Me.nudOverseasProcessorCnt.TabIndex = 15
        Me.nudOverseasProcessorCnt.Value = New Decimal(New Integer() {5, 0, 0, 0})
        '
        'lblOverseasListenerPort
        '
        Me.lblOverseasListenerPort.AutoSize = True
        Me.lblOverseasListenerPort.Location = New System.Drawing.Point(8, 123)
        Me.lblOverseasListenerPort.Name = "lblOverseasListenerPort"
        Me.lblOverseasListenerPort.Size = New System.Drawing.Size(81, 15)
        Me.lblOverseasListenerPort.TabIndex = 16
        Me.lblOverseasListenerPort.Text = "Listener Port"
        '
        'lblOverseasClientPort
        '
        Me.lblOverseasClientPort.AutoSize = True
        Me.lblOverseasClientPort.Location = New System.Drawing.Point(8, 155)
        Me.lblOverseasClientPort.Name = "lblOverseasClientPort"
        Me.lblOverseasClientPort.Size = New System.Drawing.Size(69, 15)
        Me.lblOverseasClientPort.TabIndex = 17
        Me.lblOverseasClientPort.Text = "Client Port"
        '
        'txtOverseasListenerPort
        '
        Me.txtOverseasListenerPort.Location = New System.Drawing.Point(156, 120)
        Me.txtOverseasListenerPort.Name = "txtOverseasListenerPort"
        Me.txtOverseasListenerPort.Size = New System.Drawing.Size(100, 25)
        Me.txtOverseasListenerPort.TabIndex = 18
        '
        'txtOverseasClientPort
        '
        Me.txtOverseasClientPort.Location = New System.Drawing.Point(156, 152)
        Me.txtOverseasClientPort.Name = "txtOverseasClientPort"
        Me.txtOverseasClientPort.Size = New System.Drawing.Size(100, 25)
        Me.txtOverseasClientPort.TabIndex = 19
        '
        'chkOverseasGatewayEnabled
        '
        Me.chkOverseasGatewayEnabled.AutoSize = True
        Me.chkOverseasGatewayEnabled.Location = New System.Drawing.Point(9, 4)
        Me.chkOverseasGatewayEnabled.Name = "chkOverseasGatewayEnabled"
        Me.chkOverseasGatewayEnabled.Size = New System.Drawing.Size(195, 19)
        Me.chkOverseasGatewayEnabled.TabIndex = 20
        Me.chkOverseasGatewayEnabled.Text = "是否啟用海外分行Gateway"
        Me.chkOverseasGatewayEnabled.UseVisualStyleBackColor = True
        '
        'tabScheduleList
        '
        Me.tabScheduleList.Controls.Add(Me.dgvScheduleList)
        Me.tabScheduleList.Controls.Add(Me.btnEditSchedule)
        Me.tabScheduleList.Controls.Add(Me.btnRemoveSchedule)
        Me.tabScheduleList.Controls.Add(Me.btnAddSchedule)
        Me.tabScheduleList.Location = New System.Drawing.Point(4, 25)
        Me.tabScheduleList.Name = "tabScheduleList"
        Me.tabScheduleList.Size = New System.Drawing.Size(607, 642)
        Me.tabScheduleList.TabIndex = 2
        Me.tabScheduleList.Text = "附加排程"
        Me.tabScheduleList.UseVisualStyleBackColor = True
        '
        'btnAddSchedule
        '
        Me.btnAddSchedule.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnAddSchedule.Location = New System.Drawing.Point(393, 513)
        Me.btnAddSchedule.Name = "btnAddSchedule"
        Me.btnAddSchedule.Size = New System.Drawing.Size(51, 23)
        Me.btnAddSchedule.TabIndex = 1
        Me.btnAddSchedule.Text = "新增"
        Me.btnAddSchedule.UseVisualStyleBackColor = True
        '
        'btnRemoveSchedule
        '
        Me.btnRemoveSchedule.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnRemoveSchedule.Location = New System.Drawing.Point(525, 513)
        Me.btnRemoveSchedule.Name = "btnRemoveSchedule"
        Me.btnRemoveSchedule.Size = New System.Drawing.Size(51, 23)
        Me.btnRemoveSchedule.TabIndex = 2
        Me.btnRemoveSchedule.Text = "刪除"
        Me.btnRemoveSchedule.UseVisualStyleBackColor = True
        '
        'btnEditSchedule
        '
        Me.btnEditSchedule.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnEditSchedule.Location = New System.Drawing.Point(459, 513)
        Me.btnEditSchedule.Name = "btnEditSchedule"
        Me.btnEditSchedule.Size = New System.Drawing.Size(51, 23)
        Me.btnEditSchedule.TabIndex = 3
        Me.btnEditSchedule.Text = "編輯"
        Me.btnEditSchedule.UseVisualStyleBackColor = True
        '
        'dgvScheduleList
        '
        Me.dgvScheduleList.AllowUserToAddRows = False
        Me.dgvScheduleList.AllowUserToOrderColumns = True
        Me.dgvScheduleList.AllowUserToResizeRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.White
        Me.dgvScheduleList.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.dgvScheduleList.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgvScheduleList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgvScheduleList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvScheduleList.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colID, Me.colDATA, Me.colCaption, Me.colStartTime, Me.colEndTime, Me.colDURATION, Me.colDURATIONUNIT, Me.colSTATUS})
        Me.dgvScheduleList.Location = New System.Drawing.Point(6, 6)
        Me.dgvScheduleList.MultiSelect = False
        Me.dgvScheduleList.Name = "dgvScheduleList"
        Me.dgvScheduleList.ReadOnly = True
        Me.dgvScheduleList.RowHeadersVisible = False
        Me.dgvScheduleList.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToDisplayedHeaders
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.MistyRose
        Me.dgvScheduleList.RowsDefaultCellStyle = DataGridViewCellStyle2
        Me.dgvScheduleList.RowTemplate.Height = 24
        Me.dgvScheduleList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvScheduleList.ShowEditingIcon = False
        Me.dgvScheduleList.Size = New System.Drawing.Size(597, 501)
        Me.dgvScheduleList.TabIndex = 4
        '
        'colSTATUS
        '
        Me.colSTATUS.DataPropertyName = "STATUS"
        Me.colSTATUS.HeaderText = "狀態"
        Me.colSTATUS.Name = "colSTATUS"
        Me.colSTATUS.ReadOnly = True
        Me.colSTATUS.Width = 60
        '
        'colDURATIONUNIT
        '
        Me.colDURATIONUNIT.DataPropertyName = "DURATIONUNIT"
        Me.colDURATIONUNIT.HeaderText = "時間單位"
        Me.colDURATIONUNIT.Name = "colDURATIONUNIT"
        Me.colDURATIONUNIT.ReadOnly = True
        Me.colDURATIONUNIT.Visible = False
        Me.colDURATIONUNIT.Width = 92
        '
        'colDURATION
        '
        Me.colDURATION.DataPropertyName = "DURATION"
        Me.colDURATION.HeaderText = "持續執行"
        Me.colDURATION.Name = "colDURATION"
        Me.colDURATION.ReadOnly = True
        Me.colDURATION.Visible = False
        Me.colDURATION.Width = 92
        '
        'colEndTime
        '
        Me.colEndTime.DataPropertyName = "ENDTIME"
        Me.colEndTime.HeaderText = "結束時間"
        Me.colEndTime.Name = "colEndTime"
        Me.colEndTime.ReadOnly = True
        Me.colEndTime.Width = 90
        '
        'colStartTime
        '
        Me.colStartTime.DataPropertyName = "STARTTIME"
        Me.colStartTime.HeaderText = "開始時間"
        Me.colStartTime.Name = "colStartTime"
        Me.colStartTime.ReadOnly = True
        Me.colStartTime.Width = 90
        '
        'colCaption
        '
        Me.colCaption.DataPropertyName = "CAPTION"
        Me.colCaption.HeaderText = "標題"
        Me.colCaption.Name = "colCaption"
        Me.colCaption.ReadOnly = True
        Me.colCaption.Width = 60
        '
        'colDATA
        '
        Me.colDATA.DataPropertyName = "DATA"
        Me.colDATA.HeaderText = "DATA"
        Me.colDATA.Name = "colDATA"
        Me.colDATA.ReadOnly = True
        Me.colDATA.Visible = False
        Me.colDATA.Width = 52
        '
        'colID
        '
        Me.colID.DataPropertyName = "ID"
        Me.colID.HeaderText = "ID"
        Me.colID.Name = "colID"
        Me.colID.ReadOnly = True
        Me.colID.Visible = False
        Me.colID.Width = 28
        '
        'tabCRM
        '
        Me.tabCRM.Controls.Add(Me.txtCrmFiles)
        Me.tabCRM.Controls.Add(Me.txtCrmFtpPassword)
        Me.tabCRM.Controls.Add(Me.txtCrmFtpUser)
        Me.tabCRM.Controls.Add(Me.txtCrmFtpAddress)
        Me.tabCRM.Controls.Add(Me.lblCrmFiles)
        Me.tabCRM.Controls.Add(Me.lblCrmFtpPassword)
        Me.tabCRM.Controls.Add(Me.lblCrmFtpUser)
        Me.tabCRM.Controls.Add(Me.lblCrmFtpAddress)
        Me.tabCRM.Location = New System.Drawing.Point(4, 25)
        Me.tabCRM.Name = "tabCRM"
        Me.tabCRM.Padding = New System.Windows.Forms.Padding(3)
        Me.tabCRM.Size = New System.Drawing.Size(607, 642)
        Me.tabCRM.TabIndex = 6
        Me.tabCRM.Text = "CRM"
        Me.tabCRM.UseVisualStyleBackColor = True
        '
        'lblCrmFtpAddress
        '
        Me.lblCrmFtpAddress.AutoSize = True
        Me.lblCrmFtpAddress.Location = New System.Drawing.Point(23, 19)
        Me.lblCrmFtpAddress.Name = "lblCrmFtpAddress"
        Me.lblCrmFtpAddress.Size = New System.Drawing.Size(62, 15)
        Me.lblCrmFtpAddress.TabIndex = 0
        Me.lblCrmFtpAddress.Text = "FTP網址"
        '
        'txtCrmFtpAddress
        '
        Me.txtCrmFtpAddress.Location = New System.Drawing.Point(91, 16)
        Me.txtCrmFtpAddress.Name = "txtCrmFtpAddress"
        Me.txtCrmFtpAddress.Size = New System.Drawing.Size(480, 25)
        Me.txtCrmFtpAddress.TabIndex = 1
        '
        'lblCrmFtpUser
        '
        Me.lblCrmFtpUser.AutoSize = True
        Me.lblCrmFtpUser.Location = New System.Drawing.Point(23, 50)
        Me.lblCrmFtpUser.Name = "lblCrmFtpUser"
        Me.lblCrmFtpUser.Size = New System.Drawing.Size(62, 15)
        Me.lblCrmFtpUser.TabIndex = 2
        Me.lblCrmFtpUser.Text = "FTP User"
        '
        'txtCrmFtpUser
        '
        Me.txtCrmFtpUser.Location = New System.Drawing.Point(91, 47)
        Me.txtCrmFtpUser.Name = "txtCrmFtpUser"
        Me.txtCrmFtpUser.Size = New System.Drawing.Size(139, 25)
        Me.txtCrmFtpUser.TabIndex = 3
        '
        'lblCrmFtpPassword
        '
        Me.lblCrmFtpPassword.AutoSize = True
        Me.lblCrmFtpPassword.Location = New System.Drawing.Point(23, 82)
        Me.lblCrmFtpPassword.Name = "lblCrmFtpPassword"
        Me.lblCrmFtpPassword.Size = New System.Drawing.Size(89, 15)
        Me.lblCrmFtpPassword.TabIndex = 4
        Me.lblCrmFtpPassword.Text = "FTP Password"
        '
        'txtCrmFtpPassword
        '
        Me.txtCrmFtpPassword.Location = New System.Drawing.Point(119, 79)
        Me.txtCrmFtpPassword.Name = "txtCrmFtpPassword"
        Me.txtCrmFtpPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtCrmFtpPassword.Size = New System.Drawing.Size(111, 25)
        Me.txtCrmFtpPassword.TabIndex = 5
        '
        'lblCrmFiles
        '
        Me.lblCrmFiles.AutoSize = True
        Me.lblCrmFiles.Location = New System.Drawing.Point(23, 126)
        Me.lblCrmFiles.Name = "lblCrmFiles"
        Me.lblCrmFiles.Size = New System.Drawing.Size(67, 15)
        Me.lblCrmFiles.TabIndex = 6
        Me.lblCrmFiles.Text = "檔案名稱"
        '
        'txtCrmFiles
        '
        Me.txtCrmFiles.AcceptsReturn = True
        Me.txtCrmFiles.Location = New System.Drawing.Point(91, 123)
        Me.txtCrmFiles.Multiline = True
        Me.txtCrmFiles.Name = "txtCrmFiles"
        Me.txtCrmFiles.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtCrmFiles.Size = New System.Drawing.Size(480, 139)
        Me.txtCrmFiles.TabIndex = 7
        Me.txtCrmFiles.WordWrap = False
        '
        'tabJcicTchAdm
        '
        Me.tabJcicTchAdm.Controls.Add(Me.btnConnStr_JcicTch)
        Me.tabJcicTchAdm.Controls.Add(Me.txtConnStr_JcicTch)
        Me.tabJcicTchAdm.Controls.Add(Me.txtAPI_EDOCService)
        Me.tabJcicTchAdm.Controls.Add(Me.txtAPI_JcicTch)
        Me.tabJcicTchAdm.Controls.Add(Me.lblConnStr_JcicTch)
        Me.tabJcicTchAdm.Controls.Add(Me.chkOutSourceLog)
        Me.tabJcicTchAdm.Controls.Add(Me.chkAdmEnable)
        Me.tabJcicTchAdm.Controls.Add(Me.lblAPI_EDOCService)
        Me.tabJcicTchAdm.Controls.Add(Me.gboxAdm)
        Me.tabJcicTchAdm.Controls.Add(Me.chkTchEnable)
        Me.tabJcicTchAdm.Controls.Add(Me.gboxTch)
        Me.tabJcicTchAdm.Controls.Add(Me.chkJcicEnable)
        Me.tabJcicTchAdm.Controls.Add(Me.gboxJcic)
        Me.tabJcicTchAdm.Controls.Add(Me.lblAPI_JcicTch)
        Me.tabJcicTchAdm.Location = New System.Drawing.Point(4, 25)
        Me.tabJcicTchAdm.Name = "tabJcicTchAdm"
        Me.tabJcicTchAdm.Padding = New System.Windows.Forms.Padding(3)
        Me.tabJcicTchAdm.Size = New System.Drawing.Size(607, 642)
        Me.tabJcicTchAdm.TabIndex = 3
        Me.tabJcicTchAdm.Text = "聯徵、票交、地政設定"
        Me.tabJcicTchAdm.UseVisualStyleBackColor = True
        '
        'lblAPI_JcicTch
        '
        Me.lblAPI_JcicTch.AutoSize = True
        Me.lblAPI_JcicTch.Location = New System.Drawing.Point(17, 19)
        Me.lblAPI_JcicTch.Name = "lblAPI_JcicTch"
        Me.lblAPI_JcicTch.Size = New System.Drawing.Size(157, 15)
        Me.lblAPI_JcicTch.TabIndex = 0
        Me.lblAPI_JcicTch.Text = "聯徵票交整合介面位置"
        '
        'txtAPI_JcicTch
        '
        Me.txtAPI_JcicTch.Location = New System.Drawing.Point(180, 16)
        Me.txtAPI_JcicTch.Name = "txtAPI_JcicTch"
        Me.txtAPI_JcicTch.Size = New System.Drawing.Size(405, 25)
        Me.txtAPI_JcicTch.TabIndex = 1
        '
        'gboxJcic
        '
        Me.gboxJcic.Controls.Add(Me.lblJcicIntervalUnit)
        Me.gboxJcic.Controls.Add(Me.lblJcicInterval)
        Me.gboxJcic.Controls.Add(Me.nudJcicInterval)
        Me.gboxJcic.Controls.Add(Me.txtJcicTables)
        Me.gboxJcic.Controls.Add(Me.lblJcicTables)
        Me.gboxJcic.Location = New System.Drawing.Point(20, 78)
        Me.gboxJcic.Name = "gboxJcic"
        Me.gboxJcic.Size = New System.Drawing.Size(565, 95)
        Me.gboxJcic.TabIndex = 4
        Me.gboxJcic.TabStop = False
        '
        'lblJcicTables
        '
        Me.lblJcicTables.AutoSize = True
        Me.lblJcicTables.Location = New System.Drawing.Point(21, 27)
        Me.lblJcicTables.Name = "lblJcicTables"
        Me.lblJcicTables.Size = New System.Drawing.Size(82, 15)
        Me.lblJcicTables.TabIndex = 2
        Me.lblJcicTables.Text = "來源資料表"
        '
        'txtJcicTables
        '
        Me.txtJcicTables.Location = New System.Drawing.Point(109, 24)
        Me.txtJcicTables.Name = "txtJcicTables"
        Me.txtJcicTables.Size = New System.Drawing.Size(450, 25)
        Me.txtJcicTables.TabIndex = 3
        '
        'nudJcicInterval
        '
        Me.nudJcicInterval.Location = New System.Drawing.Point(109, 56)
        Me.nudJcicInterval.Name = "nudJcicInterval"
        Me.nudJcicInterval.Size = New System.Drawing.Size(45, 25)
        Me.nudJcicInterval.TabIndex = 4
        '
        'lblJcicInterval
        '
        Me.lblJcicInterval.AutoSize = True
        Me.lblJcicInterval.Location = New System.Drawing.Point(6, 58)
        Me.lblJcicInterval.Name = "lblJcicInterval"
        Me.lblJcicInterval.Size = New System.Drawing.Size(97, 15)
        Me.lblJcicInterval.TabIndex = 5
        Me.lblJcicInterval.Text = "處理間隔時間"
        '
        'lblJcicIntervalUnit
        '
        Me.lblJcicIntervalUnit.AutoSize = True
        Me.lblJcicIntervalUnit.Location = New System.Drawing.Point(160, 58)
        Me.lblJcicIntervalUnit.Name = "lblJcicIntervalUnit"
        Me.lblJcicIntervalUnit.Size = New System.Drawing.Size(22, 15)
        Me.lblJcicIntervalUnit.TabIndex = 6
        Me.lblJcicIntervalUnit.Text = "秒"
        '
        'chkJcicEnable
        '
        Me.chkJcicEnable.AutoSize = True
        Me.chkJcicEnable.Location = New System.Drawing.Point(26, 79)
        Me.chkJcicEnable.Name = "chkJcicEnable"
        Me.chkJcicEnable.Size = New System.Drawing.Size(116, 19)
        Me.chkJcicEnable.TabIndex = 0
        Me.chkJcicEnable.Text = "聯徵資料查詢"
        Me.chkJcicEnable.UseVisualStyleBackColor = True
        '
        'gboxTch
        '
        Me.gboxTch.Controls.Add(Me.lblTchIntervalUnit)
        Me.gboxTch.Controls.Add(Me.lblTchTables)
        Me.gboxTch.Controls.Add(Me.lblTchInterval)
        Me.gboxTch.Controls.Add(Me.txtTchTables)
        Me.gboxTch.Controls.Add(Me.nudTchInterval)
        Me.gboxTch.Enabled = False
        Me.gboxTch.Location = New System.Drawing.Point(20, 179)
        Me.gboxTch.Name = "gboxTch"
        Me.gboxTch.Size = New System.Drawing.Size(565, 95)
        Me.gboxTch.TabIndex = 5
        Me.gboxTch.TabStop = False
        '
        'nudTchInterval
        '
        Me.nudTchInterval.Location = New System.Drawing.Point(109, 55)
        Me.nudTchInterval.Name = "nudTchInterval"
        Me.nudTchInterval.Size = New System.Drawing.Size(45, 25)
        Me.nudTchInterval.TabIndex = 9
        '
        'txtTchTables
        '
        Me.txtTchTables.Location = New System.Drawing.Point(109, 23)
        Me.txtTchTables.Name = "txtTchTables"
        Me.txtTchTables.Size = New System.Drawing.Size(450, 25)
        Me.txtTchTables.TabIndex = 8
        '
        'lblTchInterval
        '
        Me.lblTchInterval.AutoSize = True
        Me.lblTchInterval.Location = New System.Drawing.Point(6, 57)
        Me.lblTchInterval.Name = "lblTchInterval"
        Me.lblTchInterval.Size = New System.Drawing.Size(97, 15)
        Me.lblTchInterval.TabIndex = 10
        Me.lblTchInterval.Text = "處理間隔時間"
        '
        'lblTchTables
        '
        Me.lblTchTables.AutoSize = True
        Me.lblTchTables.Location = New System.Drawing.Point(21, 26)
        Me.lblTchTables.Name = "lblTchTables"
        Me.lblTchTables.Size = New System.Drawing.Size(82, 15)
        Me.lblTchTables.TabIndex = 7
        Me.lblTchTables.Text = "來源資料表"
        '
        'lblTchIntervalUnit
        '
        Me.lblTchIntervalUnit.AutoSize = True
        Me.lblTchIntervalUnit.Location = New System.Drawing.Point(160, 57)
        Me.lblTchIntervalUnit.Name = "lblTchIntervalUnit"
        Me.lblTchIntervalUnit.Size = New System.Drawing.Size(22, 15)
        Me.lblTchIntervalUnit.TabIndex = 11
        Me.lblTchIntervalUnit.Text = "秒"
        '
        'chkTchEnable
        '
        Me.chkTchEnable.AutoSize = True
        Me.chkTchEnable.Location = New System.Drawing.Point(26, 180)
        Me.chkTchEnable.Name = "chkTchEnable"
        Me.chkTchEnable.Size = New System.Drawing.Size(116, 19)
        Me.chkTchEnable.TabIndex = 0
        Me.chkTchEnable.Text = "票交資料查詢"
        Me.chkTchEnable.UseVisualStyleBackColor = True
        '
        'gboxAdm
        '
        Me.gboxAdm.Controls.Add(Me.lblAdmIntervalUnit)
        Me.gboxAdm.Controls.Add(Me.lblAdmTables)
        Me.gboxAdm.Controls.Add(Me.lblAdmInterval)
        Me.gboxAdm.Controls.Add(Me.txtAdmTables)
        Me.gboxAdm.Controls.Add(Me.nudAdmInterval)
        Me.gboxAdm.Location = New System.Drawing.Point(20, 311)
        Me.gboxAdm.Name = "gboxAdm"
        Me.gboxAdm.Size = New System.Drawing.Size(565, 98)
        Me.gboxAdm.TabIndex = 6
        Me.gboxAdm.TabStop = False
        '
        'nudAdmInterval
        '
        Me.nudAdmInterval.Location = New System.Drawing.Point(109, 59)
        Me.nudAdmInterval.Name = "nudAdmInterval"
        Me.nudAdmInterval.Size = New System.Drawing.Size(45, 25)
        Me.nudAdmInterval.TabIndex = 14
        '
        'txtAdmTables
        '
        Me.txtAdmTables.Location = New System.Drawing.Point(109, 27)
        Me.txtAdmTables.Name = "txtAdmTables"
        Me.txtAdmTables.Size = New System.Drawing.Size(450, 25)
        Me.txtAdmTables.TabIndex = 13
        '
        'lblAdmInterval
        '
        Me.lblAdmInterval.AutoSize = True
        Me.lblAdmInterval.Location = New System.Drawing.Point(6, 61)
        Me.lblAdmInterval.Name = "lblAdmInterval"
        Me.lblAdmInterval.Size = New System.Drawing.Size(97, 15)
        Me.lblAdmInterval.TabIndex = 15
        Me.lblAdmInterval.Text = "處理間隔時間"
        '
        'lblAdmTables
        '
        Me.lblAdmTables.AutoSize = True
        Me.lblAdmTables.Location = New System.Drawing.Point(21, 30)
        Me.lblAdmTables.Name = "lblAdmTables"
        Me.lblAdmTables.Size = New System.Drawing.Size(82, 15)
        Me.lblAdmTables.TabIndex = 12
        Me.lblAdmTables.Text = "來源資料表"
        '
        'lblAdmIntervalUnit
        '
        Me.lblAdmIntervalUnit.AutoSize = True
        Me.lblAdmIntervalUnit.Location = New System.Drawing.Point(160, 61)
        Me.lblAdmIntervalUnit.Name = "lblAdmIntervalUnit"
        Me.lblAdmIntervalUnit.Size = New System.Drawing.Size(22, 15)
        Me.lblAdmIntervalUnit.TabIndex = 16
        Me.lblAdmIntervalUnit.Text = "秒"
        '
        'lblAPI_EDOCService
        '
        Me.lblAPI_EDOCService.AutoSize = True
        Me.lblAPI_EDOCService.Location = New System.Drawing.Point(47, 286)
        Me.lblAPI_EDOCService.Name = "lblAPI_EDOCService"
        Me.lblAPI_EDOCService.Size = New System.Drawing.Size(127, 15)
        Me.lblAPI_EDOCService.TabIndex = 0
        Me.lblAPI_EDOCService.Text = "地政整合介面位置"
        '
        'txtAPI_EDOCService
        '
        Me.txtAPI_EDOCService.Location = New System.Drawing.Point(180, 280)
        Me.txtAPI_EDOCService.Name = "txtAPI_EDOCService"
        Me.txtAPI_EDOCService.Size = New System.Drawing.Size(405, 25)
        Me.txtAPI_EDOCService.TabIndex = 8
        '
        'chkAdmEnable
        '
        Me.chkAdmEnable.AutoSize = True
        Me.chkAdmEnable.Location = New System.Drawing.Point(26, 311)
        Me.chkAdmEnable.Name = "chkAdmEnable"
        Me.chkAdmEnable.Size = New System.Drawing.Size(116, 19)
        Me.chkAdmEnable.TabIndex = 7
        Me.chkAdmEnable.Text = "地政資料查詢"
        Me.chkAdmEnable.UseVisualStyleBackColor = True
        '
        'chkOutSourceLog
        '
        Me.chkOutSourceLog.AutoSize = True
        Me.chkOutSourceLog.Location = New System.Drawing.Point(26, 428)
        Me.chkOutSourceLog.Name = "chkOutSourceLog"
        Me.chkOutSourceLog.Size = New System.Drawing.Size(116, 19)
        Me.chkOutSourceLog.TabIndex = 9
        Me.chkOutSourceLog.Text = "記錄傳輸時間"
        Me.chkOutSourceLog.UseVisualStyleBackColor = True
        '
        'lblConnStr_JcicTch
        '
        Me.lblConnStr_JcicTch.AutoSize = True
        Me.lblConnStr_JcicTch.Location = New System.Drawing.Point(17, 50)
        Me.lblConnStr_JcicTch.Name = "lblConnStr_JcicTch"
        Me.lblConnStr_JcicTch.Size = New System.Drawing.Size(172, 15)
        Me.lblConnStr_JcicTch.TabIndex = 10
        Me.lblConnStr_JcicTch.Text = "聯徵票交資料庫連線字串"
        '
        'txtConnStr_JcicTch
        '
        Me.txtConnStr_JcicTch.Location = New System.Drawing.Point(195, 47)
        Me.txtConnStr_JcicTch.Name = "txtConnStr_JcicTch"
        Me.txtConnStr_JcicTch.ReadOnly = True
        Me.txtConnStr_JcicTch.Size = New System.Drawing.Size(369, 25)
        Me.txtConnStr_JcicTch.TabIndex = 12
        '
        'btnConnStr_JcicTch
        '
        Me.btnConnStr_JcicTch.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnConnStr_JcicTch.Location = New System.Drawing.Point(573, 46)
        Me.btnConnStr_JcicTch.Name = "btnConnStr_JcicTch"
        Me.btnConnStr_JcicTch.Size = New System.Drawing.Size(28, 23)
        Me.btnConnStr_JcicTch.TabIndex = 13
        Me.btnConnStr_JcicTch.Text = "…"
        Me.btnConnStr_JcicTch.UseVisualStyleBackColor = True
        '
        'tabELoan
        '
        Me.tabELoan.Controls.Add(Me.cmbAttachFileMode)
        Me.tabELoan.Controls.Add(Me.lblAttachFileMode)
        Me.tabELoan.Controls.Add(Me.btnConnStr_CL)
        Me.tabELoan.Controls.Add(Me.txtConnStr_CL)
        Me.tabELoan.Controls.Add(Me.txtAPI_ScoringService)
        Me.tabELoan.Controls.Add(Me.txtAttachFilePath)
        Me.tabELoan.Controls.Add(Me.txtUpLoadUser)
        Me.tabELoan.Controls.Add(Me.txtAdm_UpLoadFilePath)
        Me.tabELoan.Controls.Add(Me.txtUpLoadFilePath)
        Me.tabELoan.Controls.Add(Me.txtConnStr_Security)
        Me.tabELoan.Controls.Add(Me.txtConnStr_Loan_History)
        Me.tabELoan.Controls.Add(Me.txtConnStr_Loan)
        Me.tabELoan.Controls.Add(Me.lblConnStr_CL)
        Me.tabELoan.Controls.Add(Me.lblAPI_ScoringService)
        Me.tabELoan.Controls.Add(Me.lblAttach_Interval_Unit)
        Me.tabELoan.Controls.Add(Me.lblAttachFilePath)
        Me.tabELoan.Controls.Add(Me.nudAttach_Interval)
        Me.tabELoan.Controls.Add(Me.lblAttach_Interval)
        Me.tabELoan.Controls.Add(Me.txtUpLoadPassword)
        Me.tabELoan.Controls.Add(Me.lblUpLoadPassword)
        Me.tabELoan.Controls.Add(Me.lblUpLoadUser)
        Me.tabELoan.Controls.Add(Me.lblAdm_UpLoadFilePath)
        Me.tabELoan.Controls.Add(Me.lblUpLoadFilePath)
        Me.tabELoan.Controls.Add(Me.gbxAPServer)
        Me.tabELoan.Controls.Add(Me.btnConnStr_Security)
        Me.tabELoan.Controls.Add(Me.lblConnStr_Security)
        Me.tabELoan.Controls.Add(Me.btnConnStr_Loan_History)
        Me.tabELoan.Controls.Add(Me.lblConnStr_Loan_History)
        Me.tabELoan.Controls.Add(Me.btnConnStr_Loan)
        Me.tabELoan.Controls.Add(Me.lblConnStr_Loan)
        Me.tabELoan.Controls.Add(Me.gbRestartServices)
        Me.tabELoan.Location = New System.Drawing.Point(4, 25)
        Me.tabELoan.Name = "tabELoan"
        Me.tabELoan.Size = New System.Drawing.Size(607, 642)
        Me.tabELoan.TabIndex = 4
        Me.tabELoan.Text = "徵授信系統參數設定"
        Me.tabELoan.UseVisualStyleBackColor = True
        '
        'gbRestartServices
        '
        Me.gbRestartServices.Controls.Add(Me.txtRestartTime)
        Me.gbRestartServices.Controls.Add(Me.chkRestartOnTheHour)
        Me.gbRestartServices.Controls.Add(Me.txtRestartServicesName)
        Me.gbRestartServices.Controls.Add(Me.lblRestartServicesName)
        Me.gbRestartServices.Location = New System.Drawing.Point(11, 499)
        Me.gbRestartServices.Name = "gbRestartServices"
        Me.gbRestartServices.Size = New System.Drawing.Size(556, 80)
        Me.gbRestartServices.TabIndex = 36
        Me.gbRestartServices.TabStop = False
        Me.gbRestartServices.Text = "定時重啟服務"
        '
        'lblRestartServicesName
        '
        Me.lblRestartServicesName.AutoSize = True
        Me.lblRestartServicesName.Location = New System.Drawing.Point(6, 21)
        Me.lblRestartServicesName.Name = "lblRestartServicesName"
        Me.lblRestartServicesName.Size = New System.Drawing.Size(67, 15)
        Me.lblRestartServicesName.TabIndex = 35
        Me.lblRestartServicesName.Text = "服務名稱"
        '
        'txtRestartServicesName
        '
        Me.txtRestartServicesName.Location = New System.Drawing.Point(95, 18)
        Me.txtRestartServicesName.Name = "txtRestartServicesName"
        Me.txtRestartServicesName.Size = New System.Drawing.Size(455, 25)
        Me.txtRestartServicesName.TabIndex = 36
        '
        'chkRestartOnTheHour
        '
        Me.chkRestartOnTheHour.AutoSize = True
        Me.chkRestartOnTheHour.Location = New System.Drawing.Point(9, 49)
        Me.chkRestartOnTheHour.Name = "chkRestartOnTheHour"
        Me.chkRestartOnTheHour.Size = New System.Drawing.Size(86, 19)
        Me.chkRestartOnTheHour.TabIndex = 37
        Me.chkRestartOnTheHour.Text = "整點重啟"
        Me.chkRestartOnTheHour.UseVisualStyleBackColor = True
        '
        'txtRestartTime
        '
        Me.txtRestartTime.Location = New System.Drawing.Point(95, 47)
        Me.txtRestartTime.Name = "txtRestartTime"
        Me.txtRestartTime.Size = New System.Drawing.Size(455, 25)
        Me.txtRestartTime.TabIndex = 38
        '
        'lblConnStr_Loan
        '
        Me.lblConnStr_Loan.AutoSize = True
        Me.lblConnStr_Loan.Location = New System.Drawing.Point(8, 155)
        Me.lblConnStr_Loan.Name = "lblConnStr_Loan"
        Me.lblConnStr_Loan.Size = New System.Drawing.Size(142, 15)
        Me.lblConnStr_Loan.TabIndex = 0
        Me.lblConnStr_Loan.Text = "主要資料庫連接設定"
        '
        'txtConnStr_Loan
        '
        Me.txtConnStr_Loan.Location = New System.Drawing.Point(171, 152)
        Me.txtConnStr_Loan.Name = "txtConnStr_Loan"
        Me.txtConnStr_Loan.ReadOnly = True
        Me.txtConnStr_Loan.Size = New System.Drawing.Size(396, 25)
        Me.txtConnStr_Loan.TabIndex = 1
        '
        'btnConnStr_Loan
        '
        Me.btnConnStr_Loan.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnConnStr_Loan.Location = New System.Drawing.Point(576, 151)
        Me.btnConnStr_Loan.Name = "btnConnStr_Loan"
        Me.btnConnStr_Loan.Size = New System.Drawing.Size(28, 23)
        Me.btnConnStr_Loan.TabIndex = 7
        Me.btnConnStr_Loan.Text = "…"
        Me.btnConnStr_Loan.UseVisualStyleBackColor = True
        '
        'lblConnStr_Loan_History
        '
        Me.lblConnStr_Loan_History.AutoSize = True
        Me.lblConnStr_Loan_History.Location = New System.Drawing.Point(8, 187)
        Me.lblConnStr_Loan_History.Name = "lblConnStr_Loan_History"
        Me.lblConnStr_Loan_History.Size = New System.Drawing.Size(142, 15)
        Me.lblConnStr_Loan_History.TabIndex = 8
        Me.lblConnStr_Loan_History.Text = "歷史資料庫連接設定"
        '
        'txtConnStr_Loan_History
        '
        Me.txtConnStr_Loan_History.Location = New System.Drawing.Point(171, 184)
        Me.txtConnStr_Loan_History.Name = "txtConnStr_Loan_History"
        Me.txtConnStr_Loan_History.ReadOnly = True
        Me.txtConnStr_Loan_History.Size = New System.Drawing.Size(396, 25)
        Me.txtConnStr_Loan_History.TabIndex = 9
        '
        'btnConnStr_Loan_History
        '
        Me.btnConnStr_Loan_History.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnConnStr_Loan_History.Location = New System.Drawing.Point(576, 183)
        Me.btnConnStr_Loan_History.Name = "btnConnStr_Loan_History"
        Me.btnConnStr_Loan_History.Size = New System.Drawing.Size(28, 23)
        Me.btnConnStr_Loan_History.TabIndex = 10
        Me.btnConnStr_Loan_History.Text = "…"
        Me.btnConnStr_Loan_History.UseVisualStyleBackColor = True
        '
        'lblConnStr_Security
        '
        Me.lblConnStr_Security.AutoSize = True
        Me.lblConnStr_Security.Location = New System.Drawing.Point(8, 249)
        Me.lblConnStr_Security.Name = "lblConnStr_Security"
        Me.lblConnStr_Security.Size = New System.Drawing.Size(142, 15)
        Me.lblConnStr_Security.TabIndex = 11
        Me.lblConnStr_Security.Text = "安控資料庫連接設定"
        '
        'txtConnStr_Security
        '
        Me.txtConnStr_Security.Location = New System.Drawing.Point(171, 246)
        Me.txtConnStr_Security.Name = "txtConnStr_Security"
        Me.txtConnStr_Security.ReadOnly = True
        Me.txtConnStr_Security.Size = New System.Drawing.Size(396, 25)
        Me.txtConnStr_Security.TabIndex = 12
        '
        'btnConnStr_Security
        '
        Me.btnConnStr_Security.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnConnStr_Security.Location = New System.Drawing.Point(576, 245)
        Me.btnConnStr_Security.Name = "btnConnStr_Security"
        Me.btnConnStr_Security.Size = New System.Drawing.Size(28, 23)
        Me.btnConnStr_Security.TabIndex = 13
        Me.btnConnStr_Security.Text = "…"
        Me.btnConnStr_Security.UseVisualStyleBackColor = True
        '
        'gbxAPServer
        '
        Me.gbxAPServer.Controls.Add(Me.dgvAPServerList)
        Me.gbxAPServer.Location = New System.Drawing.Point(11, 14)
        Me.gbxAPServer.Name = "gbxAPServer"
        Me.gbxAPServer.Size = New System.Drawing.Size(590, 131)
        Me.gbxAPServer.TabIndex = 14
        Me.gbxAPServer.TabStop = False
        Me.gbxAPServer.Text = "徵授信系統AP Server"
        '
        'dgvAPServerList
        '
        Me.dgvAPServerList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvAPServerList.Location = New System.Drawing.Point(7, 25)
        Me.dgvAPServerList.Name = "dgvAPServerList"
        Me.dgvAPServerList.RowTemplate.Height = 24
        Me.dgvAPServerList.Size = New System.Drawing.Size(577, 100)
        Me.dgvAPServerList.TabIndex = 0
        '
        'lblUpLoadFilePath
        '
        Me.lblUpLoadFilePath.AutoSize = True
        Me.lblUpLoadFilePath.Location = New System.Drawing.Point(8, 280)
        Me.lblUpLoadFilePath.Name = "lblUpLoadFilePath"
        Me.lblUpLoadFilePath.Size = New System.Drawing.Size(62, 15)
        Me.lblUpLoadFilePath.TabIndex = 15
        Me.lblUpLoadFilePath.Text = "FTP位址"
        '
        'txtUpLoadFilePath
        '
        Me.txtUpLoadFilePath.Location = New System.Drawing.Point(106, 277)
        Me.txtUpLoadFilePath.Name = "txtUpLoadFilePath"
        Me.txtUpLoadFilePath.Size = New System.Drawing.Size(461, 25)
        Me.txtUpLoadFilePath.TabIndex = 16
        '
        'lblAdm_UpLoadFilePath
        '
        Me.lblAdm_UpLoadFilePath.AutoSize = True
        Me.lblAdm_UpLoadFilePath.Location = New System.Drawing.Point(8, 312)
        Me.lblAdm_UpLoadFilePath.Name = "lblAdm_UpLoadFilePath"
        Me.lblAdm_UpLoadFilePath.Size = New System.Drawing.Size(92, 15)
        Me.lblAdm_UpLoadFilePath.TabIndex = 17
        Me.lblAdm_UpLoadFilePath.Text = "地政FTP位址"
        '
        'txtAdm_UpLoadFilePath
        '
        Me.txtAdm_UpLoadFilePath.Location = New System.Drawing.Point(106, 309)
        Me.txtAdm_UpLoadFilePath.Name = "txtAdm_UpLoadFilePath"
        Me.txtAdm_UpLoadFilePath.Size = New System.Drawing.Size(461, 25)
        Me.txtAdm_UpLoadFilePath.TabIndex = 18
        '
        'lblUpLoadUser
        '
        Me.lblUpLoadUser.AutoSize = True
        Me.lblUpLoadUser.Location = New System.Drawing.Point(8, 343)
        Me.lblUpLoadUser.Name = "lblUpLoadUser"
        Me.lblUpLoadUser.Size = New System.Drawing.Size(62, 15)
        Me.lblUpLoadUser.TabIndex = 19
        Me.lblUpLoadUser.Text = "FTP帳號"
        '
        'lblUpLoadPassword
        '
        Me.lblUpLoadPassword.AutoSize = True
        Me.lblUpLoadPassword.Location = New System.Drawing.Point(312, 343)
        Me.lblUpLoadPassword.Name = "lblUpLoadPassword"
        Me.lblUpLoadPassword.Size = New System.Drawing.Size(62, 15)
        Me.lblUpLoadPassword.TabIndex = 20
        Me.lblUpLoadPassword.Text = "FTP密碼"
        '
        'txtUpLoadUser
        '
        Me.txtUpLoadUser.Location = New System.Drawing.Point(106, 340)
        Me.txtUpLoadUser.Name = "txtUpLoadUser"
        Me.txtUpLoadUser.Size = New System.Drawing.Size(200, 25)
        Me.txtUpLoadUser.TabIndex = 21
        '
        'txtUpLoadPassword
        '
        Me.txtUpLoadPassword.Location = New System.Drawing.Point(380, 340)
        Me.txtUpLoadPassword.Name = "txtUpLoadPassword"
        Me.txtUpLoadPassword.Size = New System.Drawing.Size(187, 25)
        Me.txtUpLoadPassword.TabIndex = 22
        Me.txtUpLoadPassword.UseSystemPasswordChar = True
        '
        'lblAttach_Interval
        '
        Me.lblAttach_Interval.AutoSize = True
        Me.lblAttach_Interval.Location = New System.Drawing.Point(8, 373)
        Me.lblAttach_Interval.Name = "lblAttach_Interval"
        Me.lblAttach_Interval.Size = New System.Drawing.Size(157, 15)
        Me.lblAttach_Interval.TabIndex = 23
        Me.lblAttach_Interval.Text = "附件背景處理間隔時間"
        '
        'nudAttach_Interval
        '
        Me.nudAttach_Interval.Location = New System.Drawing.Point(171, 371)
        Me.nudAttach_Interval.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.nudAttach_Interval.Name = "nudAttach_Interval"
        Me.nudAttach_Interval.Size = New System.Drawing.Size(57, 25)
        Me.nudAttach_Interval.TabIndex = 24
        Me.nudAttach_Interval.Value = New Decimal(New Integer() {10, 0, 0, 0})
        '
        'lblAttachFilePath
        '
        Me.lblAttachFilePath.AutoSize = True
        Me.lblAttachFilePath.Location = New System.Drawing.Point(8, 406)
        Me.lblAttachFilePath.Name = "lblAttachFilePath"
        Me.lblAttachFilePath.Size = New System.Drawing.Size(97, 15)
        Me.lblAttachFilePath.TabIndex = 25
        Me.lblAttachFilePath.Text = "附件存放目錄"
        '
        'txtAttachFilePath
        '
        Me.txtAttachFilePath.Location = New System.Drawing.Point(106, 403)
        Me.txtAttachFilePath.Name = "txtAttachFilePath"
        Me.txtAttachFilePath.Size = New System.Drawing.Size(461, 25)
        Me.txtAttachFilePath.TabIndex = 26
        '
        'lblAttach_Interval_Unit
        '
        Me.lblAttach_Interval_Unit.AutoSize = True
        Me.lblAttach_Interval_Unit.Location = New System.Drawing.Point(234, 373)
        Me.lblAttach_Interval_Unit.Name = "lblAttach_Interval_Unit"
        Me.lblAttach_Interval_Unit.Size = New System.Drawing.Size(22, 15)
        Me.lblAttach_Interval_Unit.TabIndex = 27
        Me.lblAttach_Interval_Unit.Text = "秒"
        '
        'lblAPI_ScoringService
        '
        Me.lblAPI_ScoringService.AutoSize = True
        Me.lblAPI_ScoringService.Location = New System.Drawing.Point(8, 471)
        Me.lblAPI_ScoringService.Name = "lblAPI_ScoringService"
        Me.lblAPI_ScoringService.Size = New System.Drawing.Size(90, 15)
        Me.lblAPI_ScoringService.TabIndex = 28
        Me.lblAPI_ScoringService.Text = "評分系統API"
        '
        'txtAPI_ScoringService
        '
        Me.txtAPI_ScoringService.Location = New System.Drawing.Point(106, 468)
        Me.txtAPI_ScoringService.Name = "txtAPI_ScoringService"
        Me.txtAPI_ScoringService.Size = New System.Drawing.Size(461, 25)
        Me.txtAPI_ScoringService.TabIndex = 29
        '
        'lblConnStr_CL
        '
        Me.lblConnStr_CL.AutoSize = True
        Me.lblConnStr_CL.Location = New System.Drawing.Point(8, 218)
        Me.lblConnStr_CL.Name = "lblConnStr_CL"
        Me.lblConnStr_CL.Size = New System.Drawing.Size(157, 15)
        Me.lblConnStr_CL.TabIndex = 30
        Me.lblConnStr_CL.Text = "擔保品資料庫連接設定"
        '
        'txtConnStr_CL
        '
        Me.txtConnStr_CL.Location = New System.Drawing.Point(171, 215)
        Me.txtConnStr_CL.Name = "txtConnStr_CL"
        Me.txtConnStr_CL.ReadOnly = True
        Me.txtConnStr_CL.Size = New System.Drawing.Size(396, 25)
        Me.txtConnStr_CL.TabIndex = 31
        '
        'btnConnStr_CL
        '
        Me.btnConnStr_CL.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnConnStr_CL.Location = New System.Drawing.Point(576, 214)
        Me.btnConnStr_CL.Name = "btnConnStr_CL"
        Me.btnConnStr_CL.Size = New System.Drawing.Size(28, 23)
        Me.btnConnStr_CL.TabIndex = 32
        Me.btnConnStr_CL.Text = "…"
        Me.btnConnStr_CL.UseVisualStyleBackColor = True
        '
        'lblAttachFileMode
        '
        Me.lblAttachFileMode.AutoSize = True
        Me.lblAttachFileMode.Location = New System.Drawing.Point(8, 439)
        Me.lblAttachFileMode.Name = "lblAttachFileMode"
        Me.lblAttachFileMode.Size = New System.Drawing.Size(97, 15)
        Me.lblAttachFileMode.TabIndex = 33
        Me.lblAttachFileMode.Text = "附件處理模式"
        '
        'cmbAttachFileMode
        '
        Me.cmbAttachFileMode.FormattingEnabled = True
        Me.cmbAttachFileMode.Location = New System.Drawing.Point(106, 435)
        Me.cmbAttachFileMode.Name = "cmbAttachFileMode"
        Me.cmbAttachFileMode.Size = New System.Drawing.Size(121, 23)
        Me.cmbAttachFileMode.TabIndex = 34
        '
        'tabCommon
        '
        Me.tabCommon.Controls.Add(Me.cmbELLifeCycleUnit)
        Me.tabCommon.Controls.Add(Me.txtELLifeCycle)
        Me.tabCommon.Controls.Add(Me.txtELTagPath)
        Me.tabCommon.Controls.Add(Me.txtELSrcPath)
        Me.tabCommon.Controls.Add(Me.txtDBConnString)
        Me.tabCommon.Controls.Add(Me.txtLocalServerIP)
        Me.tabCommon.Controls.Add(Me.txtLogPath)
        Me.tabCommon.Controls.Add(Me.txtTmpOutputPath)
        Me.tabCommon.Controls.Add(Me.txtTmpInputPath)
        Me.tabCommon.Controls.Add(Me.lblELLifeCycle)
        Me.tabCommon.Controls.Add(Me.btnELTagPath)
        Me.tabCommon.Controls.Add(Me.lblELTagPath)
        Me.tabCommon.Controls.Add(Me.btnELSrcPath)
        Me.tabCommon.Controls.Add(Me.lblELSrcPath)
        Me.tabCommon.Controls.Add(Me.nudLogFileBackupCount)
        Me.tabCommon.Controls.Add(Me.lblLogFileBackupCount)
        Me.tabCommon.Controls.Add(Me.lblMB)
        Me.tabCommon.Controls.Add(Me.nudLogFileSize)
        Me.tabCommon.Controls.Add(Me.chkMailEnable)
        Me.tabCommon.Controls.Add(Me.lblLogFileSize)
        Me.tabCommon.Controls.Add(Me.btnDBConnString)
        Me.tabCommon.Controls.Add(Me.gboxEmail)
        Me.tabCommon.Controls.Add(Me.lblDBConnString)
        Me.tabCommon.Controls.Add(Me.btnLogPath)
        Me.tabCommon.Controls.Add(Me.lblLocalServerIP)
        Me.tabCommon.Controls.Add(Me.gboxRemoteServerList)
        Me.tabCommon.Controls.Add(Me.lblLogPath)
        Me.tabCommon.Controls.Add(Me.lblTmpOutputPath)
        Me.tabCommon.Controls.Add(Me.btnTmpOutputPath)
        Me.tabCommon.Controls.Add(Me.btnTmpInputPath)
        Me.tabCommon.Controls.Add(Me.lblTmpInputPath)
        Me.tabCommon.Location = New System.Drawing.Point(4, 25)
        Me.tabCommon.Name = "tabCommon"
        Me.tabCommon.Padding = New System.Windows.Forms.Padding(3)
        Me.tabCommon.Size = New System.Drawing.Size(607, 642)
        Me.tabCommon.TabIndex = 0
        Me.tabCommon.Text = "一般設定"
        Me.tabCommon.UseVisualStyleBackColor = True
        '
        'txtTmpInputPath
        '
        Me.txtTmpInputPath.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtTmpInputPath.Location = New System.Drawing.Point(150, 105)
        Me.txtTmpInputPath.Name = "txtTmpInputPath"
        Me.txtTmpInputPath.Size = New System.Drawing.Size(403, 25)
        Me.txtTmpInputPath.TabIndex = 20
        '
        'lblTmpInputPath
        '
        Me.lblTmpInputPath.AutoSize = True
        Me.lblTmpInputPath.Location = New System.Drawing.Point(48, 110)
        Me.lblTmpInputPath.Name = "lblTmpInputPath"
        Me.lblTmpInputPath.Size = New System.Drawing.Size(97, 15)
        Me.lblTmpInputPath.TabIndex = 8
        Me.lblTmpInputPath.Text = "輸入暫存目錄"
        Me.lblTmpInputPath.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'btnTmpInputPath
        '
        Me.btnTmpInputPath.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnTmpInputPath.Location = New System.Drawing.Point(555, 106)
        Me.btnTmpInputPath.Name = "btnTmpInputPath"
        Me.btnTmpInputPath.Size = New System.Drawing.Size(28, 23)
        Me.btnTmpInputPath.TabIndex = 21
        Me.btnTmpInputPath.Text = "…"
        Me.btnTmpInputPath.UseVisualStyleBackColor = True
        '
        'btnTmpOutputPath
        '
        Me.btnTmpOutputPath.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnTmpOutputPath.Location = New System.Drawing.Point(555, 75)
        Me.btnTmpOutputPath.Name = "btnTmpOutputPath"
        Me.btnTmpOutputPath.Size = New System.Drawing.Size(28, 23)
        Me.btnTmpOutputPath.TabIndex = 16
        Me.btnTmpOutputPath.Text = "…"
        Me.btnTmpOutputPath.UseVisualStyleBackColor = True
        '
        'txtTmpOutputPath
        '
        Me.txtTmpOutputPath.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtTmpOutputPath.Location = New System.Drawing.Point(150, 74)
        Me.txtTmpOutputPath.Name = "txtTmpOutputPath"
        Me.txtTmpOutputPath.Size = New System.Drawing.Size(403, 25)
        Me.txtTmpOutputPath.TabIndex = 15
        '
        'lblTmpOutputPath
        '
        Me.lblTmpOutputPath.AutoSize = True
        Me.lblTmpOutputPath.Location = New System.Drawing.Point(47, 79)
        Me.lblTmpOutputPath.Name = "lblTmpOutputPath"
        Me.lblTmpOutputPath.Size = New System.Drawing.Size(97, 15)
        Me.lblTmpOutputPath.TabIndex = 1
        Me.lblTmpOutputPath.Text = "輸出暫存目錄"
        Me.lblTmpOutputPath.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblLogPath
        '
        Me.lblLogPath.AutoSize = True
        Me.lblLogPath.Location = New System.Drawing.Point(63, 141)
        Me.lblLogPath.Name = "lblLogPath"
        Me.lblLogPath.Size = New System.Drawing.Size(82, 15)
        Me.lblLogPath.TabIndex = 101
        Me.lblLogPath.Text = "記錄檔目錄"
        Me.lblLogPath.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'gboxRemoteServerList
        '
        Me.gboxRemoteServerList.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gboxRemoteServerList.Controls.Add(Me.dgvRemoteServerList)
        Me.gboxRemoteServerList.Location = New System.Drawing.Point(12, 485)
        Me.gboxRemoteServerList.Name = "gboxRemoteServerList"
        Me.gboxRemoteServerList.Size = New System.Drawing.Size(586, 159)
        Me.gboxRemoteServerList.TabIndex = 99
        Me.gboxRemoteServerList.TabStop = False
        Me.gboxRemoteServerList.Text = "遠端伺服器設定"
        '
        'dgvRemoteServerList
        '
        Me.dgvRemoteServerList.AllowUserToResizeRows = False
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.White
        Me.dgvRemoteServerList.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle3
        Me.dgvRemoteServerList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.dgvRemoteServerList.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgvRemoteServerList.Location = New System.Drawing.Point(3, 21)
        Me.dgvRemoteServerList.Name = "dgvRemoteServerList"
        Me.dgvRemoteServerList.RowHeadersVisible = False
        Me.dgvRemoteServerList.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToDisplayedHeaders
        DataGridViewCellStyle4.BackColor = System.Drawing.Color.MistyRose
        Me.dgvRemoteServerList.RowsDefaultCellStyle = DataGridViewCellStyle4
        Me.dgvRemoteServerList.RowTemplate.Height = 24
        Me.dgvRemoteServerList.Size = New System.Drawing.Size(580, 135)
        Me.dgvRemoteServerList.TabIndex = 100
        '
        'txtLogPath
        '
        Me.txtLogPath.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtLogPath.Location = New System.Drawing.Point(150, 136)
        Me.txtLogPath.Name = "txtLogPath"
        Me.txtLogPath.Size = New System.Drawing.Size(403, 25)
        Me.txtLogPath.TabIndex = 25
        '
        'lblLocalServerIP
        '
        Me.lblLocalServerIP.AutoSize = True
        Me.lblLocalServerIP.Location = New System.Drawing.Point(78, 46)
        Me.lblLocalServerIP.Name = "lblLocalServerIP"
        Me.lblLocalServerIP.Size = New System.Drawing.Size(67, 15)
        Me.lblLocalServerIP.TabIndex = 2
        Me.lblLocalServerIP.Text = "本地ＩＰ"
        Me.lblLocalServerIP.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'btnLogPath
        '
        Me.btnLogPath.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnLogPath.Location = New System.Drawing.Point(555, 137)
        Me.btnLogPath.Name = "btnLogPath"
        Me.btnLogPath.Size = New System.Drawing.Size(28, 23)
        Me.btnLogPath.TabIndex = 26
        Me.btnLogPath.Text = "…"
        Me.btnLogPath.UseVisualStyleBackColor = True
        '
        'lblDBConnString
        '
        Me.lblDBConnString.AutoSize = True
        Me.lblDBConnString.Location = New System.Drawing.Point(32, 17)
        Me.lblDBConnString.Name = "lblDBConnString"
        Me.lblDBConnString.Size = New System.Drawing.Size(112, 15)
        Me.lblDBConnString.TabIndex = 0
        Me.lblDBConnString.Text = "資料庫連接設定"
        Me.lblDBConnString.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'txtLocalServerIP
        '
        Me.txtLocalServerIP.Location = New System.Drawing.Point(150, 43)
        Me.txtLocalServerIP.Name = "txtLocalServerIP"
        Me.txtLocalServerIP.Size = New System.Drawing.Size(86, 25)
        Me.txtLocalServerIP.TabIndex = 10
        '
        'txtDBConnString
        '
        Me.txtDBConnString.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtDBConnString.Location = New System.Drawing.Point(150, 12)
        Me.txtDBConnString.Name = "txtDBConnString"
        Me.txtDBConnString.ReadOnly = True
        Me.txtDBConnString.Size = New System.Drawing.Size(403, 25)
        Me.txtDBConnString.TabIndex = 5
        '
        'gboxEmail
        '
        Me.gboxEmail.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gboxEmail.Controls.Add(Me.chkMailSMTPVerify)
        Me.gboxEmail.Controls.Add(Me.txtMailSMTPPwd)
        Me.gboxEmail.Controls.Add(Me.lblMailSMTPPwd)
        Me.gboxEmail.Controls.Add(Me.txtMailSMTPUid)
        Me.gboxEmail.Controls.Add(Me.lblMailSMTPUid)
        Me.gboxEmail.Controls.Add(Me.txtMailTo)
        Me.gboxEmail.Controls.Add(Me.lblMailTo)
        Me.gboxEmail.Controls.Add(Me.txtMailSMTP)
        Me.gboxEmail.Controls.Add(Me.lblMailCC)
        Me.gboxEmail.Controls.Add(Me.txtMailCC)
        Me.gboxEmail.Controls.Add(Me.lblMailSMTP)
        Me.gboxEmail.Controls.Add(Me.txtMailQuantity)
        Me.gboxEmail.Controls.Add(Me.lblMailQuantity)
        Me.gboxEmail.Location = New System.Drawing.Point(12, 290)
        Me.gboxEmail.Name = "gboxEmail"
        Me.gboxEmail.Size = New System.Drawing.Size(586, 189)
        Me.gboxEmail.TabIndex = 103
        Me.gboxEmail.TabStop = False
        '
        'lblMailQuantity
        '
        Me.lblMailQuantity.AutoSize = True
        Me.lblMailQuantity.Location = New System.Drawing.Point(6, 34)
        Me.lblMailQuantity.Name = "lblMailQuantity"
        Me.lblMailQuantity.Size = New System.Drawing.Size(127, 15)
        Me.lblMailQuantity.TabIndex = 7
        Me.lblMailQuantity.Text = "每日最大回報數量"
        Me.lblMailQuantity.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'txtMailQuantity
        '
        Me.txtMailQuantity.Location = New System.Drawing.Point(138, 29)
        Me.txtMailQuantity.Name = "txtMailQuantity"
        Me.txtMailQuantity.Size = New System.Drawing.Size(84, 25)
        Me.txtMailQuantity.TabIndex = 65
        '
        'lblMailSMTP
        '
        Me.lblMailSMTP.AutoSize = True
        Me.lblMailSMTP.Location = New System.Drawing.Point(27, 130)
        Me.lblMailSMTP.Name = "lblMailSMTP"
        Me.lblMailSMTP.Size = New System.Drawing.Size(103, 15)
        Me.lblMailSMTP.TabIndex = 3
        Me.lblMailSMTP.Text = "SMTP SERVER"
        Me.lblMailSMTP.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'txtMailCC
        '
        Me.txtMailCC.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtMailCC.Location = New System.Drawing.Point(138, 93)
        Me.txtMailCC.Name = "txtMailCC"
        Me.txtMailCC.Size = New System.Drawing.Size(399, 25)
        Me.txtMailCC.TabIndex = 75
        '
        'lblMailCC
        '
        Me.lblMailCC.AutoSize = True
        Me.lblMailCC.Location = New System.Drawing.Point(93, 98)
        Me.lblMailCC.Name = "lblMailCC"
        Me.lblMailCC.Size = New System.Drawing.Size(37, 15)
        Me.lblMailCC.TabIndex = 2
        Me.lblMailCC.Text = "副本"
        Me.lblMailCC.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'txtMailSMTP
        '
        Me.txtMailSMTP.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtMailSMTP.Location = New System.Drawing.Point(138, 125)
        Me.txtMailSMTP.Name = "txtMailSMTP"
        Me.txtMailSMTP.Size = New System.Drawing.Size(399, 25)
        Me.txtMailSMTP.TabIndex = 80
        '
        'lblMailTo
        '
        Me.lblMailTo.AutoSize = True
        Me.lblMailTo.Location = New System.Drawing.Point(78, 66)
        Me.lblMailTo.Name = "lblMailTo"
        Me.lblMailTo.Size = New System.Drawing.Size(52, 15)
        Me.lblMailTo.TabIndex = 1
        Me.lblMailTo.Text = "收件者"
        Me.lblMailTo.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'txtMailTo
        '
        Me.txtMailTo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtMailTo.Location = New System.Drawing.Point(138, 61)
        Me.txtMailTo.Name = "txtMailTo"
        Me.txtMailTo.Size = New System.Drawing.Size(399, 25)
        Me.txtMailTo.TabIndex = 70
        '
        'lblMailSMTPUid
        '
        Me.lblMailSMTPUid.AutoSize = True
        Me.lblMailSMTPUid.Location = New System.Drawing.Point(246, 162)
        Me.lblMailSMTPUid.Name = "lblMailSMTPUid"
        Me.lblMailSMTPUid.Size = New System.Drawing.Size(37, 15)
        Me.lblMailSMTPUid.TabIndex = 51
        Me.lblMailSMTPUid.Text = "帳號"
        Me.lblMailSMTPUid.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'txtMailSMTPUid
        '
        Me.txtMailSMTPUid.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtMailSMTPUid.Location = New System.Drawing.Point(282, 157)
        Me.txtMailSMTPUid.Name = "txtMailSMTPUid"
        Me.txtMailSMTPUid.Size = New System.Drawing.Size(123, 25)
        Me.txtMailSMTPUid.TabIndex = 90
        '
        'lblMailSMTPPwd
        '
        Me.lblMailSMTPPwd.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblMailSMTPPwd.AutoSize = True
        Me.lblMailSMTPPwd.Location = New System.Drawing.Point(411, 162)
        Me.lblMailSMTPPwd.Name = "lblMailSMTPPwd"
        Me.lblMailSMTPPwd.Size = New System.Drawing.Size(37, 15)
        Me.lblMailSMTPPwd.TabIndex = 53
        Me.lblMailSMTPPwd.Text = "密碼"
        Me.lblMailSMTPPwd.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'txtMailSMTPPwd
        '
        Me.txtMailSMTPPwd.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtMailSMTPPwd.Location = New System.Drawing.Point(453, 157)
        Me.txtMailSMTPPwd.Name = "txtMailSMTPPwd"
        Me.txtMailSMTPPwd.Size = New System.Drawing.Size(84, 25)
        Me.txtMailSMTPPwd.TabIndex = 95
        Me.txtMailSMTPPwd.UseSystemPasswordChar = True
        '
        'chkMailSMTPVerify
        '
        Me.chkMailSMTPVerify.AutoSize = True
        Me.chkMailSMTPVerify.Location = New System.Drawing.Point(138, 160)
        Me.chkMailSMTPVerify.Name = "chkMailSMTPVerify"
        Me.chkMailSMTPVerify.Size = New System.Drawing.Size(101, 19)
        Me.chkMailSMTPVerify.TabIndex = 85
        Me.chkMailSMTPVerify.Text = "使用者驗證"
        Me.chkMailSMTPVerify.UseVisualStyleBackColor = True
        '
        'btnDBConnString
        '
        Me.btnDBConnString.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnDBConnString.Location = New System.Drawing.Point(555, 13)
        Me.btnDBConnString.Name = "btnDBConnString"
        Me.btnDBConnString.Size = New System.Drawing.Size(28, 23)
        Me.btnDBConnString.TabIndex = 6
        Me.btnDBConnString.Text = "…"
        Me.btnDBConnString.UseVisualStyleBackColor = True
        Me.btnDBConnString.Visible = False
        '
        'lblLogFileSize
        '
        Me.lblLogFileSize.AutoSize = True
        Me.lblLogFileSize.Location = New System.Drawing.Point(33, 173)
        Me.lblLogFileSize.Name = "lblLogFileSize"
        Me.lblLogFileSize.Size = New System.Drawing.Size(112, 15)
        Me.lblLogFileSize.TabIndex = 105
        Me.lblLogFileSize.Text = "記錄檔ＳＩＺＥ"
        '
        'chkMailEnable
        '
        Me.chkMailEnable.AutoSize = True
        Me.chkMailEnable.Location = New System.Drawing.Point(20, 291)
        Me.chkMailEnable.Name = "chkMailEnable"
        Me.chkMailEnable.Size = New System.Drawing.Size(116, 19)
        Me.chkMailEnable.TabIndex = 60
        Me.chkMailEnable.Text = "開啟錯誤回報"
        Me.chkMailEnable.UseVisualStyleBackColor = True
        '
        'nudLogFileSize
        '
        Me.nudLogFileSize.Location = New System.Drawing.Point(150, 167)
        Me.nudLogFileSize.Maximum = New Decimal(New Integer() {50, 0, 0, 0})
        Me.nudLogFileSize.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.nudLogFileSize.Name = "nudLogFileSize"
        Me.nudLogFileSize.Size = New System.Drawing.Size(51, 25)
        Me.nudLogFileSize.TabIndex = 30
        Me.nudLogFileSize.Value = New Decimal(New Integer() {5, 0, 0, 0})
        '
        'lblMB
        '
        Me.lblMB.AutoSize = True
        Me.lblMB.Location = New System.Drawing.Point(207, 173)
        Me.lblMB.Name = "lblMB"
        Me.lblMB.Size = New System.Drawing.Size(29, 15)
        Me.lblMB.TabIndex = 107
        Me.lblMB.Text = "MB"
        '
        'lblLogFileBackupCount
        '
        Me.lblLogFileBackupCount.AutoSize = True
        Me.lblLogFileBackupCount.Location = New System.Drawing.Point(294, 173)
        Me.lblLogFileBackupCount.Name = "lblLogFileBackupCount"
        Me.lblLogFileBackupCount.Size = New System.Drawing.Size(97, 15)
        Me.lblLogFileBackupCount.TabIndex = 108
        Me.lblLogFileBackupCount.Text = "記錄檔備份數"
        '
        'nudLogFileBackupCount
        '
        Me.nudLogFileBackupCount.Location = New System.Drawing.Point(397, 167)
        Me.nudLogFileBackupCount.Maximum = New Decimal(New Integer() {20, 0, 0, 0})
        Me.nudLogFileBackupCount.Name = "nudLogFileBackupCount"
        Me.nudLogFileBackupCount.Size = New System.Drawing.Size(45, 25)
        Me.nudLogFileBackupCount.TabIndex = 35
        Me.nudLogFileBackupCount.Value = New Decimal(New Integer() {10, 0, 0, 0})
        '
        'lblELSrcPath
        '
        Me.lblELSrcPath.AutoSize = True
        Me.lblELSrcPath.Location = New System.Drawing.Point(32, 204)
        Me.lblELSrcPath.Name = "lblELSrcPath"
        Me.lblELSrcPath.Size = New System.Drawing.Size(112, 15)
        Me.lblELSrcPath.TabIndex = 110
        Me.lblELSrcPath.Text = "ＥＬ原始檔目錄"
        '
        'txtELSrcPath
        '
        Me.txtELSrcPath.Location = New System.Drawing.Point(150, 198)
        Me.txtELSrcPath.Name = "txtELSrcPath"
        Me.txtELSrcPath.Size = New System.Drawing.Size(400, 25)
        Me.txtELSrcPath.TabIndex = 40
        '
        'btnELSrcPath
        '
        Me.btnELSrcPath.Location = New System.Drawing.Point(552, 200)
        Me.btnELSrcPath.Name = "btnELSrcPath"
        Me.btnELSrcPath.Size = New System.Drawing.Size(28, 23)
        Me.btnELSrcPath.TabIndex = 41
        Me.btnELSrcPath.Text = "…"
        Me.btnELSrcPath.UseVisualStyleBackColor = True
        '
        'lblELTagPath
        '
        Me.lblELTagPath.AutoSize = True
        Me.lblELTagPath.Location = New System.Drawing.Point(2, 235)
        Me.lblELTagPath.Name = "lblELTagPath"
        Me.lblELTagPath.Size = New System.Drawing.Size(142, 15)
        Me.lblELTagPath.TabIndex = 113
        Me.lblELTagPath.Text = "ＥＬ轉碼後存放目錄"
        '
        'txtELTagPath
        '
        Me.txtELTagPath.Location = New System.Drawing.Point(150, 229)
        Me.txtELTagPath.Name = "txtELTagPath"
        Me.txtELTagPath.Size = New System.Drawing.Size(400, 25)
        Me.txtELTagPath.TabIndex = 45
        '
        'btnELTagPath
        '
        Me.btnELTagPath.Location = New System.Drawing.Point(552, 231)
        Me.btnELTagPath.Name = "btnELTagPath"
        Me.btnELTagPath.Size = New System.Drawing.Size(28, 23)
        Me.btnELTagPath.TabIndex = 46
        Me.btnELTagPath.Text = "…"
        Me.btnELTagPath.UseVisualStyleBackColor = True
        '
        'lblELLifeCycle
        '
        Me.lblELLifeCycle.AutoSize = True
        Me.lblELLifeCycle.Location = New System.Drawing.Point(17, 263)
        Me.lblELLifeCycle.Name = "lblELLifeCycle"
        Me.lblELLifeCycle.Size = New System.Drawing.Size(127, 15)
        Me.lblELLifeCycle.TabIndex = 116
        Me.lblELLifeCycle.Text = "ＥＬ資料保留週期"
        '
        'txtELLifeCycle
        '
        Me.txtELLifeCycle.Location = New System.Drawing.Point(150, 260)
        Me.txtELLifeCycle.Name = "txtELLifeCycle"
        Me.txtELLifeCycle.Size = New System.Drawing.Size(84, 25)
        Me.txtELLifeCycle.TabIndex = 50
        '
        'cmbELLifeCycleUnit
        '
        Me.cmbELLifeCycleUnit.FormattingEnabled = True
        Me.cmbELLifeCycleUnit.Location = New System.Drawing.Point(240, 260)
        Me.cmbELLifeCycleUnit.Name = "cmbELLifeCycleUnit"
        Me.cmbELLifeCycleUnit.Size = New System.Drawing.Size(59, 23)
        Me.cmbELLifeCycleUnit.TabIndex = 56
        '
        'TabControl1
        '
        Me.TabControl1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TabControl1.Controls.Add(Me.tabCommon)
        Me.TabControl1.Controls.Add(Me.tabELoan)
        Me.TabControl1.Controls.Add(Me.tabJcicTchAdm)
        Me.TabControl1.Controls.Add(Me.tabCRM)
        Me.TabControl1.Controls.Add(Me.tabScheduleList)
        Me.TabControl1.Controls.Add(Me.tabOverseasGateway)
        Me.TabControl1.Location = New System.Drawing.Point(0, 4)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(615, 671)
        Me.TabControl1.TabIndex = 100
        '
        'frmConfig
        '
        Me.AcceptButton = Me.btnSave
        Me.AutoScaleDimensions = New System.Drawing.SizeF(96.0!, 96.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi
        Me.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.CancelButton = Me.btnExit
        Me.ClientSize = New System.Drawing.Size(620, 705)
        Me.Controls.Add(Me.btnWebSettingActive)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnSave)
        Me.Controls.Add(Me.TabControl1)
        Me.Font = New System.Drawing.Font("新細明體", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "frmConfig"
        Me.Text = "eLoan Gateway Configuration"
        Me.tabOverseasGateway.ResumeLayout(False)
        Me.tabOverseasGateway.PerformLayout()
        CType(Me.nudOverseasQueueSize, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudOverseasProcessorCnt, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tabScheduleList.ResumeLayout(False)
        CType(Me.dgvScheduleList, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tabCRM.ResumeLayout(False)
        Me.tabCRM.PerformLayout()
        Me.tabJcicTchAdm.ResumeLayout(False)
        Me.tabJcicTchAdm.PerformLayout()
        Me.gboxJcic.ResumeLayout(False)
        Me.gboxJcic.PerformLayout()
        CType(Me.nudJcicInterval, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gboxTch.ResumeLayout(False)
        Me.gboxTch.PerformLayout()
        CType(Me.nudTchInterval, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gboxAdm.ResumeLayout(False)
        Me.gboxAdm.PerformLayout()
        CType(Me.nudAdmInterval, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tabELoan.ResumeLayout(False)
        Me.tabELoan.PerformLayout()
        Me.gbRestartServices.ResumeLayout(False)
        Me.gbRestartServices.PerformLayout()
        Me.gbxAPServer.ResumeLayout(False)
        CType(Me.dgvAPServerList, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudAttach_Interval, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tabCommon.ResumeLayout(False)
        Me.tabCommon.PerformLayout()
        Me.gboxRemoteServerList.ResumeLayout(False)
        CType(Me.dgvRemoteServerList, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gboxEmail.ResumeLayout(False)
        Me.gboxEmail.PerformLayout()
        CType(Me.nudLogFileSize, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudLogFileBackupCount, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabControl1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents btnWebSettingActive As System.Windows.Forms.Button
    Friend WithEvents tabOverseasGateway As TabPage
    Friend WithEvents chkOverseasGatewayEnabled As CheckBox
    Friend WithEvents txtOverseasClientPort As TextBox
    Friend WithEvents txtOverseasListenerPort As TextBox
    Friend WithEvents txtOverseasConn As TextBox
    Friend WithEvents lblOverseasClientPort As Label
    Friend WithEvents lblOverseasListenerPort As Label
    Friend WithEvents nudOverseasProcessorCnt As NumericUpDown
    Friend WithEvents lblProcessorCnt As Label
    Friend WithEvents nudOverseasQueueSize As NumericUpDown
    Friend WithEvents lblQueueSize As Label
    Friend WithEvents btnOverseasConn As Button
    Friend WithEvents lblOverseasConn As Label
    Friend WithEvents tabScheduleList As TabPage
    Friend WithEvents dgvScheduleList As DataGridView
    Friend WithEvents colID As DataGridViewTextBoxColumn
    Friend WithEvents colDATA As DataGridViewTextBoxColumn
    Friend WithEvents colCaption As DataGridViewTextBoxColumn
    Friend WithEvents colStartTime As DataGridViewTextBoxColumn
    Friend WithEvents colEndTime As DataGridViewTextBoxColumn
    Friend WithEvents colDURATION As DataGridViewTextBoxColumn
    Friend WithEvents colDURATIONUNIT As DataGridViewTextBoxColumn
    Friend WithEvents colSTATUS As DataGridViewTextBoxColumn
    Friend WithEvents btnEditSchedule As Button
    Friend WithEvents btnRemoveSchedule As Button
    Friend WithEvents btnAddSchedule As Button
    Friend WithEvents tabCRM As TabPage
    Friend WithEvents txtCrmFiles As TextBox
    Friend WithEvents txtCrmFtpPassword As TextBox
    Friend WithEvents txtCrmFtpUser As TextBox
    Friend WithEvents txtCrmFtpAddress As TextBox
    Friend WithEvents lblCrmFiles As Label
    Friend WithEvents lblCrmFtpPassword As Label
    Friend WithEvents lblCrmFtpUser As Label
    Friend WithEvents lblCrmFtpAddress As Label
    Friend WithEvents tabJcicTchAdm As TabPage
    Friend WithEvents btnConnStr_JcicTch As Button
    Friend WithEvents txtConnStr_JcicTch As TextBox
    Friend WithEvents txtAPI_EDOCService As TextBox
    Friend WithEvents txtAPI_JcicTch As TextBox
    Friend WithEvents lblConnStr_JcicTch As Label
    Friend WithEvents chkOutSourceLog As CheckBox
    Friend WithEvents chkAdmEnable As CheckBox
    Friend WithEvents lblAPI_EDOCService As Label
    Friend WithEvents gboxAdm As GroupBox
    Friend WithEvents lblAdmIntervalUnit As Label
    Friend WithEvents lblAdmTables As Label
    Friend WithEvents lblAdmInterval As Label
    Friend WithEvents txtAdmTables As TextBox
    Friend WithEvents nudAdmInterval As NumericUpDown
    Friend WithEvents chkTchEnable As CheckBox
    Friend WithEvents gboxTch As GroupBox
    Friend WithEvents lblTchIntervalUnit As Label
    Friend WithEvents lblTchTables As Label
    Friend WithEvents lblTchInterval As Label
    Friend WithEvents txtTchTables As TextBox
    Friend WithEvents nudTchInterval As NumericUpDown
    Friend WithEvents chkJcicEnable As CheckBox
    Friend WithEvents gboxJcic As GroupBox
    Friend WithEvents lblJcicIntervalUnit As Label
    Friend WithEvents lblJcicInterval As Label
    Friend WithEvents nudJcicInterval As NumericUpDown
    Friend WithEvents txtJcicTables As TextBox
    Friend WithEvents lblJcicTables As Label
    Friend WithEvents lblAPI_JcicTch As Label
    Friend WithEvents tabELoan As TabPage
    Friend WithEvents cmbAttachFileMode As ComboBox
    Friend WithEvents lblAttachFileMode As Label
    Friend WithEvents btnConnStr_CL As Button
    Friend WithEvents txtConnStr_CL As TextBox
    Friend WithEvents txtAPI_ScoringService As TextBox
    Friend WithEvents txtAttachFilePath As TextBox
    Friend WithEvents txtUpLoadUser As TextBox
    Friend WithEvents txtAdm_UpLoadFilePath As TextBox
    Friend WithEvents txtUpLoadFilePath As TextBox
    Friend WithEvents txtConnStr_Security As TextBox
    Friend WithEvents txtConnStr_Loan_History As TextBox
    Friend WithEvents txtConnStr_Loan As TextBox
    Friend WithEvents lblConnStr_CL As Label
    Friend WithEvents lblAPI_ScoringService As Label
    Friend WithEvents lblAttach_Interval_Unit As Label
    Friend WithEvents lblAttachFilePath As Label
    Friend WithEvents nudAttach_Interval As NumericUpDown
    Friend WithEvents lblAttach_Interval As Label
    Friend WithEvents txtUpLoadPassword As TextBox
    Friend WithEvents lblUpLoadPassword As Label
    Friend WithEvents lblUpLoadUser As Label
    Friend WithEvents lblAdm_UpLoadFilePath As Label
    Friend WithEvents lblUpLoadFilePath As Label
    Friend WithEvents gbxAPServer As GroupBox
    Friend WithEvents dgvAPServerList As DataGridView
    Friend WithEvents btnConnStr_Security As Button
    Friend WithEvents lblConnStr_Security As Label
    Friend WithEvents btnConnStr_Loan_History As Button
    Friend WithEvents lblConnStr_Loan_History As Label
    Friend WithEvents btnConnStr_Loan As Button
    Friend WithEvents lblConnStr_Loan As Label
    Friend WithEvents gbRestartServices As GroupBox
    Friend WithEvents txtRestartTime As TextBox
    Friend WithEvents chkRestartOnTheHour As CheckBox
    Friend WithEvents txtRestartServicesName As TextBox
    Friend WithEvents lblRestartServicesName As Label
    Friend WithEvents tabCommon As TabPage
    Friend WithEvents cmbELLifeCycleUnit As ComboBox
    Friend WithEvents txtELLifeCycle As TextBox
    Friend WithEvents txtELTagPath As TextBox
    Friend WithEvents txtELSrcPath As TextBox
    Friend WithEvents txtDBConnString As TextBox
    Friend WithEvents txtLocalServerIP As TextBox
    Friend WithEvents txtLogPath As TextBox
    Friend WithEvents txtTmpOutputPath As TextBox
    Friend WithEvents txtTmpInputPath As TextBox
    Friend WithEvents lblELLifeCycle As Label
    Friend WithEvents btnELTagPath As Button
    Friend WithEvents lblELTagPath As Label
    Friend WithEvents btnELSrcPath As Button
    Friend WithEvents lblELSrcPath As Label
    Friend WithEvents nudLogFileBackupCount As NumericUpDown
    Friend WithEvents lblLogFileBackupCount As Label
    Friend WithEvents lblMB As Label
    Friend WithEvents nudLogFileSize As NumericUpDown
    Friend WithEvents chkMailEnable As CheckBox
    Friend WithEvents lblLogFileSize As Label
    Friend WithEvents btnDBConnString As Button
    Friend WithEvents gboxEmail As GroupBox
    Friend WithEvents chkMailSMTPVerify As CheckBox
    Friend WithEvents txtMailSMTPPwd As TextBox
    Friend WithEvents lblMailSMTPPwd As Label
    Friend WithEvents txtMailSMTPUid As TextBox
    Friend WithEvents lblMailSMTPUid As Label
    Friend WithEvents txtMailTo As TextBox
    Friend WithEvents lblMailTo As Label
    Friend WithEvents txtMailSMTP As TextBox
    Friend WithEvents lblMailCC As Label
    Friend WithEvents txtMailCC As TextBox
    Friend WithEvents lblMailSMTP As Label
    Friend WithEvents txtMailQuantity As TextBox
    Friend WithEvents lblMailQuantity As Label
    Friend WithEvents lblDBConnString As Label
    Friend WithEvents btnLogPath As Button
    Friend WithEvents lblLocalServerIP As Label
    Friend WithEvents gboxRemoteServerList As GroupBox
    Friend WithEvents dgvRemoteServerList As DataGridView
    Friend WithEvents lblLogPath As Label
    Friend WithEvents lblTmpOutputPath As Label
    Friend WithEvents btnTmpOutputPath As Button
    Friend WithEvents btnTmpInputPath As Button
    Friend WithEvents lblTmpInputPath As Label
    Friend WithEvents TabControl1 As TabControl
End Class
