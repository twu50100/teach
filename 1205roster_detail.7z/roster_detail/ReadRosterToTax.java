package tool;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;


public class ReadRosterToTax {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		try {
			//讀取欲修改的資料
			FileReader fr1;
			fr1 = new FileReader("d:/test/tax/tax.csv");
			BufferedReader br1 = new BufferedReader(fr1);
			
			FileWriter fw1 = new FileWriter("d:/test/tax/1061205fw1.txt");
			
			FileWriter fw2 = new FileWriter("d:/test/tax/1061205fw2.txt");
			
			FileWriter fw3 = new FileWriter("d:/test/tax/1061205fw3.txt");
			String str1 = null;
			//暫存資料
			String [][] updateData = new String[5000][100]; 
			int c1 =0;
			while ((str1 = br1.readLine()) != null) {
				updateData[c1] = str1.split("\\,");// 分割逗號
				c1++;
			}
			

			for(int i =0;i<c1;i++){
				String n = String.format("%03d", i+1);
				String p_id = updateData[i][1];
				String e_id = updateData[i][2];
				String sql1 = "INSERT INTO TBEXP_TAX_DETAIL (ID, WITHHOLD_ID, EMP_ID, TAX_ID, TAX_NAME,INCOME_FORM,   " +
						"SOURCE_KIND, PAY_CERT_NO, SUBPOENA_NO, SUBPOENA_DATE, TAXBIZ_CODE, CROSS_INCOME, TAX_RATE, " +
						"WITHHOLDING_TAX, COST_UNIT_CODE, COST_UNIT_NAME, TEX_REMIT, ROSTER_NO,    GROUP_ID, TBEXP_ENTRY_TAX_ID, " +
						"CREATE_USER_ID, CREATE_DATE, VERSION_NO ) VALUES ('201712-00000000S006B1000100000000"+n+"','"+updateData[i][3]+"','"+updateData[i][4]+
						"','"+updateData[i][5]+"','"+updateData[i][6]+"','"+updateData[i][7]+"','G2','"+updateData[i][9]+"','"+updateData[i][10]+
						"',TO_DATE('"+updateData[i][11]+"','YYYY/MM/DD'),'"+updateData[i][12]+"','"+updateData[i][13]+"','"+updateData[i][14]+"','"+
						updateData[i][15]+"','"+updateData[i][16]+"','"+updateData[i][17]+"','"+updateData[i][18]+"','"+updateData[i][19]+
						"','IMP00000-0000-0000-00020171205000"+n+"', '','A227210094', TO_DATE('2017-12-05','YYYY-MM-DD'),'1' );";

				String sql2 ="Insert into TBEXP_PROOF_TAX_DETAIL_R (TBEXP_TAX_DETAIL_ID,TBEXP_PROOF_ID) " +
						"values ('201712-00000000S006B1000100000000"+n+"','"+p_id+"');";

				String sql3 ="Insert into TBEXP_ENTRY_EXP_GROUP (ID,GROUP_ID,TBEXP_ENTRY_ID) values " +
						"('IMP01205-0000-0000-S006B1000112050"+n+"','IIMP00000-0000-0000-00020171205000"+n+"','"+e_id+"');";

				fw1.write(sql1+"\r\n");
				fw2.write(sql2+"\r\n");
				fw3.write(sql3+"\r\n");

			}
			
			 fw1.flush();
			 fw1.close();
			 
		
			 fw2.flush();
			 fw2.close();
			 
			 fw3.flush();
			 fw3.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
