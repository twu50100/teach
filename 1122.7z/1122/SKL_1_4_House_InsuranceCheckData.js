﻿var G_PAGE_SIZE = 10;
var G_LOAD_Waitting_Msg;
var G_List = {};
var pls = { "ItemText": "請選擇", "ItemValue": "" };
var G_data = [pls];
var G_Search = {};
var G_CreateBranchNo = new Array();
//var G_AppraiseGroup = new Array();
//var G_AppraiseType = new Array();
//var G_BussinessType = new Array();
//var G_FlowBranchNo = new Array();
var G_CaseStatus = new Array();
var G_ValueCompare = new Array();
var G_Var = {};

var Init = function () {

    var AjaxInputObj =
      {
          url: "SKL_8_3_QryAccess_Book/Init",
          oMethod: genData,
      };

    //call ajax
    docCore.ajax(AjaxInputObj, true, true, G_LOAD_Waitting_Msg);
    // 添加匯出excel add by jessie 2019/3/5
    $("#exExcel").click(function () {
        var jsonObj = $.valToJson("QryAccessBox");
        var ajaxDL = {
            url: "SKL_8_3_QryAccess_Book/Export_Excel",
            data: jsonObj
        };
        docCore.ajaxDownload(ajaxDL);
    })
}


// 格式化千分位
var formatNumber = function (number, currency) {
    if (number < 1) {
        return number;
    }
    var arr = number.split(".");
    var re = /(\d{1,3})(?=(\d{3})+$)/g;
    return currency + arr[0].replace(re, "$1,") + (arr.length == 2 ? "." + arr[1] : "");
}

var genData = function (Data) {
    console.log(Data);
    G_Var.IsHeadOffice = Data.data.IsHeadOffice;
    G_List.House_LoanWay = G_Convert.list("House_LoanWay");
    G_List.House_LoanWay.unshift(pls);
    Data.data["CreateBranchNo"].unshift({ "BranchName": "請選擇", "BranchNo": "" });
    //Data.data["BussinessType"].unshift({ "ItemText": "請選擇", "ItemValue": "" });
    Data.data["FlowBranchNo"].unshift({ "BranchName": "請選擇", "BranchNo": "" });
    G_CreateBranchNo = Data.data["CreateBranchNo"];
    //G_BussinessType = Data.data["BussinessType"];
    G_FlowBranchNo = Data.data["FlowBranchNo"];
    G_CaseStatus = G_Convert.list("Common_CaseStatus");
    G_ValueCompare = G_Convert.list("Imm_ValueCompare");
    G_CaseStatus.unshift(pls);
    G_ValueCompare.unshift(pls);

    QryAccessBox(Data.data["CreateBranchNo"], G_data, Data.data["FlowBranchNo"])
}

//var QryAccessBox = function (CreateBranchNo, BussinessType, FlowBranchNo) {
var QryAccessBox = function (CreateBranchNo, FlowBranchNo) {
    $("#QryAccessBox").SexyBox({
        boxCtrl: [{
            ID: "QryAccess",
            HeadForm: "QryAccessForm",
            Head: [
                {
                    Row: "caption",
                    Ctrl: [
                        { Type: "Label", Data: "查詢條件" }
                    ]
                }
            ],
            BodyForm: "QryAccessForm",
            Body: [
                 {
                     Row: "2col",
                     ColumnClass: ["align_right", ""],
                     Ctrl: [
                         "資料日期",
                         [
                             { Type: "datepicker", Name: "p_CreateDate_S", ID: "txtp_CreateDate_S" },
                             "至",
                             { Type: "datepicker", Name: "p_CreateDate_E", ID: "txtp_CreateDate_E" },
                         ]
                     ]
                 },
               
                {
                    Row: "2col",
                    ColumnClass: ["align_right", ""],
                    Ctrl: ["案件編號", { Type: "text", Name: "p_CaseNo", ID: "txtp_CaseNo" }]
                },

                {
                    Row: "2col",
                    ColumnClass: ["align_right", ""],
                    Ctrl: ["介紹人員工編號", { Type: "text", Name: "p_CreateEmpNo", ID: "txtp_CreateEmpNo" }]
                },
            ],
            Foot: [
                {
                    Row: "",
                    RowClass: "align_center",
                    Ctrl: [{ Type: "a", Data: "查詢", Class: "button add", Event: Data_Search }]
                }
            ],
            Data: []
        }]
    });
};

var Data_Search = function () {
    var jsonObj = $.valToJson("QryAccessBox");
    G_Search = jsonObj;
    jsonObj["p_Row_S"] = "1";
    jsonObj["p_Row_E"] = "10";

    var AjaxInputObj =
    {
        url: "SKL_8_3_QryAccess_Book/DataQry",
        data: jsonObj,
        oMethod: function (res) {
            QryAccessTable(res);
        }
    };
    //call ajax
    docCore.ajax(AjaxInputObj, true, true, G_LOAD_Waitting_Msg);
};

var QryAccessTable = function (Arg) {

    var tableArg = {
        theadValue: [
            [
                { Text: "", Style: { "display": "none" } },
                { Text: "案件編號" },
                { Text: "授信方式" },
                { Text: "身分類別" },
                { Text: "統編/身分證字號" },
                { Text: "授信戶名稱" },
                { Text: "進件日期" },
                { Text: "進件單位" },
                { Text: "進件者" },
                { Text: "目前經辦(准駁)人員" },
                { Text: "案件狀態" },
                { Text: "案件審理狀況" },
                { Text: "停留時間" },
                { Text: "擬貸金額" }
            ]
        ],
        tbodyValue: {
            Value: [
                {
                    je: function (col) {
                        var td = $("<td></td>");
                        td.SexyCtrl({ Type: "hidden", ID: "LoanKey", Name: "LoanKey" }, col["LoanKey"]);
                        td.SexyCtrl({ Type: "hidden", ID: "FlowType", Name: "FlowType" }, col["FlowType"]);
                        td.SexyCtrl({ Type: "hidden", ID: "LoanCloseStatus", Name: "LoanCloseStatus" }, col["LoanCloseStatus"]);
                        td.SexyCtrl({ Type: "hidden", ID: "VersionFlowType", Name: "VersionFlowType" }, col["VersionFlowType"]);
                        td.SexyCtrl({ Type: "hidden", ID: "FlowStatus", Name: "FlowStatus" }, col["FlowStatus"]);
                        td.SexyCtrl({ Type: "hidden", ID: "CreateRoleNo", Name: "CreateRoleNo" }, col["CreateRoleNo"]);
                        td.SexyCtrl({ Type: "hidden", ID: "CreateEmpNo", Name: "CreateEmpNo" }, col["CreateEmpNo"]);
                        td.SexyCtrl({ Type: "hidden", ID: "CreateBranchNo", Name: "CreateBranchNo" }, col["CreateBranchNo"]);
                        td.SexyCtrl({ Type: "hidden", ID: "CreateDate", Name: "CreateDate" }, col["CreateDate"]);
                        td.SexyCtrl({ Type: "hidden", ID: "BusType", Name: "BusType" }, col["BusType"]);
                        td.SexyCtrl({ Type: "hidden", ID: "LoanWay", Name: "LoanWay" }, col["LoanWay"]);
                        td.SexyCtrl({ Type: "hidden", ID: "CaseNo", Name: "CaseNo" }, col["CaseNO"]);
                        td.SexyCtrl({ Type: "hidden", ID: "CustID", Name: "CustID" }, col["CustId"]);
                        td.SexyCtrl({ Type: "hidden", ID: "AgentEmpNo", Name: "AgentEmpNo" }, col["AgentEmpNo"]);
                        td.SexyCtrl({ Type: "hidden", ID: "AgentEmpName", Name: "AgentEmpName" }, col["AgentEmpName"]);
                        return td;
                    }
                },
                {
                    je: function (col) {
                        var td = $("<td></td>");
                        td.SexyCtrl({ Type: "a", Style: "cursor:pointer" }, col["CaseNO"], Case_Appraise);
                        return td
                    }
                },
                {
                    t: function (col) {
                        return G_Convert.list("House_LoanWay", col["LoanWay"]);
                    }
                },
                {
                    t: function (col) {
                        return G_Convert.list("Common_CustType", col["CustType"]);
                    }
                },
                "CustId",
                "CustName",
                "NewDate",
                {
                    t: function (col) {
                        return col["OriginBranchNo"] + col["CreateBranchName"];
                    }
                },
                {
                    t: function (col) {
                        return col["CreateEmpNo"] + col["CreateEmpName"];
                    }
                },
                {
                    h: function (col) {

                        if (col["AgentEmpNo"] != "") {

                            return col["FlowEmpNo"] + col["FlowEmpName"] + "<BR/>" + "(代理人：" + col["AgentEmpNo"] + col["AgentEmpName"] + ")";

                        } else {
                            return col["FlowEmpNo"] + col["FlowEmpName"];
                        }
                    }
                },
                "FlowPreviousDecisionDesc",
                "CaseStatus",
                {
                    t: function (col) {
                        return col["FlowDuration"] + "天"
                    }
                },
                {
                    t: function (col) {
                        if (col["ApplyAmount"] != null && col["ApplyAmount"] + "" != "") {
                            var a = (col["ApplyAmount"]) / 1000;
                            //var Amount = $.setThousandsSymbolToNumber(a + "");
                            if (a > 0)
                                return formatNumber(col["NewAmt"], '') + "仟元";
                        }
                    }
                }
            ],
            Style: [{ "display": "none" }]
        },
        Data: Arg.data.QryAccess,
        NoData: true,
        //只取部份資料的分頁方式
        PageSetting: {
            MaxPageSize: Arg.data.QryAccess.length > 0 ? Arg.data.QryAccess[0].TotalNum : 0,
            PageSize: G_PAGE_SIZE,
            Event: genPageChg,
            ShowPageCtrl: true
        }
    };
    //顯示 匯出按鈕 add by jessie 2019/3/5
    if (G_Var.IsHeadOffice) {
        $("#exExcel").parent().removeClass("hide")
    }
    $("#scDataView").find("input").off('click');
    $("#scDataView").empty();
    $("#scDataView").SexyTable(tableArg);
};

//只取部份資料的分頁方式 才需要寫分頁切換Event
var genPageChg = function (pageIdx) {
    console.log(pageIdx);
    IndexSearch(pageIdx);
};

var IndexSearch = function (pageIdx) {
    var jsonObj = G_Search;
    jsonObj["p_Row_S"] = (pageIdx * G_PAGE_SIZE) - (G_PAGE_SIZE - 1);
    jsonObj["p_Row_E"] = pageIdx * G_PAGE_SIZE;

    var AjaxInputObj =
    {
        url: "SKL_8_3_QryAccess_Book/DataQry",
        data: jsonObj,
        oMethod: function (res) {
            QryAccessTable(res);
        },
    };
    //call ajax
    docCore.ajax(AjaxInputObj, true, true, G_LOAD_Waitting_Msg);
}

var Case_Appraise = function () {
    var ptElm = $.valToJson($(this).closest("tr"));
    console.log(ptElm, $(this));

    var AjaxInputObj =
    {
        url: "SKL_8_3_QryAccess_Book/Insert_Session",
        data: ptElm,
        oMethod: function (res) {
            parent.genTreeAndMarkData("SKL_8_3_QryAccess_Book", res.data.Tree, res.data.TreeDefaultPage);
        },
    };
    //call ajax
    docCore.ajax(AjaxInputObj, true, true, G_LOAD_Waitting_Msg);
};



$(document).ready(function () {
    Init();
});