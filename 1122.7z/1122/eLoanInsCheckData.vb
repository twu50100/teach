﻿Imports System.Windows.Forms
Imports System.Xml
Imports System.Data.SqlClient
Imports eLoan_Gateway
Imports eLoan_Gateway.ClassLib
Imports System.Net   'Web
Imports System.IO    'Files
Imports System.Object
Imports System.Text
Imports Microsoft.Practices.EnterpriseLibrary.Data
Imports System.Data.Common

Module eLoanInsCheckData
    Private g_objSettings As ClassLib.Settings = Nothing
    Private g_strLogPath As String = Nothing
    Private g_writeLog As eLoan_Gateway.ClassLib.WriteLog
    Private g_strDBConnString As String = Nothing
    Private g_strDBConnEloanString As String = Nothing
    Private g_moDB_Loan As Database = Nothing
    Private g_strPutFilePath As String = Nothing
    Private g_moDB_CSS As Database = Nothing

    Sub Main()
        'eLoan資料庫連線字串
        g_objSettings = New ClassLib.Settings(Application.StartupPath)

        Try
            g_strLogPath = CStr(g_objSettings.ReadSetting("LogPath")).TrimEnd("\") & "\"
            g_strDBConnString = CStr(g_objSettings.ReadSetting("DBConnString_CSS"))
            g_strDBConnEloanString = CStr(g_objSettings.ReadSetting("DBConnString_LOAN"))
            g_writeLog = New eLoan_Gateway.ClassLib.WriteLog(g_strLogPath)
            g_moDB_CSS = DBUtil.GetDB(g_strDBConnString)
            g_moDB_Loan = DBUtil.GetDB(g_strDBConnEloanString)

            SetHouse_InsCheckData()
            FtpUpload()



        Catch ex As Exception
            If g_writeLog IsNot Nothing Then
                g_writeLog.WriteErrorLog("eLoanInsCheckData:Failed to Load Settings, " & ex.Message)
            End If
            Exit Sub
        End Try
    End Sub

    ''' <summary>
    ''' ENTERPRISE.IDX -> LNFJP.IDX
    ''' </summary>
    Private Sub SetHouse_InsCheckData()
        Dim moDBCmd As DbCommand = Nothing
        Dim dt As New DataTable
        Dim strSQL As String = ""

        strSQL = "Select '""' + [DataDate] + '""|""'+ [LoanKey] +'""|""'+ [CustNo] +'""|""'+ [CustName] +'""|""'+ [CaseNo] +'""|""'+ [ApproveDate] +'""|""'+ [CheckAmount] +'""|""'+ [LMSLLD] +'""|""'+ [LMSFLA] +'""|""'+ [IncomeSalary] +'""|""'+ [IncomeWork] +'""|""'+ [IncomeBusiness] +'""|""'+ [IncomeRant] +'""|""'+ [IncomeInterest] +'""|""'+ [IncomeOther] +'""|""'+ [IncomeYear] +'""|""'+ [Estimate] +'""|""'+ [AngentEmpName] +'""|""'+ [AngentEmpNo] +'""|""'+ [AngentUnitNo] +'""|""'+ [LastUpdateDate]  +'""' * From [House_InsCheckData] "
        moDBCmd = g_moDB_CSS.GetSqlStringCommand(strSQL)
        Dim ds As DataSet = g_moDB_CSS.ExecuteDataSet(moDBCmd)
        ''匯出的路徑跟檔案
        Dim sw As StreamWriter = New StreamWriter(g_strPutFilePath + "LOANLMSP.csv")
        If ds.Tables.Count > 0 Then
            dt = ds.Tables(0)
            For i As Integer = 0 To dt.Rows.Count - 1
                sw.WriteLine(dt.Rows(i)("House_InsCheckData"))
            Next
        End If

        sw.Close()
        moDBCmd.Dispose()

    End Sub

    Private Sub FtpUpload()
        Dim FtpFilePath As String = CStr(g_objSettings.ReadSetting("IFRS9FtpUploadIP"))
        Dim ftpID As String = CStr(g_objSettings.ReadSetting("IFRS9FtpUploadUser"))
        Dim ftpPW As String = CStr(g_objSettings.ReadSetting("IFRS9FtpUploadPwd"))
        Dim wc As WebClient = New WebClient()
        wc.Credentials = New NetworkCredential(ftpID, ftpPW)
        Dim FileData As Byte()
        Dim di As DirectoryInfo = New DirectoryInfo(g_strPutFilePath)
        For Each fi In di.GetFiles()
            FileData = wc.UploadFile(FtpFilePath + fi.Name, g_strPutFilePath + fi.Name)
        Next

        '上傳完寫入記錄檔
        Dim moDBCmd As DbCommand = Nothing
        Dim strSQL As String = ""
        Dim LastDay As DateTime = New DateTime(DateTime.Now.Year, DateTime.Now.Month, 1).AddDays(-1)
        Dim ScoreDate As String = Year(LastDay).ToString() + Month(LastDay).ToString().PadLeft(2, "0")

        strSQL = " insert into Etl_IfrsUploadMain (UploadDate,Status) values ('" & ScoreDate & "',1)"
        'moDBCmd = g_moDB_CSS.GetSqlStringCommand(strSQL)
        'g_moDB_CSS.ExecuteNonQuery(moDBCmd)

    End Sub
    Private Sub Backup()
        Dim BakPath As String = CStr(g_objSettings.ReadSetting("IFRS9BakFilePath"))
        Dim BakPrefix As String = DateTime.Now.ToString("yyyyMMdd") & "_"

        Dim di As DirectoryInfo = New DirectoryInfo(g_strPutFilePath)
        For Each fi In di.GetFiles()
            Try
                fi.MoveTo(BakPath & BakPrefix & fi.Name)
            Catch ex As Exception
                ' ignore exceptions
            End Try
        Next
    End Sub

    Private Function getUploadMain() As Boolean
        Dim moDBCmd As DbCommand = Nothing
        Dim dt As New DataTable
        Dim strSQL As String = ""
        Dim LastDay As DateTime = New DateTime(DateTime.Now.Year, DateTime.Now.Month, 1).AddDays(-1)
        Dim ScoreDate As String = Year(LastDay).ToString() + Month(LastDay).ToString().PadLeft(2, "0")
        Dim boo As Boolean = False

        strSQL = " select A.ScoreDate,B.UploadDate from ScCal_B_Main A left join Etl_IfrsUploadMain B on A.ScoreDate = B.UploadDate and A.IsLatest = 1 where A.ScoreDate = '" & ScoreDate & "' "
        moDBCmd = g_moDB_CSS.GetSqlStringCommand(strSQL)
        Dim ds As DataSet = g_moDB_CSS.ExecuteDataSet(moDBCmd)

        If ds.Tables.Count > 0 Then
            dt = ds.Tables(0)
            '判斷已有上個月評分(ScoreDate已有日期)，UploadDate沒有日期代表要開始產IFRS資料
            If dt.Rows.Count > 0 Then
                If IsDBNull(dt.Rows(0)("UploadDate")) Then
                    boo = True
                End If
            End If
        End If

        Return boo
    End Function
End Module
