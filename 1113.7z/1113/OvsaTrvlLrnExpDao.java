package tw.com.skl.exp.kernel.model6.dao;

import java.util.Calendar;
import java.util.List;

import tw.com.skl.common.model6.dao.BaseDao;
import tw.com.skl.exp.kernel.model6.bo.Department;
import tw.com.skl.exp.kernel.model6.bo.OvsaTrvlLrnExp;
import tw.com.skl.exp.kernel.model6.bo.ApplState.ApplStateCode;

/**
 * 國外研修差旅費用 Dao 介面。
 * 
 * @author Eustace
 * @version 1.0, 2009/3/10
 */
public interface OvsaTrvlLrnExpDao extends BaseDao<OvsaTrvlLrnExp, String> {
    
    /**
     * 依條件查詢國外研修差旅費用
     * <p>UC 1.6.4 研修差旅費用申請記錄表(含國外)</p>
     * <p>排序條件: 依「國外研修差旅費用.費用申請單. 建檔日期」遞增排序</p>
     * @param applStateCode 申請單狀態代碼
     * @param department 成本單位
     * @param userCode 申請人員工代號
     * @param createDateStart 建檔期間起
     * @param createDateEnd 建檔期間迄
     * @param applStateCodes 必須過濾掉的申請單狀態代碼
     * @return
     */
    List<OvsaTrvlLrnExp> findByParams(ApplStateCode applStateCode, 
            Department department, String userCode, 
            Calendar createDateStart, Calendar createDateEnd, ApplStateCode[] applStateCodes);
    
    /**
     * 依申請單號查詢出國外研修差旅費用
     * @param expApplNo 申請單號
     * @return
     */
    OvsaTrvlLrnExp findByExpApplNo(String expApplNo);
    
    /**
     * 依申請單號s查出國外研修差旅費用s
     * @param expApplNoList 申請單單號List
     * @return
     */
    List<OvsaTrvlLrnExp> findByExpApplNo(List<String> expApplNoList);

}
