﻿package tw.com.skl.exp.kernel.model6.bo;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.persistence.UniqueConstraint;
import javax.persistence.Version;

import tw.com.skl.common.model6.bo.SystemDateOperations;
import tw.com.skl.common.model6.bo.impl.BaseBoImpl;
import tw.com.skl.exp.kernel.model6.bo.listener.SystemUserOperations;

/**
 * 功能。
 * 
 * @author Chih-Liang Chang
 * @version 1.0, 2009/2/7
 */
@Entity
@Table(name = "TBEXP_FUNCTION", uniqueConstraints = { @UniqueConstraint(columnNames = "CODE") })
public class Function extends BaseBoImpl implements SystemDateOperations, SystemUserOperations, Comparable<Function> {


	private static final long serialVersionUID = -4561749503941854034L;

	/**
     * 功能代碼 
     */
    public enum FunctionCode {
        // 請依順序排列
        // B
        /** DashboardManagedBean B 1.1 個人首頁 */
        B_1_1("B01.01", "dashboardManagedBean"),
        /** UnprocessedRatifyManagedBean B 1.2 未處理之核定表 */
        B_1_2("B01.02", "unprocessedRatifyManagedBean"),
        /** PaidExpManagedBean B 1.3 已匯款之費用列表 */
        B_1_3("B01.03", "paidExpManagedBean"),
        /** RejectedForManagedBean B 1.4 退件/憑證不足之列表 */
        B_1_4("B01.04", "rejectedForManagedBean"),
        /** WaitingFirstVerifyManagedBean B UC 1.5 待初審之費用列表 */
        B_1_5("B01.05", "waitingFirstVerifyManagedBean"),
        /** RatifyStatusManagedBean B UC 1.6 核定表狀態查詢 */
        B_1_6("B01.06", "ratifyStatusManagedBean"),
        //#RE201400156_各項業務費用核銷進度統計 modify by michael in 2014/05/09 start
        /** pettyCashStatusManagedBean B UC 1.7 週轉金狀態查詢 */
        B_1_7("B01.07", "pettyCashStatusManagedBean"),
        //#RE201400156_各項業務費用核銷進度統計 modify by michael in 2014/05/09 end
        
        //RE201400156-各項業務費用核銷進度統計 CU3178 2014/5/16 START
        /** RatifyCountsManagedBean B UC 1.8 有核定表狀態統計查詢 */
        B_1_8("B01.08", "ratifyCountsManagedBean"),
        //RE201400156-各項業務費用核銷進度統計 CU3178 2014/5/16 END
        
        //RE201601995_內務關鍵績效指標費用作帳錯誤率 EC0416 2016/7/18 start
        B_1_9("B01.09", "kpiDetailManagedBean"),
        //RE201601995_內務關鍵績效指標費用作帳錯誤率 EC0416 2016/7/18 end
        
        //RE201603080_業推(發)_組發_區經理展業費匯款專案　CU3178 2016/10/06 START
        /** RemitQueryInteriorManagedBean B UC 1.10 匯款查詢(內務) */
        B_1_10("B01.10", "remitQueryInteriorManagedBean"),
        /** PaymentQueryManagedBean B UC 1.11 匯款查詢 */
        B_1_11("B01.11", "paymentQueryManagedBean"),
        //RE201603080_業推(發)_組發_區經理展業費匯款專案　CU3178 2016/10/06 END
        
        /** ExpapplBManagedBean B 2.1 費用申請 */
        B_2_1("B02.01", "expapplBManagedBean"),
        /** FirstVerifyManagedBean B 2.2 費用初審 */
        B_2_2("B02.02", "firstVerifyManagedBean"),
        /** SecondVerifyManagedBean B 2.3 費用覆核 */
        B_2_3("B02.03", "secondVerifyManagedBean"),
        /** SendCloseManagedBean B 2.4 費用送結 */
        B_2_4("B02.04", "sendCloseManagedBean"),
        /** GenDailyStmtManagedBean B 2.5 產生日計表 */
        B_2_5("B02.05", "genDailyStmtManagedBean"),
        //RE201503266_所得檢核代扣機制 CU3178 2015/09/08 START
        /** withholdingTax B 2.6 扣繳所得稅 */
        B_2_6("B02.06", "withholdingTaxManagedBean"),
        //RE201503266_所得檢核代扣機制 CU3178 2015/09/08 END
        /** RosterDetailManagedBean B 3.1 名冊建檔 */
        B_3_1("B03.01", "rosterDetailManagedBean"),
        /** RosterDetailInImportManagedBean B 3.2 轉入獎金品名冊 */
        B_3_2("B03.02", "rosterDetailInImportManagedBean"),
        /** RosterDetailInMaintainManagedBean B 3.3 獎金品批次維護 */
        B_3_3("B03.03", "rosterDetailInMaintainManagedBean"),
        /** IncomeUserImportManagedBean B 3.4 所得人資料轉入 */
        B_3_4("B03.04", "incomeUserImportManagedBean"),
        /** InCloseManagedBean B4.1 內結作業 */
        B_4_1("B04.01", "inCloseManagedBean"),
        /** SendRemitManagedBean B4.2 送匯作業 */
        B_4_2("B04.02", "sendRemitManagedBean"),
        /** DailyCloseManagedBean B4.3 日結作業 */
        B_4_3("B04.03", "dailyCloseManagedBean"),
        /** CancelDataExportManagedBean B 5.1 核銷資料轉出 managed bean */
        B_5_1("B05.01", "cancelDataExportManagedBean"),
        /** TurnOverDataExportManagedBean B 5.2 周轉金資料轉出 managed bean */
        B_5_2("B05.02", "turnOverDataExportManagedBean"),
        /** TurnOverDataQueryManagedBean B 5.3 週轉金資料查詢 managed bean */
        B_5_3("B05.03", "turnOverDataQueryManagedBean"),
        /** TurnOverDataMaintainManagedBean B 5.4 週轉金資料維護 managed bean */
        B_5_4("B05.04", "turnOverDataMaintainManagedBean"),
        /** TaxDownloadManagedBean B 6.1 稅檔下載 managed bean */
        B_6_1("B06.01", "taxDownloadManagedBean"),
        /** RatifyImportManagedBean B 7.1.1 轉入核定檔 managed bean */
        B_7_1_1("B07.01.01", "ratifyImportManagedBean"),
        //RE201400156_各項業務費用核銷進度統計 modify by michael in 2014/05/02 start
        /** RatifyExportManagedBean B 7.1.4 轉出核定表明細 managed bean */
        B_7_1_4("B07.01.04", "ratifyExportManagedBean"),
        
        /** RatifyExportManagedBean B 7.1.5 轉出核銷明細 managed bean */
        B_7_1_5("B07.01.05", "subpoenaDetailExportManagedBean"),
        //RE201400156_各項業務費用核銷進度統計 modify by michael in 2014/05/02 end
        /** AccTitleManagedBean B 7.2 會計科目基本設定 managed bean */
        B_7_2("B07.02", "accTitleManagedBean"),
        /** AccPropertyManagedBean B 7.3 會計科目特殊欄位設定 managed bean */
        B_7_3("B07.03", "accPropertyManagedBean"),
        /** DepartmentManagedBean B 7.4 組織資料維護 managed bean */
        B_7_4("B07.04", "departmentManagedBean"),
        /** UserManagedBean B 7.5 在職資料維護 managed bean */
        B_7_5("B07.05", "userManagedBean"),
        /** GroupManagedBean B 7.6 群組暨權限設定 managed bean */
        B_7_6("B07.06", "groupManagedBean"),
        /** ReturnCauseManagedBean B 7.7 退件原因維護 managed bean */
        B_7_7("B07.07", "returnCauseManagedBean"),
        /** ClosingDateManagedBean B 7.8 關帳/結帳日期維護 */
        B_7_8("B07.08", "closingDateManagedBean"),
        /** CaseWCtrlManagedBean B 7.9 W 件申請控管 managed bean */
        B_7_9("B07.09", "caseWCtrlManagedBean"),
        /** AccruedExpCtrlManagedBean B 7.10 部門應付費用提列控管 managed bean */
        B_7_10("B07.10", "accruedExpCtrlManagedBean"),
        /** VatCtrlManagedBean B 7.11 進項稅扣抵控管 managed bean */
        B_7_11("B07.11", "vatCtrlManagedBean"),
        /** CaReferenceManagedBean B 7.12 成本代號維護 managed bean */
        B_7_12("B07.12", "caReferenceManagedBean"),
        /** CaReferenceManagedBean B7.13更新轉入帳務成本單位(更新範圍為「外部系統帳務」) managed bean */
        B_7_13("B07.13", "importCostUnitManagedBean"),
        /** ImportUserPositionManagedBean B7.14更新人資職位代號 managed bean */
        B_7_14("B07.14", "importUserPositionManagedBean"),
        /** ImportUserInWorkManagedBean B7.15 更新在職資料 managed bean */
        B_7_15("B07.15", "importUserInWorkManagedBean"),
        /** ImportInvoiceCodeManagedBean B7.16字軌維護 managed bean */
        B_7_16("B07.16", "importInvoiceCodeManagedBean"),
        /** SetExpYearsManagedBean B7.17設定費用年月 managed bean */
        B_7_17("B07.17", "setExpYearsManagedBean"),        
        /**RE201201260_二代健保 cm9539 B7.18補充健保費格式代號維護 2013/01/10 start*/
        /** HealthInsIncomeFormMaintain B7.18補充健保費格式代號維護*/
        B_7_18("B07.18","healthInsIncomeFormMaintain"),
        /**RE201201260_二代健保 cm9539 B7.18補充健保費格式代號維護 2013/01/10 end*/
        /**RE201201260_二代健保 cm9539 2013/03/26 start*/
        /** healthInsData B7.19匯出健保補充保費明細申報檔*/
        B_7_19("B07.19","healthInsData"),
        /**RE201201260_二代健保 cm9539 2013/03/26 end*/
        /**RE201201260_列印補充保費扣費證明 2013/10/28 start*/
        /** PrintHealPremiumIncomeManagedBean B7.20 列印扣繳健保補充保費 */
        B_7_20("B07.07.20", "printHealPremiumIncomeManagedBean"),
        /**RE201201260_列印補充保費扣費證明 2013/10/28  end*/
        
        //RE201504772_年度組織控管 CU3178 2016/2/25 START	
        /** yearDepartmentManagedBean B7.21 組織資料年度控管 */
        B_7_21("B07.21", "yearDepartmentManagedBean"),
        //RE201504772_年度組織控管 CU3178 2016/2/25 END
        // C

        /** MedicalExpImportManagedBean C 1.1.1轉入醫檢費用核銷申請資料 */
        C_1_1_1("C01.01.01", "medicalExpImportManagedBean"),
        /** MedicalExpConfirmManagedBean C 1.1.2醫檢費用資料確認 */
        C_1_1_2("C01.01.02", "medicalExpConfirmManagedBean"),

        /** TrvlExpImportManagedBean C 1.2.1轉入研修差旅費用申請資料 */
        C_1_2_1("C01.02.01", "trvlExpImportManagedBean"),
        /** TrvlExpConfirmManagedBean C 1.2.2確認研修差旅資料 */
        C_1_2_2("C01.02.02", "trvlExpConfirmManagedBean"),
        /** RegisterFeeImportManagedBean C 1.2.3轉入考試報名費 */
        C_1_2_3("C01.02.03", "registerFeeImportManagedBean"),
        /** RegisterFeeImportMaintainManagedBean C 1.2.4考試報名費維護  */
        C_1_2_4("C01.02.04", "registerFeeImportMaintainManagedBean"),
        /** RegisterExpApplDetailQueryManagedBean C 1.2.5考試報名費核銷結果查詢  */
        C_1_2_5("C01.02.05", "registerExpApplDetailQueryManagedBean"),
        
        /** PhoneFeeImportManagedBean C1.3.1轉入電話費用核銷申請資料 */
        C_1_3_1("C01.03.01", "phoneFeeImportManagedBean"),
        /** PhoneFeeImportMaintainManagedBean C 1.3.2電話費用轉入維護 */
        C_1_3_2("C01.03.02", "phoneFeeImportMaintainManagedBean"),

        /** ImmovExpManagedBean C 1.4.1轉入不動產費用申請資料 */
        C_1_4_1("C01.04.01", "immovExpImportManagedBean"),
        /** ImmovExpManagedBean C 1.4.2不動產費用資料確認 */
        C_1_4_2("C01.04.02", "immovExpManagedBean"),

        /** GeneralExpCreateManagedBean C 1.5.1輸入一般費用核銷申請資料 */
        C_1_5_1("C01.05.01", "generalExpCreateManagedBean"),
        /** RentExpManagedBean C 1.5.2輸入租賃費用核銷申請資料 */
        C_1_5_2("C01.05.02", "rentExpManagedBean"),
        /** PubAffCarExpCreateManagedBean C 1.5.3輸入公務車費用核銷申請資料 */
        C_1_5_3("C01.05.03", "pubAffCarExpCreateManagedBean"),
        //RE201602265_將舊有功能1.5.5移至1.5.4 CU3178 2016/7/7 START
        C_1_5_4("C01.05.04", "intrTrvlLrnHRExpManagedBean"),
        //RE201602265_將舊有功能1.5.5移至1.5.4 CU3178 2016/7/7 END
        /** IntrTrvlLrnExpManagedBean C 1.5.5輸入國內研修差旅費用核銷申請資料 */
        C_1_5_5("C01.05.05", "intrTrvlLrnExpManagedBean"),
        /** OvsaTrvlLrnExpCreateManagedBean C 1.5.6輸入國外研修差旅費用核銷申請資料 */
        C_1_5_6("C01.05.06", "ovsaTrvlLrnExpCreateManagedBean"),
        /** InvestExpCreateManagedBean C 1.5.7輸入調查費用核銷申請資料 */
        C_1_5_7("C01.05.07", "investExpCreateManagedBean"),
        /** InspectExpCreateManagedBean C 1.5.8 輸入業務稽查費用核銷申請資料 */
        C_1_5_8("C01.05.08", "inspectExpCreateManagedBean"),

        /** VendorExpManagedBean C 1.5.9輸入廠商費用核銷申請資料 */
        C_1_5_9("C01.05.09", "vendorExpManagedBean"),
        /** LbrHlthInsurExpCreateManagedBean C 1.5.11輸入勞健保費用核銷申請資料 */
        C_1_5_11("C01.05.11", "lbrHlthInsurExpCreateManagedBean"),
        /** IntrTrvlBizExpManagedBean C 1.5.12國內出差旅費 */
        C_1_5_12("C01.05.12", "intrTrvlBizExpManagedBean"),
        /** SalDepOfficeExpManagedBean C 1.5.13業務部室實報實支辦公費 */
        C_1_5_13("C01.05.13", "salDepOfficeExpManagedBean"),

        /** GeneralExpApplManagedBean C 1.6.1一般費用申請紀錄表 */
        C_1_6_1("C01.06.01", "generalExpApplManagedBean"),
        /** RentExpApplManagedBean C 1.6.2租賃費用申請紀錄表 */
        C_1_6_2("C01.06.02", "rentExpApplManagedBean"),
        /** PubAffCarExpApplManagedBean C 1.6.3公務車費用申請記錄表 */
        C_1_6_3("C01.06.03", "pubAffCarExpApplManagedBean"),
        /** TrvlAndOvsaExpApplManagedBean C1.6.4研修差旅費用申請記錄表(含國外) */
        C_1_6_4("C01.06.04", "trvlAndOvsaExpApplManagedBean"),
        /** VendorExpApplManagedBean C 1.6.5廠商費用申請記錄表 */
        C_1_6_5("C01.06.05", "vendorExpApplManagedBean"),
        /** InvestExpApplManagedBean C1.6.6調查費、業務稽查費用申請記錄表 */
        C_1_6_6("C01.06.06", "investExpApplManagedBean"),
        /** DeliverDaylistGenManagedBean C 1.6.7產生送件日計表 */
        C_1_6_7("C01.06.07", "deliverDaylistGenManagedBean"),
        /** RtnItemApplManagedBean C 1.6.8退件送件表 */
        C_1_6_8("C01.06.08", "rtnItemApplManagedBean"),
        /** DeliverDaylistPrintManagedBean C 1.6.9列印送件日計表 */
        C_1_6_9("C01.06.09", "deliverDaylistPrintManagedBean"),
        /** TrvlExpApplSearchManagedBean C1.6.10出差報告表列印 */
        C_1_6_10("C01.06.10", "trvlExpApplSearchManagedBean"),
        
    	// RE201301959_友購站 modify by michael in 2013/10/07 start
		C_1_7_1("C01.07.01", "importSKMallExpManagedBean"),

		C_1_7_2("C01.07.02", "confirmSKMallExpManagedBean"),
		// RE201301959_友購站 modify by michael in 2013/10/07 end

        /** ExamineInvestExpManagedBean C 2.1.1審查調查、業務稽查費用 */
        C_2_1_1("C02.01.01", "examineInvestExpManagedBean"),
        /** ExamineTravelExpManagedBean C 2.2.1審查國內研修差旅費用(整批) */
        C_2_2_1("C02.02.01", "examineTravelExpManagedBean"),

        /** ExpapplCSignManagedBean C3.1.1簽收費用申請單 */
        C_3_1_1("C03.01.01", "expapplCSignManagedBean"),
        /** MedicalExpApproveManagedBean C3.2.1核銷醫檢費用 */
        C_3_2_1("C03.02.01", "medicalExpApproveManagedBean"),
        /** GovExpApproveManagedBean C3.2.2核銷行政費用 */
        C_3_2_2("C03.02.02", "govExpApproveManagedBean"),
        /** VendorExpApproveManagedBean C3.2.3核銷廠商費用 */
        C_3_2_3("C03.02.03", "vendorExpApproveManagedBean"),
        /** immovExpApproveManagedBean C3.2.x 不動產費用核銷申請資料 */
        C_3_2_x("C03.02.x", "immovExpApproveManagedBean"),
        /** DaylistPrintManagedBean C3.3.1列印日計表 */
        C_3_3_1("C03.03.01", "daylistPrintManagedBean"),

        /** ExpAppCFirstVerifyManagedBean C4.1.1內結 */
        C_4_1_1("C04.01.01", "expAppCFirstVerifyManagedBean"),
        /** remitManagedBean C4.1.2送匯 */
        C_4_1_2("C04.01.02", "remitManagedBean"),
        /** dialyCloseManagedBean C4.1.3日結 */
        C_4_1_3("C04.01.03", "dialyCloseManagedBean"),
        /** FirstVerifyRecoveryManagedBean C4.1.4回覆內結 */
        C_4_1_4("C04.01.04", "firstVerifyRecoveryManagedBean"),

        /** vendorExpMonCloseManagedBean C5.1.1廠商月結 */
        C_5_1_1("C05.01.01", "vendorExpMonCloseManagedBean"),
        /** remitManagedBean C5.1.2廠商費用內結臨付 */
        C_5_1_2("C05.01.02", "remitManagedBean"),
        
        //RE201603080_業推(發)_組發_區經理展業費匯款專案 　CU3178 2016/10/06 START
        /** mergeDISBManagedBean C5.1.3合併DISB */
        C_5_1_3("C05.01.03", "mergeDISBManagedBean"),
        //RE201603080_業推(發)_組發_區經理展業費匯款專案 　CU3178 2016/10/06 END

        /** RemitMoneyManagedBean C7.1.1 匯回款項 */
        C_7_1_1("C07.01.01", "remitMoneyManagedBean"),
        /** EzflyAutoNoManagedBean C7.1.2易飛網自動銷號 */
        C_7_1_2("C07.01.02", "ezflyAutoNoManagedBean"),
        /** LrnCompensateOfficeExpManagedBean C7.1.3研修教材扣抵辦公費 */
        C_7_1_3("C07.01.03", "LrnCompensateOfficeExpManagedBean"),
        /** LrnDeliveryConfirmManagedBean C7.1.4研修教材出貨確認 */
        C_7_1_4("C07.01.04", "LrnDeliveryConfirmManagedBean"),
        /** LrnCompensateOfficeExpFileGenManagedBean C7.1.5研修教材扣抵辦公費分攤檔案 */
        C_7_1_5("C07.01.05", "LrnCompensateOfficeExpFileGenManagedBean"),
        /** RemitMoneySendCloseManagedBean C7.1.6 匯回款項送結 */
        C_7_1_6("C07.01.06", "remitMoneySendCloseManagedBean"),
        /**RE201201260_二代健保 cm9539 2012/11/27 start*/
        /** HealthPremiumWithholdManagedBean C7.1.8 扣繳健保補充保費 */
        C_7_1_8("C07.01.08", "HealthPremiumWithholdManagedBean"),
        /**RE201201260_二代健保 cm9539 2012/11/27 end*/
        
        /**RE201201260_二代健保 cm9539 2012/12/25 C11.7.9 列印扣繳健保補充保費 start*/
        /** HealthPremiumWithholdManagedBean C11.7.9 列印扣繳健保補充保費 */
        C_7_1_9("C07.01.09", "PrintSupHealPremiumManagedBean"),
        /**RE201201260_二代健保 cm9539 2012/12/25 C11.7.9 列印扣繳健保補充保費 end*/

        /** BizCardInfoMaintainManagedBean C8.1.1 商務卡基本資料維護 */
        C_8_1_1("C08.01.01", "bizCardInfoMaintainManagedBean"),

        /** BizCardExpDetailImportManagedBean C8.2.1 商務卡消費明細資料轉入 */
        C_8_2_1("C08.02.01", "bizCardExpDetailImportManagedBean"),
        /** BizCardExpDetailQueryManagedBean C8.2.2 商務卡消費明細查詢 */
        C_8_2_2("C08.02.02", "bizCardExpDetailQueryManagedBean"),
        /** BizCardExpChargeFileGenManagedBean C8.2.3 產生商務卡扣款檔案 */
        C_8_2_3("C08.02.03", "bizCardExpChargeFileGenManagedBean"),

        /** BizCardExpChargeMaintainManagedBean C8.3.1 商務卡扣款帳戶明細表 */
        C_8_3_1("C08.03.01", "bizCardExpChargeMaintainManagedBean"),
        /** medicalExpDetailExportManagedBean C9.1.1 轉出醫檢費核銷明細 */
        C_9_1_1("C09.01.01", "medicalExpDetailExportManagedBean"),
        /** RentExpExportManagedBean C9.2.1租賃資料轉出 */
        C_9_2_1("C09.02.01", "rentExpExportManagedBean"),
        /** outMsgRewardCreateManagedBean C9.3.1發文獎勵費資料轉入 */
        C_9_3_1("C09.03.01", "outMsgRewardCreateManagedBean"),
        /** OutMsgRewardMaintainManagedBean C9.3.2發文獎勵費維護 */
        C_9_3_2("C09.03.02", "outMsgRewardMaintainManagedBean"),
        //RE201500829_發文獎勵費用申請流程優化 CU3178 2015/5/20 START
        C_9_3_3("C09.03.03", "outMsgRewardQueryManagedBean"),
        //RE201500829_發文獎勵費用申請流程優化 CU3178 2015/5/20 END
        /** EzflyTravelByPlaneDetailCreateManagedBean C9.4.1轉入易飛網搭機明細 */
        C_9_4_1("C09.04.01", "ezflyTravelByPlaneDetailCreateManagedBean"),
        /** ImmovExpDetailManagedBean C9.5.1轉出不動產核銷明細 */
        C_9_5_1("C09.05.01", "immovExpDetailManagedBean"),
        // RE201302499_限額人員 modify by michael in 2013/10/25 start
     	/** ImmovExpDetailManagedBean C9.5.1轉出不動產核銷明細 */
     	C_9_6_1("C09.06.01", "importUserQuotaManagedBean"),
     	// RE201302499_限額人員 modify by michael in 2013/10/25 end
        /** HospitalMaintainManagedBean C 10.1.1醫檢院檔維護 */
        C_10_1_1("C10.01.01", "hospitalMaintainManagedBean"),

        /** PapersNoMgmManagedBean C10.2.1文號管理 */
        C_10_2_1("C10.02.01", "papersNoMgmManagedBean"),
        /** LrnCourseRefFileManagedBean C10.2.2研修課程參照檔 */
        C_10_2_2("C10.02.02", "lrnCourseRefFileManagedBean"),

        //RE201504572_優化研修差旅核銷流程 EC0416 2015/12/02 START
        /** LrnCourseInManagedBean C10.2.3 轉入研修課程結訓資料*/
        C_10_2_3("C10.02.03","lrnCourseInManagedBean"),
        C_10_2_4("C10.02.04","maintainLrnCourseManagedBean"),
        //RE201504572_優化研修差旅核銷流程 EC0416 2015/12/02 END
        
        /** PhoneTypeMaintainManagedBean C10.3.1話機種類檔維護 */
        C_10_3_1("C10.03.01", "phoneTypeMaintainManagedBean"),
        /** PhoneInfoMaintainManagedBean C10.3.2話機基本資料檔維護 */
        C_10_3_2("C10.03.02", "phoneInfoMaintainManagedBean"),

        /** RentContractMaintainManagedBean C10.5.1 租賃合約維護 */
        C_10_5_1("C10.06.01", "rentContractMaintainManagedBean"),

        /** PubAffCarMaintainManagedBean C10.6.1公務車資料維護 */
        C_10_6_1("C10.06.01", "pubAffCarMaintainManagedBean"),
        /** CarInfoMaintainManagedBean C10.6.2車牌、使用人異動 */
        C_10_6_2("C10.06.02", "carInfoMaintainManagedBean"),
        /** MrsZhuWashCarDetailMaintainManagedBean C10.6.3朱太太洗車明細維護 */
        C_10_6_3("C10.06.03", "mrsZhuWashCarDetailMaintainManagedBean"),
        /** FuelPriceRangeMaintainManagedBean C10.6.4汽車燃料油價區間維護 */
        C_10_6_4("C10.06.04", "fuelPriceRangeMaintainManagedBean"),
        /** PubAffCarDriverMaintainManagedBean C10.6.5司機檔維護 */
        C_10_6_5("C10.06.05", "pubAffCarDriverMaintainManagedBean"),
        /** PubAffCarProjectCodeManagedBean C10.6.6公務車專案代號維護 */
        C_10_6_6("C10.06.06", "pubAffCarProjectCodeManagedBean"),

        /** VendorInfoMgmManagedBean C10.7.2 廠商資料管理 */
        C_10_7_1("C10.07.01", "vendorInfoMgmManagedBean"),
        /** VendorContractMgmManagedBean C10.7.2 廠商合約管理 */
        C_10_7_2("C10.07.02", "vendorContractMgmManagedBean"),
        /** VendorPayYearMonthManagedBean C10.7.3 付款年月維護 */
        C_10_7_3("C10.07.03", "vendorPayYearMonthManagedBean"),
        /** PrintedAmortizationTypeMgmManagedBean C10.7.4 印刷品編號維護 */
        C_10_7_4("C10.07.04", "printedAmortizationTypeMgmManagedBean"),

        /** ApplQuotaMaintainManagedBean C10.8.3 限額檔維護 */
        C_10_8_3("C10.08.03", "applQuotaMaintainManagedBean"),
        /** IncomeUserMaintainManagedBean C10.8.4所得人資料維護 */
        C_10_8_4("C10.08.04", "incomeUserMaintainManagedBean"),
        /** DepApplQuotaMaintainManagedBean C10.8.5 單位限額維護 */
        C_10_8_5("C10.08.05", "depApplQuotaMaintainManagedBean"),
        /** ExpapplCMaintainManagedBean C10.8.6 費用申請單維護 */
        C_10_8_6("C10.08.06", "expapplCMaintainManagedBean"),
        /** FillTaxDetailManagedBean C10.8.7 補入稅務明細 */
        C_10_8_7("C10.08.07", "fillTaxDetailManagedBean"),
        /** UpdateTaxDetailManagedBean C10.8.8 修改稅務明細 */
        C_10_8_8("C10.08.08", "updateTaxDetailManagedBean"),
        /** UpdateRosterDetailStateManagedBean C10.8.9 名冊狀態異動 */
        C_10_8_9("C10.08.09", "updateRosterDetailStateManagedBean"),
        /** FuelPriceRangeMaintenanceManagedBean C10.8.10 油價區間維護 */
        C_10_8_10("C10.08.10", "fuelPriceRangeMaintenanceManagedBean"),
        /** ApplQuotaMaintainManagedBean C10.8.11 限額人員維護 */
        C_10_8_11("C10.08.11", "applQuotaPersonMaintainManagedBean"), 
        //RE201404290_系統寄發預算實支表&線上填寫實支異常說明 ec0416 2015/07/21 start
        C_10_8_12("C10.08.12", "departmentMailManagedBean"), 
        //RE201404290_系統寄發預算實支表&線上填寫實支異常說明 ec0416 2015/07/21 end
        
        //RE201601162_國外出差旅費 EC0416 2016/04/21 START
        C10_8_13("C10.08.13", "exchangeRateManagedBean"), 
        //RE201601162_國外出差旅費 EC0416 2016/04/21 END
        
        //RE201400169-汽機車切結書  by CU3178 in 2014/2/19 start
        C_10_9_1("C10.09.11", "carAffidavitManagedBean"), 
        //RE201400169-汽機車切結書  by CU3178 in 2014/2/19 end
        //RE201402595_汽機車切結管理檔案與費用勾稽作業 CU3178 2014/09/19 START
        C_10_9_3("C10.09.03", "carAffidavitReportManagedBean"), 
        //RE201402595_汽機車切結管理檔案與費用勾稽作業 CU3178 2014/09/19 END
        /** MedicalExpApproveResultQueryManagedBean C11.1.1醫檢費核銷結果查詢 */
        C_11_1_1("C11.01.01", "medicalExpApproveResultQueryManagedBean"),
        /** MedicalExpRemitDetailManagedBean C11.1.2 醫檢費匯款明細表 */
        C_11_1_2("C11.01.02", "medicalExpRemitDetailManagedBean"),
        /** TrvlExpApproveQueryManagedBean C11.2.1研修差旅費用核銷查詢(研修部、人資部) */
        C_11_2_1("C11.02.01", "trvlExpApproveQueryManagedBean"),

        /** EzflyRealPayDetailQueryManagedBean C11.2.2易飛網實際支付明細查詢 */
        C_11_2_2("C11.02.02", "ezflyRealPayDetailQueryManagedBean"),
        /** BizTripReportManagedBean C11.2.3國內出差(研修)旅費申請總表 */
        C_11_2_3("C11.02.03", "bizTripReportManagedBean"),
        //RE201702991_國外出差系統優化作業 EC0416 2017/11/13 start
        /** OvsaTripReportManagedBean C11.2.4國外出差(研修)旅費申請總表 */
        C_11_2_4("C11.02.04", "ovsaTripReportManagedBean"),
        //RE201702991_國外出差系統優化作業 EC0416 2017/11/13 end
        /** PhoneFeeRankingQueryManagedBean C11.3.1 電話費費用排行表查詢 */
        C_11_3_1("C11.3.1", "phoneFeeRankingQueryManagedBean"),
        /** PhoneFeeListManagedBean C11.3.2電話費用表(表一) */
        C_11_3_2("C11.3.2", "PhoneFeeListManagedBean"),
        /** PhoneUserDetailManagedBean C11.3.3電話使用人明細表 */
        C_11_3_3("C11.03.03", "PhoneUserDetailManagedBean"),

        //RE201403462_預算修改 CU3178 2014/10/24 START
        /** Phone103YearDetailManagedBean C11.3.4103年各部室電話費實支表 */
        C_11_3_4("C11.03.03", "Phone103YearDetailManagedBean"),
        //RE201403462_預算修改 CU3178 2014/10/24 END
        
        /** RentContractExpireQueryManagedBean C11.4.1 租賃合約到期查詢 */
        C_11_4_1("C11.4.1", "rentContractExpireQueryManagedBean"),
        /** ShouldPayRentQueryManagedBean C11.4.2 應繳租金查詢 */
        C_11_4_2("C11.4.2", "shouldPayRentQueryManagedBean"),
        /** RentMonthlyCostManagedBean C11.4.3 租賃費用每月成本下載 */
        C_11_4_3("C11.4.3", "rentMonthlyCostManagedBean"),

        /** PubAffCarInsuranceDetailManagedBean C11.5.1公務車投保明細表 */
        C_11_5_1("C11.05.01", "pubAffCarInsuranceDetailManagedBean"),
        /** PubAffCarRegisterQueryManagedBean C11.5.2公務車車籍資料查詢 */
        C_11_5_2("C11.05.02", "pubAffCarRegisterQueryManagedBean"),
        /** PubAffCarEndMonthStatisticsReportManagedBean C11.5.3公務車月底統計報表 */
        C_11_5_3("C11.05.03", "pubAffCarEndMonthStatisticsReportManagedBean"),
        /** MustExamineCarQueryManagedBean C11.5.4須檢驗車輛查詢 */
        C_11_5_4("C11.05.04", "mustExamineCarQueryManagedBean"),
        /** CarInsuranceRenewsQueryManagedBean C11.5.5車輛保險續保查詢 */
        C_11_5_5("C11.05.05", "carInsuranceRenewsQueryManagedBean"),
        /** FuelAndRepairExpRankingManagedBean C11.5.6汽油費、修繕費排行榜 */
        C_11_5_6("C11.05.06", "fuelAndRepairExpRankingManagedBean"),
        /** PubAffCarInfoManagedBean C11.5.7 公務車基本資料列印 */
        C_11_5_7("C11.05.07", "pubAffCarInfoManagedBean"),
        /** PubAffCarExpManagedBean C11.5.8 公務車費用總表 */
        C_11_5_8("C11.05.08", "pubAffCarExpManagedBean"),
        /** PubAffCarAssociateReportManagedBean C11.5.9 協理階公務車費用明細 */
        C_11_5_9("C11.05.09", "pubAffCarAssociateReportManagedBean"),
        /** pubAffCarExpApplQueryManagedBean C11.5.10 公務車費用明細查詢功能 */
        C_11_5_10("C11.05.10", "pubAffCarExpApplQueryManagedBean"),   
        
        /** ResponsibilityAdjustExpListManagedBean C11.6.1權責調整費用明細表 */
        C_11_6_1("C11.06.01", "responsibilityAdjustExpListManagedBean"),
        /** VendorExpDetailManagedBean C11.6.2廠商費用明細表 */
        C_11_6_2("C11.06.02", "vendorExpDetailManagedBean"),
        /** VendorInvitesFundsRankingManagedBean C11.6.4廠商請款排行表 */
        C_11_6_4("C11.06.04", "vendorInvitesFundsRankingManagedBean"),
        /** PaymentAccumulateQueryManagedBean C11.6.5付款累積檔查詢 */
        C_11_6_5("C11.06.05", "paymentAccumulateQueryManagedBean"),
        /** AccruedExpensesDetailManagedBean C11.6.6應付費用明細表 */
        C_11_6_6("C11.06.06", "accruedExpensesDetailManagedBean"),
        /** VendorExpBankDepositOfTicketListManagedBean C11.6.7廠商費用銀行存款明細表(開票件) */
        C_11_6_7("C11.06.07", "vendorExpBankDepositOfTicketListManagedBean"),
        /** VendorExpBankDepositOfRemitListManagedBean C11.6.8廠商費用銀行存款明細表(匯款件) */
        C_11_6_8("C11.06.08", "vendorExpBankDepositOfRemitListManagedBean"),
        /** VendorContractPrintManagedBean C11.6.9廠商合約列印 */
        C_11_6_9("C11.06.09", "vendorContractPrintManagedBean"),
        /** VendorExpPrintedMatterManagedBean C11.6.10印刷品查詢 */
        C_11_6_10("C11.06.10", "vendorExpPrintedMatterManagedBean"),
        C_11_6_11("C11.06.11", "vendorInvoiceManagedBean"),

        /** RemitMoneyDetailPrintManagedBean C11.7.1匯回款項明細表列印 */
        C_11_7_1("C11.07.01", "remitMoneyDetailPrintManagedBean"),
        /** CancelCodeQueryManagedBean C11.7.2查詢銷帳碼 */
        C_11_7_2("C11.07.02", "cancelCodeQueryManagedBean"),
        /** subpoenaPrintManagedBean C11.7.3日結單代傳票列印 */
        C_11_7_3("C11.07.03", "subpoenaPrintManagedBean"),
        /** ReturnExpapplCManagedBean C11.7.4退件查詢 */
        C_11_7_4("C11.07.04", "returnExpapplCManagedBean"),
        /** ExpapplCManagedBean C11.7.5費用申請單狀態查詢 */
        C_11_7_5("C11.07.05", "expapplCManagedBean"),
        /** PaymentBatchManagedBean C11.7.6DISB下載 */
        C_11_7_6("C11.07.06", "paymentBatchManagedBean"),
        /** BudgetActualExpManagedBean C11.7.7預算實支查詢 */
        C_11_7_7("C11.07.07", "budgetActualExpManagedBean"),
		/** OverBudgetDetailManagedBean C11.7.8 超支明細表*/
        C_11_7_8("C11.07.08", "overBudgetDetailManagedBean"),
        /** QueryRewardCancelManagedBean C11.7.10 發文獎勵費申請記錄查詢表*/
        C_11_7_10("C11.07.10", "queryRewardCancelManagedBean"),
        //RE201403338_配合預算實支控管103年規定 CU3178 2014/10/12 START
        /** BudgetReminAmtPrintManagedBean C11.7.11 103年預算狀況實支表查詢表*/
        C_11_7_11("C11.07.11", "budgetReminAmtPrintManagedBean"),
        //RE201403338_配合預算實支控管103年規定 CU3178 2014/10/12 END
        
        //RE201500189_國內出差申請作業流程簡化 EC0416 2015/04/07 START
        C_11_7_12("C11.07.12", "ovsaTrvlRemitQueryManagedBean"),
        //RE201500189_國內出差申請作業流程簡化 EC0416 2015/04/07 END
        
        //RE201600212_105上半年度費用系統DEFECTS修改 EC0416 2016/2/2 start
        C_11_7_13("C11.07.13", "applStateFlowManagedBean"),
        //RE201600212_105上半年度費用系統DEFECTS修改 EC0416 2016/2/2 end
        
        //RE201601995_內務關鍵績效指標費用作帳錯誤率 EC0416 2016/7/18 start
        C_11_7_14("C11.07.13", "kPIDetailDepManagedBean"),
        C_11_7_15("C11.07.13", "kPIDetailUnitManagedBean"),
        //RE201601995_內務關鍵績效指標費用作帳錯誤率 EC0416 2016/7/18 end
        
        //RE201403176_C11項下載新增預算實支查詢 EC0416 2015/03/03 START
        C_11_8_1("C11.08.01","budgetExpExecuteManagedBean"),
        C_11_8_2("C11.08.02","budgetExpManagedBean"),
        C_11_8_3("C11.08.03","mealSocialBudgetManagedBean"),
        //RE201403176_C11項下載新增預算實支查詢 EC0416 2015/03/03 END
        
        //RE201603206_內網預算實支查詢移至費用系統-第一階段   CU3178 2016/8/18 START
        C_11_8_5("C11.08.05","budExpDetailManagedBean"),
        C_11_8_6("C11.08.06","projectBudExpDetailManagedBean"),
        //RE201603206_內網預算實支查詢移至費用系統-第一階段   CU3178 2016/8/18  end
        
        //RE201701547_費用系統預算優化第二階段  2017/2/17 EC0416 START
        C_11_8_7("C11.08.07","prepaidAmortizationManagedBean"),
        C_11_8_8("C11.08.08","deferredAmortizationManagedBean"),       
        //RE201701547_費用系統預算優化第二階段 2017/2/17 EC0416 END
        
        //RE201404290_系統寄發預算實支表&線上填寫實支異常說明 ec0416 2015/07/21  start
        /** BudExpOverrunExplainManagedBean C13.1 填寫預算實支異常說明*/
        C_13_1("C13.1","budExpOverrunExplainManagedBean"),
        /**BudExpOverrunReviewManagedBean C13.2 */
        C_13_2("C13.2","budExpOverrunReviewManagedBean"),
        /**MailLogManagedBean.java C13.3 */
        C_13_3("C13.3","mailLogManagedBean"),        
        //RE201404290_系統寄發預算實支表&線上填寫實支異常說明 ec0416 2015/07/21 end
        
        //RE201702775_預算實支追蹤表單_費用系統  ec0416 2017/9/29 start
        C_13_4("C13.4","budExpOverrunDetailManagedBean"),   
        //RE201702775_預算實支追蹤表單_費用系統  ec0416 2017/9/29  end
        
        // D
        /** AmortizationPrepaidExpManagedBean D 1.1 攤銷預付費用 managed bean */
        D_1_1("D01.01", "amortizationPrepaidExpManagedBean"),
        /** QueryPrepaidExpManagedBean D 1.2 查詢預付費用攤銷明細 managed bean */
        D_1_2("D01.02", "queryPrepaidExpManagedBean"),
        /** CheckPrepaidExpManagedBean D 1.3 盤點轉預付費用 managed bean */
        D_1_3("D01.03", "checkPrepaidExpManagedBean"),
        /** AmortizeDeferredAssetApplyManagedBean D 2.1 攤銷遞延資產 */
        D_2_1("D02.01", "amortizeDeferredAssetApplyManagedBean"),
        /** CarryOverTransitManagedBean D 2.2 結轉過渡科目 */
        D_2_2("D02.02", "carryOverTransitManagedBean"),
        /** TransferExpManagedBean D 2.3 結轉當期費用 */
        D_2_3("D02.03", "transferExpManagedBean"),
        /** QueryDeferredAssetManagedBean D 2.4 查詢遞延資產攤銷明細 */
        D_2_4("D02.04", "queryDeferredAssetManagedBean"),
        /** AmttImportManagedBean D 3.1 轉入分攤檔 */
        D_3_1("D03.01", "amttImportManagedBean"),
        
        //RE201700820_印刷品移回費用 CU3178 2017/6/30 START
        /** printedImportManagedBean D3.2.1轉入印刷品配送資料 */
        D_3_2_1("D03.02.01", "printedImportManagedBean"),
        /** printedReadManagedBean D3.2.2查詢印刷品配送資料 */
        D_3_2_2("D03.02.02", "printedReadManagedBean"),
        /** printedCreateManagedBean D3.2.3產生印刷品分攤檔 */
        D_3_2_3("D03.02.03", "printedCreateManagedBean"),
        //RE201700820_印刷品移回費用 CU3178 2017/6/30 END
        
        /** MonthTurnAccruedExpManagedBean D 4.1 提列每月可迴轉應付費用 */
        D_4_1("D04.01", "monthTurnAccruedExpManagedBean"),
        /** MonthNoTurnAccexpManagedBean D 4.3 提列每月不迴轉費用 */
        D_4_2("D04.02", "monthNoTurnAccexpManagedBean"),
        /** DepAccexpManagedBean D 4.3 部門提列應付費用 */
        D_4_3("D04.03", "depAccexpManagedBean"),
        /** VerifyDepAccexpManagedBean D 4.4 核定部門應付費用 */
        D_4_4("D04.04", "verifyDepAccexpManagedBean"),
        /** QueryDepAccexpManagedBean D 4.5 查詢部門提列應付費用 */
        D_4_5("D04.05", "queryDepAccexpManagedBean"),
        /** ImportAccexpManagedBean D 4.6 轉入資產區隔應付費用 */
        D_4_6("D04.06", "importAccexpManagedBean"),
        //RE201602231_廠商應付費用提列 CU3178 2016/9/7 START
        /** MonthAccuredrContractManagedBean D04.07 提列廠商應付費用 */
        D_4_7("D04.07", "vendorTurnAccruedExpManagedBean"),
        /** CloseMonthAccruedExpManagedBean D04.08 核定廠商應付費用 */
        D_4_8("D04.08", "closeMonthAccruedExpManagedBean"),
        /** VendorMonthDetailManagedBean D04.09 查詢廠商應付費用明細 */
        D_4_9("D04.09", "vendorMonthDetailManagedBean"),
        /** VendorExpDetailManagedBean D04.10 查詢已送審未內結明細 */
        D_4_10("D04.10", "vendorExpDetailGLManagedBean"),
        //RE201602231_廠商應付費用提列 CU3178 2016/9/7 END
        /** ImportCoreSubpoenaManagedBean D 5.1 轉入核心傳票檔 */
        D_5_1("D05.01", "importCoreSubpoenaManagedBean"),
        /** ImportLecturerManagedBean D 5.2 轉入講師費用明細檔 */
        D_5_2("D05.02", "importLecturerManagedBean"),
        /** ImportCoreEntryManagedBean D 5.3 動產/叡揚/核心分錄明細檔 */
        D_5_3("D05.03", "importCoreEntryManagedBean"),
        /** ImportDisbManagedBean D 5.4 DISB 回銷檔 */
        D_5_4("D05.04", "importDisbManagedBean"),
        //RE201503701_關係人交易明細查詢功能優化 CU3178 2015/10/19 START
        D_5_5("D05.05", "relationMaintainManagedBean"),
        //RE201503701_關係人交易明細查詢功能優化 CU3178 2015/10/19 END
        /** Ca00BusinessCostStatisticsManagedBean D 6.1 CA00 業務成本統計檔 */
        D_6_1("D06.01", "ca00BusinessCostStatisticsManagedBean"),
        /** Ca10BusinessCostStatisticsManagedBean D 6.2 CA10 業務成本統計檔 */
        D_6_2("D06.02", "ca10BusinessCostStatisticsManagedBean"),
        /** Ca20BusinessCostStatisticsManagedBean D 6.3 CA20 業務成本統計檔 */
        D_6_3("D06.03", "ca20BusinessCostStatisticsManagedBean"),
        /** ExpMainManagedBean D 6.5 費用主檔 */
        D_6_5("D06.05", "expMainManagedBean"),
        /** ExpRegimentationManagedBean D 6.6 費用類別檔 */
        D_6_6("D06.06", "expRegimentationManagedBean"),
        /** VatDetailManagedBean D 6.7 進項稅檔 managed bean */
        D_6_7("D06.07", "vatDetailManagedBean"),
        /** ExportDeferredAssetManagedBean D 6.8 遞延資產攤銷與結轉檔 */
        D_6_8("D06.08", "exportDeferredAssetManagedBean"),
        /** TableATextManagedBean D 6.9 A表文字檔 */
        D_6_9("D06.09", "tableATextManagedBean"),
        /** TableBTextManagedBean D 6.10 B表文字檔 */
        D_6_10("D06.10", "tableBTextManagedBean"),
        /** ExportExpMainManagedBean D 6.11 帳務主檔 */
        D_6_11("D06.11", "exportExpMainManagedBean"),
        /** ExportBudgetMonthManagedBean D 6.12 預算實支檔 */
        D_6_12("D06.12", "exportMonthBudgetManagedBean"),
        /** ManualAccountApplManagedBean D7.1 手工調整帳務 */
        D_7_1("D07.01", "manualAccountApplManagedBean"),
        /** TurnPrdAccexpApplManagedBean D 7.3 迴轉每月預付應付費用 */
        D_7_3("D07.03", "turnPrdAccexpApplManagedBean"),
        /** TurnAssetAccruedExpManagedBean D7.4迴轉資產區隔應付費用 */
        D_7_4("D07.04", "turnAssetAccruedExpManagedBean"),
        /** ChangeAccruedExpApplManagedBean D7.5沖轉部門提列應付費用 */
        D_7_5("D07.05", "changeAccruedExpApplManagedBean"),
        /** QueryTurnApplyManagedBean D 7.6 查詢迴轉資料 */
        D_7_6("D07.06", "queryTurnApplyManagedBean"),
        /** FirstVerifyManagedBean D7.7 手工調整帳務初審 */
        D_7_7("D07.07", "firstVerifyGLManagedBean"),
        /** InCloseManagedBean D8.1.1 內結作業 */
        D_8_1_1("D08.01.01", "inCloseGLManagedBean"),
        /** SendRemitManagedBean D8.1.2 送匯 */
        D_8_1_2("D08.01.02", "sendRemitGLManagedBean"),
        /** DailyCloseManaged D8.1.3 日結 */
        D_8_1_3("D08.01.03", "dailyCloseGLManagedBean"),
        /** OtherDailyCloseManagedBean D8.2 其他帳冊結帳作業 */
        D_8_2("D08.02", "otherDailyCloseManagedBean"),
        /** GeneralExpManagedBean D 9.1.1 總費用明細表 */
        D_9_1_1("D09.01.01", "generalExpManagedBean"),
        /** BusinessExpManagedBean D 9.1.2 業務費用明細表 */
        D_9_1_2("D09.01.02", "businessExpManagedBean"),
        /** Stratum3ExpandBizManagedBean D9.1.3 三階展業費用明細表 */
        D_9_1_3("D09.01.03", "stratum3ExpandBizManagedBean"),
        /** Stratum2ExpandBizManagedBean D9.1.4 二階展業費用明細表 */
        D_9_1_4("D09.01.04", "stratum2ExpandBizManagedBean"),
        /** ExternalBizPlanningManagedBean D9.1.5 外務企劃部展業費用明細表 */
        D_9_1_5("D09.01.05", "externalBizPlanningManagedBean"),
        /** CrossMarketingManagedBean D9.1.6 交叉行銷展業費用明細表 */
        D_9_1_6("D09.01.06", "crossMarketingManagedBean"),
        /** ChannelExpandBizManagedBean D9.1.7 通路展業費用明細表 */
        D_9_1_7("D09.01.07", "channelExpandBizManagedBean"),
        /** GroupInsuranceExpandManagedBean D9.1.8 團險展業費用明細表 */
        D_9_1_8("D09.01.08", "groupInsuranceExpandManagedBean"),
        /** ExternalBizPersonnelManagedBean D9.1.9 外務人事部展業費用明細表 */
        D_9_1_9("D09.01.09", "externalBizPersonnelManagedBean"),
        /** AirportExpandBizManagedBean D9.1.10 機場展業費用明細表 */
        D_9_1_10("D09.01.10", "airportExpandBizManagedBean"),
        /** ProExpandBizManagedBean D9.1.11 PRO展業費用明細表 */
        D_9_1_11("D09.01.11", "proExpandBizManagedBean"),
        /** InternationalExpandBizManagedBean D9.1.12 國際聯保展業費用明細表 */
        D_9_1_12("D09.01.12", "internationalExpandBizManagedBean"),
        /** ExternalBizPersonnel2ManagedBean D9.1.13業務分攤展業費用明細表 */
        D_9_1_13("D09.01.13", "externalBizPersonnel2ManagedBean"),
        /** NewContractExpManagedBean D9.1.14 新契約費用明細表 */
        D_9_1_14("D09.01.14", "newContractExpManagedBean"),
        /** IncomeExpManagedBean D9.1.15 收金費用明細表 */
        D_9_1_15("D09.01.15", "incomeExpManagedBean"),
        /** GeneralAffairsManagedBean D9.1.16 總務部費用明細表 */
        D_9_1_16("D09.01.16", "generalAffairsManagedBean"),
        /** TrainingExpManagedBean D9.1.17研修部展費用明細表 */
        D_9_1_17("D09.01.17", "trainingExpManagedBean"),
        /** AnnualGeneralExpManagedBean D9.1.18年度總費用明細表 */
        D_9_1_18("D09.01.18", "annualGeneralExpManagedBean"),
        /** AnnualBizExpManagedBean D9.1.19年度業務費用明細表 */
        D_9_1_19("D09.01.19", "annualBizExpManagedBean"),
        /** TrainingExpDetailManagedBean D9.1.20訓練費總明細報表 */
        D_9_1_20("D09.01.20", "trainingExpDetailManagedBean"),
        //RE201502770_費用系統新增OIU帳冊 CU3178 2015/8/11 START
        /** MarketSalesExpManagedBean D9.1.21市場行銷部展業明細表 */
        D_9_1_21("D09.01.21", "marketSalesExpManagedBean"),
        /** OIUExpManagedBean D9.1.22國際保險業務分公司明細表 */
        D_9_1_22("D09.01.22", "oIUExpManagedBean"),
        //RE201502770_費用系統新增OIU帳冊 CU3178 2015/8/11 END
        /** BudgetExecuteManagedBean D9.2.1 預算執行明細表 */
        D_9_2_1("D09.02.01", "budgetExecuteManagedBean"),
        /** HQBudgeExecuteReportManagedBean D9.2.2 本部預算執行報告表 */
        D_9_2_2("D09.02.02", "hqBudgeExecuteReportManagedBean"),
        /** BudgetExecuteGeneralDetailManagedBean D9.2.3 預算執行總明細表 */
        D_9_2_3("D09.02.03", "budgetExecuteGeneralDetailManagedBean"),
        /** EconomyInstituteReportManagedBean D9.2.4 經策會報表 */
        D_9_2_4("D09.02.04", "economyInstituteReportManagedBean"),
        /** GeneralBudgeExecuteManagedBean D9.2.5 總管理處預算執行明細表 */
        D_9_2_5("D09.02.05", "generalBudgeExecuteManagedBean"),
        /** EconomyInstituteBudgeExecuteManagedBean D9.2.6 經策會預算執行總明細表 */
        D_9_2_6("D09.02.06", "economyInstituteBudgeExecuteManagedBean"),
        /** AccruedExpensesDailyDetailManagedBean D9.4 應付費用每日明細核帳 */
        D_9_4("D09.04", "accruedExpensesDailyDetailManagedBean"),
        /** ExpDetailManagedBean D9.5 費用明細分類帳/核帳 */
        D_9_5("D09.05", "expDetailManagedBean"),
        /** AccruedExpensesDetailAssortManagedBean D9.6 應付費用明細分類帳 */
        D_9_6("D09.06", "accruedExpensesDetailAssortManagedBean"),
        /** BizExpDetailManagedBean D9.7 營業費用明細表) */
        D_9_7("D09.07", "bizExpDetailManagedBean"),
        /** UnitPerMillionManagedBean D9.8 單位每萬換算報表 */
        D_9_8("D09.08", "unitPerMillionManagedBean"),
        /** DepartmentTaxiExpManagedBean D9.10 部室計程車資明細表 */
        D_9_10("D09.10", "departmentTaxiExpManagedBean"),
        /** EmployeeTaxiExpManagedBean D9.11 員工計程車資明細表 */
        D_9_11("D09.11", "employeeTaxiExpManagedBean"),
        /** RepastExpRedundancyApplyManagedBean D9.12 餐費重複申請查核表 */
        D_9_12("D09.12", "repastExpRedundancyApplyManagedBean"),
        /** VariousIncomeDetailManagedBean D9.14 各類所得明細表 */
        D_9_14("D09.14", "variousIncomeDetailManagedBean"),
        /** ProjectEncouragementQueryManagedBean D9.16 專案、獎勵查詢 */
        D_9_16("D09.16", "projectEncouragementQueryManagedBean"),
        /** CapitalNonCapitalQueryManagedBean D9.17 資本支出、非資本支出查詢 */
        D_9_17("D09.17", "capitalNonCapitalQueryManagedBean"),
        /** CapitalDefrayManagedBean D9.18 資本支出表 */
        D_9_18("D09.18", "capitalDefrayManagedBean"),
        /** NonCapitalDefrayManagedBean D9.19 非資本支出表 */
        D_9_19("D09.19", "nonCapitalDefrayManagedBean"),
        /** RelationTradeDetailManagedBean D9.20 關係人交易明細表 */
        D_9_20("D09.20", "relationTradeDetailManagedBean"),
        /** FixUpQueryManagedBean D9.21 修繕查詢 */
        D_9_21("D09.21", "fixUpQueryManagedBean"),
        /** BuildingExpDetailManagedBean D9.22 各大樓費用明細表 */
        D_9_22("D09.22", "buildingExpDetailManagedBean"),
        /** LecturerExpReportManagedBean D9.24 講師費報表 */
        D_9_24("D09.24", "lecturerExpReportManagedBean"),
        /** BizUnitKPIStatisticManagedBean D9.27 業務單位KPI統計表 */
        D_9_27("D09.27", "bizUnitKPIStatisticManagedBean"),
        /** QueryVoucherManagedBean D9.28 89~98年費用明細帳 */
        D_9_28("D09.28","queryVoucherManagedBean"),
        /** OfficeExpManagedBean D 10.1 年度結算主任組長辦公費 */
        D_10_1("D10.01", "officeExpManagedBean"),
        /** ClosingTuitionFeeManagedBean D 10.2 結轉員工訓練費 */
        D_10_2("D10.02", "closingTuitionFeeManagedBean"),
        /** officeExpForOrganizeDevelopeManagedBean D 10.3 年度結算組織發展費 */
        D_10_3("D10.03", "officeExpForOrganizeDevelopeManagedBean"),   
        // RE201301890 modify by michael in 2013/09/04, 併薪作業 start
     	/** mergeSalaryManagedBean D 10.4 業推發組發年度未核銷併薪 */
     	D_10_4("D10.04", "mergeSalaryManagedBean"),
        // RE201301890 modify by michael in 2013/09/04, 併薪作業 end
     	
     	//RE2017 辦公費核定表提列應付費用 CU3178 2017/11/8 START
     	D_10_6("D10.06", "yyclsDetailQueryManagedBean"),
     	//RE2017 辦公費核定表提列應付費用 CU3178 2017/11/8 END
             
        /** BizDevelopManagedBean D11.1 業推業發費 */
        D_11_1("D11.01", "bizDevelopManagedBean"),
        /** SectionChiefWorkManagedBean D11.2 處長駐區辦公費 */
        D_11_2("D11.02", "sectionChiefWorkManagedBean"),
        /** LocalSalesmanEncouragementManagedBean D11.3 駐區業務獎勵費 */
        D_11_3("D11.03", "localSalesmanEncouragementManagedBean"),
        /** OutMsgRewardManagedBean D11.4 發文獎勵費 */
        D_11_4("D11.04", "outMsgRewardManagedBean"),
        /** VendorExpManagedBean D11.5 廠商費用 */
        D_11_5("D11.05", "vendorExpGLManagedBean"),
        /** OfficeExpReportedThatSupportManagedBean D11.7 辦公費實報實支 */
        D_11_7("D11.07", "officeExpReportedThatSupportManagedBean"),
        /** InputOutputTaxManagedBean D11.8 進銷項稅額查詢 */
        D_11_8("D11.08", "inputOutputTaxManagedBean"),
        /** RemitQueryManagedBean D11.9 匯款查詢 */
        D_11_9("D11.09", "remitQueryManagedBean"),
        /** CostTypeQueryManagedBean D11.10 成本別查詢 */
        D_11_10("D11.10", "costTypeQueryManagedBean"),
        /** OrgDevelopExpQueryManagedBean D11.11 組織發展費查詢 */
        D_11_11("D11.11", "orgDevelopExpQueryManagedBean"),
        /**手工帳務調整 EC0416 2016/9/13 start*/
        /** voucherQueryManagedBean D11.12 應付未付廠商費用查詢 */
        D_11_12("D11.12", "accruedexpenseManagedBean"),
        /**手工帳務調整 EC0416 2016/9/13 END*/
        //#RE201400156_各項業務費用核銷進度統計 modify by michael in 2014/05/14 start
        /** returnAmtManagedBean D UC 11.13 週轉金還款查詢 */
        D_11_13("D11.13", "returnAmtManagedBean"),
        //#RE201400156_各項業務費用核銷進度統計 modify by michael in 2014/05/14 end
        
        //RE201701547_費用系統預算優化第二階段 EC0416 2017/5/16 start
        D_11_14("D11.14","lecturerFeesManagedBean"),
        //RE201701547_費用系統預算優化第二階段 EC0416 2017/5/16 end
        
        /** SupervisorReviewManagedBean D12.1 主管覆核 */
        D_12_1("D12.01", "supervisorReviewManagedBean"),
        
        //RE201603570_預算暨費用系統_共用功能與模組整合  EC0416 2016/10/17 start
        /**E01.01一般行政費用*/
        E_1_1("E01.01", "normalBudgetManagedBean"),
        /**E01.02專案費用*/
        E_1_2("E01.02", "projectBudgetManagedBean"),
        /**E01.03編列月預算*/
        E_1_3("E01.03", "monthBudgetManagedBean"),
        /**E01.04部室人力配置*/
        E_1_4("E01.04", "humanAllocationManagedBean"),
        /**E01.05查詢預算追加減*/
        E_1_5("E01.05", "searchBudgetChangeManagedBean"),
        /**E02.01預算送審*/
        E_2_1("E02.01", "budgetApproveManagedBean"),
        /**E03.01預算審查-總公司*/
        E_3_1("E03.01", "auditBudgetForHeadquarterManagedBean"),
        /**E03.02預算審查-服務中心、營業部室本部、營業部室外埠二階、營業部室外埠三階*/
        E_3_2("E03.02", "auditBudgetForServiceCenterManagedBean"),
        /**E03.03預算審查-經管會*/
        E_3_3("E03.03", "auditBudgetForAdministrationManagedBean"),
        /**E04.01人力配置暨辦公費*/
        E_4_1("E04.01", "humanAllocationAndOfficeFeeManagedBean"),
        /**E04.02工作目標與費用預算計劃表*/
        E_4_2("E04.02", "workTargetAndExpenseReportManagedBean"),
        /**E04.03專案計畫預算報告書*/
        E_4_3("E04.03", "projectPlanBudgetManagedBean"),
        /**E04.04資本支出計劃表*/
        E_4_4("E04.04", "capitalExpenditurePlanManagedBean"),
        /**E04.05預算審查彙總報表*/
        E_4_5("E04.05", "auditBudgetCollectManagedBean"),
        /**E04.06經管會預算表*/
        E_4_6("E04.06", "administrationReportManagedBean"),
        /**E04.07月預算報表*/
        E_4_7("E04.07", "monthBudgetReportManagedBean"),
        /**E04.08事業費用報表*/
        E_4_8("E04.08", "operatingDataReportManagedBean"),
        /**E04.09事業費用分析差異表*/
        E_4_9("E04.09", "operatingDiffDataReportManagedBean"),
        //RE201700820_事業費用預算報表新增 CU3178 2017/4/17 START
        /**E04.10	事業費用預算項目屬性報表*/
        E_4_10("E04.10", "operatingBudgetItemReportManagedBean"),
        /**E4.11事業費用預算項目屬性年度差異分析報表*/
        E_4_11("E04.11", "operatingDifferBudgetItemReportManagedBean"),
        /**E4.12事業費用預算類別報表*/
        E_4_12("E04.12", "operatingBudgetTypeReportManagedBean"),
        /**E4.13事業費用預算類別年度差異分析報表*/
        E_4_13("E04.13", "operatingDifferBudgetTypeReportManagedBean"),
        /**E4.14事業費用部室屬性類別預算實支報表*/
        E_4_14("E04.14", "operatingDepPropReportManagedBean"),
        /**E4.15事業費用預算部室屬性類別年度差異分析報表*/
        E_4_15("E04.15", "operatingDifferDepPropReportManagedBean"),
        /**E4.14事業費用預算部室屬性類別報表*/
        //RE201702476_事業費用預算實支報表 CU3178 2017/8/23 START
        E_4_16("E04.16", "operatingBfmDepPropReportManagedBean"),
        //RE201700820_事業費用預算報表新增 CU3178 2017/4/17 END
        //RE201702476_事業費用預算實支報表 CU3178 2017/8/23 END
        /**E05.01部室預算下載*/
        E_5_1("E05.01", "departmentBudgetDataManagedBean"),  
        /**E05.02專案預算下載*/
        E_5_2("E05.02", "projectBudgetDataManagedBean"),
        /**E05.03資本預算下載*/
        E_5_3("E05.03", "capitalBudgetDataManagedBean"),
        /**E05.04月預算下載*/
        E_5_4("E05.04", "monthBudgetDataManagedBean"),
        /**E06.01人件費資料上傳*/
        E_6_1("E06.01", "humanFeeManagedBean"),
        /**E07.01預算項目維護*/
        E_7_1("E07.01", "budgetItemManagedBean"),
        /**E07.02編制單位維護*/
        E_7_2("E07.02", "bfmDepartmentManagedBean"),
        /**E07.03單位裁撤*/
        E_7_3("E07.03", "departmentChangeManagedBean"),
        /**E07.04預算項目查詢*/
        E_7_4("E07.04", "searchBudgetItemManagedBean"),
        /**E07.05專案查詢*/
        E_7_5("E07.05", "searchProjectBudgetManagedBean"),
        /**E07.06依部室或總公司查詢預算*/
        E_7_6("E07.06", "searchBudgetManagedBean"),
        /**E07.07預備金動支概況表*/
        E_7_7("E07.07", "preparingChangeManagedBean"),
        /**E07.08開放預算重編制*/
        E_7_8("E07.08", "rebudgetChangeManagedBean"),
        /**E07.09事業費用(檢核金額)輸入*/
        E_7_9("E07.09", "operatingDataManagedBean"),
        /**E07.10編列單位加班費用查詢*/
        E_7_10("E07.10", "budgetManagedBean"),
        /**E07.11預備金維護*/
        E_7_11("E07.11", "preparingAlterManagedBean"),
        /**E07.12追加減核定結果輸入*/
        E_7_12("E07.12", "budgetChangeManagedBean"),
        /**E07.13彙總查詢*/
        E_7_13("E07.13", "budgetSummaryManagedBean"),
        /**E07.14狀態查詢*/
        E_7_14("E07.14", "budgetStateManagedBean"),
        /**E07.15新增專案*/
        E_7_15("E07.15", "maintainCreateProjectBudget"),
        /**E07.16刪除專案*/
        E_7_16("E07.16", "maintainDeleteProjectBudget"),
        /**E07.17建立年度預算表*/
        E_7_17("E07.17", "confirmYearManagedBean"),
        /**E07.18匯入上一年度預算實支*/
        E_7_18("E07.18", "lastYearExpenditureManagedBean"),
        /**E07.19預算系統人員設定*/
        E_7_19("E07.19", "bfmUserManagedBean"),
        /**E07.20預算系統群組設定*/
        E_7_20("E07.20", "bfmGroupManagedBean"),
        //RE201700820_事業費用預算報表新增 CU3178 2017/4/17 START
        /**E07.21事業費用屬性拆分設定管理*/
        E_7_21("E07.21", "splitProjectBudgetItemManagedBean"),
        /**E08.01確認上一年度預算實支*/
        E_8_1("E08.01", "confirmLastYearBudgetManagedBean"),
        //RE201603570_預算暨費用系統_共用功能與模組整合  EC0416 2016/10/17 end
        
        //RE201702476_事業費用預算實支報表 CU3178 2017/8/23 START
        /**E09.01追加減預算性質查詢*/
        E_9_1("E09.01", "budgetChangeTypeManagedBean"),
        
        //RE201700820_事業費用預算報表新增 CU3178 2017/4/17 END        
        /**E10.01事業費用實支資料上傳*/
        E_10_1("E10.01", "operatingExpManagedBean"),
        /**E10.02事業費用科子目餘額資料上傳*/
        E_10_2("E10.02", "operatingBalanceManagedBean"),
        //RE201702476_事業費用預算實支報表 CU3178 2017/8/23 END
        
        END("","");
        
        private String code;

        private String beanId;

        FunctionCode(String code, String beanId) {
            this.code = code;
            this.beanId = beanId;
        }

        /**
         * @return the code
         */
        public String getCode() {
            return code;
        }

        /**
         * Spring 中的 ManagedBenaId
         * 
         * @return the beanId
         */
        public String getBeanId() {
            return beanId;
        }

    }

    private String id;

    /**
     * 建檔日期。
     */
    private Calendar createDate;

    /**
     * 更新日期。
     */
    private Calendar updateDate;

    /**
     * 建檔人員。
     */
    private User createUser;

    /**
     * 更新人員。
     */
    private User updateUser;

    /**
     * 功能代碼。
     */
    private String code;

    /**
     * 名稱。
     */
    private String name;

    /**
     * JSF 導頁字串。
     */
    private String outcome;

    /**
     * 項目。
     */
    private List<Item> items = new ArrayList<Item>();

    /**
     * 上層功能。
     */
    private Function parentFunction;

    /**
     * 下層功能。
     */
    private List<Function> childrenFunctions = new ArrayList<Function>();

    /**
     * 群組。
     */
    private List<Group> groups = new ArrayList<Group>();

    /**
     * 是否啟用
     */
    private boolean inputFlag;

    /**
     * 此功能設定於 Spring 中的 ManagedBenaId
     */
    private String managedBeanId;

    /**
     * 是否要出現在 menu tree
     */
    private boolean showed;

    private boolean authorized;

    /**
     * 版本
     */
    private Integer versionNo;
    
    //RE201603570_預算暨費用系統_共用功能與模組整合 CU3178 2016/10/14 START
    /**
     * 預算狀態
     */
    private List<BudgetStateType> budgetStateTypes;
    
    /**
     * 預算群組。
     */
    private List<BfmGroup> bfmGroups = new ArrayList<BfmGroup>();
    //RE201603570_預算暨費用系統_共用功能與模組整合 CU3178 2016/10/14 END

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "uuid-hex")
    @Column(name = "ID", length = 72)
    public String getId() {
        return this.id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATE_DATE", nullable = false)
    public Calendar getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Calendar createDate) {
        this.createDate = createDate;
    }

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "UPDATE_DATE", nullable = true)
    public Calendar getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Calendar updateDate) {
        this.updateDate = updateDate;
    }

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "TBEXP_CREATE_USER_ID", referencedColumnName = "ID")
    public User getCreateUser() {
        return createUser;
    }

    public void setCreateUser(User createUser) {
        this.createUser = createUser;
    }

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "TBEXP_UPDATE_USER_ID", referencedColumnName = "ID")
    public User getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(User updateUser) {
        this.updateUser = updateUser;
    }

    @Column(name = "CODE", length = 72, nullable = false)
    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    @Column(name = "NAME", length = 40, nullable = false)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Column(name = "OUTCOME", length = 200, nullable = true)
    public String getOutcome() {
        return outcome;
    }

    public void setOutcome(String outcome) {
        this.outcome = outcome;
    }

    @ManyToMany()
    @JoinTable(name = "TBEXP_FUNCTION_ITEM_R", joinColumns = { @JoinColumn(name = "TBEXP_FUNCTION_ID", referencedColumnName = "ID") }, inverseJoinColumns = { @JoinColumn(name = "TBEXP_ITEM_ID", referencedColumnName = "ID") })
    public List<Item> getItems() {
        return items;
    }

    public void setItems(List<Item> items) {
        this.items = items;
    } 

    @ManyToOne
    @JoinColumn(name = "TBEXP_FUNCTION_ID", referencedColumnName = "ID")
    public Function getParentFunction() {
        return parentFunction;
    }

    public void setParentFunction(Function parentFunction) {
        this.parentFunction = parentFunction;
    }

    @OneToMany(mappedBy = "parentFunction", fetch = FetchType.EAGER)
    public List<Function> getChildrenFunctions() {
        return childrenFunctions;
    }

    public void setChildrenFunctions(List<Function> childrenFunctions) {
        this.childrenFunctions = childrenFunctions;
    }

    @ManyToMany(mappedBy = "functions", fetch = FetchType.LAZY)
    public List<Group> getGroups() {
        return groups;
    }

    public void setGroups(List<Group> group) {
        this.groups = group;
    }

    @Column(name = "INPUT_FLAG")
    public boolean isInputFlag() {
        return inputFlag;
    }

    public void setInputFlag(boolean inputFlag) {
        this.inputFlag = inputFlag;
    }

    @Column(name = "BEAN_ID")
    public String getManagedBeanId() {
        return managedBeanId;
    }

    public void setManagedBeanId(String managedBeanId) {
        this.managedBeanId = managedBeanId;
    }

    @Column(name = "SHOWED")
    public boolean isShowed() {
        return showed;
    }

    public void setShowed(boolean showed) {
        this.showed = showed;
    }

    @Transient
    public boolean isAuthorized() {
        return authorized;
    }

    public void setAuthorized(boolean authorized) {
        this.authorized = authorized;
    }

    @Version
    @Column(name = "VERSION_NO", nullable = false, precision = 20)
    public Integer getVersionNo() {
        return versionNo;
    }

    public void setVersionNo(Integer versionNo) {
        this.versionNo = versionNo;
    }

    @Transient
    public boolean isLeaf() {
        return this.getChildrenFunctions().size() == 0;
    }

    @Transient
    public String getViewId() {
        if (this.outcome != null && this.outcome.indexOf("/faces") == 0) {
            return this.outcome.substring("/faces".length());
        }
        return null;
    }
    
    //RE201603570_預算暨費用系統_共用功能與模組整合 CU3178 2016/10/14 START
	@ManyToMany(mappedBy="functions", fetch=FetchType.LAZY)
	public List<BudgetStateType> getBudgetStateTypes() {
		return this.budgetStateTypes;
	}
	public void setBudgetStateTypes(List<BudgetStateType> budgetStateTypes) {
		this.budgetStateTypes = budgetStateTypes;
	}
	
    @ManyToMany(mappedBy = "functions", fetch = FetchType.LAZY)
    public List<BfmGroup> getBfmGroups() {
        return bfmGroups;
    }

    public void setBfmGroups(List<BfmGroup> bfmGroup) {
        this.bfmGroups = bfmGroup;
    }
    //RE201603570_預算暨費用系統_共用功能與模組整合 CU3178 2016/10/14 END

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (!(obj instanceof Function))
            return false;
        Function other = (Function) obj;
        if (code == null) {
            if (other.code != null)
                return false;
        } else if (!code.equals(other.code))
            return false;
        return true;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((code == null) ? 0 : code.hashCode());
        return result;
    }

    public int compareTo(Function o) {
        return this.getCode().compareTo(o.getCode());
    }

    @Override
    public String toString() {
        return this.code;
    }

}
