package tw.com.skl.exp.kernel.model6.logic;

import java.util.Calendar;
import java.util.List;

import tw.com.skl.common.model6.logic.BaseService;
import tw.com.skl.exp.kernel.model6.bo.Department;
import tw.com.skl.exp.kernel.model6.bo.Entry;
import tw.com.skl.exp.kernel.model6.bo.OvsaExpDrawInfo;
import tw.com.skl.exp.kernel.model6.bo.OvsaTrvlLrnExp;
import tw.com.skl.exp.kernel.model6.bo.PaymentType;
import tw.com.skl.exp.kernel.model6.bo.Station;
import tw.com.skl.exp.kernel.model6.bo.StationExpDetail;
import tw.com.skl.exp.kernel.model6.bo.User;
import tw.com.skl.exp.kernel.model6.bo.ApplState.ApplStateCode;
import tw.com.skl.exp.kernel.model6.bo.Function.FunctionCode;
import tw.com.skl.exp.kernel.model6.logic.enumeration.ApplStateEnum;

/**
 * 國外研修差旅費用Service 介面。
 *  <pre>
 * Revision History
 * 2009/09/08, Eustace Hseih, 新增List&lt;IntrTrvlBizExp&gt; findByParams(ApplStateCode applStateCode, 
            Department department, String userCode, 
            Calendar createDateStart, Calendar createDateEnd);
 * 
 * </pre>
 * @author Eustace
 */
public interface OvsaTrvlLrnExpService extends BaseService<OvsaTrvlLrnExp, String> {
    
    
    /**
     * 查出狀態為暫存中的國外研修差旅費用資料。
     * 
     * <p>C1.5.6輸入國外研修差旅費用核銷申請資料</p>
     * 
     * @param createUser 資料建立人員
     * @return 國外研修差旅費用資料List
     */
    List<OvsaTrvlLrnExp> findTempOvsaTrvlLrnExp(User createUser);
    
    /**
     * 建立狀態為"暫存中"的國外研修差旅費用資料。
     * 
     * <p>C1.5.6輸入國外研修差旅費用核銷申請資料</p>
     *
     * <ol>
     * <ul>產生分錄</ul>
     * <ul>儲存資料，要存流程簽核</ul>
     * </ol>
     * 
     * <p>POST</p>
     * <ul>
     * <li>費用申請單狀態改為"暫存中"</li> 
     * </ul>
     * 
     * @param exp 國外研修差旅費用
     * @param expEntry 費用科目
     * @param functionCode 功能代碼
     */
    void doCreateTempOvsaTrvlLrnExp(OvsaTrvlLrnExp exp, Entry expEntry, FunctionCode functionCode);
    
    
    /**
     * 更新狀態為"暫存中"的國外研修差旅費用資料。
     * 
     * <p>C1.5.6輸入國外研修差旅費用核銷申請資料</p>
     * 
     * <ul>
     * <li>重新產生分錄</li>
     * <li>儲存資料，不要存流程簽核</li> 
     * </ul> 
     *
     * <p>PRE</p>
     * <ul>
     * <li>費用申請單狀態為"暫存中"</li> 
     * </ul> 
     * 
     * <p>POST</p>
     * <ul>
     * <li>費用申請單狀態不變，一樣是"暫存中"</li> 
     * </ul>
     * 
     * @param exp
     * @param deleteEntryList TODO
     */
    void doUpdateTempOvsaTrvlLrnExp(OvsaTrvlLrnExp exp, List<Entry> deleteEntryList);
    
    
    /**
     * 確認國外研修差旅費用資料，將狀態改為"申請中"。
     * 
     * <p>C1.5.6輸入國外研修差旅費用核銷申請資料</p>
     * 
     * <ol>
     * <li>費用申請單狀態改為"申請中"</li> 
     * <li>重新產生分錄</li>
     * <li>儲存資料，存流程簽核</li> 
     * </ol>  
     * 
     * <p>PRE</p>
     * <ul>
     * <li>費用申請單狀態為"暫存中"</li> 
     * </ul> 
     * 
     * <p>POST</p>
     * <ul>
     * <li>費用申請單狀態改為"申請中"</li> 
     * </ul> 
     * 
     * @param exp 國外研修差旅費用
     * @param functionCode 功能代碼
     */
    void doConfirmOvsaTrvlLrnExp(OvsaTrvlLrnExp exp, FunctionCode functionCode); 
    
    /**
     * 更新-國外研修差旅費用資料
     * <p>C1.5.6輸入國外研修差旅費用核銷申請資料</p>
     * @param exp 國外研修差旅費用
     * @param functionCode 功能代碼
     * @param deleteEntryList 須刪除的分錄List
     */
    void doUpdateOvsaTrvlLrnExp(OvsaTrvlLrnExp exp, FunctionCode functionCode, List<Entry> deleteEntryList);
    
    /**
     * 依條件查詢國外研修差旅費用
     * <p>UC 1.6.4 研修差旅費用申請記錄表(含國外)</p>
     * <p>排序條件: 依「國外研修差旅費用.費用申請單. 建檔日期」遞增排序</p>
     * @param applStateEnum 申請單狀態Enum
     * @param department 成本單位
     * @param userCode 申請人員工代號
     * @param createDateStart 建檔期間起
     * @param createDateEnd 建檔期間迄
     * @return
     */
    List<OvsaTrvlLrnExp> findByParams(ApplStateEnum applStateEnum, 
            Department department, String userCode, 
            Calendar createDateStart, Calendar createDateEnd);
    
    /**
     * 依申請單狀態代碼找出國外研修差旅費用
     * @param applStateCode 申請單狀態
     * @return
     */
    List<OvsaTrvlLrnExp> findByApplStateCode(ApplStateCode applStateCode);
    
    /**
     * 依申請單號查出領款資料List
     * @param expApplNo 申請單單號
     * @return
     */
    List<OvsaExpDrawInfo> findOvsaExpDrawInfosByExpApplNo(String expApplNo);
    
    /**
     * 依申請單號查出國外研修差旅費用
     * @param expApplNo 申請單單號
     * @return
     */
    OvsaTrvlLrnExp findByExpApplNo(String expApplNo);
    
    /**
     * 依申請單號s查出國外研修差旅費用s
     * @param expApplNoList 申請單單號List
     * @return
     */
    List<OvsaTrvlLrnExp> findByExpApplNo(List<String> expApplNoList);
    
    /**
     * 新增國外研修差旅費用領款資料
     * @param ovsaExpDrawInfo 國外研修差旅費用領款資料
     * @return 
     */
    OvsaTrvlLrnExp doSaveOvsaExpDrawInfo(OvsaTrvlLrnExp ovsaTrvlLrnExp, OvsaExpDrawInfo ovsaExpDrawInfo);
    
    //RE201601162_國外出差旅費 EC0416 2016/05/24 start
    /**
     * 刪除該領款資料
     * @param ovsaExpDrawInfo 國外研修差旅費用領款資料
     * @return 
     */
    OvsaTrvlLrnExp doDeleteOvsaExpDrawInfo(OvsaTrvlLrnExp ovsaTrvlLrnExp, int index);
    //RE201601162_國外出差旅費 EC0416 2016/05/24 end
    
    /**
     * 新增駐在地點資料
     * @param exp 國外研修差旅費用
     * @param station 駐在地點
     * @return
     */
    OvsaTrvlLrnExp doSaveStation(OvsaTrvlLrnExp exp, Station station);
    
    /**
     * 新增日支費
     * @param exp 國外研修差旅費用
     * @param station 駐在地點
     * @param detail 駐在地點之費用明細
     * @return
     */
    OvsaTrvlLrnExp doSaveStationExpDetail(OvsaTrvlLrnExp exp, Station station, StationExpDetail detail);
    
    //RE201601162_國外出差旅費 EC0416  20160707 start
    /**
     * 刪除日支費
     * @param exp 國外研修差旅費用
     * @param station 駐在地點
     * @param detail 駐在地點之費用明細
     * @return
     */
    OvsaTrvlLrnExp doDeleteStationExpDetail(OvsaTrvlLrnExp exp, Station station, int index);
    //RE201601162_國外出差旅費 EC0416  20160707 end
    /**
     * 更新駐在地點資料
     * @param exp 國外研修差旅費用
     * @param station 駐在地點
     * @return
     */
    OvsaTrvlLrnExp doUpdateStation(OvsaTrvlLrnExp exp, Station station);
    
    //RE201601162_國外出差旅費 EC0416 2016/05/24 start
    /**
     * 刪除駐在地點資料
     * @param exp 國外研修差旅費用
     * @param delStation 駐在地點
     * @return
     */
    OvsaTrvlLrnExp doDeleteStation(OvsaTrvlLrnExp exp, int index);
    //RE201601162_國外出差旅費 EC0416 2016/05/24 end
    
    /**
     * 產生分錄資料與過渡付款明細
     * <p>C 1.5.6 輸入國外研修差旅費用核銷申請資料</p>
     * @param exp 國外研修差旅費用
     * @param expEntry 費用科目
     * @param impulsingAccTile 沖轉科目 RE201001687:201009 新增 BY文珊
     */
    void calculateEntry(OvsaTrvlLrnExp exp, Entry expEntry, PaymentType impulsingAccTile);
    
    /**
     * 新增分錄資料  RE201001687:201009 新增 BY文珊
     * @param exp 國外研修差旅費用
     * @param entry 分錄
     * @return
     */
    OvsaTrvlLrnExp doSaveEntry(OvsaTrvlLrnExp exp, Entry entry);
    
    /**
     * 更新分錄資料  RE201001687:201009 新增 BY文珊
     * @param exp 國外研修差旅費用
     * @param entry 分錄
     * @return
     */
    OvsaTrvlLrnExp doUpdateEntry(OvsaTrvlLrnExp exp, Entry entry);
    
    /**
     * 刪除分錄資料  RE201001687:201011 新增 BY文珊
     * @param exp 國外研修差旅費用
     * @param entry 分錄
     * @return
     */
    OvsaTrvlLrnExp doDeleteEntry(OvsaTrvlLrnExp exp, Entry entry);
    
    //RE201601162_國外出差旅費 EC0416 20160406 START
	void checkDate (OvsaTrvlLrnExp exp,Station station);
	
	/**
	 * 國外旅費頁面檢核
	 * @param exp
	 */
	void doValidateOvsaExp(OvsaTrvlLrnExp exp,Entry entry);
	//RE201601162_國外出差旅費 EC0416 20160406 end
}