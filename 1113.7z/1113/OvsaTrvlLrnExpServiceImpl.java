package tw.com.skl.exp.kernel.model6.logic.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.BeanUtils;

import tw.com.skl.common.model6.logic.impl.BaseServiceImpl;
import tw.com.skl.exp.kernel.model6.bo.AccTitle;
import tw.com.skl.exp.kernel.model6.bo.BudgetIn;
import tw.com.skl.exp.kernel.model6.bo.Department;
import tw.com.skl.exp.kernel.model6.bo.Entry;
import tw.com.skl.exp.kernel.model6.bo.EntryGroup;
import tw.com.skl.exp.kernel.model6.bo.ExpapplC;
import tw.com.skl.exp.kernel.model6.bo.ExpapplCDetail;
import tw.com.skl.exp.kernel.model6.bo.OvsaExpDrawInfo;
import tw.com.skl.exp.kernel.model6.bo.OvsaTrvlLrnExp;
import tw.com.skl.exp.kernel.model6.bo.PaymentType;
import tw.com.skl.exp.kernel.model6.bo.Station;
import tw.com.skl.exp.kernel.model6.bo.StationExpDetail;
import tw.com.skl.exp.kernel.model6.bo.TransitPaymentDetail;
import tw.com.skl.exp.kernel.model6.bo.User;
import tw.com.skl.exp.kernel.model6.bo.AccTitle.AccTitleCode;
import tw.com.skl.exp.kernel.model6.bo.ApplState.ApplStateCode;
import tw.com.skl.exp.kernel.model6.bo.BizMatter.BizMatterCode;
import tw.com.skl.exp.kernel.model6.bo.EntryType.EntryTypeCode;
import tw.com.skl.exp.kernel.model6.bo.EntryType.EntryTypeValueCode;
import tw.com.skl.exp.kernel.model6.bo.Function.FunctionCode;
import tw.com.skl.exp.kernel.model6.bo.IncomeIdType.IncomeIdTypeCode;
import tw.com.skl.exp.kernel.model6.bo.MiddleType.MiddleTypeCode;
import tw.com.skl.exp.kernel.model6.bo.PaymentTarget.PaymentTargetCode;
import tw.com.skl.exp.kernel.model6.bo.PaymentType.PaymentTypeCode;
import tw.com.skl.exp.kernel.model6.common.ErrorCode;
import tw.com.skl.exp.kernel.model6.common.exception.ExpRuntimeException;
import tw.com.skl.exp.kernel.model6.common.util.MessageUtils;
import tw.com.skl.exp.kernel.model6.common.util.NumberUtils;
import tw.com.skl.exp.kernel.model6.common.util.StringUtils;
import tw.com.skl.exp.kernel.model6.common.util.time.DateUtils;
import tw.com.skl.exp.kernel.model6.dao.OvsaTrvlLrnExpDao;
import tw.com.skl.exp.kernel.model6.facade.OvsaTrvlLrnExpFacade;
import tw.com.skl.exp.kernel.model6.logic.OvsaTrvlLrnExpService;
import tw.com.skl.exp.kernel.model6.logic.enumeration.ApplStateEnum;

/**
 * 國外研修差旅費用 Service 類別。
 * 
 * @author Smano Huang
 * @version 1.0, 2009/05/22
 */
public class OvsaTrvlLrnExpServiceImpl extends BaseServiceImpl<OvsaTrvlLrnExp, String, OvsaTrvlLrnExpDao> implements OvsaTrvlLrnExpService {

	protected Log logger = LogFactory.getLog(this.getClass());
	/** 國外研修差旅費用Facade */
	private OvsaTrvlLrnExpFacade facade;

	private String getMessage(String code) {
		return MessageUtils.getAccessor().getMessage(code);
	}

	public void doConfirmOvsaTrvlLrnExp(OvsaTrvlLrnExp exp, FunctionCode functionCode) {
		verifyExp(exp);
		if (null == functionCode) {
			throw new ExpRuntimeException(ErrorCode.A10007, new String[] { getMessage("tw_com_skl_exp_kernel_model6_bo_Function_code") });
		}
		Calendar sysDate = Calendar.getInstance();
		// set 中分類 = K30
		facade.getExpapplCService().setMiddleTypeByCode(exp.getExpapplC(), MiddleTypeCode.CODE_K30);
		if (!ApplStateCode.TEMP.getCode().equals(exp.getExpapplC().getApplState().getCode())) {
			// 若申請單狀態不為暫存,顯示<<申請單狀態錯誤>>
			throw new ExpRuntimeException(ErrorCode.A10041, new String[] { getMessage("tw_com_skl_exp_kernel_model6_bo_ApplState") });
		}
		// 設定「費用申請單.申請單狀態」=”申請中”
		facade.getExpapplCService().setApplStateByCode(exp.getExpapplC(), ApplStateCode.APPLIED);

		exp.getExpapplC().setUpdateUser(facade.getUserService().getLoggedInUser());
		exp.getExpapplC().setUpdateDate(sysDate);
		generateOvsaTrvlLrnExp(exp, functionCode, sysDate, 0);
	}

	public void doUpdateOvsaTrvlLrnExp(OvsaTrvlLrnExp exp, FunctionCode functionCode, List<Entry> deleteEntryList) {

		verifyTempOvsaTrvlLrnExp(exp);
		if (null == functionCode) {
			throw new ExpRuntimeException(ErrorCode.A10007, new String[] { getMessage("tw_com_skl_exp_kernel_model6_bo_Function_code") });
		}
		// 刪除分錄
		// this.facade.getExpapplCService().toDelEntrys(exp.getExpapplC(),
		// deleteEntryList);
		Calendar sysDate = Calendar.getInstance();
		generateOvsaTrvlLrnExp(exp, functionCode, sysDate, 1);
	}

	/**
	 * 產生國外研修差旅費用資料與記錄流程簽核歷程，並產生「過渡付款明細」
	 * 
	 * @param exp
	 *            國外研修差旅費用
	 * @param functionCode
	 *            功能代碼
	 * @param sysDate
	 *            系統時間
	 * @param state
	 *            0=create 1=update
	 */
	private void generateOvsaTrvlLrnExp(OvsaTrvlLrnExp exp, FunctionCode functionCode, Calendar sysDate, Integer state) {
		// 憑證金額(含) = 出差旅費合計
		exp.getExpapplC().setInvoiceAmt(exp.getAbrodTotalAmt());

		// 借貸是否平衡
		this.facade.getEntryGroupService().calcBalance(exp.getExpapplC().getEntryGroup());

		// 執行共用function《成本別為”W”時的控管》
		this.facade.getExpapplCService().handleCaseW(exp.getExpapplC());

		// 檢核行政費用申請單資料內容是否正確，包含各種規則
		this.facade.getExpapplCService().verifyExpapplC(exp.getExpapplC());

		processModifyOvsaTrvlExp(exp);

		facade.getEntryService().doCreateEntry(exp.getExpapplC().getEntryGroup().getEntries());
		/*
		 * 4. 儲存費用申請單，記錄流程簽核歷程，並產生「過渡付款明細」。  匯款時之金額為“明細金額”，非”申請金額”。 
		 * 執行共用function《產生過渡付款明細(付款對象為個人或單位)》
		 */
		// if (state == 0) {
		// this.getDao().update(exp);
		// } else if (state == 1) {
		// exp.getExpapplC().setUpdateDate(sysDate);
		// this.getDao().update(exp);
		// }

		List<Entry> entryList = null;
		if (null == exp.getExpapplC().getEntryGroup() || CollectionUtils.isEmpty(exp.getExpapplC().getEntryGroup().getEntries())) {
			throw new ExpRuntimeException(ErrorCode.C10064);
		} else {
			entryList = exp.getExpapplC().getEntryGroup().getEntries();
		}

		// RE201601162_國外出差旅費 EC0416 20160707 START
		// 分錄金額(借方)=付款金額=合計金額
		// 分錄的借方金額
		BigDecimal amtC = BigDecimal.ZERO;
		for (Entry entry : entryList) {
			if (EntryTypeCode.TYPE_2_3.getCode().equals(entry.getEntryType().getCode())) {
				amtC = amtC.add(entry.getAmt());
			}
		}
		if (amtC.compareTo(exp.getAbrodTotalAmt()) != 0) {
			throw new ExpRuntimeException(ErrorCode.C10643);
		}
		// RE201601162_國外出差旅費 EC0416 20160707 END

		Entry remitEntry = facade.getEntryService().getExpPayableEntry(entryList);

		// 產生過渡付款明細
		facade.getExpapplCService().generateTransitPaymentDetailByOvsaTrvlLrnExp(exp, remitEntry);

		// 記錄一筆流程簽核歷程
		this.facade.getFlowCheckstatusService().createByExpApplC(exp.getExpapplC(), functionCode, sysDate);
		this.getDao().update(exp);
	}

	/**
	 * 產生過渡付款明細
	 * 
	 * @param expapplC
	 *            行政費用申請單
	 * @param expEntry
	 *            應付費用科目的分錄(可null)
	 */
	@SuppressWarnings("unused")
	private void generateTransitPaymentDetail(ExpapplC expapplC, Entry expEntry) {
		if (PaymentTargetCode.PERSONAL.getCode().equals(expapplC.getPaymentTarget().getCode())) {
			if (null == expEntry) {
				this.facade.getTransitPaymentDetailService().generateTransitPaymentDetail(expapplC);
			} else {
				this.facade.getTransitPaymentDetailService().generateTransitPaymentDetail(expapplC, expEntry);
			}
		} else {
			throw new ExpRuntimeException(ErrorCode.A10007, new String[] { MessageUtils.getAccessor().getMessage("tw_com_skl_exp_kernel_model6_bo_ExpapplC_paymentTarget") });
		}

	}

	private void verifyExp(OvsaTrvlLrnExp exp) {
		// 基礎檢核欄位是否有填入
		verifyTempOvsaTrvlLrnExp(exp);
		// TODO
	}

	private void verifyTempOvsaTrvlLrnExp(OvsaTrvlLrnExp exp) {
		if (null == exp) {
			throw new ExpRuntimeException(ErrorCode.A10007, new String[] { this.getMessage("tw_com_skl_exp_kernel_model6_bo_OvsaTrvlLrnExp") });
		}
		if (null == exp.getExpapplC()) {
			throw new ExpRuntimeException(ErrorCode.A10007, new String[] { getMessage("tw_com_skl_exp_kernel_model6_bo_OvsaTrvlLrnExp_expapplC") });
		}
		if (null == exp.getExpapplC().getApplyUserInfo()) {
			throw new ExpRuntimeException(ErrorCode.A10007, new String[] { getMessage("tw_com_skl_exp_kernel_model6_bo_ExpapplC_applyUserInfo") });
		}
		if (StringUtils.isBlank(exp.getExpapplC().getExpYears())) {
			throw new ExpRuntimeException(ErrorCode.A10001, new String[] { getMessage("tw_com_skl_exp_kernel_model6_bo_ExpapplC_expYears") });
		}
		if (null == exp.getExpapplC().getPaymentType()) {
			throw new ExpRuntimeException(ErrorCode.A10007, new String[] { getMessage("tw_com_skl_exp_kernel_model6_bo_ExpapplC_paymentType") });
		}
		if (null == exp.getExpapplC().getPaymentTarget()) {
			throw new ExpRuntimeException(ErrorCode.A10007, new String[] { getMessage("tw_com_skl_exp_kernel_model6_bo_ExpapplC_paymentTarget") });
		}
		if (null == exp.getExpapplC().getExpType()) {
			throw new ExpRuntimeException(ErrorCode.A10007, new String[] { getMessage("tw_com_skl_exp_kernel_model6_bo_ExpapplC_expType") });
		}

		// 檢核-出國年月日起
		if (null == exp.getAbroadStartDate()) {
			throw new ExpRuntimeException(ErrorCode.A10001, new String[] { getMessage("tw_com_skl_exp_kernel_model6_bo_OvsaTrvlLrnExp_abroadStartDate") });
		}

		// 檢核-出國年月日迄
		if (null == exp.getAbroadEndDate()) {
			throw new ExpRuntimeException(ErrorCode.A10001, new String[] { getMessage("tw_com_skl_exp_kernel_model6_bo_OvsaTrvlLrnExp_abroadEndDate") });
		}

		// 檢核-出國事由
		if (StringUtils.isBlank(exp.getAbroadReason())) {
			throw new ExpRuntimeException(ErrorCode.A10001, new String[] { getMessage("tw_com_skl_exp_bo_OvsaTrvlLrnExp_Reason") });
		}

		// 檢核-交通費合計
		if (null == exp.getTrafficTotalExp()) {
			throw new ExpRuntimeException(ErrorCode.A10001, new String[] { getMessage("tw_com_skl_exp_kernel_model6_bo_OvsaTrvlLrnExp_trafficTotalExp") });
		}

		// 檢核-宿泊費合計
		if (null == exp.getHotelTotalExp()) {
			throw new ExpRuntimeException(ErrorCode.A10001, new String[] { getMessage("tw_com_skl_exp_kernel_model6_bo_OvsaTrvlLrnExp_hotelTotalExp") });
		}

		// 檢核-雜費合計
		if (null == exp.getMiscellaneousTotalExp()) {
			throw new ExpRuntimeException(ErrorCode.A10001, new String[] { getMessage("tw_com_skl_exp_kernel_model6_bo_OvsaTrvlLrnExp_miscellaneousTotalExp") });
		}

		// 檢核-出差旅費合計
		if (null == exp.getAbrodTotalAmt()) {
			throw new ExpRuntimeException(ErrorCode.A10001, new String[] { getMessage("tw_com_skl_exp_kernel_model6_bo_OvsaTrvlLrnExp_abrodTotalAmt") });
		}

		// 檢核-依規免稅額
		if (null == exp.getGaugeDutyFreeAmt()) {
			throw new ExpRuntimeException(ErrorCode.A10001, new String[] { getMessage("tw_com_skl_exp_kernel_model6_bo_OvsaTrvlLrnExp_gaugeDutyFreeAmt") });
		}

		// 檢核-併薪額
		if (null == exp.getSalaryAmt()) {
			throw new ExpRuntimeException(ErrorCode.A10001, new String[] { getMessage("tw_com_skl_exp_kernel_model6_bo_OvsaTrvlLrnExp_salaryAmt") });
		}

		// 檢核-駐在日數
		if (null == exp.getDaytime()) {
			throw new ExpRuntimeException(ErrorCode.A10001, new String[] { getMessage("tw_com_skl_exp_kernel_model6_bo_OvsaTrvlLrnExp_daytime") });
		}

		// 檢核-天數(出差天數)
		if (null == exp.getDaytimeNo()) {
			throw new ExpRuntimeException(ErrorCode.A10001, new String[] { getMessage("tw_com_skl_exp_kernel_model6_bo_OvsaTrvlLrnExp_daytimeNo") });
		}
		if (!NumberUtils.checkDecimalLength(exp.getDaytimeNo().toString(), 1)) {
			// 檢核-天數(出差天數) 最多只能輸入小數至1位
			throw new ExpRuntimeException(ErrorCode.C10338, new String[] { MessageUtils.getAccessor().getMessage("tw_com_skl_exp_kernel_model6_bo_OvsaTrvlLrnExp_daytimeNo"), "1" });
		}
		// 檢核-夜數(出差夜數)
		if (null == exp.getNighttimeNo()) {
			throw new ExpRuntimeException(ErrorCode.A10001, new String[] { getMessage("tw_com_skl_exp_kernel_model6_bo_OvsaTrvlLrnExp_nighttimeNo") });
		}
		if (!NumberUtils.checkDecimalLength(exp.getNighttimeNo().toString(), 1)) {
			// 檢核-夜數(出差夜數) 最多只能輸入小數至1位
			throw new ExpRuntimeException(ErrorCode.C10338, new String[] { MessageUtils.getAccessor().getMessage("tw_com_skl_exp_kernel_model6_bo_OvsaTrvlLrnExp_nighttimeNo"), "1" });
		}

		// 檢核-美金兌換率
		if (null == exp.getExchangeRateUS()) {
			throw new ExpRuntimeException(ErrorCode.A10001, new String[] { getMessage("tw_com_skl_exp_kernel_model6_bo_OvsaTrvlLrnExp_exchangeRateUS") });
		}

		// 檢核-美金兌換率 不可為0
		if (BigDecimal.ZERO.compareTo(exp.getExchangeRateUS()) >= 0) {
			throw new ExpRuntimeException(ErrorCode.A10038, new String[] { getMessage("tw_com_skl_exp_kernel_model6_bo_OvsaTrvlLrnExp_exchangeRateUS") });
		}

		if (null == exp.getBizMatter()) {
			throw new ExpRuntimeException(ErrorCode.A10001, new String[] { getMessage("tw_com_skl_exp_kernel_model6_bo_OvsaTrvlLrnExp_bizMatter") });
		}

		if (exp.getBizMatter().getCode().equals(BizMatterCode.OVSA_SUMMIT_CONFERENCE.getCode())) {
			if (BigDecimal.ZERO.compareTo(exp.getDailySpendTotalAmt()) < 0) {
				throw new ExpRuntimeException(ErrorCode.C10637);
			}
		}
	}

	private OvsaTrvlLrnExp getUpdatingData() {
		// TODO Auto-generated method stub
		return null;
	}

	public void doCreateTempOvsaTrvlLrnExp(OvsaTrvlLrnExp exp, Entry expEntry, FunctionCode functionCode) {
		// 主頁面檢核
		doValidateOvsaExp(exp, expEntry);
		verifyTempOvsaTrvlLrnExp(exp);

		if (null == functionCode) {
			throw new ExpRuntimeException(ErrorCode.A10007, new String[] { getMessage("tw_com_skl_exp_kernel_model6_bo_Function_code") });
		}

		Calendar sysDate = Calendar.getInstance();
		if (null == exp.getExpapplC().getEntryGroup()) {
			exp.getExpapplC().setEntryGroup(new EntryGroup());
		}
		expEntry.setEntryGroup(exp.getExpapplC().getEntryGroup());
		if (CollectionUtils.isEmpty(exp.getExpapplC().getEntryGroup().getEntries())) {
			exp.getExpapplC().getEntryGroup().setEntries(new ArrayList<Entry>());
		}

		// RE201701039 國外出差系統優化作業第二階段 EC0416 start
		// 設定「費用申請單.申請單狀態」=”申請中”
		// facade.getExpapplCService().setApplStateByCode(exp.getExpapplC(),
		// ApplStateCode.APPLIED);
		facade.getExpapplCService().setApplStateByCode(exp.getExpapplC(), ApplStateCode.TEMP);
		// RE201701039 國外出差系統優化作業第二階段 EC0416 end
		// 費用中分類=K30_研修差旅費用(國外)
		facade.getExpapplCService().setMiddleTypeByCode(exp.getExpapplC(), MiddleTypeCode.CODE_K30);
		// 執行共用function《成本別為”W”時的控管》
		this.facade.getExpapplCService().handleCaseW(exp.getExpapplC());
		// 檢核行政費用申請單資料內容是否正確，包含各種規則
		this.facade.getExpapplCService().verifyExpapplC(exp.getExpapplC());

		// 產生 申請單號
		exp.getExpapplC().setExpApplNo(this.facade.getExpapplCService().generateExpApplNo(exp.getExpapplC().getMiddleType().getCode()));
		// 設定建檔日期於申請單內
		exp.getExpapplC().setCreateDate(sysDate);
		// 設定建檔人員於申請單內
		exp.getExpapplC().setCreateUser(this.facade.getUserService().getLoggedInUser());

		// 如果成本別欄位為空白則在費用申請單的成本別填""
		if (StringUtils.isBlank(exp.getExpapplC().getCostTypeCode())) {
			exp.getExpapplC().setCostTypeCode(" ");
		}

		List<Entry> entryList = null;
		if (null == exp.getExpapplC().getEntryGroup() || CollectionUtils.isEmpty(exp.getExpapplC().getEntryGroup().getEntries())) {
			throw new ExpRuntimeException(ErrorCode.C10064);
		} else {
			entryList = exp.getExpapplC().getEntryGroup().getEntries();
		}

		// RE201601162_國外出差旅費 EC0416 20160707 START
		// 分錄金額(借方)=付款金額=合計金額
		// 分錄的借方金額
		BigDecimal amtC = BigDecimal.ZERO;
		for (Entry entry : entryList) {
			if (EntryTypeCode.TYPE_2_3.getCode().equals(entry.getEntryType().getCode())) {
				amtC = amtC.add(entry.getAmt());
			}
		}
		if (amtC.compareTo(exp.getAbrodTotalAmt()) != 0) {
			throw new ExpRuntimeException(ErrorCode.C10643);
		}
		// RE201601162_國外出差旅費 EC0416 20160707 END

		Entry remitEntry = facade.getEntryService().getExpPayableEntry(entryList);
		// 產生過渡付款明細
		facade.getExpapplCService().generateTransitPaymentDetailByOvsaTrvlLrnExp(exp, remitEntry);

		this.getDao().create(exp);
		// 記錄一筆流程簽核歷程
		facade.getFlowCheckstatusService().createByExpApplC(exp.getExpapplC(), functionCode, sysDate);
	}

	public void doUpdateTempOvsaTrvlLrnExp(OvsaTrvlLrnExp exp, List<Entry> deleteEntryList) {
		verifyTempOvsaTrvlLrnExp(exp);

		Calendar sysDate = Calendar.getInstance();
		// 刪除分錄
		// this.facade.getExpapplCService().toDelEntrys(exp.getExpapplC(),
		// deleteEntryList);
		exp.getExpapplC().setUpdateDate(sysDate);
		exp.getExpapplC().setUpdateUser(this.facade.getUserService().getLoggedInUser());
		if (StringUtils.isBlank(exp.getExpapplC().getCostTypeCode())) {
			exp.getExpapplC().setCostTypeCode(" ");
		}
		this.getDao().update(exp);
	}

	public List<OvsaTrvlLrnExp> findTempOvsaTrvlLrnExp(User createUser) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<OvsaTrvlLrnExp> findByParams(ApplStateEnum applStateEnum, Department department, String userCode, Calendar createDateStart, Calendar createDateEnd) {
		ApplStateCode applStateCode = null;
		ApplStateCode[] applStateCodes = null;
		// 申請單狀態
		if (null != applStateEnum) {
			if (applStateEnum.equals(ApplStateEnum.NOT_VERIFICATION_SEND)) {
				applStateCode = ApplStateCode.APPLIED;

			}

			if (applStateEnum.equals(ApplStateEnum.VERIFICATION_SEND)) {
				applStateCodes = new ApplStateCode[2];
				applStateCodes[0] = ApplStateCode.APPLIED;
				applStateCodes[1] = ApplStateCode.DELETED;
			}
		}

		return getDao().findByParams(applStateCode, department, userCode, createDateStart, createDateEnd, applStateCodes);
	}

	public List<OvsaTrvlLrnExp> findByApplStateCode(ApplStateCode applStateCode) {
		return getDao().findByParams(applStateCode, null, null, null, null, null);
	}

	/**
	 * @return 國外研修差旅費用Facade
	 */
	public OvsaTrvlLrnExpFacade getFacade() {
		return facade;
	}

	/**
	 * @param 國外研修差旅費用Facade
	 */
	public void setFacade(OvsaTrvlLrnExpFacade facade) {
		this.facade = facade;
	}

	public List<OvsaExpDrawInfo> findOvsaExpDrawInfosByExpApplNo(String expApplNo) {
		OvsaTrvlLrnExp exp = getDao().findByExpApplNo(expApplNo);
		if (null != exp && !CollectionUtils.isEmpty(exp.getOvsaExpDrawInfos())) {
			return exp.getOvsaExpDrawInfos();
		}
		return null;
	}

	public OvsaTrvlLrnExp findByExpApplNo(String expApplNo) {
		return getDao().findByExpApplNo(expApplNo);
	}

	// RE201601162_國外出差旅費 EC0416 20160707 start
	public OvsaTrvlLrnExp doDeleteOvsaExpDrawInfo(OvsaTrvlLrnExp exp, int index) {
		if (null == exp) {
			throw new ExpRuntimeException(ErrorCode.A10007, new String[] { this.getMessage("tw_com_skl_exp_kernel_model6_bo_OvsaTrvlLrnExp") });
		}
		// 移除關聯
		exp.getOvsaExpDrawInfos().remove(index);
		return exp;
	}

	// RE201601162_國外出差旅費 EC0416 20160707 end

	public OvsaTrvlLrnExp doSaveOvsaExpDrawInfo(OvsaTrvlLrnExp exp, OvsaExpDrawInfo ovsaExpDrawInfo) {
		if (null == exp) {
			throw new ExpRuntimeException(ErrorCode.A10007, new String[] { this.getMessage("tw_com_skl_exp_kernel_model6_bo_OvsaTrvlLrnExp") });
		}
		if (CollectionUtils.isEmpty(exp.getOvsaExpDrawInfos())) {
			exp.setOvsaExpDrawInfos(new ArrayList<OvsaExpDrawInfo>());
		}
		// 設定與國外研修差旅費用之間的關聯
		ovsaExpDrawInfo.setOvsaTrvlLrnExp(exp);
		// 新增領款資料
		facade.getOvsaExpDrawInfoService().doSaveOvsaExpDrawInfo(ovsaExpDrawInfo);

		// 加入關聯
		exp.getOvsaExpDrawInfos().add(ovsaExpDrawInfo);

		return exp;

	}

	// RE201601162_國外出差旅費 EC0416 20160707 start
	public OvsaTrvlLrnExp doDeleteStation(OvsaTrvlLrnExp exp, int index) {
		if (null == exp) {
			throw new ExpRuntimeException(ErrorCode.A10007, new String[] { this.getMessage("tw_com_skl_exp_kernel_model6_bo_OvsaTrvlLrnExp") });
		}
		// if (null == delStation)
		// {
		// throw new ExpRuntimeException(ErrorCode.A10007, new String[] {
		// this.getMessage("tw_com_skl_exp_kernel_model6_bo_Station") });
		// }

		// 移除關聯
		exp.getStations().remove(index);
		caculateAmt(exp);
		return exp;
	}

	// RE201601162_國外出差旅費 EC0416 20160707 end

	public OvsaTrvlLrnExp doSaveStation(OvsaTrvlLrnExp exp, Station station) {
		if (null == exp) {
			throw new ExpRuntimeException(ErrorCode.A10007, new String[] { this.getMessage("tw_com_skl_exp_kernel_model6_bo_OvsaTrvlLrnExp") });
		}
		if (null == station) {
			throw new ExpRuntimeException(ErrorCode.A10007, new String[] { this.getMessage("tw_com_skl_exp_kernel_model6_bo_Station") });
		}

		if (CollectionUtils.isEmpty(exp.getStations())) {
			exp.setStations(new ArrayList<Station>());
		}
		// 設定與國外研修差旅費用之間的關聯
		station.setOvsaTrvlLrnExp(exp);

		// 新增-駐在地點
		facade.getStationService().doSaveStation(station);

		// 加入關聯
		exp.getStations().add(station);
		caculateAmt(exp);
		return exp;

	}

	public OvsaTrvlLrnExp doUpdateStation(OvsaTrvlLrnExp exp, Station station) {
		if (null == exp) {
			throw new ExpRuntimeException(ErrorCode.A10007, new String[] { this.getMessage("tw_com_skl_exp_kernel_model6_bo_OvsaTrvlLrnExp") });
		}
		if (null == station) {
			throw new ExpRuntimeException(ErrorCode.A10007, new String[] { this.getMessage("tw_com_skl_exp_kernel_model6_bo_Station") });
		}

		for (Station station2 : exp.getStations()) {
			if (StringUtils.equals(station2.getId(), station.getId())) {
				// 更新-駐在地點
				station2 = doCaculateAmtByStation(station);
				break;
			}
		}

		caculateAmt(exp);
		return exp;

	}

	public OvsaTrvlLrnExp doSaveEntry(OvsaTrvlLrnExp exp, Entry entry) {
		if (null == exp) {
			throw new ExpRuntimeException(ErrorCode.A10007, new String[] { this.getMessage("tw_com_skl_exp_kernel_model6_bo_OvsaTrvlLrnExp") });
		}
		if (null == entry) {
			throw new ExpRuntimeException(ErrorCode.A10007, new String[] { this.getMessage("tw_com_skl_exp_kernel_model6_bo_Entry") });
		}

		// 判斷會計科目是否為扣繳類
		boolean isWithhodeType = facade.getAccTitleService().isWithholdType(entry.getAccTitle());
		if (isWithhodeType) {
			if (StringUtils.isBlank(entry.getIncomeIdType()) || entry.getIncomeIdType() == null) {
				throw new ExpRuntimeException(ErrorCode.A10035, new String[] { entry.getAccTitle().getCode() });
			} else {
				// 檢核所得人證號
				facade.getIncomeUserService().isIncomeUserDataLegal(entry.getIncomeIdType(), entry.getIncomeId());
			}
		}

		if (CollectionUtils.isEmpty(exp.getExpapplC().getEntryGroup().getEntries())) {
			exp.getExpapplC().getEntryGroup().setEntries(new ArrayList<Entry>());
		}

		// 加入關聯
		entry.setEntryGroup(exp.getExpapplC().getEntryGroup());
		exp.getExpapplC().getEntryGroup().getEntries().add(entry);

		return exp;

	}

	public OvsaTrvlLrnExp doDeleteEntry(OvsaTrvlLrnExp exp, Entry entry) {
		if (null == exp) {
			throw new ExpRuntimeException(ErrorCode.A10007, new String[] { this.getMessage("tw_com_skl_exp_kernel_model6_bo_OvsaTrvlLrnExp") });
		}
		// 移除關聯
		exp.getExpapplC().getEntryGroup().getEntries().remove(entry);

		return exp;
	}

	public OvsaTrvlLrnExp doUpdateEntry(OvsaTrvlLrnExp exp, Entry entry) {
		if (null == exp) {
			throw new ExpRuntimeException(ErrorCode.A10007, new String[] { this.getMessage("tw_com_skl_exp_kernel_model6_bo_OvsaTrvlLrnExp") });
		}
		if (null == entry) {
			throw new ExpRuntimeException(ErrorCode.A10007, new String[] { this.getMessage("tw_com_skl_exp_kernel_model6_bo_Entry") });
		}

		// 判斷會計科目是否為扣繳類
		boolean isWithhodeType = facade.getAccTitleService().isWithholdType(entry.getAccTitle());
		if (isWithhodeType) {
			if (StringUtils.isBlank(entry.getIncomeIdType()) || entry.getIncomeIdType() == null) {
				throw new ExpRuntimeException(ErrorCode.A10035, new String[] { entry.getAccTitle().getCode() });
			} else {
				// 檢核所得人證號
				facade.getIncomeUserService().isIncomeUserDataLegal(entry.getIncomeIdType(), entry.getIncomeId());
			}
		}

		// 更新日期
		exp.getExpapplC().setUpdateDate(Calendar.getInstance());
		// 更新使用者
		exp.getExpapplC().setUpdateUser(facade.getUserService().getLoggedInUser());
		return this.update(exp);
	}

	/**
	 * 計算金額[日支費合計, 日用費合計, 宿泊費合計, 雜費合計, 交通費合計, 依規免稅額, 出差旅費合計, 併薪額]
	 * 
	 * @param exp
	 */
	private void caculateAmt(OvsaTrvlLrnExp exp) {
		if (null == exp) {
			return;
		}

		// 日支費合計
		BigDecimal dailyExpTotalAmt = BigDecimal.ZERO;
		// 日用費合計
		BigDecimal dailySpendTotalAmt = BigDecimal.ZERO;
		// 宿泊費合計
		BigDecimal hotelTotalExp = BigDecimal.ZERO;
		// 雜費合計
		BigDecimal miscellaneousTotalExp = BigDecimal.ZERO;
		// 交通費合計
		BigDecimal trafficTotalExp = BigDecimal.ZERO;
		// 出差旅費合計
		BigDecimal abrodTotalAmt = BigDecimal.ZERO;
		// 依規免稅額
		BigDecimal gaugeDutyFreeAmt = BigDecimal.ZERO;
		// 併薪額
		BigDecimal salaryAmt = BigDecimal.ZERO;

		// 計算金額
		if (!CollectionUtils.isEmpty(exp.getStations())) {
			for (Station station : exp.getStations()) {
				// 日支費
				dailyExpTotalAmt = dailyExpTotalAmt.add(station.getDailyExp());
				// 日用費
				dailySpendTotalAmt = dailySpendTotalAmt.add(station.getDailySpend());
				// 宿泊費
				hotelTotalExp = hotelTotalExp.add(facade.getStationService().doCaculateHotelTotalExp(station));
				// 雜費
				miscellaneousTotalExp = miscellaneousTotalExp.add(facade.getStationService().doCaculateMiscellaneousTotalExp(station));
				// 交通費
				trafficTotalExp = trafficTotalExp.add(facade.getStationService().doCaculateTrafficTotalExp(station));
			}
		}

		// 依規免稅額　= 日支費(合計各駐在地點) +(國外申請單.「交通費、宿泊費、雜費」合計)
		gaugeDutyFreeAmt = gaugeDutyFreeAmt.add(dailyExpTotalAmt).add(hotelTotalExp).add(miscellaneousTotalExp).add(trafficTotalExp);
		// 併薪額：日用費(合計各駐在地點) 減 日支費(合計各駐在地點)　若差額大於0，其差額即為併薪額；反之，若差額小於、等於０，則無併薪額。
		salaryAmt = salaryAmt.add(dailySpendTotalAmt).subtract(dailyExpTotalAmt);
		if (BigDecimal.ZERO.compareTo(salaryAmt) >= 0) {
			// 差額小於、等於０，則無併薪額。
			salaryAmt = BigDecimal.ZERO;
		}

		// 若日用費合計>日支費合計
		if (dailySpendTotalAmt.compareTo(dailyExpTotalAmt) > 0) {
			// 出差旅費合計 = 依規免稅額+併薪額
			abrodTotalAmt = gaugeDutyFreeAmt.add(salaryAmt);
		}

		// 若日用費合計<日支費合計
		if (dailySpendTotalAmt.compareTo(dailyExpTotalAmt) < 0) {
			// 出差旅費合計 =日用費(合計各駐在地點)+(合計各駐在地點的「交通費、宿泊費、雜費、」
			abrodTotalAmt = dailySpendTotalAmt.add(hotelTotalExp).add(miscellaneousTotalExp).add(trafficTotalExp);
		}

		// Set totalAmount....
		exp.setDailyExpTotalAmt(dailyExpTotalAmt);
		exp.setDailySpendTotalAmt(dailySpendTotalAmt);
		exp.setHotelTotalExp(hotelTotalExp);
		exp.setMiscellaneousTotalExp(miscellaneousTotalExp);
		exp.setTrafficTotalExp(trafficTotalExp);

		exp.setGaugeDutyFreeAmt(gaugeDutyFreeAmt);
		exp.setAbrodTotalAmt(abrodTotalAmt);
		exp.setSalaryAmt(salaryAmt);
	}

	public List<OvsaTrvlLrnExp> findByExpApplNo(List<String> expApplNoList) {
		return getDao().findByExpApplNo(expApplNoList);
	}

	public OvsaTrvlLrnExp doSaveStationExpDetail(OvsaTrvlLrnExp exp, Station station, StationExpDetail detail) {
		if (null == exp) {
			throw new ExpRuntimeException(ErrorCode.A10007, new String[] { this.getMessage("tw_com_skl_exp_kernel_model6_bo_OvsaTrvlLrnExp") });
		}
		if (null == station) {
			throw new ExpRuntimeException(ErrorCode.A10007, new String[] { this.getMessage("tw_com_skl_exp_kernel_model6_bo_Station") });
		}
		if (null == detail) {
			throw new ExpRuntimeException(ErrorCode.A10007, new String[] { this.getMessage("tw_com_skl_exp_kernel_model6_bo_StationExpDetail") });
		}

		facade.getStationExpDetailService().verifyStationExpDetail(detail);

		// 當付款方式 = 沖轉暫付 時 銷帳碼只能有一個(但相同銷帳碼OK)
		if (StringUtils.equals(PaymentTypeCode.C_CHANGE_TEMP_PAY.getCode(), detail.getPaymentType().getCode())) {
			// 查出 駐在地點之費用明細 , 付款方式 = 沖轉暫付
			List<StationExpDetail> list = facade.getStationExpDetailService().findByParams(exp.getExpapplC().getExpApplNo(), PaymentTypeCode.C_CHANGE_TEMP_PAY, null);

			if (!CollectionUtils.isEmpty(list)) {
				for (StationExpDetail stationExpDetail : list) {
					if (!StringUtils.equals(detail.getCancelCode(), stationExpDetail.getCancelCode())) {
						// 銷帳碼不相同則顯示<<沖轉暫付只能有一個相同的銷帳碼>>
						throw new ExpRuntimeException(ErrorCode.C10403);
					}
				}
			}
		}

		doSaveStationExpDetail(station, detail);
		caculateAmt(exp);

		return exp;
	}

	// 0715 start
	public OvsaTrvlLrnExp doDeleteStationExpDetail(OvsaTrvlLrnExp exp, Station station, int index) {
		if (null == exp) {
			throw new ExpRuntimeException(ErrorCode.A10007, new String[] { this.getMessage("tw_com_skl_exp_kernel_model6_bo_OvsaTrvlLrnExp") });
		}
		if (null == station) {
			throw new ExpRuntimeException(ErrorCode.A10007, new String[] { this.getMessage("tw_com_skl_exp_kernel_model6_bo_Station") });
		}
		// if (null == detail)
		// {
		// throw new ExpRuntimeException(ErrorCode.A10007, new String[] {
		// this.getMessage("tw_com_skl_exp_kernel_model6_bo_StationExpDetail")
		// });
		// }

		// 0802 start
		// for (Station station2 : exp.getStations())
		// {
		// if (StringUtils.equals(station2.getId(), station.getId()))
		// {
		// 刪除日支費並更新-駐在地點
		// station2.getStationExpDetails().remove(index);
		// BeanUtils.copyProperties(station2, station);
		// break;
		// }
		// }

		station.getStationExpDetails().remove(index);
		// 0802 end

		caculateAmt(exp);

		return exp;
	}

	// 0715 end

	private Station doCaculateAmtByStation(Station station) {
		verifyStation(station);

		// 計算-雜費
		station.setMiscExp(facade.getStationService().doCaculateMiscellaneousTotalExp(station));

		// 計算-宿泊費
		station.setStayExp(facade.getStationService().doCaculateHotelTotalExp(station));

		// 計算-交通費
		station.setTrafficExp(facade.getStationService().doCaculateTrafficTotalExp(station));
		return station;
	}

	private void verifyStation(Station station) {
		if (null == station) {
			throw new ExpRuntimeException(ErrorCode.A10007, new String[] { getMessage("tw_com_skl_exp_kernel_model6_bo_Station") });
		}

		/*
		 * 檢核輸入”駐在起迄期間”需有值，若否，則顯示《須輸入駐在起迄期間》訊息，且不可暫存。
		 */
		if (null == station.getStationStartDate() || null == station.getStationEndDate()) {
			throw new ExpRuntimeException(ErrorCode.A10001, new String[] { getMessage("tw_com_skl_exp_kernel_model6_bo_Station_stationStartEndDate") });
		}

		/*
		 * 檢核”日用費”欄位值不可為空白，若為空白，則顯示《日用費不可為空白》訊息，且不可暫存。
		 */
		if (null == station.getDailySpend()) {
			throw new ExpRuntimeException(ErrorCode.A10001, new String[] { getMessage("tw_com_skl_exp_kernel_model6_bo_Station_dailySpend") });
		}

		if (null == station.getIValue()) {
			throw new ExpRuntimeException(ErrorCode.A10001, new String[] { getMessage("tw_com_skl_exp_kernel_model6_bo_Station_iValue") });
		}

		BigDecimal one = new BigDecimal("1");

		if (one.compareTo(station.getIValue()) < 0) {
			// i值僅能輸入0.1~1
			throw new ExpRuntimeException(ErrorCode.C10337, new String[] { getMessage("tw_com_skl_exp_kernel_model6_bo_Station_iValue"), "0.01~1" });
		}
	}

	private Station doSaveStationExpDetail(Station station, StationExpDetail detail) {

		verifyStation(station);
		facade.getStationExpDetailService().verifyStationExpDetail(detail);

		if (CollectionUtils.isEmpty(station.getStationExpDetails())) {
			station.setStationExpDetails(new ArrayList<StationExpDetail>());
		}

		detail.setStation(station);
		station.getStationExpDetails().add(detail);
		facade.getStationExpDetailService().doSaveStationExpDetail(detail);

		return doCaculateAmtByStation(station);
	}

	public Station doDeleteStationExpDetail(Station station, StationExpDetail detail) {
		if (null == station) {
			throw new ExpRuntimeException(ErrorCode.A10007, new String[] { getMessage("tw_com_skl_exp_kernel_model6_bo_Station") });
		}
		if (null == detail) {
			throw new ExpRuntimeException(ErrorCode.A10007, new String[] { getMessage("tw_com_skl_exp_kernel_model6_bo_StationExpDetail") });
		}
		// 移除關聯
		station.getStationExpDetails().remove(detail);
		// 刪除日支費
		// facade.getStationExpDetailService().doDeleteStationExpDetail(detail);

		return station;
	}

	public void calculateEntry(OvsaTrvlLrnExp exp, Entry expEntry, PaymentType impulsingAccTile) {
		if (null == exp) {
			throw new ExpRuntimeException(ErrorCode.A10007, new String[] { this.getMessage("tw_com_skl_exp_kernel_model6_bo_OvsaTrvlLrnExp") });
		}
		if (null == exp.getBizMatter()) {
			throw new ExpRuntimeException(ErrorCode.A10007, new String[] { this.getMessage("tw_com_skl_exp_kernel_model6_bo_OvsaTrvlLrnExp_bizMatter") });
		}

		Department depCode = facade.getDepartmentService().findByCode(expEntry.getCostUnitCode());
		if (null == depCode) {
			throw new ExpRuntimeException(ErrorCode.C10013);
		}

		// 如果出差事由為國外高峰會議，則日用費不得請領，跳出錯誤訊息
		if (exp.getBizMatter().getCode().equals(BizMatterCode.OVSA_SUMMIT_CONFERENCE.getCode())) {
			if (BigDecimal.ZERO.compareTo(exp.getDailySpendTotalAmt()) < 0) {
				throw new ExpRuntimeException(ErrorCode.C10637);
			}
		}

		/*
		 * 【檢核】 1.檢核「依規免稅額、日用費合計、日支費合計」不可為0，若為0，
		 * 顯示《「依規免稅額、日用費合計、日支費合計」不可為0，請確認駐在地點費用已全數輸入》訊息， 且不需產生國外出差分錄。
		 * 
		 * modify 2010/02/03 修改「依規免稅額、日用費合計、日支費合計」可為0 , By Eustace
		 */
		if (null == exp.getGaugeDutyFreeAmt() || BigDecimal.ZERO.compareTo(exp.getGaugeDutyFreeAmt()) > 0 || null == exp.getDailySpendTotalAmt() || BigDecimal.ZERO.compareTo(exp.getDailySpendTotalAmt()) > 0 || null == exp.getDailyExpTotalAmt() || BigDecimal.ZERO.compareTo(exp.getDailyExpTotalAmt()) > 0) {
			// 顯示《「依規免稅額、日用費合計、日支費合計」不可為0，請確認駐在地點費用已全數輸入》訊息
			throw new ExpRuntimeException(ErrorCode.C10386);
		}
		// 檢核新增駐在地點與行程總計檢核
		checkCaculateAmt(exp);

		List<Entry> entryList = new ArrayList<Entry>();
		Entry tempExpEntry = new Entry();
		BeanUtils.copyProperties(expEntry, tempExpEntry);

		/*
		 *  國外差旅分錄產生方式 ※ 若日用費合計 > 日支費合計 (需累計各駐在地點)  (1)以「依規免稅額」產生
		 * 借方62040223國外研修旅費  (2)有併薪額 產生借方61130223人事-薪津-其他-職員薪津-婚喪禮金或國外旅費併薪，
		 * 其科目金額為頁面上的「併薪額」欄位值  (3)併薪額達起扣額產生貸方20210235應付代收款，所得人類別為「員工代號」、
		 * 所得人證號為「費用申請單.申請人員工代號」  (4)
		 * 若於日支費頁面付款方式選擇「沖轉暫付」，以輸入之銷帳碼產生貸方10522102科目(暫付-旅費借支)
		 * ，科目金額僅能為該銷帳碼可沖轉餘額為上限，產生暫付科目需先扣除20210235應付代收款科目金額後 ，再產生暫付科目及其金額。  (5)
		 * 若借方總額 – 貸方科目仍有差額時，系統自動補「應付費用-待匯」科目及金額。 (4)、(5)需求單修改，請參考" ※ 產生貸方沖轉科目"
		 * 
		 * ※ 若 日用費合計 < 日支費合計 (需累計各駐在地點)  (1) 以「日用費合計 + 交通費合計 +宿泊費合計
		 * +雜費合計」產生62040223國外研修旅費  (2) 付款方式選擇「沖轉暫付」，產生貸方暫付科目及其金額  (3) 若借方總額 –
		 * 貸方科目仍有差額時，系統自動補「應付費用-待匯」科目及金額。 (2)、(3)需求單修改，請參考" ※ 產生貸方沖轉科目"
		 * 
		 * 
		 * RE201001687:201009 修改為以下規則 BY 文珊 ※ 產生貸方沖轉科目 (1)
		 * 「---」（空白）：貸方科目以「20210391應付費用-待匯」產生 (2)
		 * 「沖轉借支」：貸方科目以「10522102暫付及待結轉帳項-旅費借支」產生。 (3
		 * 「沖轉週轉金」：貸方科目以「10130400週轉金－其他」產生。
		 */

		// 若日用費合計 > 日支費合計
		if (exp.getDailySpendTotalAmt().compareTo(exp.getDailyExpTotalAmt()) > 0) {
			// (1)以「依規免稅額」產生 借方62040223國外研修旅費
			tempExpEntry.setAmt(exp.getGaugeDutyFreeAmt());
			tempExpEntry.setEntryType(facade.getEntryTypeService().findEntryTypeByEntryTypeCode(EntryTypeCode.TYPE_2_3));
			entryList.add(tempExpEntry);

			// (2)有併薪額 產生借方61130223人事-薪津-其他-職員薪津-婚喪禮金或國外旅費併薪，其科目金額為頁面上的「併薪額」欄位值
			if (null != exp.getSalaryAmt() && BigDecimal.ZERO.compareTo(exp.getSalaryAmt()) != 0) {
				Entry entry = new Entry();
				// 借方
				entry.setEntryType(facade.getEntryTypeService().findEntryTypeByEntryTypeCode(EntryTypeCode.TYPE_2_3));
				// 金額為頁面上的「併薪額」欄位值
				entry.setAmt(exp.getSalaryAmt());
				// 61130223人事-薪津-其他-職員薪津-婚喪禮金或國外旅費併薪
				entry.setAccTitle(facade.getAccTitleService().findByCode(AccTitleCode.GIFT_FUNERAL_MONEY.getCode()));

				// Defect:1788 SIT-C-UC1.5.6 產生「
				// 61130223人事-薪津-其他-職員薪津-婚喪禮金或國外旅費併薪」科目時，需帶入「成本單位」欄位
				Department department = facade.getCostUnitDefaultService().findDefaultCostUnit(FunctionCode.C_1_5_6, null, exp.getExpapplC().getApplyUserInfo().getDepUnitCode3());
				if (null == department) {
					throw new ExpRuntimeException(ErrorCode.A20002, new String[] { MessageUtils.getAccessor().getMessage("tw_com_skl_exp_kernel_model6_bo_Entry_costUnit") });
				}
				entry.setCostUnitCode(department.getCode());
				entry.setCostUnitName(department.getName());
				entry.setSummary(expEntry.getSummary());
				entryList.add(entry);

				// 計算所得稅
				BigDecimal amt = facade.getAccTitleService().calculateTaxAmt(entry.getAccTitle(), entry.getAmt(), true);
				// (3)併薪額達起扣額產生貸方20210235應付代收款，所得人類別為「員工代號」、所得人證號為「費用申請單.申請人員工代號」
				if (null != amt && BigDecimal.ZERO.compareTo(amt) < 0) {
					Entry entryC = new Entry();
					// 貸方
					entryC.setEntryType(facade.getEntryTypeService().findEntryTypeByEntryTypeCode(EntryTypeCode.TYPE_2_4));
					// 金額
					entryC.setAmt(amt);
					// 20210235應付代收款
					entryC.setAccTitle(facade.getAccTitleService().findByCode(AccTitleCode.INCOME_TAX_20210235.getCode()));
					// 所得人類別為「身份證字號」modify 2010/01/26 Defect:1935 PROD-C-UC1.5.6
					// 產生產生61130223人事-薪津-其他-職員薪津-婚喪禮金或國外旅費併薪」科目, 「所得人證號」 應為
					// 「費用申請單.申請人資訊.身份證字號」
					entryC.setIncomeIdType(IncomeIdTypeCode.IDENTITY_ID.getCode());
					// 所得人證號為「費用申請單.申請人資訊.身份證字號」 modify 2010/01/26 Defect:1935
					// PROD-C-UC1.5.6 產生產生61130223人事-薪津-其他-職員薪津-婚喪禮金或國外旅費併薪」科目,
					// 「所得人證號」 應為 「費用申請單.申請人資訊.身份證字號」
					entryC.setIncomeId(exp.getExpapplC().getApplyUserInfo().getIdentityId());
					entryList.add(entryC);
				}
			}

		}

		// 若 日用費合計 < 日支費合計
		if (exp.getDailySpendTotalAmt().compareTo(exp.getDailyExpTotalAmt()) < 0) {
			BigDecimal amt = BigDecimal.ZERO;
			// (1) 以「日用費合計 + 交通費合計 +宿泊費合計 +雜費合計」產生62040223國外研修旅費
			amt = amt.add(exp.getDailySpendTotalAmt());// +日用費合計
			amt = amt.add(exp.getTrafficTotalExp());// +交通費合計
			amt = amt.add(exp.getHotelTotalExp());// +宿泊費合計
			amt = amt.add(exp.getMiscellaneousTotalExp());// +雜費合計
			tempExpEntry.setAmt(amt);
			entryList.add(tempExpEntry);

		}

		// 沖轉暫付流程 扣除20210235應付代收款科目金額後
		/*
		 * (4) 若於日支費頁面付款方式選擇「沖轉暫付」，以輸入之銷帳碼產生貸方10522102科目(暫付-旅費借支)
		 * ，科目金額僅能為該銷帳碼可沖轉餘額為上限，產生暫付科目需先扣除20210235應付代收款科目金額後 ，再產生暫付科目及其金額。
		 */
		/*
		 * generateEntryByPaymentTypeCode(exp,
		 * PaymentTypeCode.C_CHANGE_TEMP_PREPAID, entryList);
		 * generateEntryByPaymentTypeCode(exp,
		 * PaymentTypeCode.C_CHANGE_TEMP_PAY, entryList);
		 * 
		 * BigDecimal amtD = BigDecimal.ZERO;//借方金額 BigDecimal amtC =
		 * BigDecimal.ZERO;//貸方金額 //計算借貸方總額 for (Entry entry : entryList) { if
		 * (EntryTypeValueCode
		 * .D.equals(EntryTypeValueCode.getByValue(entry.getEntryType()))) {
		 * amtD = amtD.add(entry.getAmt());
		 * System.out.println("amtD====="+amtD); } else { amtC =
		 * amtC.add(entry.getAmt()); System.out.println("amtC====="+amtC); } }
		 * 
		 * //若借方總額 – 貸方科目仍有差額時，系統自動補「應付費用-待匯」科目及金額。 BigDecimal remitAmt =
		 * amtD.subtract(amtC); if (BigDecimal.ZERO.compareTo(remitAmt) < 0) {
		 * // 檢核貸方”應付費用科目金額”需等於「國外研修差旅費用領款資料.金額」的總合，否則顯示《應付費用金額需等於付款對象金額總和》訊息，
		 * 且不需產生國外出差分錄 if
		 * (remitAmt.compareTo(getDrawInfosAmount(exp.getOvsaExpDrawInfos()))!=
		 * 0) { entryList = null; //顯示《應付費用金額需等於付款對象金額總和》訊息，且不需產生國外出差分錄 throw
		 * new ExpRuntimeException(ErrorCode.C10387); }
		 * 
		 * Entry remitEntry = new Entry(); //貸方
		 * remitEntry.setEntryType(facade.getEntryTypeService
		 * ().findEntryTypeByEntryTypeCode(EntryTypeCode.TYPE_2_4));
		 * remitEntry.setAmt(amtD.subtract(amtC));
		 * remitEntry.setAccTitle(facade.
		 * getAccTitleService().findByCode(AccTitleCode
		 * .PAYBLE_REMIT.getCode()));
		 * 
		 * //產生過渡付款明細
		 * facade.getExpapplCService().generateTransitPaymentDetailByOvsaTrvlLrnExp
		 * (exp, remitEntry);
		 * 
		 * entryList.add(remitEntry); }
		 */

		/*
		 * RE201001687:201009 修改為以下規則: BY 文珊 ※ 產生貸方沖轉科目 (1)
		 * 「---」（空白）：貸方科目以「20210391應付費用-待匯」產生 金額:借方 -貸方, 須有付款對象 (2)
		 * 「沖轉借支」(沖轉暫付)：貸方科目以「10522102暫付及待結轉帳項-旅費借支」產生。
		 * 銷帳碼可至「駐在地點之費用明細(TBEXP_STATION_EXP_DETAIL)」取得」
		 * 
		 * (3) 「沖轉週轉金」：貸方科目以「10130400週轉金－其他」產生。 金額:借方 -貸方
		 */

		if (null == impulsingAccTile) {
			// 貸方科目:20210391應付費用-待匯
			BigDecimal amtD = BigDecimal.ZERO;// 借方金額
			BigDecimal amtC = BigDecimal.ZERO;// 貸方金額
			// 計算借貸方總額
			for (Entry entry : entryList) {
				if (EntryTypeValueCode.D.equals(EntryTypeValueCode.getByValue(entry.getEntryType()))) {
					amtD = amtD.add(entry.getAmt());
					// System.out.println("amtD====="+amtD);
				} else {
					amtC = amtC.add(entry.getAmt());
					// System.out.println("amtC====="+amtC);
				}
			}

			// 若借方總額 – 貸方科目仍有差額時，系統自動補「應付費用-待匯」科目及金額。
			BigDecimal remitAmt = amtD.subtract(amtC);
			if (BigDecimal.ZERO.compareTo(remitAmt) < 0) {
				// 
				// 檢核貸方”應付費用科目金額”需等於「國外研修差旅費用領款資料.金額」的總合，否則顯示《應付費用金額需等於付款對象金額總和》訊息，且不需產生國外出差分錄
				if (remitAmt.compareTo(getDrawInfosAmount(exp.getOvsaExpDrawInfos())) != 0) {
					entryList = null;
					// 顯示《應付費用金額需等於付款對象金額總和》訊息，且不需產生國外出差分錄
					throw new ExpRuntimeException(ErrorCode.C10387);
				}

				Entry remitEntry = new Entry();
				// 貸方
				remitEntry.setEntryType(facade.getEntryTypeService().findEntryTypeByEntryTypeCode(EntryTypeCode.TYPE_2_4));
				remitEntry.setAmt(amtD.subtract(amtC));
				remitEntry.setAccTitle(facade.getAccTitleService().findByCode(AccTitleCode.PAYBLE_REMIT.getCode()));

				// 產生過渡付款明細
				// facade.getExpapplCService().generateTransitPaymentDetailByOvsaTrvlLrnExp(exp,
				// remitEntry);

				entryList.add(remitEntry);
			}

		} else if (PaymentTypeCode.C_CHANGE_TEMP_PAY.getCode().equals(impulsingAccTile.getCode())) {
			// 貸方科目:10522102暫付及待結轉帳項-旅費借支
			/**
			 * (1)產生沖轉預付C_CHANGE_TEMP_PREPAID(用銷帳碼計算產生)
			 * (2)產生沖轉暫付C_CHANGE_TEMP_PAY(借方 -沖轉預付) IF(沖轉暫付的銷帳碼金額足夠){ 1.借方
			 * -沖轉預付金額:沖轉暫付 2.付款對象須為空值 }ELSE{ 1.銷帳碼剩下的金額:沖轉暫付 2.借方
			 * -沖轉預付-銷帳碼剩下的金額:應付費用-待匯 3.有付款對象 }
			 */
			generateEntryByPaymentTypeCode(exp, PaymentTypeCode.C_CHANGE_TEMP_PREPAID, entryList); // 預付
			generateEntryByPaymentTypeCode(exp, PaymentTypeCode.C_CHANGE_TEMP_PAY, entryList);// 暫付
			// 若借方總額 – 貸方科目仍有差額時，系統自動補「應付費用-待匯」科目及金額。
			generateEntryByAccTitle(exp, AccTitleCode.PAYBLE_REMIT, entryList);

		} else if (PaymentTypeCode.C_WORKING_CAPITAL.getCode().equals(impulsingAccTile.getCode())) {
			// 「沖轉週轉金」：貸方科目「10130400週轉金－其他」

			// RE201001687 2010/11/11 需求變更,取消「沖轉週轉金」付款對象檢核)
			// 須檢核不能有付款對象
			/*
			 * if(exp.getOvsaExpDrawInfos().size() > 0){
			 * //顯示《沖轉科目為「沖轉週轉金」時，不須設定「付款對象」資料》訊息，且不需產生國外出差分錄 throw new
			 * ExpRuntimeException(ErrorCode.C10557); }
			 */
			// 若借方總額 – 貸方科目仍有差額時，系統自動補「週轉金-其他」科目及金額。
			generateEntryByAccTitle(exp, AccTitleCode.CODE_10130400, entryList);

		}

		// 憑證金額(含) = 出差旅費合計
		exp.getExpapplC().setInvoiceAmt(exp.getAbrodTotalAmt());

		/**
		 *  分錄中若有會計科目「61130223人事-薪津-其他-職員薪津-婚喪禮金或國外旅費併薪」科目時，需儲存以下欄位: (#266) 
		 * 「國外研修差旅費用.所得人證號類別」= “4員工代號”  「國外研修差旅費用.所得人證號」= 「費用申請單.申請人資訊.員工代號」
		 */
		exp.setIncomeIdType(null);
		exp.setIncomeUserId(null);

		for (Entry entry : entryList) {
			entry.setEntryGroup(exp.getExpapplC().getEntryGroup());
			if (AccTitleCode.GIFT_FUNERAL_MONEY.equals(AccTitleCode.getByValue(entry.getAccTitle()))) {
				exp.setIncomeIdType(facade.getIncomeIdTypeService().findByCode(IncomeIdTypeCode.EMP_ID));
				exp.setIncomeUserId(exp.getExpapplC().getApplyUserInfo().getUserId());
			}
		}
		exp.getExpapplC().getEntryGroup().setEntries(entryList);
		BeanUtils.copyProperties(tempExpEntry, expEntry);
	}

	private void generateEntryByAccTitle(OvsaTrvlLrnExp exp, AccTitleCode accTitlecode, List<Entry> entryList) {
		BigDecimal amtD = BigDecimal.ZERO;// 借方金額
		BigDecimal amtC = BigDecimal.ZERO;// 貸方金額
		// 計算借貸方總額
		for (Entry entry : entryList) {
			if (EntryTypeValueCode.D.equals(EntryTypeValueCode.getByValue(entry.getEntryType()))) {
				amtD = amtD.add(entry.getAmt());
				// System.out.println("amtD====="+amtD);
			} else {
				amtC = amtC.add(entry.getAmt());
				// System.out.println("amtC====="+amtC);
			}
		}

		// 若借方總額 – 貸方科目仍有差額時，系統自動補科目及金額。
		BigDecimal remitAmt = amtD.subtract(amtC);
		if (BigDecimal.ZERO.compareTo(remitAmt) < 0) {
			// 科目:應付費用-代匯
			if (AccTitleCode.PAYBLE_REMIT.equals(accTitlecode)) {
				// 
				// 檢核貸方”應付費用科目金額”需等於「國外研修差旅費用領款資料.金額」的總合，否則顯示《應付費用金額需等於付款對象金額總和》訊息，且不需產生國外出差分錄
				if (remitAmt.compareTo(getDrawInfosAmount(exp.getOvsaExpDrawInfos())) != 0) {
					entryList = null;
					// 顯示《應付費用金額需等於付款對象金額總和》訊息，且不需產生國外出差分錄
					throw new ExpRuntimeException(ErrorCode.C10387);
				}
			}

			Entry remitEntry = new Entry();
			// 貸方
			remitEntry.setEntryType(facade.getEntryTypeService().findEntryTypeByEntryTypeCode(EntryTypeCode.TYPE_2_4));
			remitEntry.setAmt(amtD.subtract(amtC));

			// 科目:週轉金
			if (AccTitleCode.CODE_10130400.equals(accTitlecode)) {
				remitEntry.setAccTitle(facade.getAccTitleService().findByCode(AccTitleCode.CODE_10130400.getCode()));
			}

			// 科目:應付費用-代匯
			if (AccTitleCode.PAYBLE_REMIT.equals(accTitlecode)) {
				remitEntry.setAccTitle(facade.getAccTitleService().findByCode(AccTitleCode.PAYBLE_REMIT.getCode()));
			}

			entryList.add(remitEntry);
		}
	}

	private BigDecimal generateEntryByPaymentTypeCode(OvsaTrvlLrnExp exp, PaymentTypeCode paymentTypeCode, List<Entry> entryList) {

		List<StationExpDetail> stationExpDetailList = new ArrayList<StationExpDetail>();
		// 找出沖轉預付 or 沖轉暫付的資料(如果是自付則找不出資料?)
		//
		// List<StationExpDetail> stationExpDetailList =
		// facade.getStationExpDetailService().findByParams(exp.getExpapplC().getExpApplNo(),
		// paymentTypeCode, null);

		// 把新增/駐在地點的多筆DETAILLIST加入迴圈中
		// 0725 start
		// 沖轉科目產生規則沒寫好
		for (Station station : exp.getStations()) {
			for (StationExpDetail stationExpDetail : station.getStationExpDetails()) {
				// 判斷付款方式
				if (paymentTypeCode.getCode().equals(stationExpDetail.getPaymentType().getCode())) {
					stationExpDetailList.add(stationExpDetail);
				}
			}
		}

		if (CollectionUtils.isEmpty(stationExpDetailList)) {
			return BigDecimal.ZERO;
		}
		// 累計相同銷帳碼金額 (key = 銷帳碼, value = 累計金額)
		Map<String, BigDecimal> cancelCodeMap = new HashMap<String, BigDecimal>();
		for (StationExpDetail detail : stationExpDetailList) {
			if (!cancelCodeMap.containsKey(detail.getCancelCode())) {
				cancelCodeMap.put(detail.getCancelCode(), BigDecimal.ZERO);
			}
			BigDecimal total = cancelCodeMap.get(detail.getCancelCode());
			cancelCodeMap.put(detail.getCancelCode(), total.add(detail.getAmount()));
		}

		BigDecimal incomeTaxAmt = BigDecimal.ZERO;
		// 沖轉預付=10511205預付費用–總務部商務卡
		AccTitleCode accTitleCode = null;
		if (PaymentTypeCode.C_CHANGE_TEMP_PAY.equals(paymentTypeCode)) {
			// 沖轉暫付=10522102暫付及待結轉帳項-旅費借支
			accTitleCode = AccTitleCode.TEMP_PAY_TRAVEL_EXP_ADVANCE;
			if (!CollectionUtils.isEmpty(entryList)) {
				// 找出20210235應付代收款科目金額
				for (Entry entry : entryList) {
					if (StringUtils.equals(AccTitleCode.INCOME_TAX_20210235.getCode(), entry.getAccTitle().getCode())) {
						incomeTaxAmt = entry.getAmt();
						break;
					}
				}
			}
		}

		if (PaymentTypeCode.C_CHANGE_TEMP_PREPAID.equals(paymentTypeCode)) {
			// 沖轉預付=10511205預付費用–總務部商務卡
			accTitleCode = AccTitleCode.PREPAY_BIZCARD;
		}

		if (CollectionUtils.isEmpty(entryList)) {
			entryList = new ArrayList<Entry>();
		}

		BigDecimal amt = BigDecimal.ZERO;// 超過銷帳碼的錢
		if (PaymentTypeCode.C_CHANGE_TEMP_PREPAID.equals(paymentTypeCode)) {
			for (String key : cancelCodeMap.keySet()) {
				BigDecimal cancelCodeAmt = cancelCodeMap.get(key).subtract(incomeTaxAmt);
				BigDecimal totalAmt = facade.getEntryService().getCancelCodeBalance(key);

				if (BigDecimal.ZERO.compareTo(cancelCodeAmt) >= 0 || BigDecimal.ZERO.compareTo(totalAmt) >= 0) {
					throw new ExpRuntimeException(ErrorCode.C10022);
				}

				// 若該筆銷帳碼申請的金額大於可用餘額, 則申請金額=可用餘額, 超過的部分則產生在應附待匯科目
				if (totalAmt.compareTo(cancelCodeAmt) <= 0) {
					amt = amt.add(cancelCodeAmt.subtract(totalAmt));
					cancelCodeAmt = totalAmt;
				}
				Entry entry = new Entry();
				// 貸方
				entry.setEntryType(facade.getEntryTypeService().findEntryTypeByEntryTypeCode(EntryTypeCode.TYPE_2_4));
				// 會計科目
				entry.setAccTitle(facade.getAccTitleService().findByCode(accTitleCode.getCode()));
				// 金額
				entry.setAmt(cancelCodeAmt);
				entry.setCancelCode(key);
				entryList.add(entry);
			}
		} else if (PaymentTypeCode.C_CHANGE_TEMP_PAY.equals(paymentTypeCode)) {
			// RE201601162_國外旅費 CU3178 2016/8/12 START
			// BigDecimal amtD = BigDecimal.ZERO;// 借方金額
			// BigDecimal amtC = BigDecimal.ZERO;// 貸方金額
			// // 計算借貸方總額
			// for (Entry entry : entryList)
			// {
			// if
			// (EntryTypeValueCode.D.equals(EntryTypeValueCode.getByValue(entry.getEntryType())))
			// {
			// amtD = amtD.add(entry.getAmt());
			// } else
			// {
			// amtC = amtC.add(entry.getAmt());
			// }
			// }
			// BigDecimal cancelCodeAmt = amtD.subtract(amtC);
			// BigDecimal totalAmt = BigDecimal.ZERO;
			// String cancelCode = null;
			// for (String key : cancelCodeMap.keySet())
			// {
			// cancelCode = key;
			// totalAmt = facade.getEntryService().getCancelCodeBalance(key);
			// }
			// if (BigDecimal.ZERO.compareTo(cancelCodeAmt) >= 0 ||
			// BigDecimal.ZERO.compareTo(totalAmt) >= 0)
			// {
			// throw new ExpRuntimeException(ErrorCode.C10022);
			// }
			//
			// // 若該筆銷帳碼申請的金額大於可用餘額, 則申請金額=可用餘額, 超過的部分則產生在應附待匯科目
			// if (totalAmt.compareTo(cancelCodeAmt) <= 0)
			// {
			// amt = amt.add(cancelCodeAmt.subtract(totalAmt));
			// cancelCodeAmt = totalAmt;
			// }
			// Entry entry = new Entry();
			// // 貸方
			// entry.setEntryType(facade.getEntryTypeService().findEntryTypeByEntryTypeCode(EntryTypeCode.TYPE_2_4));
			// // 會計科目
			// entry.setAccTitle(facade.getAccTitleService().findByCode(accTitleCode.getCode()));
			// // 金額
			// entry.setAmt(cancelCodeAmt);
			// entry.setCancelCode(cancelCode);
			// entryList.add(entry);
			// 修改沖轉暫付
			for (String key : cancelCodeMap.keySet()) {
				BigDecimal cancelCodeAmt = cancelCodeMap.get(key);
				BigDecimal totalAmt = facade.getEntryService().getCancelCodeBalance(key);

				if (BigDecimal.ZERO.compareTo(cancelCodeAmt) >= 0 || BigDecimal.ZERO.compareTo(totalAmt) >= 0) {
					throw new ExpRuntimeException(ErrorCode.C10022);
				}

				// 若該筆銷帳碼申請的金額大於可用餘額, 則申請金額=可用餘額, 超過的部分則產生在應附待匯科目
				if (totalAmt.compareTo(cancelCodeAmt) <= 0) {
					amt = amt.add(cancelCodeAmt.subtract(totalAmt));
					cancelCodeAmt = totalAmt;
				}
				Entry entry = new Entry();
				// 貸方
				entry.setEntryType(facade.getEntryTypeService().findEntryTypeByEntryTypeCode(EntryTypeCode.TYPE_2_4));
				// 會計科目
				entry.setAccTitle(facade.getAccTitleService().findByCode(accTitleCode.getCode()));
				// 金額
				entry.setAmt(cancelCodeAmt);
				entry.setCancelCode(key);
				entryList.add(entry);
			}
			// RE201601162_國外旅費 CU3178 2016/8/12 END

		}

		return amt;
	}

	private BigDecimal getDrawInfosAmount(List<OvsaExpDrawInfo> ovsaExpDrawInfos) {
		if (CollectionUtils.isEmpty(ovsaExpDrawInfos)) {
			return BigDecimal.ZERO;
		}
		BigDecimal amt = BigDecimal.ZERO;

		for (OvsaExpDrawInfo info : ovsaExpDrawInfos) {
			amt = amt.add(info.getAmt());
		}

		return amt;

	}

	/**
	 * 若傳入的解款行代碼或總行代碼前三碼為700時,回傳true
	 * 
	 * @param code
	 * @return
	 */
	private boolean checkCode(String code) {
		if (StringUtils.isBlank(code) || code.length() < 3) {
			return false;
		}

		if (StringUtils.equals(TransitPaymentDetail.OUTWARD_BANK_CODE_HEADER, code.substring(0, 3))) {
			return true;
		}
		return false;
	}

	public void checkDate(OvsaTrvlLrnExp exp, Station station) {

		// 出國年月起日
		Calendar startDate = exp.getAbroadStartDate();
		// 出國年月迄日
		Calendar endDate = exp.getAbroadEndDate();
		// 出國年月起日不可為空
		if (startDate == null) {
			throw new ExpRuntimeException(ErrorCode.A10001, new String[] { getMessage("tw_com_skl_exp_kernel_model6_bo_OvsaTrvlLrnExp_abroadStartDate") });
		}
		// 出國年月迄日不可為空
		if (endDate == null) {
			throw new ExpRuntimeException(ErrorCode.A10001, new String[] { getMessage("tw_com_skl_exp_kernel_model6_bo_OvsaTrvlLrnExp_abroadEndDate") });
		}

		if (startDate.compareTo(endDate) >= 1) {
			// 錯誤訊息 出國年月期間起日不可大於出國年月期間迄日
			throw new ExpRuntimeException(ErrorCode.C10634, new String[] { MessageUtils.getAccessor().getMessage("tw_com_skl_exp_kernel_model6_bo_OvsaTrvlLrnExp_abroadStartDate"), MessageUtils.getAccessor().getMessage("tw_com_skl_exp_kernel_model6_bo_OvsaTrvlLrnExp_abroadEndDate") });
		}
		// 駐在期間起
		Calendar stationStartDate = station.getStationStartDate();
		// 駐在期間迄
		Calendar stationEndDate = station.getStationEndDate();
		// 駐在期間起不可為空
		if (stationStartDate == null) {
			throw new ExpRuntimeException(ErrorCode.A10001, new String[] { getMessage("tw_com_skl_exp_kernel_model6_bo_Station_stationStartDate") });
		}
		// 駐在期間迄不可為空
		if (stationEndDate == null) {
			throw new ExpRuntimeException(ErrorCode.A10001, new String[] { getMessage("tw_com_skl_exp_kernel_model6_bo_Station_stationEndDate") });
		}

		if (stationStartDate.compareTo(stationEndDate) >= 1) {
			// 錯誤訊息 駐在期間起日不可大於駐在期間迄日
			throw new ExpRuntimeException(ErrorCode.C10634, new String[] { MessageUtils.getAccessor().getMessage("tw_com_skl_exp_kernel_model6_bo_Station_stationStartDate"), MessageUtils.getAccessor().getMessage("tw_com_skl_exp_kernel_model6_bo_Station_stationEndDate") });
		}
		// 判斷駐在起訖期間在出國年月區間之內
		if (!(stationStartDate.compareTo(startDate) >= 0 && (stationStartDate.compareTo(endDate) <= 0))) {
			// 錯誤訊息 駐在起日要再出國年月區間
			throw new ExpRuntimeException(ErrorCode.C10635, new String[] { MessageUtils.getAccessor().getMessage("tw_com_skl_exp_kernel_model6_bo_Station_stationStartDate") });
		}
		if (!(stationEndDate.compareTo(startDate) >= 0 && (stationEndDate.compareTo(endDate) <= 0))) {
			// 錯誤訊息 駐在迄日要再出國年月區間
			throw new ExpRuntimeException(ErrorCode.C10635, new String[] { MessageUtils.getAccessor().getMessage("tw_com_skl_exp_kernel_model6_bo_Station_stationEndDate") });
		}
	}

	/**
	 * 計算金額[日支費合計, 日用費合計, 宿泊費合計, 雜費合計, 交通費合計, 依規免稅額, 出差旅費合計, 併薪額]
	 * 
	 * @param exp
	 */
	private void checkCaculateAmt(OvsaTrvlLrnExp exp) {
		if (null == exp) {
			return;
		}

		// 日支費合計
		BigDecimal dailyExpTotalAmt = BigDecimal.ZERO;
		// 日用費合計
		BigDecimal dailySpendTotalAmt = BigDecimal.ZERO;
		// 宿泊費合計
		BigDecimal hotelTotalExp = BigDecimal.ZERO;
		// 雜費合計
		BigDecimal miscellaneousTotalExp = BigDecimal.ZERO;
		// 交通費合計
		BigDecimal trafficTotalExp = BigDecimal.ZERO;
		// 出差旅費合計
		BigDecimal abrodTotalAmt = BigDecimal.ZERO;
		// 依規免稅額
		BigDecimal gaugeDutyFreeAmt = BigDecimal.ZERO;
		// 併薪額
		BigDecimal salaryAmt = BigDecimal.ZERO;

		// 計算金額
		if (!CollectionUtils.isEmpty(exp.getStations())) {
			for (Station station : exp.getStations()) {
				// 日支費
				dailyExpTotalAmt = dailyExpTotalAmt.add(station.getDailyExp());
				// 日用費
				dailySpendTotalAmt = dailySpendTotalAmt.add(station.getDailySpend());
				// 宿泊費
				hotelTotalExp = hotelTotalExp.add(facade.getStationService().doCaculateHotelTotalExp(station));
				// 雜費
				miscellaneousTotalExp = miscellaneousTotalExp.add(facade.getStationService().doCaculateMiscellaneousTotalExp(station));
				// 交通費
				trafficTotalExp = trafficTotalExp.add(facade.getStationService().doCaculateTrafficTotalExp(station));
			}
		}

		// 依規免稅額　= 日支費(合計各駐在地點) +(國外申請單.「交通費、宿泊費、雜費」合計)
		gaugeDutyFreeAmt = gaugeDutyFreeAmt.add(dailyExpTotalAmt).add(hotelTotalExp).add(miscellaneousTotalExp).add(trafficTotalExp);
		// 併薪額：日用費(合計各駐在地點) 減 日支費(合計各駐在地點)　若差額大於0，其差額即為併薪額；反之，若差額小於、等於０，則無併薪額。
		salaryAmt = salaryAmt.add(dailySpendTotalAmt).subtract(dailyExpTotalAmt);
		if (BigDecimal.ZERO.compareTo(salaryAmt) >= 0) {
			// 差額小於、等於０，則無併薪額。
			salaryAmt = BigDecimal.ZERO;
		}

		// 若日用費合計>日支費合計
		if (dailySpendTotalAmt.compareTo(dailyExpTotalAmt) > 0) {
			// 出差旅費合計 = 依規免稅額+併薪額
			abrodTotalAmt = gaugeDutyFreeAmt.add(salaryAmt);
		}

		// 若日用費合計<日支費合計
		if (dailySpendTotalAmt.compareTo(dailyExpTotalAmt) < 0) {
			// 出差旅費合計 =日用費(合計各駐在地點)+(合計各駐在地點的「交通費、宿泊費、雜費、」
			abrodTotalAmt = dailySpendTotalAmt.add(hotelTotalExp).add(miscellaneousTotalExp).add(trafficTotalExp);
		}

		// 檢核日支費合計
		if (exp.getDailyExpTotalAmt().compareTo(dailyExpTotalAmt) != 0) {
			throw new ExpRuntimeException(ErrorCode.C10639, new String[] { getMessage("tw_com_skl_exp_kernel_model6_bo_OvsaTrvlLrnExp_dailyExpTotalAmt") });
		}
		// 日用費合計
		if (exp.getDailySpendTotalAmt().compareTo(dailySpendTotalAmt) != 0) {
			throw new ExpRuntimeException(ErrorCode.C10639, new String[] { getMessage("tw_com_skl_exp_kernel_model6_bo_OvsaTrvlLrnExp_dailySpendTotalAmt") });
		}
		// 宿泊費合計
		if (exp.getHotelTotalExp().compareTo(hotelTotalExp) != 0) {
			throw new ExpRuntimeException(ErrorCode.C10639, new String[] { getMessage("tw_com_skl_exp_kernel_model6_bo_OvsaTrvlLrnExp_hotelTotalExp") });
		}
		// 雜費合計
		if (exp.getMiscellaneousTotalExp().compareTo(miscellaneousTotalExp) != 0) {
			throw new ExpRuntimeException(ErrorCode.C10639, new String[] { getMessage("tw_com_skl_exp_kernel_model6_bo_OvsaTrvlLrnExp_miscellaneousTotalExp") });
		}
		// 交通費合計
		if (exp.getTrafficTotalExp().compareTo(trafficTotalExp) != 0) {
			throw new ExpRuntimeException(ErrorCode.C10639, new String[] { getMessage("tw_com_skl_exp_kernel_model6_bo_OvsaTrvlLrnExp_trafficTotalExp") });
		}
		// 依規免稅額
		if (exp.getGaugeDutyFreeAmt().compareTo(gaugeDutyFreeAmt) != 0) {
			throw new ExpRuntimeException(ErrorCode.C10639, new String[] { getMessage("tw_com_skl_exp_kernel_model6_bo_OvsaTrvlLrnExp_gaugeDutyFreeAmt") });
		}
		// 出差旅費合計
		if (exp.getAbrodTotalAmt().compareTo(abrodTotalAmt) != 0) {
			throw new ExpRuntimeException(ErrorCode.C10639, new String[] { getMessage("tw_com_skl_exp_kernel_model6_bo_OvsaTrvlLrnExp_abrodTotalAmt_NT") });
		}
		// 併薪額
		if (exp.getSalaryAmt().compareTo(salaryAmt) != 0) {
			throw new ExpRuntimeException(ErrorCode.C10639, new String[] { getMessage("tw_com_skl_exp_kernel_model6_bo_OvsaTrvlLrnExp_salaryAmt") });
		}
	}

	public void processModifyOvsaTrvlExp(OvsaTrvlLrnExp exp) {
		if (null == exp) {
			return;
		}

		// 原始國外出差
		OvsaTrvlLrnExp originbo = findByExpApplNo(exp.getExpapplC().getExpApplNo());

		// 1.處理分錄
		List<Entry> nowEntries = exp.getExpapplC().getEntryGroup().getEntries();
		EntryGroup originalEg = facade.getEntryGroupService().findByPK(exp.getExpapplC().getEntryGroup().getId());
		List<Entry> originalEntries = originalEg.getEntries();
		// 刪除不需要之分錄
		facade.getEntryService().processModifyEntry(exp.getExpapplC(), originalEntries, nowEntries);

		// 2.處理駐在地點費用明細
		// 現行駐在地點費用明細
		List<StationExpDetail> nowStationExpDeails = new ArrayList<StationExpDetail>();
		for (Station nowStation : exp.getStations()) {
			nowStationExpDeails.addAll(nowStation.getStationExpDetails());
		}

		// 原始駐在地點費用明細
		List<StationExpDetail> originStationExpDeails = new ArrayList<StationExpDetail>();
		for (Station originStation : originbo.getStations()) {
			originStationExpDeails.addAll(originStation.getStationExpDetails());
		}

		// 要刪除駐在地點費用明細
		List<StationExpDetail> deleteStationExpDeails = new ArrayList<StationExpDetail>();
		for (StationExpDetail originStationExpDetail : originStationExpDeails) {
			if (!nowStationExpDeails.contains(originStationExpDetail)) {
				deleteStationExpDeails.add(originStationExpDetail);
			}
		}

		// 刪除駐在地點費用明細
		facade.getStationExpDetailService().delete(deleteStationExpDeails);

		// 3.駐在地點
		// 現行駐在地點
		List<Station> nowStationList = exp.getStations();

		// 原始駐在地點
		List<Station> originStationList = originbo.getStations();

		// 要刪除駐在地點
		List<Station> deleteStation = new ArrayList<Station>();
		for (Station originStation : originStationList) {
			if (!nowStationList.contains(originStation)) {
				deleteStation.add(originStation);
			}
		}

		// 刪除駐在地點
		facade.getStationService().delete(deleteStation);

		// 4.處理領款資料
		// 現行領款資料
		List<OvsaExpDrawInfo> nowOvsaExpDrawInfoList = exp.getOvsaExpDrawInfos();

		// 原始領款資料
		List<OvsaExpDrawInfo> originOvsaExpDrawInfoList = originbo.getOvsaExpDrawInfos();

		// 要刪除駐在地點
		List<OvsaExpDrawInfo> deleteOvsaExpDrawInfo = new ArrayList<OvsaExpDrawInfo>();
		for (OvsaExpDrawInfo originOvsaExpDrawInfo : originOvsaExpDrawInfoList) {
			if (!nowOvsaExpDrawInfoList.contains(originOvsaExpDrawInfo)) {
				deleteOvsaExpDrawInfo.add(originOvsaExpDrawInfo);
			}
		}

		// 刪除駐在地點
		facade.getOvsaExpDrawInfoService().delete(deleteOvsaExpDrawInfo);

	}

	/**
	 * 國外旅費頁面檢核
	 * 
	 * @param exp
	 */
	public void doValidateOvsaExp(OvsaTrvlLrnExp exp, Entry entry) {
		// 申請人員工代號不可為空
		if (exp.getExpapplC().getApplyUserInfo() == null || StringUtils.isBlank(exp.getExpapplC().getApplyUserInfo().getUserId())) {
			throw new ExpRuntimeException(ErrorCode.A10001, new String[] { MessageUtils.getAccessor().getMessage("tw_com_skl_exp_kernel_model6_bo_ExpapplC_applyUserInfo_userCode") });
		}
		// 成本單位不可為空
		if (StringUtils.isBlank(entry.getCostUnitCode())) {
			throw new ExpRuntimeException(ErrorCode.A10001, new String[] { MessageUtils.getAccessor().getMessage("C1_5_6_costUnit") });
		}
		// 出國事由(主辦單位 課程或會議主題)不可為空
		if (StringUtils.isBlank(exp.getAbroadReason())) {
			throw new ExpRuntimeException(ErrorCode.A10001, new String[] { MessageUtils.getAccessor().getMessage("tw_com_skl_exp_bo_OvsaTrvlLrnExp_Reason") });
		}
		// 出差事由不可為空
		if (exp.getBizMatter() == null) {
			throw new ExpRuntimeException(ErrorCode.A10001, new String[] { MessageUtils.getAccessor().getMessage("tw_com_skl_exp_kernel_model6_bo_OvsaTrvlLrnExp_bizMatter") });
		}
		// 檢核專案代號
		this.facade.getExpapplCService().checkProjectCode(exp.getExpapplC().getProjectCode(), entry.getCostUnitCode());

		// 出國年月起日不可為空
		if (exp.getAbroadStartDate() == null) {
			throw new ExpRuntimeException(ErrorCode.A10001, new String[] { getMessage("tw_com_skl_exp_kernel_model6_bo_OvsaTrvlLrnExp_abroadStartDate") });
		}
		// //出國年月迄日不可為空
		// if (exp.getAbroadEndDate() == null){
		// throw new ExpRuntimeException(ErrorCode.A10001, new String[] {
		// getMessage("tw_com_skl_exp_kernel_model6_bo_OvsaTrvlLrnExp_abroadEndDate")
		// });
		// }
		// //出國年月期間起日不可大於出國年月期間迄日
		// if (exp.getAbroadStartDate().compareTo(exp.getAbroadEndDate()) >= 1){
		// throw new ExpRuntimeException(ErrorCode.C10634, new String[] {
		// MessageUtils.getAccessor().getMessage("tw_com_skl_exp_kernel_model6_bo_OvsaTrvlLrnExp_abroadStartDate"),
		// MessageUtils.getAccessor().getMessage("tw_com_skl_exp_kernel_model6_bo_OvsaTrvlLrnExp_abroadEndDate")
		// });
		// }

		if (!CollectionUtils.isEmpty(exp.getStations())) {
			for (Station station : exp.getStations()) {
				checkDate(exp, station);
			}
		}

		// 美金兌換率不可為0
		if (exp.getExchangeRateUS().compareTo(BigDecimal.ZERO) <= 0) {
			throw new ExpRuntimeException(ErrorCode.C10224, new String[] { MessageUtils.getAccessor().getMessage("tw_com_skl_exp_kernel_model6_bo_OvsaTrvlLrnExp_exchangeRateUS") });
		}
		// 摘要不可為空
		if (StringUtils.isBlank(entry.getSummary())) {
			throw new ExpRuntimeException(ErrorCode.A10001, new String[] { MessageUtils.getAccessor().getMessage("C1_5_6_summary") });
		}

	}

	// RE201601162_國外出差旅費 EC0416 20160406 end
}