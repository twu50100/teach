package tw.com.skl.exp.kernel.model6.bo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Calendar;
import java.util.List;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.persistence.Version;

import tw.com.skl.common.model6.bo.BaseBo;
import tw.com.skl.common.model6.bo.impl.BaseBoImpl;

/**
 * 國外出差日報表
 * 
 * @author EC0416
 * @version 1.0, 2017/8/9
 */
@Entity()
@Table(name = "TBEXP_OVSA_DAILYWORK")
public class OvsaDailyWork extends BaseBoImpl implements Serializable, BaseBo {

	private String id;

	/**
	 * 費用申請單
	 */
	private ExpapplC expapplC;

	/**
	 * 出差日期
	 */
	private Calendar abroadDate;

	private String abroadDateString;

	/**
	 * 開始時間時
	 */
	private String startTimeHour;

	/**
	 * 開始時間分
	 */
	private String startTimeMinute;

	/**
	 * 結束時間時
	 */
	private String endTimeHour;

	/**
	 * 結束時間分
	 */
	private String endTimeMinute;

	// RE201702991_國外出差系統優化作業 EC0416 2017/11/13 start
	/**
	 * 參訪業務/工作紀要
	 */
	private String workDetail;

	/**
	 * 參訪機構
	 */
	private String visitAgency;

	/**
	 * 參訪對象
	 */
	private String visitor;

	// RE201702991_國外出差系統優化作業 EC0416 2017/11/13 end
	/**
	 * 建檔日期
	 */
	private Calendar createDate;

	/**
	 * 更新日期
	 */
	private Calendar updateDate;

	/**
	 * 建檔人員。
	 */
	private User createUser;

	/**
	 * 更新人員。
	 */
	private User updateUser;

	/**
	 * 版本
	 */
	private Integer versionNo;

	@Id()
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "uuid-hex")
	@Column(name = "ID", length = 72)
	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	// bi-directional many-to-one association to ExpapplC
	/**
	 * @return 費用申請單
	 */
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "TBEXP_EXPAPPL_C_ID", referencedColumnName = "ID", nullable = false)
	public ExpapplC getExpapplC() {
		return this.expapplC;
	}

	/**
	 * @param 費用申請單
	 */
	public void setExpapplC(ExpapplC expapplC) {
		this.expapplC = expapplC;
	}

	/**
	 * 出差日期
	 * 
	 * @return
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "ABROAD_DATE", nullable = false, length = 7)
	public Calendar getAbroadDate() {
		return abroadDate;
	}

	/**
	 * 出差日期
	 * 
	 * @param abroadDate
	 */
	public void setAbroadDate(Calendar abroadDate) {
		this.abroadDate = abroadDate;
	}

	/**
	 * @return 開始時間時
	 */
	@Basic()
	@Column(name = "START_TIME_HOUR", nullable = false, length = 2)
	public String getStartTimeHour() {
		return startTimeHour;
	}

	/**
	 * @param 開始時間時
	 */
	public void setStartTimeHour(String startTimeHour) {
		this.startTimeHour = startTimeHour;
	}

	/**
	 * @return 開始時間分
	 */
	@Basic()
	@Column(name = "START_TIME_MINUTE", nullable = false, length = 2)
	public String getStartTimeMinute() {
		return startTimeMinute;
	}

	/**
	 * @param 開始時間分
	 */
	public void setStartTimeMinute(String startTimeMinute) {
		this.startTimeMinute = startTimeMinute;
	}

	/**
	 * @return 結束時間時
	 */
	@Basic()
	@Column(name = "END_TIME_HOUR", nullable = false, length = 2)
	public String getEndTimeHour() {
		return endTimeHour;
	}

	/**
	 * @param 結束時間時
	 */
	public void setEndTimeHour(String endTimeHour) {
		this.endTimeHour = endTimeHour;
	}

	/**
	 * @return 結束時間分
	 */
	@Basic()
	@Column(name = "END_TIME_MINUTE", nullable = false, length = 2)
	public String getEndTimeMinute() {
		return endTimeMinute;
	}

	/**
	 * @param 結束時間分
	 */
	public void setEndTimeMinute(String endTimeMinute) {
		this.endTimeMinute = endTimeMinute;
	}
	
	// RE201702991_國外出差系統優化作業 EC0416 2017/11/13 start
	/**
	 * @return 工作內容
	 */
	@Basic()
	@Column(name = "WORK_DETAIL", nullable = false, length = 1000)
	public String getWorkDetail() {
		return workDetail;
	}

	/**
	 * @param 工作內容
	 */
	public void setWorkDetail(String workDetail) {
		this.workDetail = workDetail;
	}
	
	/**
	 * @return 參訪機構
	 */
	@Basic()
	@Column(name = "VISIT_AGENCY", nullable = false, length = 40)
	public String getVisitAgency() {
		return visitAgency;
	}
	
	/**
	 * @param 參訪機構
	 */
	public void setVisitAgency(String visitAgency) {
		this.visitAgency = visitAgency;
	}
	
	/**
	 * @return 參訪對象
	 */
	@Basic()
	@Column(name = "VISITOR", nullable = false, length = 0)
	public String getVisitor() {
		return visitor;
	}
	/**
	 * @param 參訪對象
	 */
	public void setVisitor(String visitor) {
		this.visitor = visitor;
	}

	// RE201702991_國外出差系統優化作業 EC0416 2017/11/13 end

	/**
	 * @return 建檔日期
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATE_DATE")
	public Calendar getCreateDate() {
		return createDate;
	}

	/**
	 * @return 建檔日期
	 */
	public void setCreateDate(Calendar createDate) {
		this.createDate = createDate;
	}

	/**
	 * @return 更新日期
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPDATE_DATE")
	public Calendar getUpdateDate() {
		return updateDate;
	}

	/**
	 * @return 更新日期
	 */
	public void setUpdateDate(Calendar updateDate) {
		this.updateDate = updateDate;
	}

	/**
	 * @return 建檔人員
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "TBEXP_CREATE_USER_ID", referencedColumnName = "ID")
	public User getCreateUser() {
		return createUser;
	}

	/**
	 * @return 建檔人員
	 */
	public void setCreateUser(User createUser) {
		this.createUser = createUser;
	}

	/**
	 * @return 更新人員
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "TBEXP_UPDATE_USER_ID", referencedColumnName = "ID")
	public User getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(User updateUser) {
		this.updateUser = updateUser;
	}

	/**
	 * @return 版本
	 */
	@Version
	@Column(name = "VERSION_NO", nullable = false, precision = 20)
	public Integer getVersionNo() {
		return versionNo;
	}

	/**
	 * @param versionNo
	 *            版本
	 */
	public void setVersionNo(Integer versionNo) {
		this.versionNo = versionNo;
	}

	@Transient
	public String getAbroadDateString() {
		return abroadDateString;
	}

	public void setAbroadDateString(String abroadDateString) {
		this.abroadDateString = abroadDateString;
	}

}