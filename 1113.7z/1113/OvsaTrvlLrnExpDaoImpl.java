package tw.com.skl.exp.kernel.model6.dao.jpa;

import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.util.CollectionUtils;

import tw.com.skl.common.model6.dao.jpa.BaseDaoImpl;
import tw.com.skl.exp.kernel.model6.bo.Department;
import tw.com.skl.exp.kernel.model6.bo.OvsaTrvlLrnExp;
import tw.com.skl.exp.kernel.model6.bo.ApplState.ApplStateCode;
import tw.com.skl.exp.kernel.model6.bo.SysType.SysTypeCode;
import tw.com.skl.exp.kernel.model6.common.util.ArrayUtils;
import tw.com.skl.exp.kernel.model6.common.util.StringUtils;
import tw.com.skl.exp.kernel.model6.common.util.time.DateUtils;
import tw.com.skl.exp.kernel.model6.dao.OvsaTrvlLrnExpDao;



/**
 * 
 * 國外研修差旅費用 Dao 介面。
 * 
 * @author smanohuang
 * @version 1.0, 2009/05/21
 */
public class OvsaTrvlLrnExpDaoImpl extends BaseDaoImpl<OvsaTrvlLrnExp, String> implements OvsaTrvlLrnExpDao{
    protected Log logger = LogFactory.getLog(this.getClass());
    public List<OvsaTrvlLrnExp> findByParams(ApplStateCode applStateCode, Department department, String userCode,
            Calendar createDateStart, Calendar createDateEnd, ApplStateCode[] applStateCodes) {
        StringBuffer queryString = new StringBuffer();
        queryString.append("select distinct o");
        queryString.append(" from OvsaTrvlLrnExp o");
        queryString.append(" inner join o.expapplC expapplC");
        queryString.append(" inner join expapplC.entryGroup entryGroup");
        queryString.append(" left join entryGroup.entries entry");

        boolean truncated = false;

        Map<String, Object> params = new HashMap<String, Object>();

        // 申請單狀態
        if (null != applStateCode) {
            if (!truncated) {
                queryString.append(" where");
                truncated = true;
            }
            queryString.append(" o.expapplC.applState.code =:applStateCode");
            params.put("applStateCode", applStateCode.getCode());

            queryString.append(" and o.expapplC.applState.sysType.code =:sysTypeCode");
            params.put("sysTypeCode", SysTypeCode.C.getCode());

            queryString.append(" and");


        }

        //        成本單位
        if (null != department) {
            if (!truncated) {
                queryString.append(" where");
                truncated = true;
            }
            queryString.append(" entry.costUnitCode =:costUnitCode");
            params.put("costUnitCode", department.getCode());

            queryString.append(" and");

        }

        // 申請人員工代號
        if (StringUtils.isNotBlank(userCode)) {
            if (!truncated) {
                queryString.append(" where");
                truncated = true;
            }
            //「國外研修差旅費用.費用申請單.申請人資訊.員工代號」=傳入參數「申請人員工代號」
            queryString.append(" o.expapplC.applyUserInfo.userId =:userCode");
            params.put("userCode", userCode);

            queryString.append(" and");

        }

        // 建檔期間起
        if (null != createDateStart) {
            if (!truncated) {
                queryString.append(" where");
                truncated = true;
            }

            //「國外研修差旅費用.費用申請單.建檔日期」>傳入參數「建檔期間起日」(0:00)
            queryString.append(" o.expapplC.createDate >=:createDateStart");
            params.put("createDateStart", DateUtils.getFirstMinuteOfDay(createDateStart));

            queryString.append(" and");
        }

        // 建檔期間迄
        if (null != createDateEnd) {
            if (!truncated) {
                queryString.append(" where");
                truncated = true;
            }
            createDateEnd.add(Calendar.DATE, 1);
            //「國外研修差旅費用.費用申請單.建檔日期」<=傳入參數「建檔期間迄日」(0:00)+1天
            queryString.append(" o.expapplC.createDate <:createDateEnd");
            params.put("createDateEnd", DateUtils.getFirstMinuteOfDay(createDateEnd));

            queryString.append(" and");

        }

        if(!ArrayUtils.isEmpty(applStateCodes)){
            if (!truncated) {
                queryString.append(" where");
                truncated = true;
            }

            queryString.append(" o.expapplC.applState.code not in(");

            int i = 0;
            for (ApplStateCode code : applStateCodes) {
                if (i != 0) {
                    queryString.append(",");
                }

                queryString.append(" :notApplStateCode"+i);
                params.put("notApplStateCode"+i, code.getCode());

                i++;
            }
            queryString.append(")");

            queryString.append(" and o.expapplC.applState.sysType.code =:sysTypeCode");
            params.put("sysTypeCode", SysTypeCode.C.getCode());

            queryString.append(" and");
        }

        if (truncated) {
            //刪除最後一個and字串
            queryString.delete(queryString.lastIndexOf("and"), queryString.length());
        }

        //依「國外研修差旅費用.費用申請單. 建檔日期」遞增排序
        queryString.append(" ORDER BY o.expapplC.createDate ASC");

        logger.info("SQL String =("+queryString.toString()+" )");

        List<OvsaTrvlLrnExp> list = findByNamedParams(queryString.toString(), params);

        if(!CollectionUtils.isEmpty(list)){
            return list;  
        }else {
            return null;
        }
    }
    public OvsaTrvlLrnExp findByExpApplNo(String expApplNo) {
        if (StringUtils.isBlank(expApplNo)) {
            return null;
        }
        StringBuffer queryString = new StringBuffer();
        queryString.append("select distinct exp");
        queryString.append(" from OvsaTrvlLrnExp exp");
        queryString.append(" left join exp.stations station");
        queryString.append(" left join fetch exp.stations");
        queryString.append(" left join station.ovsaCity ovsaCity");
        queryString.append(" left join fetch station.ovsaCity");
        queryString.append(" left join ovsaCity.country country");
        queryString.append(" left join fetch ovsaCity.country");
        queryString.append(" left join country.zoneType zoneType");
        queryString.append(" left join fetch country.zoneType");

        queryString.append(" left join exp.ovsaExpDrawInfos ovsaExpDrawInfo");
        queryString.append(" left join fetch exp.ovsaExpDrawInfos");

        queryString.append(" left join exp.expapplC expapplC");
        queryString.append(" left join fetch exp.expapplC");
        queryString.append(" left join expapplC.expItem expItem");
        queryString.append(" left join fetch expapplC.expItem");
        queryString.append(" left join fetch expItem.budgetItem");
        queryString.append(" left join fetch expapplC.applyUserInfo");
        queryString.append(" left join fetch expapplC.drawMoneyUserInfo");
        queryString.append(" left join fetch expapplC.deliverDaylist");
        queryString.append(" left join fetch expapplC.dailyStatement");
        queryString.append(" left join fetch expapplC.verifyUser");
        queryString.append(" left join fetch expapplC.actualVerifyUser");
        queryString.append(" inner join expapplC.createUser createUser");
        queryString.append(" inner join fetch expapplC.createUser");
        queryString.append(" inner join fetch createUser.department");
        queryString.append(" left join fetch expapplC.updateUser");
        queryString.append(" left join fetch expapplC.expapplCDetails");
        queryString.append(" left join expapplC.entryGroup entryGroup");
        queryString.append(" left join fetch expapplC.entryGroup");
        queryString.append(" inner join fetch entryGroup.entries");
        queryString.append(" left join entryGroup.entries entry");
        queryString.append(" left join fetch entry.entryGroup");
        queryString.append(" left join fetch entry.accTitle");
        queryString.append(" left join fetch entry.subpoena");
        queryString.append(" left join fetch entry.subpoenaD");
        queryString.append(" left join fetch entry.expapplCDetail");
        queryString.append(" where exp.expapplC.expApplNo =:expApplNo");

        Map<String, Object> params = new HashMap<String, Object>();
        //申請單號
        params.put("expApplNo", expApplNo);

        //過濾掉刪除(99)
        queryString.append(" and expapplC.applState.code <>:applStateCode");
        params.put("applStateCode", ApplStateCode.DELETED.getCode());

        List<OvsaTrvlLrnExp> expList = findByNamedParams(queryString.toString(), params);

        if(CollectionUtils.isEmpty(expList)){
            return null;
        }else{
            return expList.get(0);
        }
    }
    public List<OvsaTrvlLrnExp> findByExpApplNo(List<String> expApplNoList) {
        if (CollectionUtils.isEmpty(expApplNoList)) {
            return null;
        }
        StringBuffer queryString = new StringBuffer();
        queryString.append("select distinct exp");
        queryString.append(" from OvsaTrvlLrnExp exp");
        queryString.append(" left join exp.stations station");
        queryString.append(" left join fetch exp.stations");
        queryString.append(" left join station.ovsaCity ovsaCity");
        queryString.append(" left join fetch station.ovsaCity");
        queryString.append(" left join ovsaCity.country country");
        queryString.append(" left join fetch ovsaCity.country");
        queryString.append(" left join country.zoneType zoneType");
        queryString.append(" left join fetch country.zoneType");

        queryString.append(" left join exp.ovsaExpDrawInfos ovsaExpDrawInfo");
        queryString.append(" left join fetch exp.ovsaExpDrawInfos");

        queryString.append(" left join exp.expapplC expapplC");
        queryString.append(" left join fetch exp.expapplC");
        queryString.append(" left join expapplC.expItem expItem");
        queryString.append(" left join fetch expapplC.expItem");
        queryString.append(" left join fetch expItem.budgetItem");
        queryString.append(" left join fetch expapplC.applyUserInfo");
        queryString.append(" left join fetch expapplC.drawMoneyUserInfo");
        queryString.append(" left join fetch expapplC.deliverDaylist");
        queryString.append(" left join fetch expapplC.dailyStatement");
        queryString.append(" left join fetch expapplC.verifyUser");
        queryString.append(" left join fetch expapplC.actualVerifyUser");
        queryString.append(" inner join expapplC.createUser createUser");
        queryString.append(" inner join fetch expapplC.createUser");
        queryString.append(" inner join fetch createUser.department");
        queryString.append(" left join fetch expapplC.updateUser");
        queryString.append(" left join fetch expapplC.expapplCDetails");
        queryString.append(" left join expapplC.entryGroup entryGroup");
        queryString.append(" left join fetch expapplC.entryGroup");
        queryString.append(" inner join fetch entryGroup.entries");
        queryString.append(" left join entryGroup.entries entry");
        queryString.append(" left join fetch entry.entryGroup");
        queryString.append(" left join fetch entry.accTitle");
        queryString.append(" left join fetch entry.subpoena");
        queryString.append(" left join fetch entry.subpoenaD");
        queryString.append(" left join fetch entry.expapplCDetail");
        queryString.append(" where expapplC.expApplNo in(");

        Map<String, Object> params = new HashMap<String, Object>();
        int index = 0;
        for (String expApplNo : expApplNoList) {
            if (index != 0) {
                queryString.append(", ");
            }
            queryString.append(":expApplNo"+index);
            params.put("expApplNo"+index, expApplNo);

            index++;
        }
        queryString.append(")");

        //過濾掉刪除(99)
        queryString.append(" and expapplC.applState.code <>:applStateCode");
        params.put("applStateCode", ApplStateCode.DELETED.getCode());

        //排序 :依「費用申請單. 建檔日期」、「費用申請單.申請單號」遞增排序(#259)
        queryString.append(" ORDER BY expapplC.createDate ASC, expapplC.expApplNo ASC");
        
        List<OvsaTrvlLrnExp> expList = findByNamedParams(queryString.toString(), params);

        if(CollectionUtils.isEmpty(expList)){
            return null;
        }else{
            return expList;
        }
    }



}
