Public Interface IOutSourceHandler

#Region "Properties"

    ''' <summary>
    ''' ��Ʈw�s�u�r��
    ''' </summary>
    ''' <remarks></remarks>
    ReadOnly Property ConnectionString_Eloan() As String

    ReadOnly Property ConnectionString_DJCIC() As String

    ReadOnly Property ConnectionString_IMP_JCIC() As String

    ReadOnly Property ConnectionString_IMP_ADM() As String

    ''' <summary>
    ''' �ݳB�z��Table
    ''' </summary>
    ''' <remarks></remarks>
    ReadOnly Property Tables() As String

    ''' <summary>
    ''' �B�z���j�ɶ�
    ''' </summary>
    ''' <remarks></remarks>
    ReadOnly Property Interval() As Integer

    ''' <summary>
    ''' Log�s����|
    ''' </summary>
    ''' <remarks></remarks>
    ReadOnly Property LogPath() As String

    '''' <summary>
    '''' �O�_�O���ǿ�O��
    '''' </summary>
    '''' <value></value>
    '''' <returns></returns>
    '''' <remarks></remarks>
    'Property OutSourceLog() As Boolean

#End Region

#Region "�ҰʻP�����A�ȱ`��"

    Sub StartThread()
    Sub StopThread()

#End Region

End Interface
