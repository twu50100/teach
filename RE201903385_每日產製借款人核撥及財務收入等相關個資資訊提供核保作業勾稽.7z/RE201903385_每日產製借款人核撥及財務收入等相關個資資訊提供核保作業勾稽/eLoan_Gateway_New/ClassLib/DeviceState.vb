Public Class DeviceState
    Private g_lstStateList As New List(Of StateMessage)
    Private g_strStateID As String = Nothing

    Public Sub New()

    End Sub

    Public Sub AddState(ByVal p_strID As String, ByVal p_strGroupID As String, ByVal p_strMessage As String)
        Dim m_objStateMessage As New StateMessage(p_strID, p_strGroupID, p_strMessage)
        g_lstStateList.Add(m_objStateMessage)
    End Sub

    Private Class StateMessage
        Private g_strID As String = Nothing
        Private g_strGroupID As String = Nothing
        Private g_strMessage As String = Nothing

        Public Sub New(ByVal p_strID As String, ByVal p_strGroupID As String, ByVal p_strMessage As String)
            g_strID = p_strID
            g_strGroupID = p_strGroupID
            g_strMessage = p_strMessage
        End Sub

        Public ReadOnly Property ID() As String
            Get
                Return g_strID
            End Get
        End Property

        Public ReadOnly Property GroupID() As String
            Get
                Return g_strGroupID
            End Get
        End Property

        Public ReadOnly Property Message() As String
            Get
                Return g_strMessage
            End Get
        End Property

    End Class

End Class
