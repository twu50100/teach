﻿Imports System.Data.Common
Imports System.Security.Cryptography
Imports System.IO
Imports System.Text
Imports System.Threading
Imports Microsoft.Practices.EnterpriseLibrary.Data
Imports System.Collections.Concurrent

Public Class ClassLib

    Public Class DBUtil
        Private db As Database
        Public Shared Function GetDB(ByVal mDBConnString As String) As Database
            Dim fac = DbProviderFactories.GetFactory("System.Data.SqlClient")
            Return New GenericDatabase(mDBConnString, fac)
        End Function
    End Class

    '''' <summary>
    '''' 處理連接SQL SERVER端的程序導向
    '''' </summary>
    '''' <remarks>
    '''' 以不同傳入參數使用不同sp來處理
    '''' 
    '''' 
    '''' </remarks>
    '''' 
    'Public Class SQLConnect
    '    Private ConnString As String = ""

    'Public Shared Function ExecuteDataTable(ByRef p_comd As SqlCommand) As DataTable
    '    ExecuteDataTable = Nothing
    '    If p_comd IsNot Nothing Then
    '        Dim m_reader As SqlDataReader = Nothing
    '        Try
    '            m_reader = p_comd.ExecuteReader()

    '            If m_reader IsNot Nothing Then
    '                ExecuteDataTable = getDataTable(m_reader)
    '            End If

    '            'Catch ex As Exception
    '        Finally
    '            If m_reader IsNot Nothing Then m_reader.Close()
    '            p_comd.Dispose()
    '            p_comd = Nothing
    '        End Try
    '    End If
    'End Function

    'Public Shared Function ExecuteNonQuery(ByRef p_comd As SqlCommand) As Integer
    '    ExecuteNonQuery = 0
    '    If p_comd IsNot Nothing Then
    '        Try
    '            ExecuteNonQuery = p_comd.ExecuteNonQuery()
    '            'Catch ex As Exception
    '        Finally
    '            p_comd.Dispose()
    '            p_comd = Nothing
    '        End Try
    '    End If
    'End Function

    'Public Shared Function getDataTable(ByRef p_reader As SqlDataReader) As DataTable
    '    Dim m_dt As DataTable = Nothing

    '    If p_reader IsNot Nothing Then
    '        While p_reader.Read
    '            If m_dt Is Nothing Then
    '                m_dt = New DataTable()
    '                For i As Integer = 0 To p_reader.FieldCount - 1
    '                    Dim m_dc As New DataColumn(p_reader.GetName(i), p_reader.GetFieldType(i))
    '                    m_dt.Columns.Add(m_dc)
    '                Next
    '            End If

    '            Dim m_dr As DataRow = m_dt.NewRow

    '            For i As Integer = 0 To m_dt.Columns.Count - 1
    '                m_dr(i) = p_reader(i)
    '            Next

    '            m_dt.Rows.Add(m_dr)
    '        End While
    '    End If

    '    Return m_dt
    'End Function

    'Public Shared Sub AddInParameter(ByRef p_comd As SqlCommand, ByVal p_strParameterName As String, _
    '                    ByVal p_dbType As Data.DbType, ByVal p_objValue As Object)
    '    Dim m_para As New SqlParameter(p_strParameterName, p_dbType)
    '    If p_objValue Is Nothing Then
    '        m_para.IsNullable = True
    '        m_para.SourceColumnNullMapping = True
    '        m_para.Value = DBNull.Value
    '    Else
    '        m_para.Value = p_objValue
    '    End If

    '    p_comd.Parameters.Add(m_para)
    'End Sub

    'End Class

    ''' <summary>
    ''' 處理字串加解密
    ''' </summary>
    ''' <remarks></remarks>
    Public Class Cryptography
        Private bytKey As Byte() = {80, 200, 64, 255, 246, 184, 194, 116, 107, 13, 140, 243, 216, 209, 141, 186, 194, 210, 139, 82, 0, 118, 131, 13, 120, 39, 109, 118, 170, 40, 189, 61}
        Private bytIV As Byte() = {222, 105, 98, 52, 34, 113, 8, 93, 99, 160, 130, 133, 146, 216, 32, 147}
        '字串加密
        Public Function Enc(ByVal strInput As String) As String
            If strInput.Trim.Length = 0 Then Return ""
            Dim bytInput() As Byte = Encoding.Unicode.GetBytes(strInput)
            Dim ms As New MemoryStream

            Dim RijndaelAlg As Rijndael = Rijndael.Create
            Dim cs As New CryptoStream(ms, RijndaelAlg.CreateEncryptor(Me.bytKey, Me.bytIV), CryptoStreamMode.Write)
            cs.Write(bytInput, 0, bytInput.Length)
            cs.FlushFinalBlock()

            Return Convert.ToBase64String(ms.ToArray)
            Return strInput
        End Function
        '字串解密
        Public Function Dec(ByVal strInput As String) As String
            If strInput.Trim.Length = 0 Then Return ""
            Dim bytInput() As Byte = Convert.FromBase64String(strInput)
            Dim ms As New MemoryStream

            Dim RijndaelAlg As Rijndael = Rijndael.Create
            Dim cs As New CryptoStream(ms, RijndaelAlg.CreateDecryptor(Me.bytKey, Me.bytIV), CryptoStreamMode.Write)
            cs.Write(bytInput, 0, bytInput.Length)
            cs.FlushFinalBlock()

            Return Encoding.Unicode.GetString(ms.ToArray)
            Return strInput
        End Function

    End Class

    ''' <summary>
    ''' 寫入記錄
    ''' </summary>
    ''' <remarks>
    ''' 2009.04.28 Modified by Kevin, 加上Log File備份分檔
    ''' </remarks>
    Public Class WriteLog
        Private Const cstrErrorLogFile As String = "Error.log"
        'Private Const cstrDebugLogFile As String = "Debug.log"

        Private Shared intNextBackupNo As Integer = 0       '下一個備份檔編號
        Private Shared intMaxBackupCount As Integer = 10    '保留最新的備份數
        Private Shared intMaxFileSize As Integer = 5        '每個Log File的最大Size
        Private Shared strFilePath As String = ""           'Log File路徑
        Private Shared flgStop As Boolean = False           '是否停止監看Log File Size

        ''' <summary>
        ''' 啟始Log File Monitor
        ''' </summary>
        ''' <param name="Path">Log File路徑</param>
        ''' <param name="p_intMaxFileSize">Log File檔案最大Size</param>
        ''' <param name="p_intMaxBackupCount">保留Log File數</param>
        ''' <remarks>
        ''' 2009.04.28 Created by Kevin
        ''' </remarks>
        Public Shared Sub StartFileMonitor(ByVal Path As String, Optional ByVal p_intMaxFileSize As Integer = 5, Optional ByVal p_intMaxBackupCount As Integer = 10)
            strFilePath = Path.TrimEnd("/") & "/"
            intMaxBackupCount = p_intMaxBackupCount
            intMaxFileSize = p_intMaxFileSize

            If intMaxBackupCount > 0 Then
                intNextBackupNo = 0
                Dim dtMinDateTime As DateTime = DateTime.Now
                For i As Integer = 1 To intMaxBackupCount - 1
                    If File.Exists(strFilePath & cstrErrorLogFile & i.ToString) Then
                        If File.GetLastWriteTime(strFilePath & cstrErrorLogFile & i.ToString).Ticks < dtMinDateTime.Ticks Then
                            dtMinDateTime = File.GetLastWriteTime(strFilePath & cstrErrorLogFile & i.ToString)
                            intNextBackupNo = i - 1
                        End If
                    Else
                        intNextBackupNo = i - 1
                        Exit For
                    End If
                Next
            Else
                intNextBackupNo = -1
            End If

            flgStop = False
            Dim thdFileMonitor As New Thread(AddressOf FileMonitor)
            thdFileMonitor.Start()

        End Sub

        ''' <summary>
        ''' 停止Log File Monitor
        ''' </summary>
        ''' <remarks>
        ''' 2009.04.28 Created by Kevin
        ''' </remarks>
        Public Shared Sub StopFileMonitor()
            flgStop = True
        End Sub

        ''' <summary>
        ''' Log File Monitor Thread
        ''' </summary>
        ''' <remarks>
        ''' 2009.04.28 Created by Kevin
        ''' </remarks>
        Private Shared Sub FileMonitor()

            While Not flgStop

                Try
                    If File.Exists(strFilePath & cstrErrorLogFile) Then
                        Dim intFileSize As Integer = My.Computer.FileSystem.GetFileInfo(strFilePath & cstrErrorLogFile).Length \ 1048576
                        If intFileSize >= intMaxFileSize Then
                            If intNextBackupNo >= 0 Then
                                Dim strBackupFileName As String = strFilePath & cstrErrorLogFile & (intNextBackupNo + 1).ToString
                                If File.Exists(strBackupFileName) Then
                                    File.Delete(strBackupFileName)
                                End If

                                File.Move(strFilePath & cstrErrorLogFile, strBackupFileName)
                                intNextBackupNo = (intNextBackupNo + 1) Mod intMaxBackupCount
                            Else
                                File.Delete(strFilePath & cstrErrorLogFile)
                            End If
                        End If
                    End If
                Catch ex As Exception

                End Try

                Thread.Sleep(500)
            End While

        End Sub

        Private strPath As String = ""
        Private dtThread As New DataTable
        Private Shared lockMe As New Object
        Private queue As New ConcurrentQueue(Of clsQue)

        Private Class clsQue
            Private _msg As String
            Public Property Msg() As String
                Get
                    Return _msg
                End Get
                Set(ByVal value As String)
                    _msg = value
                End Set
            End Property

            Private _path As String
            Public Property Path() As String
                Get
                    Return _path
                End Get
                Set(ByVal value As String)
                    _path = value
                End Set
            End Property
        End Class

        Public Sub New(ByVal Path As String)
            strPath = Path.TrimEnd("\") & "\"
            strPath = strPath & cstrErrorLogFile
        End Sub

        Public Sub WriteErrorLog(ByVal Msg As String)
            Dim myThread As New Thread(AddressOf WriteLogFile)

            Dim que As New clsQue
            que.Path = strPath
            que.Msg = Now.ToString & " - " & Msg & "！" & vbCrLf
            queue.Enqueue(que)

            Console.WriteLine(myThread.Name + ":" + Msg)
            myThread.Start()
        End Sub

        Private Sub WriteLogFile()
            Try
                If Thread.CurrentThread Is Nothing Then
                    Exit Sub
                End If

                Dim que As New clsQue
                Dim chkQue As Boolean
                chkQue = queue.TryDequeue(que)

                If chkQue Then
                    Dim Path As String = que.Path
                    Dim Msg As String = que.Msg

                    SyncLock lockMe
                        File.AppendAllText(Path, Msg)
                    End SyncLock
                End If
            Catch ex As Exception

            End Try
        End Sub

    End Class

    Public Class Settings
        Private ReadOnly g_strSettingsFileName = "settings.xml"
        Private ReadOnly g_strSettingsTableName = "Settings"
        Private g_dsELoanGateway As New DataSet("eLoanGateway")
        Private g_strStartupPath As String = Nothing

        Public Enum SettingType
            _String = 1
            _Integer = 2
            _Boolean = 3
        End Enum

        Public Sub New(ByVal p_strStartupPath As String)
            g_strStartupPath = p_strStartupPath

            If File.Exists(g_strStartupPath & "\" & g_strSettingsFileName) Then
                g_dsELoanGateway.ReadXml(g_strStartupPath & "\" & g_strSettingsFileName)
            Else
                Dim m_dtSettings As New DataTable(g_strSettingsTableName)
                g_dsELoanGateway.Tables.Add(m_dtSettings)

                m_dtSettings.Columns.Add("Key", GetType(String))
                m_dtSettings.Columns(0).MaxLength = 30
                m_dtSettings.Columns.Add("Type", GetType(String))
                m_dtSettings.Columns.Add("Value", GetType(String))
                m_dtSettings.Columns(2).MaxLength = 255
            End If
        End Sub

        Public Sub Save()
            g_dsELoanGateway.WriteXml(g_strStartupPath & "\" & g_strSettingsFileName)
        End Sub

        Public Sub AddSetting(ByVal p_strKey As String, ByVal p_enumType As SettingType, ByVal p_strValue As Object)
            Dim m_dtSettings As DataTable = CType(g_dsELoanGateway.Tables(g_strSettingsTableName), DataTable)
            Dim m_drSettings() As DataRow = m_dtSettings.Select("Key='" & p_strKey & "'")
            If m_drSettings.Length > 0 Then
                m_drSettings(0)("Type") = p_enumType.ToString
                m_drSettings(0)("Value") = p_strValue.ToString
            Else
                Dim m_drSetting As DataRow = CType(g_dsELoanGateway.Tables(g_strSettingsTableName), DataTable).NewRow()

                m_drSetting("Key") = p_strKey
                m_drSetting("Type") = p_enumType.ToString
                m_drSetting("Value") = p_strValue.ToString

                m_dtSettings.Rows.Add(m_drSetting)
            End If
        End Sub

        Public Function ReadSetting(ByVal p_strKey) As Object
            ReadSetting = Nothing

            Dim m_dtSettings As DataTable = CType(g_dsELoanGateway.Tables(g_strSettingsTableName), DataTable)
            Dim m_drSettings() As DataRow = m_dtSettings.Select("Key='" & p_strKey & "'")

            If m_drSettings.Length > 0 Then
                Select Case CType(m_drSettings(0)("Type"), String)
                    Case SettingType._String.ToString
                        Dim m_strValue As String = m_drSettings(0)("Value").ToString
                        ReadSetting = m_strValue
                    Case SettingType._Integer.ToString
                        Dim m_intValue As Integer = 0
                        If Integer.TryParse(m_drSettings(0)("Value").ToString, m_intValue) Then
                            ReadSetting = m_intValue
                        End If
                    Case SettingType._Boolean.ToString
                        Dim m_bolValue As Boolean = m_drSettings(0)("Value").ToString.ToLower = "true"
                        ReadSetting = m_bolValue
                End Select
            End If

            Return ReadSetting
        End Function

        Public Sub AddList(ByVal p_dtList As DataTable)

            If g_dsELoanGateway.Tables(p_dtList.TableName) IsNot Nothing Then
                g_dsELoanGateway.Tables.Remove(p_dtList.TableName)
            End If

            g_dsELoanGateway.Tables.Add(p_dtList)
        End Sub

        Public Function ReadList(ByVal p_strListName As String) As DataTable
            ReadList = Nothing

            If g_dsELoanGateway.Tables(p_strListName) IsNot Nothing Then
                ReadList = g_dsELoanGateway.Tables(p_strListName)
            End If

            Return ReadList
        End Function

    End Class

    '#Region "難字處理"

    '    ''' <summary>
    '    ''' 新光轉碼對映表名稱
    '    ''' </summary>
    '    ''' <remarks>
    '    ''' UCS2BIG5 : Unicode -> BIG5
    '    ''' UCS2EXT  : Unicode -> BIG5延伸碼
    '    ''' BIG52UCS : BIG5 -> Unicode
    '    ''' EXT2UCS  : BIG5延伸碼 -> Unicode
    '    ''' 2009.06.08 Created by Kevin
    '    ''' </remarks>
    '    Protected Enum WordConvertMappingType
    '        UCS2BIG5 = 0
    '        UCS2EXT = 1
    '        BIG52UCS = 2
    '        EXT2UCS = 3
    '    End Enum

    '    ''' <summary>
    '    ''' 新光轉碼公用類別
    '    ''' </summary>
    '    ''' <remarks>
    '    ''' 2009.06.08 Created by Kevin
    '    ''' </remarks>
    '    Public Class WordConvert4SKBank
    '        'Code Mapping Hashtable
    '        Private Shared m_htCodeMapping(0 To 3) As Hashtable

    '        ''' <summary>
    '        ''' 初始化新光轉碼類別(將Mapping Table載入至Mapping Hashtable)
    '        ''' </summary>
    '        ''' <param name="p_strConnString">DB Connection String</param>
    '        ''' <remarks>
    '        ''' 2009.06.08 Created by Kevin
    '        ''' </remarks>
    '        Public Shared Sub Init(ByVal p_strConnString As String)
    '            For i As Integer = 0 To m_htCodeMapping.Length - 1
    '                Dim m_enmMappingType As WordConvertMappingType = i
    '                Dim sqlSelect As String = Nothing

    '                m_htCodeMapping(i) = New Hashtable()
    '                m_htCodeMapping(i).Clear()

    '                sqlSelect = " SELECT " & _
    '                                    " From_Code " & _
    '                                    ",To_Code " & _
    '                            " FROM " & _
    '                                    " Maintain_Code_Mapping " & _
    '                            " WHERE " & _
    '                                    " LanguageType = @LanguageType " & _
    '                            " AND " & _
    '                                    " Mapping_Type = @Mapping_Type "

    '                Dim dbc As New SqlConnection(p_strConnString)
    '                Dim dbcom As New SqlCommand(sqlSelect, dbc)
    '                Dim m_dbParam As SqlParameter

    '                m_dbParam = New SqlParameter("@LanguageType", SqlDbType.VarChar)
    '                m_dbParam.Value = "zh-TW"
    '                dbcom.Parameters.Add(m_dbParam)

    '                m_dbParam = New SqlParameter("@Mapping_Type", SqlDbType.VarChar)
    '                m_dbParam.Value = m_enmMappingType.ToString
    '                dbcom.Parameters.Add(m_dbParam)

    '                Try
    '                    dbc.Open()

    '                    Dim m_dbReader As SqlDataReader = dbcom.ExecuteReader()
    '                    If m_dbReader IsNot Nothing Then
    '                        While m_dbReader.Read()
    '                            Dim m_strFrom_Code As String = m_dbReader.GetString(0)
    '                            Dim m_strTo_Code As String = m_dbReader.GetString(1)
    '                            m_htCodeMapping(i).Add(m_strFrom_Code, m_strTo_Code)
    '                        End While
    '                    End If
    '                Catch ex As Exception

    '                Finally
    '                    If dbcom IsNot Nothing Then dbcom.Dispose()
    '                    If dbc IsNot Nothing Then
    '                        dbc.Close()
    '                        dbc.Dispose()
    '                    End If
    '                End Try

    '            Next
    '        End Sub

    '        ''' <summary>
    '        ''' 新光轉碼程式 BIG5 轉 Unicode
    '        ''' </summary>
    '        ''' <param name="byteBuffer">欲轉碼之BIG5資料Buffer</param>
    '        ''' <param name="intLength">資料總長度(Bytes)</param>
    '        ''' <returns>轉碼後之Unicode資料</returns>
    '        ''' <remarks>
    '        ''' 2009.06.08 Created by Kevin
    '        ''' </remarks>
    '        Public Shared Function BIG52UCS(ByVal byteBuffer() As Byte, ByVal intLength As String) As String
    '            BIG52UCS = ""

    '            Dim m_objFromEncoding As Encoding = Encoding.GetEncoding(950)
    '            Dim m_objToEncoding As Encoding = Encoding.Unicode

    '            For i As Integer = 0 To intLength - 1
    '                If byteBuffer(i) > 127 Then     '全形字的第一個byte

    '                    Dim m_strWordHex4BIG5 As String = Right("0" & Hex(byteBuffer(i)), 2) & Right("0" & Hex(byteBuffer(i + 1)), 2)
    '                    Dim m_strWordHex4UCS As String = Nothing
    '                    Dim strTemp As String = ""

    '                    If m_htCodeMapping(WordConvertMappingType.BIG52UCS).ContainsKey(m_strWordHex4BIG5) = True Then
    '                        m_strWordHex4UCS = m_htCodeMapping(WordConvertMappingType.BIG52UCS)(m_strWordHex4BIG5).ToString()
    '                    ElseIf m_htCodeMapping(WordConvertMappingType.EXT2UCS).ContainsKey(m_strWordHex4BIG5) = True Then
    '                        m_strWordHex4UCS = m_htCodeMapping(WordConvertMappingType.EXT2UCS)(m_strWordHex4BIG5).ToString()
    '                    End If

    '                    If m_strWordHex4UCS IsNot Nothing Then
    '                        Dim m_byteTemp((m_strWordHex4UCS.Length \ 2) - 1) As Byte
    '                        For j As Integer = 0 To m_strWordHex4UCS.Length - 1 Step 2
    '                            m_byteTemp(m_byteTemp.Length - 1 - (j \ 2)) = Convert.ToInt16(m_strWordHex4UCS.Substring(j, 2), 16)
    '                        Next

    '                        strTemp = m_objToEncoding.GetString(m_byteTemp, 0, m_byteTemp.Length)
    '                    Else
    '                        strTemp = m_objFromEncoding.GetString(byteBuffer, i, 2)
    '                    End If

    '                    If strTemp = "?" Then       '無法正常轉碼
    '                        BIG52UCS &= "??"
    '                    Else
    '                        BIG52UCS &= strTemp
    '                    End If
    '                    i += 1
    '                Else                            '半形字
    '                    BIG52UCS &= m_objFromEncoding.GetString(byteBuffer, i, 1)
    '                End If
    '            Next

    '            Return BIG52UCS
    '        End Function

    '        ''' <summary>
    '        ''' 新光轉碼程式 Unicode 轉 BIG5
    '        ''' </summary>
    '        ''' <param name="p_strUCS">欲轉碼之Unicode資料字串</param>
    '        ''' <returns>轉碼後之BIG5資料Buffer</returns>
    '        ''' <remarks>
    '        ''' 2009.06.08 Created by Kevin
    '        ''' </remarks>
    '        Public Shared Function UCS2BIG5(ByVal p_strUCS As String) As Byte()
    '            Dim byteBuffer(p_strUCS.Length * 2) As Byte
    '            Dim m_intCount As Integer = 0

    '            Dim m_objFromEncoding As Encoding = Encoding.Unicode
    '            Dim m_objToEncoding As Encoding = Encoding.GetEncoding(950)

    '            For i As Integer = 0 To p_strUCS.Length - 1
    '                Dim m_strWord As String = p_strUCS.Substring(i, 1)
    '                Dim m_byteFromTemp() As Byte = m_objFromEncoding.GetBytes(m_strWord)

    '                Dim m_strWordHex4BIG5 As String = Nothing

    '                If m_byteFromTemp.Length = 2 Then
    '                    Dim m_strWordHex4UCS As String = Right("0" & Hex(m_byteFromTemp(1)), 2) & Right("0" & Hex(m_byteFromTemp(0)), 2)

    '                    If m_htCodeMapping(WordConvertMappingType.UCS2BIG5).ContainsKey(m_strWordHex4UCS) = True Then
    '                        m_strWordHex4BIG5 = m_htCodeMapping(WordConvertMappingType.UCS2BIG5)(m_strWordHex4UCS).ToString
    '                    ElseIf m_htCodeMapping(WordConvertMappingType.UCS2EXT).ContainsKey(m_strWordHex4UCS) = True Then
    '                        m_strWordHex4BIG5 = m_htCodeMapping(WordConvertMappingType.UCS2EXT)(m_strWordHex4UCS).ToString
    '                    End If

    '                End If

    '                If m_strWordHex4BIG5 IsNot Nothing Then
    '                    For j As Integer = 0 To m_strWordHex4BIG5.Length - 1 Step 2
    '                        byteBuffer(m_intCount) = Convert.ToInt16(m_strWordHex4BIG5.Substring(j, 2), 16)
    '                        m_intCount += 1
    '                    Next
    '                Else
    '                    Dim m_byteToTemp() As Byte = Encoding.Convert(m_objFromEncoding, m_objToEncoding, m_byteFromTemp)
    '                    If m_byteToTemp IsNot Nothing AndAlso m_byteToTemp.Length > 0 Then
    '                        For j As Integer = 0 To m_byteToTemp.Length - 1
    '                            byteBuffer(m_intCount) = m_byteToTemp(j)
    '                            m_intCount += 1
    '                        Next

    '                        If m_byteToTemp.Length = 1 AndAlso m_byteToTemp(0) = 63 AndAlso m_byteFromTemp.Length > 1 Then
    '                            byteBuffer(m_intCount) = 63
    '                            m_intCount += 1
    '                        End If
    '                    End If
    '                End If
    '            Next

    '            If m_intCount > 0 Then
    '                ReDim UCS2BIG5(m_intCount - 1)
    '                Array.Copy(byteBuffer, UCS2BIG5, m_intCount)
    '            Else
    '                UCS2BIG5 = Nothing
    '            End If

    '            Return UCS2BIG5
    '        End Function

    '    End Class
    '    ''' <summary>
    '    ''' 排除難字
    '    ''' </summary>
    '    ''' <param name="byteBuffer">欲處理的Buffer</param>
    '    ''' <param name="intLength">資料長度</param>
    '    ''' <param name="intEncoding">編碼方式</param>
    '    ''' <remarks>
    '    ''' 2009.04.15 Created by Kevin
    '    ''' </remarks>
    '    Public Shared Sub ObviateSpecialWord(ByRef byteBuffer() As Byte, ByVal intLength As Integer, ByVal intEncoding As Integer)
    '        For i As Integer = 0 To intLength - 1
    '            If byteBuffer(i) > 127 Then     '全形字的第一個byte
    '                Dim strTemp As String = Encoding.GetEncoding(intEncoding).GetString(byteBuffer, i, 2)
    '                If strTemp = "?" Then       '無法正常轉碼
    '                    byteBuffer(i) = Asc("?")
    '                    byteBuffer(i + 1) = Asc("?")
    '                End If
    '                i = i + 1
    '            End If
    '        Next
    '    End Sub

    '#End Region

    'Public Shared Function JcicProcess(ByRef content1, ByVal length1) As String

    '    Dim bytes, z, content1_length As Integer
    '    Dim data_str As New System.Text.StringBuilder, temp_char As String
    '    bytes = 0
    '    z = 0
    '    'data_str = ""
    '    temp_char = ""
    '    content1_length = Len(content1)
    '    '當位元組小於傳入的長度，以及未處理到最後一字時才進行處理
    '    Do While (bytes < length1 And z < content1_length)
    '        z = z + 1
    '        temp_char = Mid(content1, z, 1)
    '        If Len(Hex(Asc(temp_char))) > 2 Then '中文字位元組長度加2
    '            bytes = bytes + 2
    '        Else
    '            bytes = bytes + 1
    '        End If
    '        data_str.Append(temp_char)
    '    Loop
    '    content1 = Mid(content1, z + 1) '將字串去掉前面算出的data_str，存入processing_content中
    '    JcicProcess = data_str.ToString    '回傳算出的data_str
    'End Function

End Class