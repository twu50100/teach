﻿Imports System.Windows.Forms
Imports System.Xml
Imports System.Data.SqlClient
Imports eLoan_Gateway
Imports eLoan_Gateway.ClassLib
Imports System.Net   'Web
Imports System.IO    'Files
Imports System.Object
Imports System.Text
Imports Microsoft.Practices.EnterpriseLibrary.Data
Imports System.Data.Common

Module eLoanInsCheckData
    Private g_objSettings As ClassLib.Settings = Nothing
    Private g_strLogPath As String = Nothing
    Private g_writeLog As eLoan_Gateway.ClassLib.WriteLog
    Private g_strDBConnString As String = Nothing
    Private g_strDBConnEloanString As String = Nothing

    Sub Main()
        'eLoan資料庫連線字串
        g_objSettings = New ClassLib.Settings(Application.StartupPath)

        Try
            g_strLogPath = CStr(g_objSettings.ReadSetting("LogPath")).TrimEnd("\") & "\"

            g_writeLog = New eLoan_Gateway.ClassLib.WriteLog(g_strLogPath)

        Catch ex As Exception
            If g_writeLog IsNot Nothing Then
                g_writeLog.WriteErrorLog("eLoanInsCheckData:Failed to Load Settings, " & ex.Message)
            End If
            Exit Sub
        End Try
    End Sub

End Module
