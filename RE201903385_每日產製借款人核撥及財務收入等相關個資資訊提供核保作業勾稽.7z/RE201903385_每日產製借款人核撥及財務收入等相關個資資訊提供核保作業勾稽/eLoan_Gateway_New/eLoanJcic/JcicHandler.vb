Imports System.Collections.Concurrent
Imports System.Data.Common
Imports System.Data.SqlClient
Imports System.IO
Imports System.Text
Imports eLoan_Gateway.ClassLib
Imports Microsoft.Practices.EnterpriseLibrary.Data
Public Class JcicHandler
    Implements eLoan_Gateway.IOutSourceHandler

    Private g_threadMain As Threading.Thread = Nothing
    Private g_bolStop As Boolean = True
    Private Enc As Encoding = Encoding.GetEncoding(950)
    Private g_writeLog As WriteLog = Nothing

#Region "Properties"

    ''' <summary>
    ''' ��Ʈw�s�u�r��
    ''' </summary>
    ''' <remarks></remarks>
    Private g_strConnString_eloan As String = Nothing
    Public ReadOnly Property ConnectionString() As String _
            Implements eLoan_Gateway.IOutSourceHandler.ConnectionString_Eloan
        Get
            Return g_strConnString_eloan
        End Get

    End Property


    Private g_strConnString_IMP_DJCIC As String = Nothing
    Public Property ConnectionString_IMP_JCIC() As String _
            Implements eLoan_Gateway.IOutSourceHandler.ConnectionString_IMP_JCIC
        Get
            Return g_strConnString_IMP_DJCIC
        End Get

        Set(value As String)
            g_strConnString_IMP_DJCIC = value
        End Set
    End Property

    Private g_strConnString_IMP_Adm As String = Nothing
    Public Property ConnectionString_IMP_Adm() As String _
            Implements eLoan_Gateway.IOutSourceHandler.ConnectionString_IMP_ADM
        Get
            Return g_strConnString_IMP_Adm
        End Get

        Set(value As String)
            g_strConnString_IMP_Adm = value
        End Set
    End Property


    Private g_strConnString_DJCIC As String = Nothing
    Public Property ConnectionString_DJCIC() As String _
        Implements eLoan_Gateway.IOutSourceHandler.ConnectionString_DJCIC
        Get
            Return g_strConnString_DJCIC
        End Get

        Set(value As String)
            g_strConnString_DJCIC = value
        End Set
    End Property

    ''' <summary>
    ''' �ݳB�z��Table
    ''' </summary>
    ''' <remarks></remarks>
    Private g_strTables() As String = Nothing
    Public ReadOnly Property Tables() As String _
            Implements eLoan_Gateway.IOutSourceHandler.Tables
        Get
            Dim m_strTemp As String = ""
            If g_strTables IsNot Nothing AndAlso g_strTables.Length > 0 Then
                For i As Integer = 0 To g_strTables.Length - 1
                    m_strTemp &= g_strTables(i) & ";"
                Next
            End If
            Return m_strTemp.TrimEnd(";")
        End Get
    End Property

    ''' <summary>
    ''' �B�z���j�ɶ�
    ''' </summary>
    ''' <remarks></remarks>
    Private g_intInterval As Integer = 0
    Public ReadOnly Property Interval() As Integer _
            Implements eLoan_Gateway.IOutSourceHandler.Interval
        Get
            Return g_intInterval \ 1000
        End Get
    End Property

    ''' <summary>
    ''' Log�s����|
    ''' </summary>
    ''' <remarks></remarks>
    Private g_strLogPath As String = Nothing
    Public ReadOnly Property LogPath() As String _
            Implements eLoan_Gateway.IOutSourceHandler.LogPath
        Get
            Return g_strLogPath
        End Get
    End Property

#End Region

#Region "�غc�l"

    ''' <summary>
    ''' �غc�l�禡
    ''' </summary>
    ''' <param name="p_strConnectionString_eloan">��Ʈw�s�u�r��</param>
    ''' <param name="p_strTables">�ݳB�z��Table</param>
    ''' <param name="p_intInterval">�B�z���j�ɶ�</param>
    ''' <param name="p_strLogPath">Log�s����|</param>
    ''' <remarks></remarks>
    Sub New(ByVal p_strConnectionString_eloan As String,
                ByVal p_strTables As String,
                ByVal p_intInterval As Integer,
                ByVal p_strLogPath As String,
                p_strConnectionString_IMP_DJCIC As String,
                p_strConnectionString_DJCIC As String)
        g_strConnString_eloan = p_strConnectionString_eloan
        g_strConnString_IMP_DJCIC = p_strConnectionString_IMP_DJCIC
        g_strConnString_DJCIC = p_strConnectionString_DJCIC

        g_strTables = p_strTables.Split(";")
        g_intInterval = p_intInterval * 1000
        g_strLogPath = p_strLogPath

        g_writeLog = New WriteLog(g_strLogPath)
    End Sub

#End Region

#Region "�ҰʻP�����A�ȱ`��"
    Private messagesLock As New Object

    Public Sub StartThread() _
        Implements eLoan_Gateway.IOutSourceHandler.StartThread

        g_bolStop = False
        If g_threadMain Is Nothing Then
            g_threadMain = New Threading.Thread(AddressOf MainThread)
            g_threadMain.Start()
        End If
    End Sub

    Public Sub StopThread() _
        Implements eLoan_Gateway.IOutSourceHandler.StopThread

        g_bolStop = True

        If g_threadMain IsNot Nothing Then
            For i As Integer = 0 To 20
                If g_threadMain.ThreadState = Threading.ThreadState.Stopped Then
                    Exit For
                End If
                Threading.Thread.Sleep(1000)
            Next
            If g_threadMain.ThreadState <> Threading.ThreadState.Stopped Then
                Try
                    g_threadMain.Abort()
                Catch ex As Exception
                End Try
            End If

            g_threadMain = Nothing
        End If
    End Sub

#End Region

#Region "����ǥD��"
    Private Sub MainThread()
        While Not g_bolStop
            UpdateApplyStatus()
            UpdateJcicStatus()
            ParseJcicData()
            If g_bolStop Then Exit While
            Threading.Thread.Sleep(g_intInterval)
        End While
    End Sub

#End Region

    Private Sub ParseJcicData()
        Dim section As Array
        Dim m_ErrorLog As String = ""
        Dim x As Long '
        Dim j As Integer
        Dim Check(0) As String
        Dim parse_status As Integer = 0 '�ѪR���A0:���ѪR 1:�ѪR���� 2:�ѪR����
        Dim iSort As Integer = 0 '�C�@��ATOM���h�ָ��
        Dim ResponseData, processing_content As String
        Dim sElement As String = "" 'ATOM���W�٨ҦpKRM040

        Try
            '�s�u��Ʈw
            Dim moDB_IMP_DJCIC As Database = DBUtil.GetDB(g_strConnString_IMP_DJCIC)
            Dim moDB_DJCIC As Database = DBUtil.GetDB(g_strConnString_DJCIC)
            Dim moDB_ELOAN As Database = DBUtil.GetDB(g_strConnString_eloan)

            '1.���oSKL_DJCIC.MQMessage_History�����
            Dim dtDJCIC_MQMessage_History_Top As DataTable = GetDJCIC_MQMessage_History_Top(moDB_DJCIC)


            '2.���oSKL_IMP_JCIC. ATOM��쪺���
            Dim dtJcicItemElementContent As DataTable = GetElementContent(moDB_IMP_DJCIC)
            If dtJcicItemElementContent.Rows.Count = 0 Then
                g_writeLog.WriteErrorLog("JcicItemElementContent�L�]�w��� ")
                Exit Sub
            End If
            Dim dvJcicItemElementContent As DataView = New DataView(dtJcicItemElementContent) '����ATOM����줺�e

            '3.SQL���O
            Dim moDBCmd_Paras_JCIC As DbCommand = Nothing
            Dim moDBCmd_DeleteDJCIC As DbCommand = Nothing
            Dim moDBCmd_UpdateELOAN As DbCommand = Nothing
            Dim moDBCmd_InsertImpDJCIC As DbCommand = Nothing
            Dim sqlInsertColumn As String = ""
            Dim sqlInsertValue As String = ""
            Dim sqlInsert As StringBuilder = New StringBuilder
            Dim sqlInsertAtom_IMP As StringBuilder = New StringBuilder
            Dim sqlDelete As StringBuilder = New StringBuilder
            Dim sqlCopy As String = ""
            Dim sqlUpdate As String = ""
            Dim dataFmt() As String = {"R", "H"}
            Dim p_strTableName As String = Nothing

            Dim dic As New ConcurrentDictionary(Of String, Integer)

            '4.�����p�x�ѪR
            Dim strMqHis_SeqNo, strMqHis_RequestID, strMqHis_Status, strMqHis_ResponseTime, strMqHis_RequestData, strMqErrCode As String
            Dim dtIMP As DataTable
            Dim dvIMP As DataView
            For Each drMqHis As DataRow In dtDJCIC_MQMessage_History_Top.Rows
                strMqHis_SeqNo = drMqHis.Item("SeqNo").ToString()
                strMqHis_RequestID = drMqHis.Item("RequestID").ToString()
                strMqHis_Status = drMqHis.Item("Status").ToString()
                strMqHis_RequestData = drMqHis.Item("RequestData")
                strMqHis_ResponseTime = drMqHis.Item("ResponseTime")
                strMqErrCode = drMqHis.Item("ErrCode").ToString.TrimEnd
                m_ErrorLog = "****[SeqNo]=" & strMqHis_SeqNo & "[ResponseTime]=" & strMqHis_ResponseTime & "[Status]=" & strMqHis_Status & " [ErrCode] = " & strMqErrCode & " *** "

                parse_status = 0
                sqlInsert.Clear()
                sqlDelete.Clear()
                sqlInsertAtom_IMP.Clear()
                sqlInsertColumn = ""
                sqlInsertValue = ""
                'strMaxSort = ""
                sqlCopy = ""
                sElement = ""
                sqlUpdate = ""

                If strMqHis_Status = "2" And strMqHis_RequestID.StartsWith("Q") And strMqErrCode = "0000" Then '2�w���� 
                    ''***�ݭn�ѪR START
                    ResponseData = Mid(drMqHis.Item("ResponseData"), 16)     '�^�Ǫ���ƫe15�ӵL�γB�A�ҥH�q��16�Ӷ}�l�� 
                    If ResponseData.Length > 0 Then
                        dtIMP = New DataTable
                        With dtIMP
                            .Columns.Add("Element", GetType(System.String))
                            .Columns.Add("iSort", GetType(System.Int32))
                        End With
                        section = Split(ResponseData, Chr(10))  '�Ǧ^���� (linefeed) �r��
                        Array.Sort(section) '�Ƨǰ}�C���M�����p�x��ƨS���̷Ӷ��Ƿ|�Ӧ��s�WMQMessageAtom_IMP���� 
                        '*****�զX�s�WJCIC_XXX�����
                        For x = 0 To UBound(section)
                            processing_content = Mid(section(x), 7)
                            If sElement <> Left(section(x), 6) Then
                                'If sElement <> "" Then '�����C��ATOM������
                                '    strMaxSort = strMaxSort + sElement + "|" + iSort.ToString + ";"
                                'End If
                                sElement = Left(section(x), 6)
                                iSort = 1
                                If Trim(sElement) <> "" Then
                                    dic(sElement) = iSort
                                    'strMaxSort = strMaxSort + sElement + "|" + iSort.ToString + ";"
                                End If
                            Else
                                iSort = iSort + 1
                                dic(sElement) = iSort
                            End If

                            If sElement <> "" Then
                                '��X�p�x�^�Ǹ�ƪ�ATOM�bIMP_JCIC�����
                                dvJcicItemElementContent.RowFilter = "elementNo='" & sElement & "'"
                                dvJcicItemElementContent.Sort = "Sort"

                                If dvJcicItemElementContent.Count = 0 Then '�L�]�wElementContent�N�ߥX���~
                                    g_writeLog.WriteErrorLog(m_ErrorLog + ",mElementContent�L���,[ATOM]=" & sElement)
                                    parse_status = 1 '�ѪR����
                                    Exit For
                                End If

                                If iSort = 1 Then
                                    '�R��MQMessageAtom_IMP�PJCIC_XXX������
                                    sqlDelete.Append(" DELETE FROM MQMessageAtom_IMP WHERE JcicSeqNo=@JcicSeqNo AND ResponseTime = @ResponseTime AND ATOM_CODE='" & sElement & "' ;" &
                                            " DELETE FROM Jcic_" & sElement & " WITH (ROWLOCK)  WHERE JcicSeqNo=@JcicSeqNo AND ResponseTime = @ResponseTime ;")
                                End If

                                '����IMP���Ǹ�
                                Dim dr As DataRow = dtIMP.NewRow
                                dr("Element") = sElement
                                dr("iSort") = iSort
                                dtIMP.Rows.Add(dr)

                                '�s�WJCIC_XXX������
                                sqlInsertColumn = " INSERT INTO Jcic_" & sElement & " ( UKey,JcicSeqNo,ResponseTime,RequestCode,RequestData,Sort,LastUpdateDate"
                                sqlInsertValue = " VALUES (@UKey,@JcicSeqNo,@ResponseTime,@RequestCode,@RequestData," & iSort.ToString & ", getdate()"
                                For j = 0 To dvJcicItemElementContent.Count - 1
                                    Check(0) = processToken(processing_content, dvJcicItemElementContent.Item(j).Item("Length"))
                                    Check(0) = Replace(Check(0), "'", "''")
                                    sqlInsertColumn = sqlInsertColumn + "," & dvJcicItemElementContent.Item(j).Item("Content")
                                    sqlInsertValue = sqlInsertValue + ",'" & (Check(0)).TrimEnd & "'"

                                Next
                                sqlInsert.Append(sqlInsertColumn.ToString + ") " + sqlInsertValue.ToString + ") ;")
                            End If
                        Next 'section ATOM���

                        If dtIMP.Rows.Count > 0 Then
                            dvIMP = New DataView(dtIMP)
                            dvIMP.Sort = "Element,iSort desc"
                            sElement = ""
                            For k As Integer = 0 To dvIMP.Count - 1
                                If (dvIMP.Item(k).Item("Element") <> sElement) Then
                                    sqlInsertAtom_IMP.Append("INSERT INTO MQMessageAtom_IMP (JcicSeqNo,ResponseTime,ATOM_CODE,ATOM_ROWS) " &
                                            " VALUES (@JcicSeqNo , @ResponseTime,'" & dvIMP.Item(k).Item("Element") & "'," & dvIMP.Item(k).Item("iSort") & "); ")
                                End If
                                sElement = dvIMP.Item(k).Item("Element")
                            Next k
                        End If


                        If sqlInsert.ToString.Length > 0 Then
                            Try
                                moDBCmd_Paras_JCIC = moDB_IMP_DJCIC.GetSqlStringCommand(sqlDelete.ToString + sqlInsert.ToString + sqlInsertAtom_IMP.ToString)
                                moDB_IMP_DJCIC.AddInParameter(moDBCmd_Paras_JCIC, "@UKey", DbType.String, Guid.NewGuid.ToString)
                                moDB_IMP_DJCIC.AddInParameter(moDBCmd_Paras_JCIC, "@JcicSeqNo", DbType.String, strMqHis_SeqNo)
                                moDB_IMP_DJCIC.AddInParameter(moDBCmd_Paras_JCIC, "@ResponseTime", DbType.DateTime, strMqHis_ResponseTime)
                                moDB_IMP_DJCIC.AddInParameter(moDBCmd_Paras_JCIC, "@RequestData", DbType.String, strMqHis_RequestData)
                                moDB_IMP_DJCIC.AddInParameter(moDBCmd_Paras_JCIC, "@RequestCode", DbType.String, Right(strMqHis_RequestID, 3))
                                moDB_IMP_DJCIC.ExecuteNonQuery(moDBCmd_Paras_JCIC)

                                parse_status = 2 '�w�ѪR
                            Catch ex As Exception
                                g_writeLog.WriteErrorLog(m_ErrorLog + ";insert SQL fail :[SQL]=" & sqlDelete.ToString + sqlInsert.ToString + sqlInsertAtom_IMP.ToString & ",[EX]=" & ex.Message.ToString)
                                parse_status = 1 '�ѪR����
                                Continue For '������History�N�O���ѪR����
                            End Try
                        End If
                    End If 'ResponseData>0
                End If ''***�ݭn�ѪR END

                'g_writeLog.WriteErrorLog(m_ErrorLog + ";[parse_status]=" & parse_status)

                If parse_status = "2" Or strMqHis_RequestID.StartsWith("H") Or strMqHis_Status = "3" Or
                    (strMqHis_Status = "2" And strMqErrCode <> "0000") Then
                    'parse_status = "2"�w�ѪR
                    'strMqHis_RequestID.StartsWith("H")�OHTML��� 
                    'strMqHis_Status=3�B�z����
                    'strMqHis_Status = "2" And strMqErrCode <> "0000"�w�g�^�Ц������~�T��
                    ''1.�NDJCIC��MQMessage_History�s�W��IMP_JCIC.MQMessage_History�� 
                    sqlCopy = " DELETE From MQMessage_History Where SeqNo =@JcicSeqNo And ResponseTime=@ResponseTime ;
                                INSERT INTO MQMessage_History VALUES
                                (@JcicSeqNo ,@ResponseTime ,@BankCode ,@LineCode ,@SysDate ,@SysTime 
                                ,@RequestID,@ResponseID,@ErrCode ,@BranchCode ,@JBranchCode 
                                ,@UserID ,@Filler ,@RequestData ,@Memo ,@Status ,@Pivotal 
                                ,@SendDate ,@SendTime ,@ReturnDate ,@ReturnTime ,@ReSeqNo ,@Total 
                                ,@responsedata ,@AgreeDate )"
                    moDBCmd_InsertImpDJCIC = moDB_IMP_DJCIC.GetSqlStringCommand(sqlCopy.ToString)
                    moDB_IMP_DJCIC.AddInParameter(moDBCmd_InsertImpDJCIC, "@JcicSeqNo", DbType.String, strMqHis_SeqNo)
                    moDB_IMP_DJCIC.AddInParameter(moDBCmd_InsertImpDJCIC, "@ResponseTime", DbType.DateTime, strMqHis_ResponseTime)
                    moDB_IMP_DJCIC.AddInParameter(moDBCmd_InsertImpDJCIC, "@BankCode", DbType.String, drMqHis.Item("BankCode").ToString)
                    moDB_IMP_DJCIC.AddInParameter(moDBCmd_InsertImpDJCIC, "@LineCode", DbType.String, drMqHis.Item("LineCode").ToString)
                    moDB_IMP_DJCIC.AddInParameter(moDBCmd_InsertImpDJCIC, "@SysDate", DbType.String, drMqHis.Item("SysDate").ToString)
                    moDB_IMP_DJCIC.AddInParameter(moDBCmd_InsertImpDJCIC, "@SysTime", DbType.String, drMqHis.Item("SysTime").ToString)
                    moDB_IMP_DJCIC.AddInParameter(moDBCmd_InsertImpDJCIC, "@RequestID", DbType.String, strMqHis_RequestID)
                    moDB_IMP_DJCIC.AddInParameter(moDBCmd_InsertImpDJCIC, "@ResponseID", DbType.String, drMqHis.Item("ResponseID").ToString)
                    moDB_IMP_DJCIC.AddInParameter(moDBCmd_InsertImpDJCIC, "@ErrCode", DbType.String, drMqHis.Item("ErrCode").ToString)
                    moDB_IMP_DJCIC.AddInParameter(moDBCmd_InsertImpDJCIC, "@BranchCode", DbType.String, drMqHis.Item("BranchCode").ToString)
                    moDB_IMP_DJCIC.AddInParameter(moDBCmd_InsertImpDJCIC, "@JBranchCode", DbType.String, drMqHis.Item("JBranchCode").ToString)
                    moDB_IMP_DJCIC.AddInParameter(moDBCmd_InsertImpDJCIC, "@UserID", DbType.String, drMqHis.Item("UserID").ToString)
                    moDB_IMP_DJCIC.AddInParameter(moDBCmd_InsertImpDJCIC, "@Filler", DbType.String, drMqHis.Item("Filler").ToString)
                    moDB_IMP_DJCIC.AddInParameter(moDBCmd_InsertImpDJCIC, "@RequestData", DbType.String, strMqHis_RequestData)
                    moDB_IMP_DJCIC.AddInParameter(moDBCmd_InsertImpDJCIC, "@Memo", DbType.String, drMqHis.Item("Memo").ToString)
                    moDB_IMP_DJCIC.AddInParameter(moDBCmd_InsertImpDJCIC, "@Status", DbType.String, drMqHis.Item("Status").ToString)
                    moDB_IMP_DJCIC.AddInParameter(moDBCmd_InsertImpDJCIC, "@Pivotal", DbType.String, drMqHis.Item("Pivotal").ToString)
                    moDB_IMP_DJCIC.AddInParameter(moDBCmd_InsertImpDJCIC, "@SendDate", DbType.String, drMqHis.Item("SendDate").ToString)
                    moDB_IMP_DJCIC.AddInParameter(moDBCmd_InsertImpDJCIC, "@SendTime", DbType.String, drMqHis.Item("SendTime").ToString)
                    moDB_IMP_DJCIC.AddInParameter(moDBCmd_InsertImpDJCIC, "@ReturnDate", DbType.String, drMqHis.Item("ReturnDate").ToString)
                    moDB_IMP_DJCIC.AddInParameter(moDBCmd_InsertImpDJCIC, "@ReturnTime", DbType.String, drMqHis.Item("ReturnTime").ToString)
                    moDB_IMP_DJCIC.AddInParameter(moDBCmd_InsertImpDJCIC, "@ReSeqNo", DbType.String, drMqHis.Item("ReSeqNo").ToString)
                    moDB_IMP_DJCIC.AddInParameter(moDBCmd_InsertImpDJCIC, "@Total", DbType.String, drMqHis.Item("Total").ToString)
                    moDB_IMP_DJCIC.AddInParameter(moDBCmd_InsertImpDJCIC, "@responsedata", DbType.String, drMqHis.Item("responsedata").ToString)
                    moDB_IMP_DJCIC.AddInParameter(moDBCmd_InsertImpDJCIC, "@AgreeDate", DbType.DateTime, drMqHis.Item("AgreeDate"))
                    moDB_IMP_DJCIC.AddInParameter(moDBCmd_InsertImpDJCIC, "@RequestCode", DbType.String, Right(strMqHis_RequestID, 3))
                    moDB_IMP_DJCIC.AddInParameter(moDBCmd_InsertImpDJCIC, "@Sort", DbType.String, iSort.ToString)
                    moDB_IMP_DJCIC.ExecuteNonQuery(moDBCmd_InsertImpDJCIC)
                    ''2.�b�R��DJCIC��MQMessage_History
                    sqlCopy = " DELETE From MQMessage_History Where SeqNo =@JcicSeqNo And ResponseTime=@ResponseTime ;"
                    moDBCmd_DeleteDJCIC = moDB_DJCIC.GetSqlStringCommand(sqlCopy)
                    moDB_DJCIC.AddInParameter(moDBCmd_DeleteDJCIC, "@JcicSeqNo", DbType.String, strMqHis_SeqNo)
                    moDB_DJCIC.AddInParameter(moDBCmd_DeleteDJCIC, "@ResponseTime", DbType.DateTime, strMqHis_ResponseTime)
                    moDB_DJCIC.ExecuteNonQuery(moDBCmd_DeleteDJCIC)

                End If

                '��s�ѪR���A
                For a As Integer = 0 To g_strTables.Length - 1
                    p_strTableName = g_strTables(a)
                    For k As Integer = 0 To dataFmt.Length - 1
                        sqlUpdate &= " Update " & p_strTableName & dataFmt(k) &
                                     " set JcicParseStatus=@JcicParseStatus,LastUpdateDate=getdate() " &
                                    " WHERE JcicSeqNo=@JcicSeqNo and JcicResponseTime=@JcicResponseTime ;"
                    Next k
                Next
                If sqlUpdate.Length > 0 Then
                    moDBCmd_UpdateELOAN = moDB_ELOAN.GetSqlStringCommand(sqlUpdate)
                    moDB_ELOAN.AddInParameter(moDBCmd_UpdateELOAN, "@JcicSeqNo", DbType.String, strMqHis_SeqNo)
                    moDB_ELOAN.AddInParameter(moDBCmd_UpdateELOAN, "@JcicResponseTime", DbType.DateTime, strMqHis_ResponseTime)
                    moDB_ELOAN.AddInParameter(moDBCmd_UpdateELOAN, "@JcicParseStatus", DbType.String, parse_status)
                    moDB_ELOAN.ExecuteNonQuery(moDBCmd_UpdateELOAN)
                End If

            Next
        Catch ex As Exception
            g_writeLog.WriteErrorLog(m_ErrorLog + ";ParseJcicData :" & ex.Message.ToString)
        Finally
            g_writeLog.WriteErrorLog("Run ParseJcicData End....")
        End Try
    End Sub

    '���oIMP_JCIC���C�@��JCIC_XXX�����
    Private Function GetElementContent(ByVal moDB As Database) As DataTable

        Dim moDBCmd As DbCommand = Nothing
        Dim dt As New DataTable
        Try
            '�]���i�঳���W��O�d�r(�ҡGDESC)�A�ҥH���W�٥[�W[]
            Dim msSQL As String = "select elementNo,Length,Sort,'[' + Content + ']' Content from Parse_JcicItemElementContent "
            moDBCmd = moDB.GetSqlStringCommand(msSQL.ToString)
            Dim ds As DataSet = moDB.ExecuteDataSet(moDBCmd)
            If ds.Tables.Count > 0 Then
                dt = ds.Tables(0)
            End If
        Catch ex As Exception
            Throw ex
        Finally
            moDBCmd.Dispose()
        End Try

        Return dt
    End Function

    '���oDJCIC MQMessage_History��
    Private Function GetDJCIC_MQMessage_History_Top(ByVal moDB As Database) As DataTable

        Dim moDBCmd As DbCommand = Nothing
        Dim dt As New DataTable
        Try
            Dim msSQL As String = "
                          SELECT TOP 30 SeqNo
                              ,ResponseTime=convert(varchar(50),ResponseTime,21)
                              ,BankCode,LineCode,SysDate,SysTime,RequestID
                              ,ResponseID,ErrCode,BranchCode,JBranchCode
                              ,UserID,Filler,RequestData,Memo,Status
                              ,Pivotal,SendDate,SendTime,ReturnDate
                              ,ReturnTime,ReSeqNo,Total,responsedata
                              ,AgreeDate
                          From MQMessage_History
                          Order By responseTime desc
                      "

            moDBCmd = moDB.GetSqlStringCommand(msSQL.ToString)
            Dim ds As DataSet = moDB.ExecuteDataSet(moDBCmd)
            If ds.Tables.Count > 0 Then
                dt = ds.Tables(0)
            End If
        Catch ex As Exception
            Throw ex
        Finally
            moDBCmd.Dispose()
        End Try

        Return dt
    End Function

    Function processToken(ByRef content1, ByVal length1)

        Dim bytes, z, content1_length As Integer
        Dim data_str As New System.Text.StringBuilder, temp_char As String
        bytes = 0
        z = 0
        'data_str = ""
        temp_char = ""
        content1_length = Len(content1)
        '���줸�դp��ǤJ�����סA�H�Υ��B�z��̫�@�r�ɤ~�i��B�z
        Do While (bytes < length1 And z < content1_length)
            z = z + 1
            temp_char = Mid(content1, z, 1)
            If Len(Hex(Asc(temp_char))) > 2 Then '����r�줸�ժ��ץ[2
                bytes = bytes + 2
            Else
                bytes = bytes + 1
            End If
            data_str.Append(temp_char)
        Loop
        content1 = Mid(content1, z + 1) '�N�r��h���e����X��data_str�A�s�Jprocessing_content��
        processToken = data_str.ToString    '�^�Ǻ�X��data_str
    End Function

    '�ˬd�p�x�t�θ�Ʈw,�P�BELOAN�ӽеo�d��檬�p
    Private Sub UpdateApplyStatus()
        Dim m_ErrorLog As String = ""
        '�s�u��Ʈw
        Dim moDB_eloan As Database = DBUtil.GetDB(g_strConnString_eloan)
        Dim moDB_DJCIC As Database = DBUtil.GetDB(g_strConnString_DJCIC)

        Dim sqlSelect As String = ""
        Dim sqlUpdate As String = ""

        Dim dataFmt() As String = {"R", "H"}
        Dim p_strTableName As String = Nothing
        Dim m_dsEloanApplyResult As DataSet = Nothing
        Dim m_dsDjcicApplyResult As DataSet = Nothing

        Try
            For a As Integer = 0 To g_strTables.Length - 1
                p_strTableName = g_strTables(a)

                sqlSelect = " With T as ("

                For k As Integer = 0 To dataFmt.Length - 1
                    sqlSelect &= " SELECT LoanKey ,UKey ,JcicApplySeqNo ,JcicApplyStatus " &
                            " FROM " & p_strTableName & dataFmt(k) & " (NOLOCK) " &
                            " WHERE JcicApplyStatus in ('0','1') union"
                    ''JcicApplyStatus 0:�w�ӽЫݵo�d  1:�w�P�N�o�d�ݩ�� 2:�w�P�N��� 3:�ڵ��o�d 4:�ڵ����
                Next k

                '�N�̫᪺ union����
                sqlSelect = sqlSelect.Substring(0, sqlSelect.Length - 6) & " ) SELECT DISTINCT LoanKey ,UKey ,JcicApplySeqNo ,JcicApplyStatus FROM T "


                '��XELOAN_JcicData�٦b�d�ߤ������
                Dim m_comd_eloan As SqlCommand = moDB_eloan.GetSqlStringCommand(sqlSelect)
                m_dsEloanApplyResult = moDB_eloan.ExecuteDataSet(m_comd_eloan)
                Dim m_ApplySeqnoList As String = ""
                If m_dsEloanApplyResult.Tables(0).Rows.Count > 0 Then
                    For i As Integer = 0 To m_dsEloanApplyResult.Tables(0).Rows.Count - 1
                        '�@���N�Ҧ����p�x�ӽнs���զX���r��
                        m_ApplySeqnoList = m_ApplySeqnoList + "'" + m_dsEloanApplyResult.Tables(0).Rows(i)("JcicApplySeqNo").ToString + "',"
                    Next
                    m_ApplySeqnoList = m_ApplySeqnoList.TrimEnd(",")
                End If

                If m_ApplySeqnoList.Length = 0 Then
                    Exit Sub
                End If

                sqlSelect = "   SELECT A.ApplySeqNo ,A.ApplyStatus,A.SeqNo" &
                                "   FROM MQMessage_Apply A (NOLOCK)" &
                                "   WHERE  ApplySeqNo in (" & m_ApplySeqnoList & ") AND ApplyStatus<>'0' "
                Dim m_comd_Djcic As SqlCommand = moDB_DJCIC.GetSqlStringCommand(sqlSelect)
                m_dsDjcicApplyResult = moDB_DJCIC.ExecuteDataSet(m_comd_Djcic)
                If m_dsDjcicApplyResult.Tables(0).Rows.Count = 0 Then
                    Exit Sub
                End If

                '�}�l��sELOAN���p�x�ӽЪ��A
                Dim dvDjcicApplyResult As DataView = New DataView(m_dsDjcicApplyResult.Tables(0))
                Dim m_LoanKey, m_UKey, m_JcicApplySeqNo, m_JcicApplyStatus, m_DJcicApplySeqNo, m_DJcicApplyStatus, m_DJcicSeqNo As String

                For i As Integer = 0 To m_dsEloanApplyResult.Tables(0).Rows.Count - 1
                    m_LoanKey = m_dsEloanApplyResult.Tables(0).Rows(i)("LoanKey").ToString
                    m_UKey = m_dsEloanApplyResult.Tables(0).Rows(i)("UKey").ToString
                    m_JcicApplySeqNo = m_dsEloanApplyResult.Tables(0).Rows(i)("JcicApplySeqNo").ToString
                    m_JcicApplyStatus = m_dsEloanApplyResult.Tables(0).Rows(i)("JcicApplyStatus").ToString

                    m_ErrorLog = "****[LoanKey]=" & m_LoanKey & ",[UKey]=" & m_UKey & ",[JcicApplySeqNo]=" & m_JcicApplySeqNo & "***"
                    dvDjcicApplyResult.RowFilter = "ApplySeqNo='" & m_JcicApplySeqNo & "'"
                    If dvDjcicApplyResult.Count = 0 Then
                        Continue For
                    End If
                    m_DJcicApplySeqNo = dvDjcicApplyResult.Item(0).Item("ApplySeqNo").ToString
                    m_DJcicApplyStatus = dvDjcicApplyResult.Item(0).Item("ApplyStatus").ToString
                    m_DJcicSeqNo = dvDjcicApplyResult.Item(0).Item("SeqNo").ToString
                    For k As Integer = 0 To dataFmt.Length - 1
                        sqlUpdate = sqlUpdate + " UPDATE " & p_strTableName & dataFmt(k) & " WITH (ROWLOCK) SET " &
                                    " JcicApplyStatus =@JcicApplyStatus," &
                                    " JcicSeqNo=@JcicSeqNo+" & IIf(dataFmt(k) = "H", "0", "1") & "," &
                                    " JcicStatus=case @JcicApplyStatus when '2' then '0' end," &
                                    " LastUpdateDate=getdate() " &
                                    " WHERE LoanKey = @LoanKey AND UKey = @UKey "
                    Next

                    m_comd_eloan = moDB_eloan.GetSqlStringCommand(sqlUpdate)
                    moDB_eloan.AddInParameter(m_comd_eloan, "@JcicApplyStatus", DbType.String, m_DJcicApplyStatus)
                    moDB_eloan.AddInParameter(m_comd_eloan, "@JcicSeqNo", DbType.String, m_DJcicSeqNo)
                    moDB_eloan.AddInParameter(m_comd_eloan, "@LoanKey", DbType.String, m_LoanKey)
                    moDB_eloan.AddInParameter(m_comd_eloan, "@UKey", DbType.String, m_UKey)
                    moDB_eloan.ExecuteNonQuery(m_comd_eloan)

                Next
            Next
        Catch ex As Exception
            g_writeLog.WriteErrorLog(m_ErrorLog + "****UpdateApplyStatus error =" & ex.ToString() & "***")
        Finally
            g_writeLog.WriteErrorLog("Run UpdateApplyStatus End....")
        End Try
    End Sub


    '�ˬd�p�x�t�θ�Ʈw,�P�BELOAN�p�x���p
    Private Sub UpdateJcicStatus()
        Dim m_ErrorLog As String = ""
        '�s�u��Ʈw
        Dim moDB_eloan As Database = DBUtil.GetDB(g_strConnString_eloan)
        Dim moDB_DJCIC As Database = DBUtil.GetDB(g_strConnString_DJCIC)

        Dim sqlSelect As String = ""
        Dim sqlUpdate As String = ""

        Dim dataFmt() As String = {"R", "H"}
        Dim p_strTableName As String = Nothing
        Dim m_dsEloanResult As DataSet = Nothing
        Dim m_dsDjcicResult As DataSet = Nothing

        Try
            For a As Integer = 0 To g_strTables.Length - 1
                p_strTableName = g_strTables(a)

                sqlSelect = " With T as ("

                For k As Integer = 0 To dataFmt.Length - 1
                    sqlSelect &= " SELECT LoanKey ,UKey ,JcicSeqNo " &
                                " FROM " & p_strTableName & dataFmt(k) & " (NOLOCK) " &
                                " WHERE JcicStatus in ('0','1') union"
                    ''0�ݶǰe  1�ݦ^��  2�w����  3�B�z����  4���n�J
                Next k

                '�N�̫᪺ union����
                sqlSelect = sqlSelect.Substring(0, sqlSelect.Length - 6) & " ) SELECT DISTINCT LoanKey ,UKey ,JcicSeqNo FROM T "

                '��XELOAN_JcicData�٦b�ݶǰe�������
                Dim m_comd_eloan As SqlCommand = moDB_eloan.GetSqlStringCommand(sqlSelect)
                m_dsEloanResult = moDB_eloan.ExecuteDataSet(m_comd_eloan)
                Dim m_SeqnoList As String = ""
                If m_dsEloanResult.Tables(0).Rows.Count > 0 Then
                    For i As Integer = 0 To m_dsEloanResult.Tables(0).Rows.Count - 1
                        '�@���N�Ҧ����p�x�s���զX���r��
                        m_SeqnoList = m_SeqnoList + "'" + m_dsEloanResult.Tables(0).Rows(i)("JcicSeqNo").ToString + "',"
                    Next
                    m_SeqnoList = m_SeqnoList.TrimEnd(",")
                End If

                If m_SeqnoList.Length = 0 Then
                    Exit Sub
                End If

                sqlSelect = "   SELECT RequestData,SeqNo,Status,SendDate,ErrCode," &
                            "   ReturnDate=case when ReturnDate<>'' and ReturnTime<>'' then
                            convert(varchar, convert(datetime, ReturnDate), 111)+ ' ' + substring(ReturnTime, 1, 2)+ ':' + substring(ReturnTime, 3, 2)+ ':' + substring(ReturnTime, 5, 2) end,
                            responsedata,RequestID" &
                                "   FROM MQMessage A (NOLOCK)" &
                                "   WHERE  SeqNo in (" & m_SeqnoList & ")"
                Dim m_comd_Djcic As SqlCommand = moDB_DJCIC.GetSqlStringCommand(sqlSelect)
                m_dsDjcicResult = moDB_DJCIC.ExecuteDataSet(m_comd_Djcic)
                If m_dsDjcicResult.Tables(0).Rows.Count = 0 Then
                    Exit Sub
                End If
                sqlSelect = "" 'test
                '�}�l��sELOAN���p�x�d�ߪ��A
                Dim dvDjcicResult As DataView = New DataView(m_dsDjcicResult.Tables(0))
                Dim m_LoanKey, m_UKey, m_SeqNo,
                    m_MQRequestData, m_MQStatus, m_MQSendDate, m_MQReturnDate, m_MQresponsedata, m_MQRequestID, m_MQErrCode As String
                For i As Integer = 0 To m_dsEloanResult.Tables(0).Rows.Count - 1
                    m_LoanKey = m_dsEloanResult.Tables(0).Rows(i)("LoanKey").ToString
                    m_UKey = m_dsEloanResult.Tables(0).Rows(i)("UKey").ToString
                    m_SeqNo = m_dsEloanResult.Tables(0).Rows(i)("JcicSeqNo").ToString

                    m_ErrorLog = "****[LoanKey]=" & m_LoanKey & ",[UKey]=" & m_UKey & ",[JcicSeqNo]=" & m_SeqNo & "***"
                    dvDjcicResult.RowFilter = "SeqNo = '" & m_SeqNo & "'"
                    If dvDjcicResult.Count = 0 Then
                        Continue For
                    End If
                    m_MQRequestData = dvDjcicResult.Item(0).Item("RequestData").ToString.TrimEnd(" ")
                    m_MQStatus = dvDjcicResult.Item(0).Item("Status").ToString
                    m_MQSendDate = dvDjcicResult.Item(0).Item("SendDate").ToString.TrimEnd(" ")
                    m_MQErrCode = dvDjcicResult.Item(0).Item("ErrCode").ToString.TrimEnd(" ")
                    m_MQReturnDate = dvDjcicResult.Item(0).Item("ReturnDate").ToString.TrimEnd(" ")
                    m_MQresponsedata = dvDjcicResult.Item(0).Item("responsedata").ToString.Replace(Chr(23), "")
                    m_MQRequestID = dvDjcicResult.Item(0).Item("RequestID").ToString

                    sqlUpdate = " UPDATE " & p_strTableName & IIf(m_MQRequestID.StartsWith("H"), dataFmt(1), dataFmt(0)) & " WITH (ROWLOCK) SET " &
                                    " JcicStatus =@JcicStatus,JcicRealQueryDate=@JcicRealQueryDate,JcicErrCode=@JcicErrCode," &
                                    " JcicResponseTime=@JcicResponseTime,JcicResponseData=@JcicResponseData,LastUpdateDate=getdate() " &
                                    " WHERE LoanKey = @LoanKey AND UKey = @UKey and JcicSeqNo=@JcicSeqNo "


                    m_comd_eloan = moDB_eloan.GetSqlStringCommand(sqlUpdate)
                    moDB_eloan.AddInParameter(m_comd_eloan, "@JcicStatus", DbType.String, m_MQStatus)
                    moDB_eloan.AddInParameter(m_comd_eloan, "@JcicErrCode", DbType.String, m_MQErrCode)
                    moDB_eloan.AddInParameter(m_comd_eloan, "@JcicRealQueryDate", DbType.String, IIf(m_MQSendDate.Length = 0, Nothing, m_MQSendDate))
                    moDB_eloan.AddInParameter(m_comd_eloan, "@JcicResponseTime", DbType.String, IIf(m_MQReturnDate.Length = 0, Nothing, m_MQReturnDate))
                    moDB_eloan.AddInParameter(m_comd_eloan, "@JcicResponseData", DbType.String, m_MQresponsedata)
                    moDB_eloan.AddInParameter(m_comd_eloan, "@LoanKey", DbType.String, m_LoanKey)
                    moDB_eloan.AddInParameter(m_comd_eloan, "@UKey", DbType.String, m_UKey)
                    moDB_eloan.AddInParameter(m_comd_eloan, "@JcicSeqNo", DbType.String, m_SeqNo)
                    moDB_eloan.ExecuteNonQuery(m_comd_eloan)

                    ''only for TEST
                    'If "F103453214;A222498392;F126093645;H122979324;A201658254;A220447860;G220197290;".Contains(m_MQRequestData) And m_MQStatus = "2" Then
                    '    sqlSelect = " if (select count(1) from MQMessage_History where charindex(Rtrim(RequestData),@RequestData)>0)=0 " +
                    '                        " Begin " +
                    '                        " insert into MQMessage_History" +
                    '                        " Select [SeqNo] " +
                    '                        " 	,[ResponseTime]=convert(varchar, convert(datetime, ReturnDate), 111)+ ' ' + substring(ReturnTime, 1, 2)+ ':' + substring(ReturnTime, 3, 2)+ ':' + substring(ReturnTime, 5, 2)" +
                    '                        "   ,[BankCode],[LineCode],[SysDate],[SysTime],[RequestID],[ResponseID],[ErrCode]" +
                    '                        "   ,[BranchCode],[JBranchCode],[UserID],[Filler],[RequestData],[Memo],[Status],[Pivotal],[SendDate],[SendTime],[ReturnDate]" +
                    '                        "   ,[ReturnTime],[ReSeqNo],[Total],[responsedata],[AgreeDate] " +
                    '                        " From [dbo].[MQMessage]" +
                    '                        " Where charindex(RTrim(RequestData),@RequestData) > 0 and [Status]=2 and Reseqno is not null " +
                    '                        " end "
                    '    Dim m_comd2_Djcic As SqlCommand = moDB_DJCIC.GetSqlStringCommand(sqlSelect)
                    '    moDB_DJCIC.AddInParameter(m_comd2_Djcic, "@RequestData", DbType.String, m_MQRequestData)
                    '    moDB_DJCIC.ExecuteNonQuery(m_comd2_Djcic)
                    'End If
                    ''only for TEST
                Next
            Next
        Catch ex As Exception
            g_writeLog.WriteErrorLog(m_ErrorLog + "****UpdateJcicStatus error =" & ex.ToString() & "***")
        Finally
            g_writeLog.WriteErrorLog("Run UpdateJcicStatus End....")
        End Try
    End Sub
End Class
