﻿Imports System.Windows.Forms
Imports System.IO


Public Structure Schedule

    Public ScheduleEnable As Boolean

    Public Caption As String
    Public ProgramPath As String
    Public StartTime As String 'HHmmss
    'Public EndTime As String 'HHmmss
    Public Duration As String
    Public DurationUnit As String

    Public Sunday As Boolean
    Public Monday As Boolean
    Public Tuesday As Boolean
    Public Wednesday As Boolean
    Public Thusday As Boolean
    Public Friday As Boolean
    Public Saturday As Boolean

    Public Function ToStringArray() As String()
        Dim strArray(12) As String
        strArray(0) = ScheduleEnable.ToString
        strArray(1) = Caption
        strArray(2) = ProgramPath
        strArray(3) = StartTime
        strArray(4) = Duration
        strArray(5) = DurationUnit
        strArray(6) = Sunday.ToString
        strArray(7) = Monday.ToString
        strArray(8) = Tuesday.ToString
        strArray(9) = Wednesday.ToString
        strArray(10) = Thusday.ToString
        strArray(11) = Friday.ToString
        strArray(12) = Saturday.ToString
        Return strArray
    End Function


End Structure

Public Class dlgSchedule
    Public ScheduleData As New Schedule


    Public Sub New()

        ' 此為 Windows Form 設計工具所需的呼叫。
        InitializeComponent()

        ' 在 InitializeComponent() 呼叫之後加入任何初始設定。


    End Sub

    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
        '輸入檢查
        If Me.txtProgramPath.Text.Trim.Length = 0 Or File.Exists(Me.txtProgramPath.Text.Trim) = False Then
            Me.txtProgramPath.Focus()
            Exit Sub
        End If
        If Me.txtDuration.Text.Trim.Length = 0 Or Me.txtDuration.Text.Trim = "0" Then
            Me.txtDuration.Focus()
            Exit Sub
        End If


        'temp data
        With ScheduleData
            .ScheduleEnable = Me.chkScheduleEnable.Checked

            .Caption = Me.txtCaption.Text.Trim
            .ProgramPath = Me.txtProgramPath.Text.Trim
            .StartTime = Me.dtpStartTime.Value.ToString("HH:mm:ss")
            
            'Dim strEndTime As String = .StartTime
            'Select Case Me.cboDurationUnit.SelectedValue
            '    Case "s"
            '        strEndTime = Me.dtpStartTime.Value.AddSeconds(Me.txtDuration.Text.Trim).ToString("HH:mm:ss")
            '    Case "m"
            '        strEndTime = Me.dtpStartTime.Value.AddMinutes(Me.txtDuration.Text.Trim).ToString("HH:mm:ss")
            '    Case "h"
            '        strEndTime = Me.dtpStartTime.Value.AddHours(Me.txtDuration.Text.Trim).ToString("HH:mm:ss")
            '    Case Else
            '        strEndTime = Me.dtpStartTime.Value.AddMinutes(1).ToString("HH:mm:ss")
            'End Select
            '.EndTime = strEndTime
            .Duration = Me.txtDuration.Text.Trim
            .DurationUnit = Me.cboDurationUnit.SelectedValue

            .Sunday = Me.chkSunday.Checked
            .Monday = Me.chkMonday.Checked
            .Tuesday = Me.chkTuesday.Checked
            .Wednesday = Me.chkWednesday.Checked
            .Thusday = Me.chkThusday.Checked
            .Friday = Me.chkFriday.Checked
            .Saturday = Me.chkSaturday.Checked
        End With

        Me.DialogResult = System.Windows.Forms.DialogResult.OK

        Me.Close()

    End Sub

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel

        Me.Close()
    End Sub

    Private Sub dlgSchedule_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        '初始化
        Dim dtDurationUnit As New DataTable
        With dtDurationUnit
            .Columns.Add("Value")
            .Columns.Add("Text")
            .Rows.Add(.NewRow)
            .Rows(.Rows.Count - 1).Item("Value") = "s"
            .Rows(.Rows.Count - 1).Item("Text") = "秒"
            .Rows.Add(.NewRow)
            .Rows(.Rows.Count - 1).Item("Value") = "m"
            .Rows(.Rows.Count - 1).Item("Text") = "分"
            .Rows.Add(.NewRow)
            .Rows(.Rows.Count - 1).Item("Value") = "h"
            .Rows(.Rows.Count - 1).Item("Text") = "時"
        End With
        Me.cboDurationUnit.DataSource = dtDurationUnit
        Me.cboDurationUnit.ValueMember = "Value"
        Me.cboDurationUnit.DisplayMember = "Text"


        '載入值
        With Me.ScheduleData
            Me.chkScheduleEnable.Checked = .ScheduleEnable
            If .Caption IsNot Nothing Then Me.txtCaption.Text = .Caption
            If .ProgramPath IsNot Nothing Then Me.txtProgramPath.Text = .ProgramPath
            If .StartTime IsNot Nothing Then Me.dtpStartTime.Value = Now.ToString("yyyy/MM/dd") & " " & .StartTime
            If .Duration IsNot Nothing Then Me.txtDuration.Text = .Duration
            If .DurationUnit IsNot Nothing Then Me.cboDurationUnit.SelectedValue = .DurationUnit
            Me.chkSunday.Checked = .Sunday
            Me.chkMonday.Checked = .Monday
            Me.chkTuesday.Checked = .Tuesday
            Me.chkWednesday.Checked = .Wednesday
            Me.chkThusday.Checked = .Thusday
            Me.chkFriday.Checked = .Friday
            Me.chkSaturday.Checked = .Saturday
        End With

    End Sub

    Private Sub btnProgramPath_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnProgramPath.Click
        Dim ofdProgramPath As New OpenFileDialog
        With ofdProgramPath
            .CheckFileExists = True
            .CheckPathExists = True
            .Filter = "Executable Files (*.exe;*.com;*.bat)|*.exe;*.com;*.bat|All Files (*.*)|*.*"
            .InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles)
            .Multiselect = False
            .RestoreDirectory = True
        End With
        If ofdProgramPath.ShowDialog = System.Windows.Forms.DialogResult.OK Then
            Me.txtProgramPath.Text = ofdProgramPath.FileName
        End If
    End Sub

    Private Sub txtDuration_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtDuration.Leave
        Try
            Me.txtDuration.Text = CInt(Val(Me.txtDuration.Text.Trim)).ToString
        Catch ex0 As OverflowException
            Me.txtDuration.Text = System.Int32.MaxValue.ToString
        Catch ex As Exception
            Me.txtDuration.Text = "1"
        Finally
            If Me.txtDuration.Text.Trim = "0" Then Me.txtDuration.Text = "1"
        End Try
    End Sub



End Class
