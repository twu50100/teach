Imports System.Net
Imports Microsoft.Win32
Imports System.Text
Imports System.IO
Imports eLoan_Gateway.ClassLib
Imports System.Runtime.InteropServices

''' <summary>
''' Windows Form�]�w�����A�]�w�ɥ[�K���m��Reg
''' </summary>
''' <remarks>
''' ���]�w���ءG
''' 1. SQL connString-textbox
''' 2. Local Server IP-combobox
''' 3. Remote Server List(IP, Port)�BI/O Type�BI/O����
''' 4. ���s�X����
''' 5. I/O�Ȧs�ؿ�(�ؿ��U�P��s�X���@�ɮ�)
''' 
''' </remarks>

Public Class frmConfig

    Private dtConnType As DataTable '�s�u�覡
    Private dtDocEncoding As DataTable '���s�X
    Private dtDatabase As DataTable '�s����Ʈw
    Private dtSchedule As DataTable '�Ƶ{�M��
    Private dtLogFlag As DataTable '�O�_�O��Log
    Private Crypt As New ClassLib.Cryptography '�[�ѱK
    Private objSettings As ClassLib.Settings

    '�غc�l
    Public Sub New()

        ' ���� Windows Form �]�p�u��һݪ��I�s�C
        InitializeComponent()

        ' �b InitializeComponent() �I�s����[�J�����l�]�w�C
        Call InitDataGrid()
        Call InitAPServerDataGrid()

        objSettings = New ClassLib.Settings(Application.StartupPath)

        dtSchedule = New DataTable("ScheduleList")
        With dtSchedule
            .Columns.Add("ID", GetType(System.Int32)).AllowDBNull = False
            .Columns("ID").AutoIncrement = True
            .Columns("ID").AutoIncrementSeed = 1
            .Columns("ID").AutoIncrementStep = 1
            .Columns.Add("CAPTION")
            .Columns.Add("STARTTIME")
            .Columns.Add("ENDTIME")
            .Columns.Add("DURATION", GetType(System.Int32))
            .Columns.Add("DURATIONUNIT", GetType(System.Char))
            .Columns.Add("STATUS")
            .Columns.Add("DATA", GetType(Schedule))
        End With



    End Sub
    '��l��
    Private Sub frmConfig_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Try

            Dim strDBConnString As String = CType(objSettings.ReadSetting("DBConnString_LOAN"), String)
            Me.txtDBConnString.Text = strDBConnString
            Dim strLocalServerIP As String = CType(objSettings.ReadSetting("LocalServerIP"), String)
            Me.txtLocalServerIP.Text = strLocalServerIP
            Dim strTmpOutputPath As String = CType(objSettings.ReadSetting("TmpOutputPath"), String)
            Me.txtTmpOutputPath.Text = strTmpOutputPath
            Dim strTmpInputPath As String = CType(objSettings.ReadSetting("TmpInputPath"), String)
            Me.txtTmpInputPath.Text = strTmpInputPath
            Dim strLogPath As String = CType(objSettings.ReadSetting("LogPath"), String)
            Me.txtLogPath.Text = strLogPath

            '2009.04.28 Add by Kevin ------------------------------------------
            Dim intLogFileSize As Integer = CType(objSettings.ReadSetting("LogFileSize"), Integer)
            Me.nudLogFileSize.Value = intLogFileSize
            Dim intLogFileBackupCount As Integer = CType(objSettings.ReadSetting("LogFileBackupCount"), Integer)
            Me.nudLogFileBackupCount.Value = intLogFileBackupCount
            '------------------------------------------------------------------
            'Dim blnMailEnable As Boolean = CType(objSettings.ReadSetting("MailEnable"), Boolean)
            'Me.chkMailEnable.Checked = blnMailEnable
            'Dim strMailQuantity As String = CType(objSettings.ReadSetting("MailQuantity"), String)
            'Me.txtMailQuantity.Text = strMailQuantity
            'Dim strMailTo As String = CType(objSettings.ReadSetting("MailTo"), String)
            'Me.txtMailTo.Text = strMailTo
            'Dim strMailCC As String = CType(objSettings.ReadSetting("MailCC"), String)
            'Me.txtMailCC.Text = strMailCC
            'Dim strMailSMTP As String = CType(objSettings.ReadSetting("MailSMTP"), String)
            'Me.txtMailSMTP.Text = strMailSMTP
            'Dim blnMailSMTPVerify As Boolean = CType(objSettings.ReadSetting("MailSMTPVerify"), Boolean)
            'Me.chkMailSMTPVerify.Checked = blnMailSMTPVerify
            'Dim strMailSMTPUid As String = CType(objSettings.ReadSetting("MailSMTPUid"), String)
            'Me.txtMailSMTPUid.Text = strMailSMTPUid
            'Dim strMailSMTPPwd As String = CType(objSettings.ReadSetting("MailSMTPPwd"), String)
            'Me.txtMailSMTPPwd.Text = Crypt.Dec(strMailSMTPPwd)

            Dim strConnStr_Loan As String = CType(objSettings.ReadSetting("DBConnString_LOAN"), String)
            Me.txtConnStr_Loan.Text = strConnStr_Loan

            Me.nudAttach_Interval.Value = CInt(objSettings.ReadSetting("Attach_Interval"))
            Me.txtAttachFilePath.Text = CStr(objSettings.ReadSetting("AttachFilePath"))

            '2011.12.13 Add by Kevin ------------------------------------------[START]
            'Dim dtAttachFileMode As New DataTable
            'With dtAttachFileMode
            '    .Columns.Add("Value")
            '    .Columns.Add("Text")
            '    .Rows.Add(.NewRow)
            '    .Rows(.Rows.Count - 1).Item("Value") = "LOCAL"
            '    .Rows(.Rows.Count - 1).Item("Text") = "�����Ϻ�"
            '    .Rows.Add(.NewRow)
            '    .Rows(.Rows.Count - 1).Item("Value") = "FTP"
            '    .Rows(.Rows.Count - 1).Item("Text") = "FTP"
            'End With
            'Me.cmbAttachFileMode.DataSource = dtAttachFileMode
            'Me.cmbAttachFileMode.ValueMember = "Value"
            'Me.cmbAttachFileMode.DisplayMember = "Text"

            'Dim strAttachFileMode As String = CType(objSettings.ReadSetting("AttachFileMode"), String)
            'Me.cmbAttachFileMode.SelectedValue = strAttachFileMode
            '2011.12.13 Add by Kevin ------------------------------------------[END]

            'Dim strUpLoadFilePath As String = CType(objSettings.ReadSetting("UpLoadFilePath"), String)
            'Me.txtUpLoadFilePath.Text = strUpLoadFilePath
            'Dim strAdm_UpLoadFilePath As String = CType(objSettings.ReadSetting("Adm_UpLoadFilePath"), String)
            'Me.txtAdm_UpLoadFilePath.Text = strAdm_UpLoadFilePath
            'Dim strUpLoadUser As String = CType(objSettings.ReadSetting("UpLoadUser"), String)
            'Me.txtUpLoadUser.Text = strUpLoadUser
            'Dim strUpLoadPassword As String = CType(objSettings.ReadSetting("UpLoadPassword"), String)
            'Me.txtUpLoadPassword.Text = Crypt.Dec(strUpLoadPassword)

            'Me.txtAPI_JcicTch.Text = CStr(objSettings.ReadSetting("API_JcicTch"))

            Dim strConnStr_JcicTch As String = CType(objSettings.ReadSetting("ConnStr_JcicTch"), String)
            Me.txtConnStr_JcicTch.Text = strConnStr_JcicTch

            Me.chkJcicEnable.Checked = CBool(objSettings.ReadSetting("JcicEnable"))
            Me.txtJcicTables.Text = CStr(objSettings.ReadSetting("JcicTables"))
            Me.nudJcicInterval.Value = CInt(objSettings.ReadSetting("JcicInterval"))

            Me.chkTchEnable.Checked = CBool(objSettings.ReadSetting("TchEnable"))
            Me.txtTchTables.Text = CStr(objSettings.ReadSetting("TchTables"))
            Me.nudTchInterval.Value = CInt(objSettings.ReadSetting("TchInterval"))

            Me.txtAPI_EDOCService.Text = CStr(objSettings.ReadSetting("API_EDOCService"))

            Me.chkAdmEnable.Checked = CBool(objSettings.ReadSetting("AdmEnable"))
            Me.txtAdmTables.Text = CStr(objSettings.ReadSetting("AdmTables"))
            Me.nudAdmInterval.Value = CInt(objSettings.ReadSetting("AdmInterval"))

            Me.chkOutSourceLog.Checked = CBool(objSettings.ReadSetting("OutSourceLog"))

            Me.txtAPI_ScoringService.Text = CStr(objSettings.ReadSetting("API_ScoringService"))

            '2013.04.25 Add by Kevin ------------------------------------------
            Me.txtRestartServicesName.Text = CStr(objSettings.ReadSetting("RestartServicesName"))
            Me.chkRestartOnTheHour.Checked = CBool(objSettings.ReadSetting("RestartOnTheHour"))
            Me.txtRestartTime.Text = CStr(objSettings.ReadSetting("RestartTime"))



            'Dim m_dtRemoteServerList As DataTable = objSettings.ReadList("RemoteServerList")

            'Dim strDBConnString As String = reg.GetValue("DBConnString")
            'Me.txtDBConnString.Text = strDBConnString
            'Dim strLocalServerIP As String = reg.GetValue("LocalServerIP")
            'Me.txtLocalServerIP.Text = strLocalServerIP
            'Dim strTmpOutputPath As String = reg.GetValue("TmpOutputPath")
            'Me.txtTmpOutputPath.Text = strTmpOutputPath
            'Dim strTmpInputPath As String = reg.GetValue("TmpInputPath")
            'Me.txtTmpInputPath.Text = strTmpInputPath
            'Dim strLogPath As String = reg.GetValue("LogPath")
            'Me.txtLogPath.Text = strLogPath
            'Dim blnMailEnable As Boolean = reg.GetValue("MailEnable").ToString.ToLower = "true"
            'Me.chkMailEnable.Checked = blnMailEnable
            'Dim strMailQuantity As String = reg.GetValue("MailQuantity")
            'Me.txtMailQuantity.Text = strMailQuantity
            'Dim strMailTo As String = reg.GetValue("MailTo")
            'Me.txtMailTo.Text = strMailTo
            'Dim strMailCC As String = reg.GetValue("MailCC")
            'Me.txtMailCC.Text = strMailCC
            'Dim strMailSMTP As String = reg.GetValue("MailSMTP")
            'Me.txtMailSMTP.Text = strMailSMTP
            'Dim blnMailSMTPVerify As Boolean = reg.GetValue("MailSMTPVerify").ToString.ToLower = "true"
            'Me.chkMailSMTPVerify.Checked = blnMailSMTPVerify
            'Dim strMailSMTPUid As String = reg.GetValue("MailSMTPUid")
            'Me.txtMailSMTPUid.Text = strMailSMTPUid
            'Dim strMailSMTPPwd As String = reg.GetValue("MailSMTPPwd")
            'Me.txtMailSMTPPwd.Text = Crypt.Dec(strMailSMTPPwd)

            'Dim schedule_reg As RegistryKey = reg
            '���ݦ��A���M��
            'Dim m_dtRemoteServerList As DataTable = objSettings.ReadList("RemoteServerList")
            'Me.dgvRemoteServerList.DataSource = m_dtRemoteServerList

            'Dim m_dtAPServerList As DataTable = objSettings.ReadList("APServerList")
            'Me.dgvAPServerList.DataSource = m_dtAPServerList

            'If m_dtRemoteServerList IsNot Nothing Then
            '    For i As Integer = 0 To m_dtRemoteServerList.Rows.Count - 1
            '        Me.dgvRemoteServerList.Rows.Add(m_dtRemoteServerList.Rows(i).ItemArray)
            '    Next
            'End If

            'reg = reg.OpenSubKey("RemoteServerList")
            'Dim strList As String() = reg.GetValueNames
            'For Each str As String In strList
            '    Dim strRow As String() = reg.GetValue(str)
            '    Me.dgvRemoteServerList.Rows.Add(strRow)
            'Next

            'reg.Close()
            '�Ƶ{

            Dim m_dtTempScheduleList As DataTable = objSettings.ReadList("ScheduleList")
            If m_dtTempScheduleList IsNot Nothing Then
                For i As Integer = 0 To m_dtTempScheduleList.Rows.Count - 1
                    Dim strRow As DataRow = m_dtTempScheduleList.Rows(i)
                    If strRow.ItemArray.Length <> 13 Then Throw New Exception("��Ƥ��šI")

                    Dim oScheduleData As New Schedule()
                    With oScheduleData
                        If m_dtTempScheduleList.Columns.Contains("ScheduleEnable") Then
                            .ScheduleEnable = strRow("ScheduleEnable").ToString.ToLower = "true"
                        Else
                            .ScheduleEnable = False
                        End If
                        If m_dtTempScheduleList.Columns.Contains("Caption") Then
                            .Caption = strRow("Caption").ToString
                        Else
                            .Caption = ""
                        End If
                        If m_dtTempScheduleList.Columns.Contains("ProgramPath") Then
                            .ProgramPath = strRow("ProgramPath").ToString
                        Else
                            .ProgramPath = ""
                        End If
                        If m_dtTempScheduleList.Columns.Contains("StartTime") Then
                            .StartTime = strRow("StartTime").ToString
                        Else
                            .StartTime = "00:00:00"
                        End If
                        If m_dtTempScheduleList.Columns.Contains("Duration") Then
                            .Duration = strRow("Duration").ToString
                        Else
                            .Duration = "5"
                        End If
                        If m_dtTempScheduleList.Columns.Contains("DurationUnit") Then
                            .DurationUnit = strRow("DurationUnit").ToString
                        Else
                            .DurationUnit = "m"
                        End If
                        If m_dtTempScheduleList.Columns.Contains("Sunday") Then
                            .Sunday = strRow("Sunday").ToString.ToLower = "true"
                        Else
                            .Sunday = False
                        End If
                        If m_dtTempScheduleList.Columns.Contains("Monday") Then
                            .Monday = strRow("Monday").ToString.ToLower = "true"
                        Else
                            .Monday = False
                        End If
                        If m_dtTempScheduleList.Columns.Contains("Tuesday") Then
                            .Tuesday = strRow("Tuesday").ToString.ToLower = "true"
                        Else
                            .Tuesday = False
                        End If
                        If m_dtTempScheduleList.Columns.Contains("Wednesday") Then
                            .Wednesday = strRow("Wednesday").ToString.ToLower = "true"
                        Else
                            .Wednesday = False
                        End If
                        If m_dtTempScheduleList.Columns.Contains("Thusday") Then
                            .Thusday = strRow("Thusday").ToString.ToLower = "true"
                        Else
                            .Thusday = False
                        End If
                        If m_dtTempScheduleList.Columns.Contains("Friday") Then
                            .Friday = strRow("Friday").ToString.ToLower = "true"
                        Else
                            .Friday = False
                        End If
                        If m_dtTempScheduleList.Columns.Contains("Saturday") Then
                            .Saturday = strRow("Saturday").ToString.ToLower = "true"
                        Else
                            .Saturday = False
                        End If
                    End With
                    With dtSchedule
                        .Rows.Add(.NewRow)
                        .Rows(.Rows.Count - 1).Item("CAPTION") = oScheduleData.Caption
                        .Rows(.Rows.Count - 1).Item("STARTTIME") = oScheduleData.StartTime
                        .Rows(.Rows.Count - 1).Item("DURATION") = oScheduleData.Duration
                        .Rows(.Rows.Count - 1).Item("DURATIONUNIT") = oScheduleData.DurationUnit
                        If IsDate(oScheduleData.StartTime) Then
                            Select Case oScheduleData.DurationUnit
                                Case "s"
                                    .Rows(.Rows.Count - 1).Item("ENDTIME") = CDate(.Rows(.Rows.Count - 1).Item("STARTTIME")).AddSeconds(oScheduleData.Duration).ToString("HH:mm:ss")
                                Case "m"
                                    .Rows(.Rows.Count - 1).Item("ENDTIME") = CDate(.Rows(.Rows.Count - 1).Item("STARTTIME")).AddMinutes(oScheduleData.Duration).ToString("HH:mm:ss")
                                Case "h"
                                    .Rows(.Rows.Count - 1).Item("ENDTIME") = CDate(.Rows(.Rows.Count - 1).Item("STARTTIME")).AddHours(oScheduleData.Duration).ToString("HH:mm:ss")
                            End Select
                        End If
                        .Rows(.Rows.Count - 1).Item("STATUS") = IIf(oScheduleData.ScheduleEnable, "�ҥ�", "�Ȥ�")
                        .Rows(.Rows.Count - 1).Item("DATA") = oScheduleData
                    End With
                Next
            End If

            Me.dgvScheduleList.DataSource = dtSchedule

            'schedule_reg = schedule_reg.OpenSubKey("ScheduleList")
            'If schedule_reg IsNot Nothing Then
            '    Dim strID As String() = schedule_reg.GetValueNames
            '    For Each str As String In strID
            '        Dim strRow As String() = schedule_reg.GetValue(str)
            '        If strRow.Length <> 13 Then Throw New Exception("��Ƥ��šI")

            '        Dim oScheduleData As New Schedule()
            '        With oScheduleData
            '            .ScheduleEnable = strRow(0).ToLower = "true"
            '            .Caption = strRow(1)
            '            .ProgramPath = strRow(2)
            '            .StartTime = strRow(3)
            '            '.EndTime = strRow(4)
            '            .Duration = strRow(4)
            '            .DurationUnit = strRow(5)
            '            .Sunday = strRow(6).ToLower = "true"
            '            .Monday = strRow(7).ToLower = "true"
            '            .Tuesday = strRow(8).ToLower = "true"
            '            .Wednesday = strRow(9).ToLower = "true"
            '            .Thusday = strRow(10).ToLower = "true"
            '            .Friday = strRow(11).ToLower = "true"
            '            .Saturday = strRow(12).ToLower = "true"
            '        End With
            '        With dtSchedule
            '            .Rows.Add(.NewRow)
            '            .Rows(.Rows.Count - 1).Item("CAPTION") = oScheduleData.Caption
            '            .Rows(.Rows.Count - 1).Item("STARTTIME") = oScheduleData.StartTime
            '            .Rows(.Rows.Count - 1).Item("DURATION") = oScheduleData.Duration
            '            .Rows(.Rows.Count - 1).Item("DURATIONUNIT") = oScheduleData.DurationUnit
            '            If IsDate(oScheduleData.StartTime) Then
            '                Select Case oScheduleData.DurationUnit
            '                    Case "s"
            '                        .Rows(.Rows.Count - 1).Item("ENDTIME") = CDate(.Rows(.Rows.Count - 1).Item("STARTTIME")).AddSeconds(oScheduleData.Duration).ToString("HH:mm:ss")
            '                    Case "m"
            '                        .Rows(.Rows.Count - 1).Item("ENDTIME") = CDate(.Rows(.Rows.Count - 1).Item("STARTTIME")).AddMinutes(oScheduleData.Duration).ToString("HH:mm:ss")
            '                    Case "h"
            '                        .Rows(.Rows.Count - 1).Item("ENDTIME") = CDate(.Rows(.Rows.Count - 1).Item("STARTTIME")).AddHours(oScheduleData.Duration).ToString("HH:mm:ss")
            '                End Select
            '            End If
            '            .Rows(.Rows.Count - 1).Item("STATUS") = IIf(oScheduleData.ScheduleEnable, "�ҥ�", "�Ȥ�")
            '            .Rows(.Rows.Count - 1).Item("DATA") = oScheduleData
            '        End With
            '    Next
            '    schedule_reg.Close()
            'End If

        Catch ex As Exception
            MsgBox("���J�n���ɮɵo�Ϳ��~�I")
        Finally
            Me.chkMailEnable_CheckedChanged(sender, e)
            Me.chkJcicEnable_CheckedChanged(sender, e)
            Me.chkAdmEnable_CheckedChanged(sender, e)
            Me.chkRestartOnTheHour_CheckedChanged(sender, e)
        End Try

    End Sub
    Private Sub InitAPServerDataGrid()
        Dim colIP As New DataGridViewTextBoxColumn
        With colIP
            .Name = "IP"
            .ValueType = GetType(System.String)
            .HeaderText = "AP Server�Ϻо��s�u�r��"
            .Width = 200
            .DataPropertyName = "IP"
        End With

        Dim colUserID As New DataGridViewTextBoxColumn
        With colUserID
            .Name = "UserID"
            .ValueType = GetType(System.String)
            .HeaderText = "�n�JID"
            .Width = 100
            .DataPropertyName = "UserID"
        End With

        Dim colPassword As New DataGridViewTextBoxColumn
        With colPassword
            .Name = "EditPassword"
            .ValueType = GetType(System.String)
            .HeaderText = "�n�J�K�X"
            .Width = 100
            .DataPropertyName = "EditPassword"
        End With

        Dim colHidPassword As New DataGridViewTextBoxColumn
        With colHidPassword
            .Name = "Password"
            .ValueType = GetType(System.String)
            .HeaderText = "�n�J�K�X"
            .Width = 100
            .DataPropertyName = "Password"
            .Visible = False
        End With

        Dim colPath As New DataGridViewTextBoxColumn
        With colPath
            .Name = "Path"
            .ValueType = GetType(System.String)
            .HeaderText = "�s����|"
            .Width = 100
            .DataPropertyName = "Path"
        End With

        With Me.dgvAPServerList.Columns
            .Add(colIP)
            .Add(colUserID)
            .Add(colPassword)
            .Add(colHidPassword)
            .Add(colPath)
        End With

    End Sub

    Private m_blnIsPasswordField As Boolean = False
    Private Sub dgvAPServerList_CellBeginEdit(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellCancelEventArgs) Handles dgvAPServerList.CellBeginEdit
        If Me.dgvAPServerList.Columns(e.ColumnIndex).Name = "EditPassword" Then
            If Me.dgvAPServerList.Rows(e.RowIndex).Cells(e.ColumnIndex).Value IsNot Nothing AndAlso _
                Me.dgvAPServerList.Rows(e.RowIndex).Cells(e.ColumnIndex).Value.ToString.Trim <> "" Then
                Me.dgvAPServerList.Rows(e.RowIndex).Cells(e.ColumnIndex).Value = Crypt.Dec(Me.dgvAPServerList.Rows(e.RowIndex).Cells(e.ColumnIndex + 1).Value)
            End If
            m_blnIsPasswordField = True
        Else
            m_blnIsPasswordField = False
        End If
    End Sub

    Private Sub dgvAPServerList_CellEndEdit(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgvAPServerList.CellEndEdit
        If m_blnIsPasswordField Then
            Me.dgvAPServerList.Rows(e.RowIndex).Cells(e.ColumnIndex + 1).Value = Crypt.Enc(Me.dgvAPServerList.Rows(e.RowIndex).Cells(e.ColumnIndex).Value)
            Me.dgvAPServerList.Rows(e.RowIndex).Cells(e.ColumnIndex).Value = Space(Me.dgvAPServerList.Rows(e.RowIndex).Cells(e.ColumnIndex).Value.ToString.Length).Replace(" ", "*")
        End If
    End Sub

    Private Sub dgvAPServerList_EditingControlShowing(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewEditingControlShowingEventArgs) Handles dgvAPServerList.EditingControlShowing
        Dim m_ctrlPassword As DataGridViewTextBoxEditingControl = CType(e.Control, DataGridViewTextBoxEditingControl)
        If m_blnIsPasswordField Then
            m_ctrlPassword.PasswordChar = "*"
            m_ctrlPassword.UseSystemPasswordChar = True
        Else
            m_ctrlPassword.PasswordChar = ""
            m_ctrlPassword.UseSystemPasswordChar = False
        End If
    End Sub

    '��l��DataGrid
    Private Sub InitDataGrid()
        Dim colIP As New DataGridViewTextBoxColumn
        With colIP
            .Name = "IP"
            .ValueType = GetType(System.String)
            .HeaderText = "����IP"
            .Width = 100
            .DataPropertyName = "IP"
        End With

        Dim colPort As New DataGridViewTextBoxColumn
        With colPort
            .Name = "Port"
            .ValueType = GetType(System.Int32)
            .HeaderText = "����Port"
            .Width = 100
            .DataPropertyName = "Port"
        End With
        Dim colListen As New DataGridViewTextBoxColumn
        With colListen
            .Name = "Listen"
            .ValueType = GetType(System.Int32)
            .HeaderText = "���aPort"
            .Width = 100
            .DataPropertyName = "Listen"
        End With

        dtConnType = New DataTable
        With dtConnType
            .Columns.Add("Code", GetType(System.String))
            .Columns.Add("Name", GetType(System.String))
            .Rows.Add(.NewRow)
            .Rows(.Rows.Count - 1).Item("Code") = "Full"
            .Rows(.Rows.Count - 1).Item("Name") = "���ɳs�u"
            .Rows.Add(.NewRow)
            .Rows(.Rows.Count - 1).Item("Code") = "Need"
            .Rows(.Rows.Count - 1).Item("Name") = "�ݭn�ɳs�u"
            '.Rows.Add(.NewRow)
            '.Rows(.Rows.Count - 1).Item("Code") = "Half"
            '.Rows(.Rows.Count - 1).Item("Name") = "�̾ڻݭn"
        End With

        Dim colConnType As New DataGridViewComboBoxColumn
        With colConnType
            .Name = "ConnType"
            .DataSource = dtConnType
            .DisplayMember = "Name"
            .ValueMember = "Code"
            .HeaderText = "�s�u�覡"
            .Width = 100
            .DataPropertyName = "ConnType"
        End With

        dtDocEncoding = New DataTable
        With dtDocEncoding
            .Columns.Add("Code", GetType(System.String))
            .Columns.Add("Name", GetType(System.String))
            '�ۭq
            .Rows.Add(.NewRow)
            .Rows(.Rows.Count - 1).Item("Code") = "937"
            .Rows(.Rows.Count - 1).Item("Name") = "EBCDIC:937"

            '����
            For Each encinfo As EncodingInfo In Encoding.GetEncodings
                .Rows.Add(.NewRow)
                .Rows(.Rows.Count - 1).Item("Code") = encinfo.CodePage
                .Rows(.Rows.Count - 1).Item("Name") = Format(encinfo.CodePage, "00000") & "-" & encinfo.DisplayName
            Next

        End With

        Dim colDocEncodingOut As New DataGridViewComboBoxColumn
        With colDocEncodingOut
            .Name = "DocEncodingOut"
            .DataSource = dtDocEncoding
            .DisplayMember = "Name"
            .ValueMember = "Code"
            .HeaderText = "�ǰe�s�X"
            .Width = 100 '
            .DataPropertyName = "DocEncodingOut"
        End With
        Dim colDocEncodingIn As New DataGridViewComboBoxColumn
        With colDocEncodingIn
            .Name = "DocEncodingIn"
            .DataSource = dtDocEncoding
            .DisplayMember = "Name"
            .ValueMember = "Code"
            .HeaderText = "�����s�X"
            .Width = 100
            .DataPropertyName = "DocEncodingIn"
        End With

        'dtDatabase = New DataTable
        'With dtDatabase
        '    .Columns.Add("Database", GetType(System.String))
        '    .Columns.Add("DatabaseName", GetType(System.String))

        '    '�ۭq
        '    .Rows.Add(.NewRow)
        '    .Rows(.Rows.Count - 1).Item("Database") = "SKBank_Loan"
        '    .Rows(.Rows.Count - 1).Item("DatabaseName") = "SKBank_Loan"

        '    .Rows.Add(.NewRow)
        '    .Rows(.Rows.Count - 1).Item("Database") = "SKBank_CL"
        '    .Rows(.Rows.Count - 1).Item("DatabaseName") = "SKBank_CL"

        'End With

        Dim colDatabase As New DataGridViewTextBoxColumn
        With colDatabase
            .Name = "Database"
            .ValueType = GetType(System.String)
            .HeaderText = "�s����Ʈw"
            .Width = 120
            .DataPropertyName = "Database"
        End With

        Dim colTable As New DataGridViewTextBoxColumn
        With colTable
            .Name = "Table"
            .ValueType = GetType(System.String)
            .HeaderText = "�ӷ�Table"
            .Width = 120
            .DataPropertyName = "Table"
        End With

        Dim colMaxCount As New DataGridViewTextBoxColumn
        With colMaxCount
            .Name = "MaxCount"
            .ValueType = GetType(System.Int32)
            .HeaderText = "�榸�d�߼�"
            .Width = 100
            .DataPropertyName = "MaxCount"
        End With





        Dim colDeadline As New DataGridViewTextBoxColumn
        With colDeadline
            .Name = "Deadline"
            .ValueType = GetType(System.Int32)
            .HeaderText = "��ƹO��(��)"
            .Width = 100
            .DataPropertyName = "Deadline"
        End With

        Dim colTimeoutRestart As New DataGridViewTextBoxColumn
        With colTimeoutRestart
            .Name = "TimeoutRestart"
            .ValueType = GetType(System.Int32)
            .HeaderText = "����O�ɭ��o(��)"
            .Width = 200
            .DataPropertyName = "TimeoutRestart"
        End With

        Dim colOutputConnTime As New DataGridViewTextBoxColumn
        With colOutputConnTime
            .Name = "OutputConnTime"
            .ValueType = GetType(System.Int32)
            .HeaderText = "�B�z����(��)"
            .Width = 100
            .DataPropertyName = "OutputConnTime"
        End With

        Dim colInputConnTime As New DataGridViewTextBoxColumn
        With colInputConnTime
            .Name = "InputConnTime"
            .ValueType = GetType(System.Int32)
            .HeaderText = "�ǿ驵��(��)"
            .Width = 100
            .DataPropertyName = "InputConnTime"
        End With

        Dim colPingInterval As New DataGridViewTextBoxColumn
        With colPingInterval
            .Name = "PingInterval"
            .ValueType = GetType(System.String)
            .HeaderText = "PING�X�ʶ��j(����)"
            .Width = 200
            .DataPropertyName = "PingInterval"
        End With

        Dim colStartTime As New DataGridViewTextBoxColumn
        With colStartTime
            .Name = "StartTime"
            .ValueType = GetType(System.String)
            .HeaderText = "�}�l�ɶ�(0000)"
            .Width = 120
            .DataPropertyName = "StartTime"
        End With

        Dim colEndTime As New DataGridViewTextBoxColumn
        With colEndTime
            .Name = "EndTime"
            .ValueType = GetType(System.String)
            .HeaderText = "�����ɶ�(0000)"
            .Width = 120
            .DataPropertyName = "EndTime"
        End With

        dtLogFlag = New DataTable
        With dtLogFlag
            .Columns.Add("Code", GetType(System.String))
            .Columns.Add("Name", GetType(System.String))
            '�ۭq
            .Rows.Add(.NewRow)
            .Rows(.Rows.Count - 1).Item("Code") = "0"
            .Rows(.Rows.Count - 1).Item("Name") = "�_"
            .Rows.Add(.NewRow)
            .Rows(.Rows.Count - 1).Item("Code") = "1"
            .Rows(.Rows.Count - 1).Item("Name") = "�O"

        End With

        Dim colLogFlag As New DataGridViewComboBoxColumn
        With colLogFlag
            .Name = "LogFlag"
            .DataSource = dtLogFlag
            .DisplayMember = "Name"
            .ValueMember = "Code"
            .HeaderText = "�O�_�O��Log"
            .Width = 100
            .DataPropertyName = "LogFlag"
        End With

        With Me.dgvRemoteServerList.Columns
            .Add(colIP)
            .Add(colPort)
            .Add(colListen)
            .Add(colConnType)
            .Add(colDocEncodingOut)
            .Add(colDocEncodingIn)
            .Add(colDatabase)
            .Add(colTable)
            .Add(colMaxCount)
            .Add(colDeadline)
            .Add(colTimeoutRestart)
            .Add(colOutputConnTime)
            .Add(colInputConnTime)
            .Add(colPingInterval)
            .Add(colStartTime)
            .Add(colEndTime)
            .Add(colLogFlag)
        End With

    End Sub
    '�榡����
    Private Sub dgRemoteServerList_CellValidating(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellValidatingEventArgs) Handles dgvRemoteServerList.CellValidating
        If e.FormattedValue.ToString.Trim.Length = 0 Then Exit Sub

        Select Case Me.dgvRemoteServerList.Columns(e.ColumnIndex).Name
            Case "IP" 'IP
                Try
                    Dim ipValid As System.Net.IPAddress
                    ipValid = System.Net.IPAddress.Parse(e.FormattedValue)
                Catch '�ϥΪ̶ǤJ���D�X�k��IP��}�榡
                    MsgBox("�D�k���עޮ榡�I")
                    e.Cancel = True
                End Try

            Case "Port", "Listen" 'Port
                Try
                    Dim intResult As Integer = CInt(e.FormattedValue)
                    If intResult <= 0 Or intResult > 65535 Then
                        Throw New Exception
                    End If
                Catch ex As Exception
                    MsgBox("�D�k���s����d��I")
                    e.Cancel = True
                End Try

            Case "OutputConnTime", "InputConnTime", "MaxCount", "ELCount", "T6E027_28Count", "T6C001Count", "Deadline", "TimeoutRestart", "PingInterval" 'Integer
                Try
                    Dim intResult As Integer = CInt(e.FormattedValue)

                Catch ex As Exception
                    MsgBox("�D�k���ƭȡI")
                    e.Cancel = True
                End Try

            Case "StartTime", "EndTime"
                Try
                    Dim intTime As Integer = CInt(e.FormattedValue)
                    Dim strTime As String = Format(intTime, "00:00")
                    Dim dateTime As DateTime = CDate(strTime)
                Catch ex As Exception
                    MsgBox("�D�k���ɶ��榡�I")
                    e.Cancel = True
                End Try

                'Case "PingTime"
                '    Try
                '        Dim strPingTime() As String = CStr(e.FormattedValue).Split(",")
                '        If strPingTime IsNot Nothing AndAlso strPingTime.Length > 0 Then
                '            For i As Integer = 0 To strPingTime.Length - 1
                '                Dim strTime As String = strPingTime(i).Insert(2, ":")
                '                Dim dateTime As DateTime = CDate(strTime)
                '            Next
                '        End If
                '    Catch ex As Exception
                '        MsgBox("�D�k���ɶ��榡�I")
                '        e.Cancel = True
                '    End Try
            Case Else


        End Select
    End Sub
    '����
    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        End
    End Sub
    '�}�Ҹ�Ƨ����|-��X
    Private Sub btnTmpOutputPath_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTmpOutputPath.Click
        Dim fbdOutput As New FolderBrowserDialog
        With fbdOutput
            .Description = "��ܿ�X�μȦs��Ƨ�"
            .RootFolder = Environment.SpecialFolder.MyComputer
            .ShowNewFolderButton = True
            .ShowDialog()
            Me.txtTmpOutputPath.Text = IIf(.SelectedPath = "", Me.txtTmpOutputPath.Text, .SelectedPath)
        End With
    End Sub
    '�}�Ҹ�Ƨ����|-��J
    Private Sub btnTmpInputPath_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTmpInputPath.Click
        Dim fbdInput As New FolderBrowserDialog
        With fbdInput
            .Description = "��ܿ�J�μȦs��Ƨ�"
            .RootFolder = Environment.SpecialFolder.MyComputer
            .ShowNewFolderButton = True
            .ShowDialog()
            Me.txtTmpInputPath.Text = IIf(.SelectedPath = "", Me.txtTmpInputPath.Text, .SelectedPath)
        End With
    End Sub

    '�x�s��Registry
    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        objSettings.AddSetting("DBConnString_LOAN", Settings.SettingType._String, Me.txtDBConnString.Text.Trim)
        objSettings.AddSetting("LocalServerIP", Settings.SettingType._String, Me.txtLocalServerIP.Text.Trim)
        objSettings.AddSetting("TmpOutputPath", Settings.SettingType._String, Me.txtTmpOutputPath.Text.Trim)
        objSettings.AddSetting("TmpInputPath", Settings.SettingType._String, Me.txtTmpInputPath.Text.Trim)
        objSettings.AddSetting("LogPath", Settings.SettingType._String, Me.txtLogPath.Text.Trim)
        '2009.11.11 Add by Kevin ----------------------------------------------
        objSettings.AddSetting("ConnStr_Loan", Settings.SettingType._String, Me.txtConnStr_Loan.Text.Trim)
        objSettings.AddSetting("ConnStr_Loan_History", Settings.SettingType._String, Me.txtConnStr_Loan_History.Text.Trim)
        objSettings.AddSetting("ConnStr_CL", Settings.SettingType._String, Me.txtConnStr_CL.Text.Trim)
        objSettings.AddSetting("ConnStr_Security", Settings.SettingType._String, Me.txtConnStr_Security.Text.Trim)
        '----------------------------------------------------------------------
        '2009.11.17 Add by Kevin ----------------------------------------------
        objSettings.AddSetting("UpLoadFilePath", Settings.SettingType._String, Me.txtUpLoadFilePath.Text.Trim)
        objSettings.AddSetting("Adm_UpLoadFilePath", Settings.SettingType._String, Me.txtAdm_UpLoadFilePath.Text.Trim)
        objSettings.AddSetting("UpLoadUser", Settings.SettingType._String, Me.txtUpLoadUser.Text.Trim)
        objSettings.AddSetting("UpLoadPassword", Settings.SettingType._String, Crypt.Enc(Me.txtUpLoadPassword.Text.Trim))
        objSettings.AddSetting("Attach_Interval", Settings.SettingType._Integer, Me.nudAttach_Interval.Value)
        objSettings.AddSetting("AttachFilePath", Settings.SettingType._String, Me.txtAttachFilePath.Text.Trim)
        '----------------------------------------------------------------------
        '2011.12.13 Add by Kevin ----------------------------------------------
        objSettings.AddSetting("AttachFileMode", Settings.SettingType._String, Me.cmbAttachFileMode.SelectedValue)
        '----------------------------------------------------------------------
        '2009.07.03 Add by Kevin ----------------------------------------------
        objSettings.AddSetting("ELSrcPath", Settings.SettingType._String, Me.txtELSrcPath.Text.Trim)
        objSettings.AddSetting("ELTagPath", Settings.SettingType._String, Me.txtELTagPath.Text.Trim)
        objSettings.AddSetting("ELLifeCycle", Settings.SettingType._Integer, CInt(Me.txtELLifeCycle.Text.Trim))
        objSettings.AddSetting("ELLifeCycleUnit", Settings.SettingType._String, Me.cmbELLifeCycleUnit.SelectedValue)
        '----------------------------------------------------------------------
        '2009.04.28 Add by Kevin ----------------------------------------------
        objSettings.AddSetting("LogFileSize", Settings.SettingType._Integer, Me.nudLogFileSize.Value)
        objSettings.AddSetting("LogFileBackupCount", Settings.SettingType._Integer, Me.nudLogFileBackupCount.Value)
        '----------------------------------------------------------------------
        objSettings.AddSetting("MailEnable", Settings.SettingType._Boolean, Me.chkMailEnable.Checked)
        objSettings.AddSetting("MailQuantity", Settings.SettingType._String, Me.txtMailQuantity.Text.Trim)
        objSettings.AddSetting("MailTo", Settings.SettingType._String, Me.txtMailTo.Text.Trim)
        objSettings.AddSetting("MailCC", Settings.SettingType._String, Me.txtMailCC.Text.Trim)
        objSettings.AddSetting("MailSMTP", Settings.SettingType._String, Me.txtMailSMTP.Text.Trim)
        objSettings.AddSetting("MailSMTPVerify", Settings.SettingType._Boolean, Me.chkMailSMTPVerify.Checked)
        objSettings.AddSetting("MailSMTPUid", Settings.SettingType._String, Me.txtMailSMTPUid.Text.Trim)
        objSettings.AddSetting("MailSMTPPwd", Settings.SettingType._String, Crypt.Enc(Me.txtMailSMTPPwd.Text.Trim))

        objSettings.AddSetting("API_JcicTch", Settings.SettingType._String, Me.txtAPI_JcicTch.Text.Trim)
        objSettings.AddSetting("ConnStr_JcicTch", Settings.SettingType._String, Me.txtConnStr_JcicTch.Text.Trim)
        objSettings.AddSetting("JcicEnable", Settings.SettingType._Boolean, Me.chkJcicEnable.Checked)
        objSettings.AddSetting("JcicTables", Settings.SettingType._String, Me.txtJcicTables.Text.Trim)
        objSettings.AddSetting("JcicInterval", Settings.SettingType._Integer, Me.nudJcicInterval.Value)

        objSettings.AddSetting("TchEnable", Settings.SettingType._Boolean, Me.chkTchEnable.Checked)
        objSettings.AddSetting("TchTables", Settings.SettingType._String, Me.txtTchTables.Text.Trim)
        objSettings.AddSetting("TchInterval", Settings.SettingType._Integer, Me.nudTchInterval.Value)

        objSettings.AddSetting("API_EDOCService", Settings.SettingType._String, Me.txtAPI_EDOCService.Text.Trim)
        objSettings.AddSetting("AdmEnable", Settings.SettingType._Boolean, Me.chkAdmEnable.Checked)
        objSettings.AddSetting("AdmTables", Settings.SettingType._String, Me.txtAdmTables.Text.Trim)
        objSettings.AddSetting("AdmInterval", Settings.SettingType._Integer, Me.nudAdmInterval.Value)

        objSettings.AddSetting("OutSourceLog", Settings.SettingType._Boolean, Me.chkOutSourceLog.Checked)
        objSettings.AddSetting("API_ScoringService", Settings.SettingType._String, Me.txtAPI_ScoringService.Text)

        '2013.04.25 Add by Kevin ----------------------------------------------
        objSettings.AddSetting("RestartServicesName", Settings.SettingType._String, Me.txtRestartServicesName.Text)
        objSettings.AddSetting("RestartOnTheHour", Settings.SettingType._Boolean, Me.chkRestartOnTheHour.Checked)
        objSettings.AddSetting("RestartTime", Settings.SettingType._String, Me.txtRestartTime.Text)




        Dim m_dtRemoteServerList As New DataTable("RemoteServerList")

        For i As Integer = 0 To Me.dgvRemoteServerList.ColumnCount - 1
            m_dtRemoteServerList.Columns.Add(Me.dgvRemoteServerList.Columns(i).Name, GetType(String))
        Next

        For Each row As DataGridViewRow In Me.dgvRemoteServerList.Rows
            If Not row.Cells(0).Value Is Nothing Then
                Dim m_drRemoteServerList As DataRow = m_dtRemoteServerList.NewRow()
                For j As Integer = 0 To row.Cells.Count - 1
                    Dim cell As DataGridViewCell = row.Cells(j)
                    m_drRemoteServerList(j) = IIf(cell.Value Is Nothing, "", cell.Value)
                Next
                m_dtRemoteServerList.Rows.Add(m_drRemoteServerList)
            End If
        Next

        objSettings.AddList(m_dtRemoteServerList)

        Dim m_dtAPServerList As New DataTable("APServerList")
        For i As Integer = 0 To Me.dgvAPServerList.ColumnCount - 1
            m_dtAPServerList.Columns.Add(Me.dgvAPServerList.Columns(i).Name, GetType(String))
        Next

        For Each row As DataGridViewRow In Me.dgvAPServerList.Rows
            If Not row.Cells(0).Value Is Nothing Then
                Dim m_drAPServerList As DataRow = m_dtAPServerList.NewRow()
                For j As Integer = 0 To row.Cells.Count - 1
                    Dim cell As DataGridViewCell = row.Cells(j)
                    m_drAPServerList(j) = IIf(cell.Value Is Nothing, "", cell.Value)
                Next
                m_dtAPServerList.Rows.Add(m_drAPServerList)
            End If
        Next

        objSettings.AddList(m_dtAPServerList)


        Dim m_dtScheduleList As New DataTable("ScheduleList")

        m_dtScheduleList.Columns.Add("ScheduleEnable", GetType(String))
        m_dtScheduleList.Columns.Add("Caption", GetType(String))
        m_dtScheduleList.Columns.Add("ProgramPath", GetType(String))
        m_dtScheduleList.Columns.Add("StartTime", GetType(String))
        m_dtScheduleList.Columns.Add("Duration", GetType(String))
        m_dtScheduleList.Columns.Add("DurationUnit", GetType(String))
        m_dtScheduleList.Columns.Add("Sunday", GetType(String))
        m_dtScheduleList.Columns.Add("Monday", GetType(String))
        m_dtScheduleList.Columns.Add("Tuesday", GetType(String))
        m_dtScheduleList.Columns.Add("Wednesday", GetType(String))
        m_dtScheduleList.Columns.Add("Thusday", GetType(String))
        m_dtScheduleList.Columns.Add("Friday", GetType(String))
        m_dtScheduleList.Columns.Add("Saturday", GetType(String))

        For i As Integer = 0 To Me.dtSchedule.Rows.Count - 1
            Dim m_drSchedule As DataRow = m_dtScheduleList.NewRow()
            m_drSchedule.ItemArray = CType(Me.dtSchedule.Rows(i)("DATA"), Schedule).ToStringArray
            m_dtScheduleList.Rows.Add(m_drSchedule)
        Next

        objSettings.AddList(m_dtScheduleList)
        'For Each row As DataRow In Me.dtSchedule.Rows
        '    regScheduleList.SetValue(row("ID"), CType(row("DATA"), Schedule).ToStringArray)
        'Next
        'regScheduleList.Close()

        objSettings.Save()
        MsgBox("�]�w�Ȥw�x�s�I")
    End Sub

    '�s��s���r��
    Private Sub btnDBConnString_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDBConnString.Click
        Dim dlgDBConnString As New dlgDBConnString
        dlgDBConnString.strDBConnString = Me.txtDBConnString.Text
        If dlgDBConnString.ShowDialog() = System.Windows.Forms.DialogResult.OK Then
            Me.txtDBConnString.Text = dlgDBConnString.strDBConnString ' & Crypt.Enc(dlgDBConnString.strPWD)
        End If
        dlgDBConnString.Dispose()
    End Sub
    '�O���ɿ�X��Ƨ����|
    Private Sub btnLogPath_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLogPath.Click
        Dim fbdLog As New FolderBrowserDialog
        With fbdLog
            .Description = "��ܰO���ɿ�X��Ƨ�"
            .RootFolder = Environment.SpecialFolder.Desktop
            .ShowNewFolderButton = True
            .ShowDialog()
            Me.txtLogPath.Text = IIf(.SelectedPath = "", Me.txtTmpInputPath.Text, .SelectedPath)
        End With
    End Sub
    'IP��J�ˬd
    Private Sub txtLocalServerIP_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtLocalServerIP.Leave
        Try
            Dim ipValid As System.Net.IPAddress
            ipValid = System.Net.IPAddress.Parse(Me.txtLocalServerIP.Text.Trim)
        Catch '�ϥΪ̶ǤJ���D�X�k��IP��}�榡
            MsgBox("�D�k���עޮ榡�I")
            Me.txtLocalServerIP.Focus()
            Me.txtLocalServerIP.SelectAll()
        End Try
    End Sub
    '�s�ʲM��
    Private Sub chkMailEnable_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkMailEnable.CheckedChanged
        Me.gboxEmail.Enabled = Me.chkMailEnable.Checked
    End Sub
    '�s��Jcic�M��
    Private Sub chkJcicEnable_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkJcicEnable.CheckedChanged
        Me.gboxJcic.Enabled = Me.chkJcicEnable.Checked
    End Sub

    '�s��Adm�M��
    Private Sub chkAdmEnable_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkAdmEnable.CheckedChanged
        Me.gboxAdm.Enabled = Me.chkAdmEnable.Checked
    End Sub

    '�Ʀr
    Private Sub txtMailQuantity_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtMailQuantity.Leave
        Try
            Me.txtMailQuantity.Text = CInt(Val(Me.txtMailQuantity.Text.Trim)).ToString
        Catch ex0 As OverflowException
            Me.txtMailQuantity.Text = System.Int32.MaxValue.ToString
        Catch ex As Exception
            Me.txtMailQuantity.Text = "0"
        End Try
    End Sub
    '�l��a�}
    Private Sub txtMail_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtMailTo.Validating, txtMailCC.Validating
        Dim strEmail As String = CType(sender, TextBox).Text.Trim
        If strEmail.Length = 0 Then Exit Sub
        Try
            Dim MailAddress As New Net.Mail.MailAddress(strEmail)
        Catch ex As Exception
            MsgBox(ex.Message)
            e.Cancel = True
        End Try
    End Sub

    '�s�W�Ƶ{����
    Private Sub btnAddSchedule_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddSchedule.Click
        Dim dlgAddSchedule As New dlgSchedule
        Dim dlgResult As DialogResult = dlgAddSchedule.ShowDialog()
        If dlgResult = System.Windows.Forms.DialogResult.OK Then
            '�s�W���
            Dim oNewData As Schedule = dlgAddSchedule.ScheduleData
            With dtSchedule
                .Rows.Add(.NewRow)
                .Rows(.Rows.Count - 1).Item("CAPTION") = oNewData.Caption
                .Rows(.Rows.Count - 1).Item("STARTTIME") = oNewData.StartTime
                .Rows(.Rows.Count - 1).Item("DURATION") = oNewData.Duration
                .Rows(.Rows.Count - 1).Item("DURATIONUNIT") = oNewData.DurationUnit
                If IsDate(oNewData.StartTime) Then
                    Select Case oNewData.DurationUnit
                        Case "s"
                            .Rows(.Rows.Count - 1).Item("ENDTIME") = CDate(.Rows(.Rows.Count - 1).Item("STARTTIME")).AddSeconds(oNewData.Duration).ToString("HH:mm:ss")
                        Case "m"
                            .Rows(.Rows.Count - 1).Item("ENDTIME") = CDate(.Rows(.Rows.Count - 1).Item("STARTTIME")).AddMinutes(oNewData.Duration).ToString("HH:mm:ss")
                        Case "h"
                            .Rows(.Rows.Count - 1).Item("ENDTIME") = CDate(.Rows(.Rows.Count - 1).Item("STARTTIME")).AddHours(oNewData.Duration).ToString("HH:mm:ss")
                    End Select
                End If
                .Rows(.Rows.Count - 1).Item("STATUS") = IIf(oNewData.ScheduleEnable, "�ҥ�", "�Ȥ�")
                .Rows(.Rows.Count - 1).Item("DATA") = oNewData
            End With
        End If
        dlgAddSchedule.Dispose()
        Me.dgvScheduleList.DataSource = dtSchedule


    End Sub
    '�s��Ƶ{����
    Private Sub btnEditSchedule_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEditSchedule.Click
        Dim ID As Integer = Me.dgvScheduleList.CurrentRow.Cells("colID").Value
        If ID > 0 Then
            Dim oScheduleData As Schedule = Me.dtSchedule.Select("ID=" & ID)(0).Item("DATA")
            Dim dlgAddSchedule As New dlgSchedule
            dlgAddSchedule.ScheduleData = oScheduleData
            Dim dlgResult As DialogResult = dlgAddSchedule.ShowDialog()
            If dlgResult = System.Windows.Forms.DialogResult.OK Then
                '�s�W���
                Dim oData As Schedule = dlgAddSchedule.ScheduleData
                With dtSchedule.Select("ID=" & ID)(0)
                    .Item("CAPTION") = oData.Caption
                    .Item("STARTTIME") = oData.StartTime
                    .Item("DURATION") = oData.Duration
                    .Item("DURATIONUNIT") = oData.DurationUnit
                    If IsDate(oData.StartTime) Then
                        Select Case oData.DurationUnit
                            Case "s"
                                .Item("ENDTIME") = CDate(.Item("STARTTIME")).AddSeconds(oData.Duration).ToString("HH:mm:ss")
                            Case "m"
                                .Item("ENDTIME") = CDate(.Item("STARTTIME")).AddMinutes(oData.Duration).ToString("HH:mm:ss")
                            Case "h"
                                .Item("ENDTIME") = CDate(.Item("STARTTIME")).AddHours(oData.Duration).ToString("HH:mm:ss")
                        End Select
                    End If
                    .Item("STATUS") = IIf(oData.ScheduleEnable, "�ҥ�", "�Ȥ�")
                    .Item("DATA") = oData
                End With
            End If
            dlgAddSchedule.Dispose()
            Me.dgvScheduleList.DataSource = dtSchedule
        End If
    End Sub
    '�s��Ƶ{����
    Private Sub dgvScheduleList_CellDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgvScheduleList.CellDoubleClick
        Dim ID As Integer = Me.dgvScheduleList.CurrentRow.Cells("colID").Value
        If ID > 0 Then
            Dim oScheduleData As Schedule = Me.dtSchedule.Select("ID=" & ID)(0).Item("DATA")
            Dim dlgAddSchedule As New dlgSchedule
            dlgAddSchedule.ScheduleData = oScheduleData
            Dim dlgResult As DialogResult = dlgAddSchedule.ShowDialog()
            If dlgResult = System.Windows.Forms.DialogResult.OK Then
                '�s�W���
                Dim oData As Schedule = dlgAddSchedule.ScheduleData
                With dtSchedule.Select("ID=" & ID)(0)
                    .Item("CAPTION") = oData.Caption
                    .Item("STARTTIME") = oData.StartTime
                    .Item("DURATION") = oData.Duration
                    .Item("DURATIONUNIT") = oData.DurationUnit
                    If IsDate(oData.StartTime) Then
                        Select Case oData.DurationUnit
                            Case "s"
                                .Item("ENDTIME") = CDate(.Item("STARTTIME")).AddSeconds(oData.Duration).ToString("HH:mm:ss")
                            Case "m"
                                .Item("ENDTIME") = CDate(.Item("STARTTIME")).AddMinutes(oData.Duration).ToString("HH:mm:ss")
                            Case "h"
                                .Item("ENDTIME") = CDate(.Item("STARTTIME")).AddHours(oData.Duration).ToString("HH:mm:ss")
                        End Select
                    End If
                    .Item("STATUS") = IIf(oData.ScheduleEnable, "�ҥ�", "�Ȥ�")
                    .Item("DATA") = oData
                End With
            End If
            dlgAddSchedule.Dispose()
            Me.dgvScheduleList.DataSource = dtSchedule
        End If
    End Sub
    '�����Ƶ{����
    Private Sub btnRemoveSchedule_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRemoveSchedule.Click
        Dim ID As Integer = Me.dgvScheduleList.CurrentRow.Cells("colID").Value
        If ID > 0 Then
            Me.dtSchedule.Rows.Remove(Me.dtSchedule.Select("ID=" & ID)(0))
            Me.dgvScheduleList.DataSource = Me.dtSchedule
        End If

    End Sub

    ''' <summary>
    ''' �D�n��Ʈw�s���r��]�w
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks>
    ''' 2009.11.11 Created by Kevin
    ''' </remarks>
    Private Sub btnConnStr_Loan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnConnStr_Loan.Click
        Dim dlgDBConnString As New dlgDBConnString
        dlgDBConnString.strDBConnString = Me.txtConnStr_Loan.Text
        If dlgDBConnString.ShowDialog() = System.Windows.Forms.DialogResult.OK Then
            Me.txtConnStr_Loan.Text = dlgDBConnString.strDBConnString ' & Crypt.Enc(dlgDBConnString.strPWD)
            Me.txtDBConnString.Text = dlgDBConnString.strDBConnString ' & Crypt.Enc(dlgDBConnString.strPWD)
        End If
        dlgDBConnString.Dispose()
    End Sub



    ''' <summary>
    ''' �~���t���p�x�����Ʈw�s�u�r��
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnConnStr_JcicTch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnConnStr_JcicTch.Click
        Dim dlgDBConnString As New dlgDBConnString
        Dim m_strTempConnStr As String = Me.txtConnStr_JcicTch.Text
        m_strTempConnStr = m_strTempConnStr.Replace("data source", "server")
        m_strTempConnStr = m_strTempConnStr.Replace("initial catalog", "database")
        m_strTempConnStr = m_strTempConnStr.Replace("user id", "uid")
        m_strTempConnStr = m_strTempConnStr.Replace("password", "pwd")
        dlgDBConnString.strDBConnString = m_strTempConnStr
        If dlgDBConnString.ShowDialog() = System.Windows.Forms.DialogResult.OK Then
            m_strTempConnStr = dlgDBConnString.strDBConnString ' & Crypt.Enc(dlgDBConnString.strPWD)
            m_strTempConnStr = m_strTempConnStr.Replace("server", "data source")
            m_strTempConnStr = m_strTempConnStr.Replace("database", "initial catalog")
            m_strTempConnStr = m_strTempConnStr.Replace("uid", "user id")
            m_strTempConnStr = m_strTempConnStr.Replace("pwd", "password")
            Me.txtConnStr_JcicTch.Text = m_strTempConnStr
        End If
        dlgDBConnString.Dispose()
    End Sub

    ''' <summary>
    ''' �����]�w�ȥͮ�
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnWebSettingActive_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnWebSettingActive.Click

        If MsgBox("�O�_�T�w�ͮ�?" & vbCrLf & "����ͮħ@�~�N�|�Ͻu�W�ϥΪ̵o�����_!", MsgBoxStyle.YesNo, "�����]�w�ȥͮ�") = MsgBoxResult.Yes Then

            If Me.dgvAPServerList.Rows.Count > 1 Then
                Dim m_strMessage As String = ""
                Dim m_strWebConfigFile As String = Application.StartupPath.TrimEnd("\") & "\Web.config"
                Dim m_strSecurityWebConfigFile As String = Application.StartupPath.TrimEnd("\") & "\SecurityWeb.config"
                Dim m_strBaseWebConfigFile As String = Application.StartupPath.TrimEnd("\") & "\BaseWeb.config"
                Dim m_strSecurityBaseWebConfigFile As String = Application.StartupPath.TrimEnd("\") & "\SecurityBaseWeb.config"
                Dim m_dsWebConfigFile As New DataSet()

                m_dsWebConfigFile.ReadXml(m_strBaseWebConfigFile)

                If m_dsWebConfigFile.Tables.Contains("add") Then
                    For i As Integer = 0 To m_dsWebConfigFile.Tables("add").Rows.Count - 1
                        With m_dsWebConfigFile.Tables("add").Rows(i)
                            Dim m_strConnectionString As String = Nothing
                            Select Case (.Item("name") & "")
                                Case "ConnStr_Loan"
                                    If Me.txtConnStr_Loan.Text.Trim <> "" Then
                                        m_strConnectionString = Me.txtConnStr_Loan.Text.Trim
                                    End If

                            End Select

                            If m_strConnectionString IsNot Nothing Then
                                Dim m_intPwdIndex As Integer = m_strConnectionString.IndexOf(";pwd=")
                                If m_intPwdIndex >= 0 Then
                                    Dim m_strPassword As String = m_strConnectionString.Substring(m_intPwdIndex + 5)
                                    m_strConnectionString = m_strConnectionString.Substring(0, m_strConnectionString.Length - m_strPassword.Length)
                                    m_strPassword = Crypt.Dec(m_strPassword)
                                    m_strConnectionString &= m_strPassword
                                End If
                                .Item("connectionString") = m_strConnectionString
                            End If

                            Dim m_strValue As String = Nothing
                            Select Case (.Item("key") & "")
                                Case "UpLoadFilePath"
                                    m_strValue = Me.txtUpLoadFilePath.Text.Trim
                                Case "Adm_UpLoadFilePath"
                                    m_strValue = Me.txtAdm_UpLoadFilePath.Text.Trim
                                Case "UpLoadUser"
                                    m_strValue = Me.txtUpLoadUser.Text.Trim
                                Case "UpLoadPassword"
                                    m_strValue = Me.txtUpLoadPassword.Text.Trim
                                Case "API_JcicTch"
                                    m_strValue = Me.txtAPI_JcicTch.Text.Trim
                                Case "API_EDOCService"
                                    m_strValue = Me.txtAPI_EDOCService.Text.Trim
                                Case "API_ScoringService"
                                    m_strValue = Me.txtAPI_ScoringService.Text.Trim
                            End Select

                            If m_strValue IsNot Nothing Then
                                .Item("value") = m_strValue
                            End If

                        End With
                    Next
                End If

                m_dsWebConfigFile.WriteXml(m_strWebConfigFile)

                m_dsWebConfigFile = New DataSet()
                m_dsWebConfigFile.ReadXml(m_strSecurityBaseWebConfigFile)

                If m_dsWebConfigFile.Tables.Contains("add") Then
                    For i As Integer = 0 To m_dsWebConfigFile.Tables("add").Rows.Count - 1
                        With m_dsWebConfigFile.Tables("add").Rows(i)
                            Dim m_strConnectionString As String = Nothing
                            Select Case (.Item("name") & "")
                                Case "ConnStr_Loan"
                                    If Me.txtConnStr_Loan.Text.Trim <> "" Then
                                        m_strConnectionString = Me.txtConnStr_Loan.Text.Trim
                                    End If

                            End Select

                            If m_strConnectionString IsNot Nothing Then
                                Dim m_intPwdIndex As Integer = m_strConnectionString.IndexOf(";pwd=")
                                If m_intPwdIndex >= 0 Then
                                    Dim m_strPassword As String = m_strConnectionString.Substring(m_intPwdIndex + 5)
                                    m_strConnectionString = m_strConnectionString.Substring(0, m_strConnectionString.Length - m_strPassword.Length)
                                    m_strPassword = Crypt.Dec(m_strPassword)
                                    m_strConnectionString &= m_strPassword
                                End If
                                .Item("connectionString") = m_strConnectionString
                            End If

                        End With
                    Next
                End If

                m_dsWebConfigFile.WriteXml(m_strSecurityWebConfigFile)

                For i As Integer = 0 To Me.dgvAPServerList.Rows.Count - 2
                    If Me.dgvAPServerList.Rows(i).Cells(0).Value.ToString <> "" Then
                        NetUseDisk("x", Me.dgvAPServerList.Rows(i).Cells(0).Value.ToString, Me.dgvAPServerList.Rows(i).Cells(1).Value.ToString, Crypt.Dec(Me.dgvAPServerList.Rows(i).Cells(3).Value.ToString))
                        Threading.Thread.Sleep(5000)

                        Dim m_strDestWebConfigFile As String = "x:\" & Me.dgvAPServerList.Rows(i).Cells(4).Value.ToString.Trim.Trim("\") & "\eLoan\Web.Config"
                        Try
                            File.Copy(m_strWebConfigFile, m_strDestWebConfigFile, True)
                            m_strMessage &= Me.dgvAPServerList.Rows(i).Cells(0).Value.ToString & " eLoan �����]�w�Ȥw�ͮ�!" & vbCrLf
                        Catch ex As Exception
                            m_strMessage &= Me.dgvAPServerList.Rows(i).Cells(0).Value.ToString & " eLoan �o�Ϳ��~!" & vbCrLf
                        End Try

                        m_strDestWebConfigFile = "x:\" & Me.dgvAPServerList.Rows(i).Cells(4).Value.ToString.Trim.Trim("\") & "\Security\Web.Config"
                        Try
                            File.Copy(m_strSecurityWebConfigFile, m_strDestWebConfigFile, True)
                            m_strMessage &= Me.dgvAPServerList.Rows(i).Cells(0).Value.ToString & " Security �����]�w�Ȥw�ͮ�!" & vbCrLf
                        Catch ex As Exception
                            m_strMessage &= Me.dgvAPServerList.Rows(i).Cells(0).Value.ToString & " Security �o�Ϳ��~!" & vbCrLf
                        End Try

                        NetUseDelete("x")
                        Threading.Thread.Sleep(5000)
                    End If
                Next

                Try
                    File.Delete(m_strWebConfigFile)
                    File.Delete(m_strSecurityWebConfigFile)
                Catch ex As Exception
                End Try

                MsgBox(m_strMessage, MsgBoxStyle.DefaultButton1, "�����]�w�ȥͮ�")
            Else
                MsgBox("�L�]�wAP Server!", MsgBoxStyle.DefaultButton1, "�����]�w�ȥͮ�")
            End If
        End If
    End Sub

    Private Sub NetUseDisk(ByVal p_strDisk As String, ByVal p_strAddress As String, ByVal p_strUser As String, ByVal p_strPassword As String)
        Dim m_strCommandFormat As String = "NET USE {0} {1} {2} {3}"
        Dim m_strCommand As String = Nothing
        Dim m_strDisk As String = ""
        Dim m_strUser As String = ""
        If p_strDisk IsNot Nothing Then m_strDisk = p_strDisk & ":"
        If p_strUser IsNot Nothing Then m_strUser = "/USER:" & p_strUser

        m_strCommand = String.Format(m_strCommandFormat, m_strDisk, p_strAddress, p_strPassword, m_strUser)
        Shell(m_strCommand)
    End Sub

    Private Sub NetUseDelete(ByVal p_strDisk As String)
        Dim m_strCommandFormat As String = "NET USE {0} /DELETE"
        Dim m_strCommand As String = Nothing
        Dim m_strDisk As String = ""
        If p_strDisk IsNot Nothing Then m_strDisk = p_strDisk & ":"

        m_strCommand = String.Format(m_strCommandFormat, m_strDisk)
        Shell(m_strCommand)
    End Sub


    Private Sub chkRestartOnTheHour_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkRestartOnTheHour.CheckedChanged
        If Me.chkRestartOnTheHour.Checked Then
            Me.txtRestartTime.ReadOnly = True
        Else
            Me.txtRestartTime.ReadOnly = False
        End If
    End Sub
End Class
