﻿Imports System.Windows.Forms
'Imports Microsoft.SqlServer.Management.Smo
'Imports Microsoft.SqlServer.Management.Common
Imports eLoan_Gateway.ClassLib

Public Class dlgDBConnString
    Private strDBConnFormat As String = "server={0};database={1};uid={2};pwd={3}"
    Private Crypt As New ClassLib.Cryptography '加解密

    Public strDBConnString As String = ""

    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
        Me.strDBConnString = String.Format(strDBConnFormat, Me.cboServer.SelectedValue, Me.txtDatabase.Text.Trim, Me.txtUID.Text.Trim, Crypt.Enc(Me.txtPWD.Text.Trim))
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.Close()
    End Sub

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

    Private Sub dlgDBConnString_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Return
        '載入清單
        Dim dtServerList As DataTable = Nothing ' Microsoft.SqlServer.Management.Smo.SmoApplication.EnumAvailableSqlServers()
        Me.cboServer.DataSource = dtServerList
        Me.cboServer.ValueMember = "Name"
        Me.cboServer.DisplayMember = "Name"

        '設定預設值
        If strDBConnString IsNot Nothing AndAlso strDBConnString <> "" Then
            Dim m_strDBConnPart() As String = strDBConnString.Split(";")
            If m_strDBConnPart IsNot Nothing AndAlso m_strDBConnPart.Length > 0 Then
                For i As Integer = 0 To m_strDBConnPart.Length - 1
                    Dim m_intEqualIndex As Integer = m_strDBConnPart(i).IndexOf("=")
                    If m_intEqualIndex > 0 Then
                        Dim m_strParamName As String = m_strDBConnPart(i).Substring(0, m_intEqualIndex)
                        Dim m_strParamValue As String = m_strDBConnPart(i).Substring(m_intEqualIndex + 1, m_strDBConnPart(i).Length - m_intEqualIndex - 1)

                        Select Case m_strParamName
                            Case "server"
                                For j As Integer = 0 To Me.cboServer.Items.Count - 1
                                    Dim m_drvItem As System.Data.DataRowView = CType(Me.cboServer.Items(j), System.Data.DataRowView)
                                    If m_drvItem("Name").ToString = m_strParamValue Then
                                        Me.cboServer.SelectedValue = m_strParamValue
                                        Exit For
                                    End If
                                Next
                                If Me.cboServer.Items.Contains(m_strParamValue) Then
                                    Me.cboServer.SelectedValue = m_strParamValue
                                End If
                            Case "database"
                                Me.txtDatabase.Text = m_strParamValue
                            Case "uid"
                                Me.txtUID.Text = m_strParamValue
                            Case "pwd"
                                Me.txtPWD.Text = Crypt.Dec(m_strParamValue)
                        End Select
                    End If
                Next
            End If
        End If
    End Sub

    Private Sub btnTEST_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTEST.Click
        Dim blnCanConnect As Boolean = False

        Try
            'Dim svrConn As New ServerConnection(Me.cboServer.SelectedValue, Me.txtUID.Text.Trim, Me.txtPWD.Text.Trim)
            'Dim svr As New Server(svrConn)
            'For i As Integer = 0 To svr.Databases.Count - 1
            '    If svr.Databases(i).Name.Trim.ToLower = Me.txtDatabase.Text.Trim.ToLower Then blnCanConnect = True
            'Next
            'svrConn.Disconnect()
        Catch ex As Exception
            blnCanConnect = False
        End Try
        If blnCanConnect Then
            MsgBox("連接成功！")
        Else
            MsgBox("連接失敗！")
        End If

    End Sub
End Class
