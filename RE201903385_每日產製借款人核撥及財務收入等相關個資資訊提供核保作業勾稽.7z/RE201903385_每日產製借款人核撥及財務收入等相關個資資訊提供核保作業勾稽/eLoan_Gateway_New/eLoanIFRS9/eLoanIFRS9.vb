﻿Imports System.Windows.Forms
Imports System.Xml
Imports System.Data.SqlClient
Imports eLoan_Gateway
Imports eLoan_Gateway.ClassLib
Imports System.Net   'Web
Imports System.IO    'Files
Imports System.Object
Imports System.Text
Imports Microsoft.Practices.EnterpriseLibrary.Data
Imports System.Data.Common

Module eLoanIFRS9
    Private g_objSettings As ClassLib.Settings = Nothing
    Private g_strLogPath As String = Nothing
    Private g_writeLog As eLoan_Gateway.ClassLib.WriteLog
    Private g_strAPI_EDOCService As String = Nothing
    Private g_strDBConnString As String = Nothing
    Private g_strDBConnEloanString As String = Nothing
    Private g_moDB_CSS As Database = Nothing
    Private g_moDB_Loan As Database = Nothing
    Private g_strPutFilePath As String = Nothing
    Private g_strPutJCICFilePath As String = Nothing

    Sub Main()
        'eLoan資料庫連線字串
        g_objSettings = New ClassLib.Settings(Application.StartupPath)

        Try
            g_strLogPath = CStr(g_objSettings.ReadSetting("LogPath")).TrimEnd("\") & "\"

            g_writeLog = New eLoan_Gateway.ClassLib.WriteLog(g_strLogPath)

            g_strDBConnString = CStr(g_objSettings.ReadSetting("DBConnString_CSS"))
            g_strDBConnEloanString = CStr(g_objSettings.ReadSetting("DBConnString_LOAN"))
            g_strPutFilePath = CStr(g_objSettings.ReadSetting("IFRS9PutFilePath"))
            g_strPutJCICFilePath = CStr(g_objSettings.ReadSetting("JCICPutFilePath"))

            g_moDB_CSS = DBUtil.GetDB(g_strDBConnString)
            g_moDB_Loan = DBUtil.GetDB(g_strDBConnEloanString)

            If getUploadMain() Then
                SetIFRS9Idx_Etl_EntIfrsRank()
                SetIFRS9Txt_Etl_EntIfrsRank()
                SetIFRS9Idx_Etl_EntIfrsTrans()
                SetIFRS9Txt_Etl_EntIfrsTrans()
                SetIFRS9Idx_Etl_HouseIfrsRank()
                SetIFRS9Txt_Etl_HouseIfrsRank()
                SetIFRS9Idx_Etl_HouseIfrsTrans()
                SetIFRS9Txt_Etl_HouseIfrsTrans()
                FtpUpload()
                Backup()
                SetJCICBatchList()
            End If

        Catch ex As Exception
            If g_writeLog IsNot Nothing Then
                g_writeLog.WriteErrorLog("eLoanIFRS9:Failed to Load Settings, " & ex.Message)
            End If
            Exit Sub
        End Try
    End Sub

    ''' <summary>
    ''' ENTERPRISE.IDX -> LNFJP.IDX
    ''' </summary>
    Private Sub SetIFRS9Idx_Etl_EntIfrsRank()
        Dim moDBCmd As DbCommand = Nothing
        Dim dt As New DataTable
        Dim strSQL As String = ""
        Dim LastDay As DateTime = New DateTime(DateTime.Now.Year, DateTime.Now.Month, 1).AddDays(-1)
        Dim strStartDay As String = Year(LastDay).ToString() + Month(LastDay).ToString().PadLeft(2, "0") + "01"
        Dim strLastDay As String = LastDay.ToString("yyyyMMdd")

        strSQL = "Select '" & strStartDay & ",'+ cast(Count(*) as varchar) as ENTERPRISEIDX From [Etl_EntIfrsRank] WHERE EtlDate = '" & strLastDay & "'"
        moDBCmd = g_moDB_CSS.GetSqlStringCommand(strSQL)
        Dim ds As DataSet = g_moDB_CSS.ExecuteDataSet(moDBCmd)

        Dim sw As StreamWriter = New StreamWriter(g_strPutFilePath + "LNFJP.IDX")
        If ds.Tables.Count > 0 Then
            dt = ds.Tables(0)
            For i As Integer = 0 To dt.Rows.Count - 1
                sw.WriteLine(DateTime.Now.ToString("yyyyMMdd") & "," & dt.Rows(i)("ENTERPRISEIDX"))
            Next
        End If

        sw.Close()
        moDBCmd.Dispose()

    End Sub

    ''' <summary>
    ''' ENTERPRISE.TXT -> LNFJP.TXT
    ''' </summary>
    Private Sub SetIFRS9Txt_Etl_EntIfrsRank()
        Dim moDBCmd As DbCommand = Nothing
        Dim dt As New DataTable
        Dim strSQL As String = ""
        Dim LastDay As DateTime = New DateTime(DateTime.Now.Year, DateTime.Now.Month, 1).AddDays(-1)
        Dim strStartDay As String = Year(LastDay).ToString() + Month(LastDay).ToString().PadLeft(2, "0") + "01"
        Dim strLastDay As String = LastDay.ToString("yyyyMMdd")

        strSQL = "SELECT '""' + [LMSACN] + '"",""'+ [ORankNo] +'"",""'+ [OScoreDate] +'"",""'+ [NRankNo] +'"",""'+ [NScoreDate] +'""' as ENTERPRISETXT FROM [dbo].[Etl_EntIfrsRank] WHERE EtlDate = '" & strLastDay & "'"
        moDBCmd = g_moDB_CSS.GetSqlStringCommand(strSQL)
        Dim ds As DataSet = g_moDB_CSS.ExecuteDataSet(moDBCmd)

        Dim sw As StreamWriter = New StreamWriter(g_strPutFilePath + "LNFJP.TXT")
        If ds.Tables.Count > 0 Then
            dt = ds.Tables(0)
            For i As Integer = 0 To dt.Rows.Count - 1
                sw.WriteLine(dt.Rows(i)("ENTERPRISETXT"))
            Next
        End If

        sw.Close()
        moDBCmd.Dispose()

    End Sub

    ''' <summary>
    ''' ENTERPRISE_SCORE_TRANSFER.IDX -> LNFLP.IDX
    ''' </summary>
    Private Sub SetIFRS9Idx_Etl_EntIfrsTrans()
        Dim moDBCmd As DbCommand = Nothing
        Dim dt As New DataTable
        Dim strSQL As String = ""
        Dim LastDay As DateTime = New DateTime(DateTime.Now.Year, DateTime.Now.Month, 1).AddDays(-1)
        Dim strStartDay As String = Year(LastDay).ToString() + Month(LastDay).ToString().PadLeft(2, "0") + "01"
        Dim strLastDay As String = LastDay.ToString("yyyyMMdd")

        strSQL = "Select '" & strStartDay & ",'+ cast(Count(*) as varchar) as ENTERPRISE_SCORE_TRANSFERIDX From [Etl_EntIfrsTrans] WHERE EtlDate = '" & strLastDay & "'"
        moDBCmd = g_moDB_CSS.GetSqlStringCommand(strSQL)
        Dim ds As DataSet = g_moDB_CSS.ExecuteDataSet(moDBCmd)

        Dim sw As StreamWriter = New StreamWriter(g_strPutFilePath + "LNFLP.IDX")
        If ds.Tables.Count > 0 Then
            dt = ds.Tables(0)
            For i As Integer = 0 To dt.Rows.Count - 1
                sw.WriteLine(DateTime.Now.ToString("yyyyMMdd") & "," & dt.Rows(i)("ENTERPRISE_SCORE_TRANSFERIDX"))
            Next
        End If

        sw.Close()
        moDBCmd.Dispose()

    End Sub

    ''' <summary>
    ''' ENTERPRISE_SCORE_TRANSFER.TXT -> LNFLP.TXT
    ''' </summary>
    Private Sub SetIFRS9Txt_Etl_EntIfrsTrans()
        Dim moDBCmd As DbCommand = Nothing
        Dim dt As New DataTable
        Dim strSQL As String = ""
        Dim LastDay As DateTime = New DateTime(DateTime.Now.Year, DateTime.Now.Month, 1).AddDays(-1)
        Dim strStartDay As String = Year(LastDay).ToString() + Month(LastDay).ToString().PadLeft(2, "0") + "01"
        Dim strLastDay As String = LastDay.ToString("yyyyMMdd")

        strSQL = "SELECT '""' + [EtlDate] + '"",""'+ [RankNo] +'"",""'+ [Column01] +'"",""'+ [Column02] +'"",""'+ [Column03] +'"",""'+ [Column04] +'"",""'+ [Column05] +'"",""'+ [Column06] +'"",""'+ [Column07] +'"",""'+ [Column08] +'"",""'+ [Column09] +'""' as ENTERPRISE_SCORE_TRANSFERTXT FROM [dbo].[Etl_EntIfrsTrans] WHERE EtlDate = '" & strLastDay & "'"
        moDBCmd = g_moDB_CSS.GetSqlStringCommand(strSQL)
        Dim ds As DataSet = g_moDB_CSS.ExecuteDataSet(moDBCmd)

        Dim sw As StreamWriter = New StreamWriter(g_strPutFilePath + "LNFLP.TXT")
        If ds.Tables.Count > 0 Then
            dt = ds.Tables(0)
            For i As Integer = 0 To dt.Rows.Count - 1
                sw.WriteLine(dt.Rows(i)("ENTERPRISE_SCORE_TRANSFERTXT"))
            Next
        End If

        sw.Close()
        moDBCmd.Dispose()

    End Sub

    ''' <summary>
    ''' HOUSELOAN.IDX -> LNFKP.IDX
    ''' </summary>
    Private Sub SetIFRS9Idx_Etl_HouseIfrsRank()
        Dim moDBCmd As DbCommand = Nothing
        Dim dt As New DataTable
        Dim strSQL As String = ""
        Dim LastDay As DateTime = New DateTime(DateTime.Now.Year, DateTime.Now.Month, 1).AddDays(-1)
        Dim strStartDay As String = Year(LastDay).ToString() + Month(LastDay).ToString().PadLeft(2, "0") + "01"
        Dim strLastDay As String = LastDay.ToString("yyyyMMdd")

        strSQL = "Select '" & strStartDay & ",'+ cast(Count(*) as varchar) as HOUSELOANIDX From [Etl_HouseIfrsRank] WHERE EtlDate = '" & strLastDay & "'"
        moDBCmd = g_moDB_CSS.GetSqlStringCommand(strSQL)
        Dim ds As DataSet = g_moDB_CSS.ExecuteDataSet(moDBCmd)

        Dim sw As StreamWriter = New StreamWriter(g_strPutFilePath + "LNFKP.IDX")
        If ds.Tables.Count > 0 Then
            dt = ds.Tables(0)
            For i As Integer = 0 To dt.Rows.Count - 1
                sw.WriteLine(DateTime.Now.ToString("yyyyMMdd") & "," & dt.Rows(i)("HOUSELOANIDX"))
            Next
        End If

        sw.Close()
        moDBCmd.Dispose()

    End Sub

    ''' <summary>
    ''' HOUSELOAN.TXT -> LNFKP.TXT
    ''' </summary>
    Private Sub SetIFRS9Txt_Etl_HouseIfrsRank()
        Dim moDBCmd As DbCommand = Nothing
        Dim dt As New DataTable
        Dim strSQL As String = ""
        Dim LastDay As DateTime = New DateTime(DateTime.Now.Year, DateTime.Now.Month, 1).AddDays(-1)
        Dim strStartDay As String = Year(LastDay).ToString() + Month(LastDay).ToString().PadLeft(2, "0") + "01"
        Dim strLastDay As String = LastDay.ToString("yyyyMMdd")

        strSQL = "SELECT '""' + [LMSACN] + '"",""'+ [LMSAPN] +'"",""'+ [ORankNo] +'"",""'+ [OScoreDate] +'"",""'+ [OScoreModel] +'"",""'+ [NRankNo] +'"",""'+ [NScoreDate] +'"",""'+ [NScoreModel] +'""' as HOUSELOANTXT FROM [dbo].[Etl_HouseIfrsRank] WHERE EtlDate = '" & strLastDay & "'"
        moDBCmd = g_moDB_CSS.GetSqlStringCommand(strSQL)
        Dim ds As DataSet = g_moDB_CSS.ExecuteDataSet(moDBCmd)

        Dim sw As StreamWriter = New StreamWriter(g_strPutFilePath + "LNFKP.TXT")
        If ds.Tables.Count > 0 Then
            dt = ds.Tables(0)
            For i As Integer = 0 To dt.Rows.Count - 1
                sw.WriteLine(dt.Rows(i)("HOUSELOANTXT"))
            Next
        End If

        sw.Close()
        moDBCmd.Dispose()

    End Sub

    ''' <summary>
    ''' HOUSELOAN_SCORE_TRANSFER.IDX -> LNFMP.IDX
    ''' </summary>
    Private Sub SetIFRS9Idx_Etl_HouseIfrsTrans()
        Dim moDBCmd As DbCommand = Nothing
        Dim dt As New DataTable
        Dim strSQL As String = ""
        Dim LastDay As DateTime = New DateTime(DateTime.Now.Year, DateTime.Now.Month, 1).AddDays(-1)
        Dim strStartDay As String = Year(LastDay).ToString() + Month(LastDay).ToString().PadLeft(2, "0") + "01"
        Dim strLastDay As String = LastDay.ToString("yyyyMMdd")

        strSQL = "Select '" & strStartDay & ",'+ cast(Count(*) as varchar) as HOUSELOAN_SCORE_TRANSFERIDX From [Etl_HouseIfrsTrans] WHERE EtlDate = '" & strLastDay & "'"
        moDBCmd = g_moDB_CSS.GetSqlStringCommand(strSQL)
        Dim ds As DataSet = g_moDB_CSS.ExecuteDataSet(moDBCmd)

        Dim sw As StreamWriter = New StreamWriter(g_strPutFilePath + "LNFMP.IDX")
        If ds.Tables.Count > 0 Then
            dt = ds.Tables(0)
            For i As Integer = 0 To dt.Rows.Count - 1
                sw.WriteLine(DateTime.Now.ToString("yyyyMMdd") & "," & dt.Rows(i)("HOUSELOAN_SCORE_TRANSFERIDX"))
            Next
        End If

        sw.Close()
        moDBCmd.Dispose()

    End Sub

    ''' <summary>
    ''' HOUSELOAN_SCORE_TRANSFER.TXT -> LNFMP.TXT
    ''' </summary>
    Private Sub SetIFRS9Txt_Etl_HouseIfrsTrans()
        Dim moDBCmd As DbCommand = Nothing
        Dim dt As New DataTable
        Dim strSQL As String = ""
        Dim LastDay As DateTime = New DateTime(DateTime.Now.Year, DateTime.Now.Month, 1).AddDays(-1)
        Dim strStartDay As String = Year(LastDay).ToString() + Month(LastDay).ToString().PadLeft(2, "0") + "01"
        Dim strLastDay As String = LastDay.ToString("yyyyMMdd")

        strSQL = "SELECT '""' + [EtlDate] + '"",""'+ [RankNo] +'"",""'+ [Column01] +'"",""'+ [Column02] +'"",""'+ [Column03] +'"",""'+ [Column04] +'"",""'+ [Column05] +'"",""'+ [Column06] +'"",""'+ [Column07] +'"",""'+ [Column08] +'"",""'+ [Column09] +'""' as HOUSELOAN_SCORE_TRANSFERTXT FROM [dbo].[Etl_HouseIfrsTrans] WHERE EtlDate = '" & strLastDay & "'"
        moDBCmd = g_moDB_CSS.GetSqlStringCommand(strSQL)
        Dim ds As DataSet = g_moDB_CSS.ExecuteDataSet(moDBCmd)

        Dim sw As StreamWriter = New StreamWriter(g_strPutFilePath + "LNFMP.TXT")
        If ds.Tables.Count > 0 Then
            dt = ds.Tables(0)
            For i As Integer = 0 To dt.Rows.Count - 1
                sw.WriteLine(dt.Rows(i)("HOUSELOAN_SCORE_TRANSFERTXT"))
            Next
        End If

        sw.Close()
        moDBCmd.Dispose()

    End Sub

    Private Sub FtpUpload()
        Dim FtpFilePath As String = CStr(g_objSettings.ReadSetting("IFRS9FtpUploadIP"))
        Dim ftpID As String = CStr(g_objSettings.ReadSetting("IFRS9FtpUploadUser"))
        Dim ftpPW As String = CStr(g_objSettings.ReadSetting("IFRS9FtpUploadPwd"))
        Dim wc As WebClient = New WebClient()
        wc.Credentials = New NetworkCredential(ftpID, ftpPW)
        Dim FileData As Byte()
        Dim di As DirectoryInfo = New DirectoryInfo(g_strPutFilePath)
        For Each fi In di.GetFiles()
            FileData = wc.UploadFile(FtpFilePath + fi.Name, g_strPutFilePath + fi.Name)
        Next

        '上傳完寫入記錄檔
        Dim moDBCmd As DbCommand = Nothing
        Dim strSQL As String = ""
        Dim LastDay As DateTime = New DateTime(DateTime.Now.Year, DateTime.Now.Month, 1).AddDays(-1)
        Dim ScoreDate As String = Year(LastDay).ToString() + Month(LastDay).ToString().PadLeft(2, "0")

        strSQL = " insert into Etl_IfrsUploadMain (UploadDate,Status) values ('" & ScoreDate & "',1)"
        moDBCmd = g_moDB_CSS.GetSqlStringCommand(strSQL)
        g_moDB_CSS.ExecuteNonQuery(moDBCmd)

    End Sub

    Private Sub Backup()
        Dim BakPath As String = CStr(g_objSettings.ReadSetting("IFRS9BakFilePath"))
        Dim BakPrefix As String = DateTime.Now.ToString("yyyyMMdd") & "_"
        
        Dim di As DirectoryInfo = New DirectoryInfo(g_strPutFilePath)
        For Each fi In di.GetFiles()
            Try
                fi.MoveTo(BakPath & BakPrefix & fi.Name)
            Catch ex As Exception
                ' ignore exceptions
            End Try
        Next
    End Sub

    Private Function getUploadMain() As Boolean
        Dim moDBCmd As DbCommand = Nothing
        Dim dt As New DataTable
        Dim strSQL As String = ""
        Dim LastDay As DateTime = New DateTime(DateTime.Now.Year, DateTime.Now.Month, 1).AddDays(-1)
        Dim ScoreDate As String = Year(LastDay).ToString() + Month(LastDay).ToString().PadLeft(2, "0")
        Dim boo As Boolean = False

        strSQL = " select A.ScoreDate,B.UploadDate from ScCal_B_Main A left join Etl_IfrsUploadMain B on A.ScoreDate = B.UploadDate and A.IsLatest = 1 where A.ScoreDate = '" & ScoreDate & "' "
        moDBCmd = g_moDB_CSS.GetSqlStringCommand(strSQL)
        Dim ds As DataSet = g_moDB_CSS.ExecuteDataSet(moDBCmd)

        If ds.Tables.Count > 0 Then
            dt = ds.Tables(0)
            '判斷已有上個月評分(ScoreDate已有日期)，UploadDate沒有日期代表要開始產IFRS資料
            If dt.Rows.Count > 0 Then
                If IsDBNull(dt.Rows(0)("UploadDate")) Then
                    boo = True
                End If
            End If
        End If

        Return boo
    End Function

    Private Sub SetJCICBatchList()
        Dim moDBCmd As DbCommand = Nothing
        Dim dt As New DataTable
        Dim strSQL As String = ""
        Dim LastDay As DateTime = New DateTime(DateTime.Now.Year, DateTime.Now.Month, 1).AddDays(-1)
        Dim ScoreDate As String = Year(LastDay).ToString() + Month(LastDay).ToString().PadLeft(2, "0")
        'Dim ScoreDate As String = "201802"
        Dim TxtDate As String = (DateTime.Now.Year - 1911).ToString & DateTime.Now.Month.ToString().PadLeft(2, "0") & DateTime.Now.Day.ToString().PadLeft(2, "0")
        Dim TxtName As String = TxtDate & "003-CR06-01"

        strSQL = " select CustId from Risk_House_Query where DataDate = '" & ScoreDate & "' and ReRankNo in ('7','8','O','B') Group by CustId "
        moDBCmd = g_moDB_Loan.GetSqlStringCommand(strSQL)
        Dim ds As DataSet = g_moDB_Loan.ExecuteDataSet(moDBCmd)

        Dim sw As StreamWriter = New StreamWriter(g_strPutJCICFilePath & TxtName & ".txt")
        If ds.Tables.Count > 0 Then
            dt = ds.Tables(0)
            For i As Integer = 0 To dt.Rows.Count - 1
                '自行使用文字(不足20碼請補空白)20碼 + 強制碼(0代表非強制查詢，1為強制)1碼 + 需輸入欄位資料(身分證字號，法人編號等等......) + 換行字元分隔(ASCII碼13+ASCII碼10)
                sw.WriteLine(DateTime.Now.ToString("yyyyMMddHHmmss").PadRight(20, " ") & "0" & dt.Rows(i)("CustId").ToString())
            Next
        End If

        sw.Close()
        moDBCmd.Dispose()


    End Sub

End Module
