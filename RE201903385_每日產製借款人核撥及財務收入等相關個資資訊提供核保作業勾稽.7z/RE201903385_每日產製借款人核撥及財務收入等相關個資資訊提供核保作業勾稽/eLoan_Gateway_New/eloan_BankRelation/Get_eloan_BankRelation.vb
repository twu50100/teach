Imports System.Windows.Forms
Imports System.Xml
Imports System.Data.SqlClient
Imports eLoan_Gateway
Imports eLoan_Gateway.ClassLib
Imports System.Net   'Web
Imports System.IO    'Files
Imports System.Object
Imports System.Text
Imports Microsoft.Practices.EnterpriseLibrary.Data

Module Get_Adm_Parameter
    Private g_objSettings As ClassLib.Settings = Nothing
    Private g_strLogPath As String = Nothing
    Private g_writeLog As eLoan_Gateway.ClassLib.WriteLog
    Private g_strAPI_EDOCService As String = Nothing
    Private g_strDBConnString As String = Nothing
    Private Crypt As New ClassLib.Cryptography
    Private SqlStr As New System.Text.StringBuilder
    Private i, j, k As Integer
    Private comd As SqlCommand
    Private comdTemptable As SqlCommand
    Private dt As DataTable = Nothing
    Private dr As DataSet = Nothing
    Private fileStrs As String() = {"BPMEXBP.csv.s", "BPMEXCP.csv.s", "BPMEXTP.csv.s"}
    Private fileStr As String() = {"BPMEXBP.csv", "BPMEXCP.csv", "BPMEXTP.csv"}

    Sub Main()
        'eLoan��Ʈw�s�u�r��
        g_objSettings = New ClassLib.Settings(Application.StartupPath)

        Try
            g_strLogPath = CStr(g_objSettings.ReadSetting("LogPath")).TrimEnd("\") & "\"
            g_writeLog = New eLoan_Gateway.ClassLib.WriteLog(g_strLogPath)


            GetFileFromFtp()
            DeCipherFile()
            WriteToHostDB()

        Catch ex As Exception
            If g_writeLog IsNot Nothing Then
                g_writeLog.WriteErrorLog("eloan_BankRelation:Failed to Load Settings, " & ex.Message)
            End If
            Exit Sub
        End Try

    End Sub
    Private Sub GetFileFromFtp()

        For i As Integer = 0 To fileStrs.Length - 1
            'Dim downFileName As String = "ftp://10.11.50.119/BankRelation/" + fileStrs(i)
            Dim downFileName As String = CStr(g_objSettings.ReadSetting("DownLoadFilePath")) + fileStrs(i)
            Dim wrDownload As FtpWebRequest = CType(FtpWebRequest.Create(downFileName), FtpWebRequest)
            'Specify Username & Password'


            'wrDownload.Credentials = New NetworkCredential("eloanftp", "23895858")
            Dim ftpID As String = CStr(g_objSettings.ReadSetting("DownLoadUser"))
            Dim ftpPW As String = CStr(g_objSettings.ReadSetting("DownLoadPassword"))
            wrDownload.Credentials = New NetworkCredential(ftpID, ftpPW)
            'Specify That You Want To Download A File'
            wrDownload.Method = WebRequestMethods.Ftp.DownloadFile

            Dim localFile = Application.StartupPath + "\" + fileStrs(i)

            Using response As System.Net.FtpWebResponse = CType(wrDownload.GetResponse, System.Net.FtpWebResponse)
                Using responseStream As IO.Stream = response.GetResponseStream

                    Using fs As New IO.FileStream(localFile, IO.FileMode.Create)
                        Dim buffer(2047) As Byte
                        Dim read As Integer = 0
                        Do
                            read = responseStream.Read(buffer, 0, buffer.Length)
                            fs.Write(buffer, 0, read)
                        Loop Until read = 0
                        responseStream.Close()
                        fs.Flush()
                        fs.Close()
                    End Using
                    responseStream.Close()
                End Using
                response.Close()
            End Using
        Next
    End Sub
    Private Sub DeCipherFile()
        '�H�U�B�z�{�ǤD�S�~���ѽX�{�������Ҧ��ɮ׸ѽX��, ��o����U�@��Ʈw�g�ɤu�@
        Dim process As New Process()
        process.StartInfo.FileName = Application.StartupPath + "\" + "CipherUtil1.bat"
        process.StartInfo.UseShellExecute = False
        process.StartInfo.RedirectStandardOutput = True
        process.Start()

        ' Synchronously read the standard output of the spawned process. 
        Dim reader As StreamReader = process.StandardOutput
        Dim output As String = reader.ReadToEnd()
        Console.WriteLine(output)

        process.WaitForExit()
        process.Close()

    End Sub
    Private Sub WriteToHostDB()
        Try
            For i As Integer = 0 To fileStr.Length - 1
                Dim localfile As String = Application.StartupPath + "\" + fileStr(i)
                Dim TextFileReader As New Microsoft.VisualBasic.FileIO.TextFieldParser(localfile, System.Text.Encoding.GetEncoding("big5"))
                TextFileReader.TextFieldType = FileIO.FieldType.Delimited
                TextFileReader.SetDelimiters(",")
                Dim CurrentRow As String()
                SqlStr.Clear()
                SqlStr.Append("BEGIN TRANSACTION;")
                SqlStr.Append(Environment.NewLine)
                SqlStr.Append("BEGIN TRY")
                SqlStr.Append(Environment.NewLine)
                Select Case fileStr(i)
                    Case "BPMEXBP.csv"
                        SqlStr.Append("DELETE FROM BankRelation_Family;")
                    Case "BPMEXCP.csv"
                        SqlStr.Append("DELETE FROM BankRelation_Company;")
                    Case "BPMEXTP.csv"
                        SqlStr.Append("DELETE FROM BankRelation_Self;")
                End Select
                While Not TextFileReader.EndOfData
                    Try
                        CurrentRow = TextFileReader.ReadFields()
                        If Not CurrentRow Is Nothing Then
                            Dim Str As String = ""
                            Select Case fileStr(i)
                                Case "BPMEXBP.csv"
                                    Str = "INSERT BankRelation_Family (CustName, CustId, RelationId, LAW001, LAW002, LAW003, LAW005, LAW008, LastUpdate_Date) VALUES (N'" + CurrentRow(0) + "', " + "N'" + CurrentRow(1) + "', " + "N'" + CurrentRow(2) + "', " + "N'" + CurrentRow(3) + "', " + "N'" + CurrentRow(4) + "', " + "N'" + CurrentRow(5) + "', " + "N'" + CurrentRow(6) + "', " + "N'" + CurrentRow(7) + "', " + "getdate()" + ");"
                                Case "BPMEXCP.csv"
                                    Str = "INSERT BankRelation_Company (CustName, CustId, CompanyId, LAW001, LAW002, LAW003, LAW005, LAW008, LastUpdate_Date) VALUES (N'" + CurrentRow(0) + "', " + "N'" + CurrentRow(1) + "', " + "N'" + CurrentRow(2) + "', " + "N'" + CurrentRow(3) + "', " + "N'" + CurrentRow(4) + "', " + "N'" + CurrentRow(5) + "', " + "N'" + CurrentRow(6) + "', " + "N'" + CurrentRow(7) + "', " + "getdate()" + ");"
                                Case "BPMEXTP.csv"
                                    Str = "INSERT BankRelation_Self (CustName, CustId, LAW001, LAW002, LAW003, LAW005, LAW008, LastUpdate_Date) VALUES (N'" + CurrentRow(0) + "', " + "N'" + CurrentRow(1) + "', " + "N'" + CurrentRow(2) + "', " + "N'" + CurrentRow(3) + "', " + "N'" + CurrentRow(4) + "', " + "N'" + CurrentRow(5) + "', " + "N'" + CurrentRow(6) + "', " + "getdate()" + ");"
                            End Select
                            SqlStr.Append(Str)
                        End If
                    Catch ex As Microsoft.VisualBasic.FileIO.MalformedLineException
                        'MsgBox("Line " & ex.Message & "is not valid and will be skipped.")
                        g_writeLog.WriteErrorLog("Line141" & ex.Message & "is not valid and will be skipped.")
                    End Try

                End While
                SqlStr.Append(Environment.NewLine)
                SqlStr.Append("END TRY")
                SqlStr.Append(Environment.NewLine)
                SqlStr.Append("BEGIN CATCH")
                SqlStr.Append(Environment.NewLine)
                SqlStr.Append("SELECT ERROR_NUMBER() AS ErrorNumber ,ERROR_SEVERITY() AS ErrorSeverity, ERROR_STATE() AS ErrorState")
                SqlStr.Append(", ERROR_PROCEDURE() As ErrorProcedure , ERROR_LINE() As ErrorLine , ERROR_MESSAGE() AS ErrorMessage;")
                SqlStr.Append(Environment.NewLine)
                SqlStr.Append(" IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;")
                SqlStr.Append("END CATCH")
                SqlStr.Append(Environment.NewLine)
                SqlStr.Append("IF @@TRANCOUNT > 0 COMMIT TRANSACTION;")
                TextFileReader.Dispose()

                g_strDBConnString = CStr(g_objSettings.ReadSetting("DBConnString_LOAN"))
                Dim moDB_ELOAN As Database = DBUtil.GetDB(g_strDBConnString)

                comd = moDB_ELOAN.GetSqlStringCommand(SqlStr.ToString)
                moDB_ELOAN.ExecuteNonQuery(comd)

            Next

        Catch ex As Exception
            'MsgBox("Line " & ex.Message & "is not valid and will be skipped.")
            'g_writeLog.WriteErrorLog("Adm_Paramenter: GetAdmParameterNew Error, " & ex.Message)
            g_writeLog.WriteErrorLog("Line170" & ex.Message & "is not valid and will be skipped.")
        End Try

    End Sub
End Module
