Imports System.Data.Common
Imports System.Data.SqlClient
Imports System.Xml
Imports System.IO
Imports System.Text
Imports eLoan_Gateway.ClassLib
Imports Microsoft.Practices.EnterpriseLibrary.Data

Public Class AdmHandler
    Implements eLoan_Gateway.IOutSourceHandler

    Private g_threadAdm As Threading.Thread = Nothing
    Private g_bolStop As Boolean = True
    Private Enc As Encoding = Encoding.GetEncoding(950)
    Private g_writeLog As WriteLog = Nothing

#Region "Properties"

    ''' <summary>
    ''' ��Ʈw�s�u�r��
    ''' </summary>
    ''' <remarks></remarks>
    Private g_strConnString_eloan As String = Nothing
    Public ReadOnly Property ConnectionString() As String _
            Implements eLoan_Gateway.IOutSourceHandler.ConnectionString_Eloan
        Get
            Return g_strConnString_eloan
        End Get

    End Property


    Private g_strConnString_IMP_DJCIC As String = Nothing
    Public Property ConnectionString_IMP_JCIC() As String _
            Implements eLoan_Gateway.IOutSourceHandler.ConnectionString_IMP_JCIC
        Get
            Return g_strConnString_IMP_DJCIC
        End Get

        Set(value As String)
            g_strConnString_IMP_DJCIC = value
        End Set
    End Property

    Private g_strConnString_IMP_Adm As String = Nothing
    Public Property ConnectionString_IMP_Adm() As String _
            Implements eLoan_Gateway.IOutSourceHandler.ConnectionString_IMP_ADM
        Get
            Return g_strConnString_IMP_Adm
        End Get

        Set(value As String)
            g_strConnString_IMP_Adm = value
        End Set
    End Property


    Private g_strConnString_DJCIC As String = Nothing
    Public Property ConnectionString_DJCIC() As String _
        Implements eLoan_Gateway.IOutSourceHandler.ConnectionString_DJCIC
        Get
            Return g_strConnString_DJCIC
        End Get

        Set(value As String)
            g_strConnString_DJCIC = value
        End Set
    End Property


    ''' <summary>
    ''' �ݳB�z��Table
    ''' </summary>
    ''' <remarks></remarks>
    Private g_strTables() As String = Nothing
    Public ReadOnly Property Tables() As String _
        Implements eLoan_Gateway.IOutSourceHandler.Tables
        Get
            Dim m_strTemp As String = ""
            If g_strTables IsNot Nothing AndAlso g_strTables.Length > 0 Then
                For i As Integer = 0 To g_strTables.Length - 1
                    m_strTemp &= g_strTables(i) & ";"
                Next
            End If
            Return m_strTemp.TrimEnd(";")
        End Get
    End Property

    ''' <summary>
    ''' �B�z���j�ɶ�
    ''' </summary>
    ''' <remarks></remarks>
    Private g_intInterval As Integer = 0
    Public ReadOnly Property Interval() As Integer _
        Implements eLoan_Gateway.IOutSourceHandler.Interval
        Get
            Return g_intInterval \ 1000
        End Get
    End Property

    ''' <summary>
    ''' Log�s����|
    ''' </summary>
    ''' <remarks></remarks>
    Private g_strLogPath As String = Nothing
    Public ReadOnly Property LogPath() As String _
        Implements eLoan_Gateway.IOutSourceHandler.LogPath
        Get
            Return g_strLogPath
        End Get
    End Property

    ''' <summary>
    ''' �a�F��X������m
    ''' </summary>
    ''' <remarks></remarks>
    Private g_strAPI_EDOCService As String = Nothing
    Public ReadOnly Property API_EDOCService() As String
        Get
            Return g_strAPI_EDOCService
        End Get
    End Property

#End Region

#Region "�غc�l"

    ''' <summary>
    ''' �غc�l�禡
    ''' </summary>
    ''' <param name="p_strConnectionString_eloan">��Ʈw�s�u�r��</param>
    ''' <param name="p_strAPI_EDOCService">�a�F��X������m</param>
    ''' <param name="p_strTables">�ݳB�z��Table</param>
    ''' <param name="p_intInterval">�B�z���j�ɶ�</param>
    ''' <param name="p_strLogPath">Log�s����|</param>
    ''' <remarks></remarks>
    Sub New(ByVal p_strConnectionString_eloan As String,
            ByVal p_strAPI_EDOCService As String,
            ByVal p_strTables As String,
            ByVal p_intInterval As Integer,
            ByVal p_strLogPath As String,
            ByVal p_strConnectionString_IMP_ADM As String)
        g_strConnString_eloan = p_strConnectionString_eloan
        g_strConnString_IMP_Adm = p_strConnectionString_IMP_ADM
        g_strAPI_EDOCService = p_strAPI_EDOCService
        g_strTables = p_strTables.Split(";")
        g_intInterval = p_intInterval * 1000
        g_strLogPath = p_strLogPath

        g_writeLog = New WriteLog(g_strLogPath)
    End Sub

#End Region

#Region "�ҰʻP�����A�ȱ`��"

    Public Sub StartThread() _
        Implements eLoan_Gateway.IOutSourceHandler.StartThread

        g_bolStop = False

        If g_threadAdm Is Nothing Then
            g_threadAdm = New Threading.Thread(AddressOf AdmThread)
            g_threadAdm.Start()
        End If

    End Sub

    Public Sub StopThread() _
        Implements eLoan_Gateway.IOutSourceHandler.StopThread

        g_bolStop = True

        If g_threadAdm IsNot Nothing Then
            For i As Integer = 0 To 20
                If g_threadAdm.ThreadState = Threading.ThreadState.Stopped Then
                    Exit For
                End If
                Threading.Thread.Sleep(1000)
            Next
            If g_threadAdm.ThreadState <> Threading.ThreadState.Stopped Then
                Try
                    g_threadAdm.Abort()
                Catch ex As Exception
                End Try
            End If

            g_threadAdm = Nothing
        End If

    End Sub

#End Region

#Region "����ǥD��"

    Private Sub AdmThread()

        While Not g_bolStop

            For i As Integer = 0 To g_strTables.Length - 1
                GetADMData(g_strTables(i))
                ParserData(g_strTables(i))
                If g_bolStop Then Exit While
            Next

            Threading.Thread.Sleep(g_intInterval)
        End While

    End Sub


#End Region

#Region "�a�F�t�άd��"

    Private Sub GetADMData(ByVal p_strTableName As String)
        Dim m_GetData As EDOCServiceService = New EDOCServiceService
        Dim sqlSelect As String = ""
        Dim sqlUpdate As String = ""
        Dim m_comd As SqlCommand = Nothing
        Dim m_dt As DataTable = Nothing
        Dim m_strUKey As String = Nothing
        Dim m_strLoanKey As String = Nothing

        m_GetData.Url = g_strAPI_EDOCService

        sqlSelect = " SELECT " & _
                            " UKey " & _
                            ",LoanKey " & _
                    " FROM " & _
                            p_strTableName & " (NOLOCK) " & _
                    " WHERE " & _
                            " QueryStatus = '0' "
        Try
            Dim moDB_ELOAN As Database = DBUtil.GetDB(g_strConnString_eloan)

            m_comd = moDB_ELOAN.GetSqlStringCommand(sqlSelect)
            Dim m_ds As DataSet = moDB_ELOAN.ExecuteDataSet(m_comd)
            m_dt = m_ds.Tables(0)

            If m_dt IsNot Nothing AndAlso m_dt.Rows.Count > 0 Then
                Dim m_objXML As New XmlDocument
                Dim m_node, m_node2, cnode As XmlNode
                Dim m_strRetMsg, m_strCode, m_strMsg, m_strIR00Code, m_strCode2, m_strDesc, m_strDesc2,
                    m_strDocType, m_strPage, m_strURL, TransCert, m_strGUID As String
                Dim m_dt3 As DataTable
                For i As Integer = 0 To m_dt.Rows.Count - 1



                    m_strUKey = m_dt.Rows(i)("UKey").ToString
                    m_strLoanKey = m_dt.Rows(i)("LoanKey").ToString
                    g_writeLog.WriteErrorLog("****[Table]=" & p_strTableName & ",[UKey]=" & m_strUKey & ",[LoanKey]=" & m_strLoanKey & "***")
                    Try
                        m_strRetMsg = m_GetData.applyQuery(m_strUKey)
                        m_objXML.LoadXml(m_strRetMsg)

                        m_node = m_objXML.DocumentElement.SelectSingleNode("RespMsg") '<RespMsg>
                        m_node2 = m_objXML.DocumentElement.SelectSingleNode("Result")    '<Result>

                        m_strCode = (CType(m_node, XmlElement).GetAttribute("Code").ToString)
                        m_strMsg = (CType(m_node, XmlElement).InnerText.ToString)

                        '0   �d�ߦ��\
                        g_writeLog.WriteErrorLog("�d�ߪ��A[m_strCode]=" & m_strCode)
                        Select Case m_strCode

                            Case "0"

                                For j As Integer = 0 To m_node2.ChildNodes.Count - 1

                                    cnode = m_node2.ChildNodes.Item(j) '<EDOCData>

                                    If Not IsNothing((CType(cnode.SelectSingleNode("Status"), XmlElement))) Then

                                        m_strIR00Code = (CType(cnode.SelectSingleNode("IR00"), XmlElement).GetAttribute("ID").ToString)
                                        m_strCode2 = (CType(cnode.SelectSingleNode("Status"), XmlElement).GetAttribute("Code").ToString)
                                        m_strDesc = (CType(cnode.SelectSingleNode("Status"), XmlElement).GetAttribute("Desc").ToString)
                                        m_strDesc2 = (CType(cnode.SelectSingleNode("Status"), XmlElement).InnerText.ToString)
                                        m_strDocType = "null"
                                        If cnode.SelectSingleNode("DocType") IsNot Nothing Then
                                            m_strDocType = (CType(cnode.SelectSingleNode("DocType"), XmlElement).GetAttribute("Code").ToString)
                                        End If
                                        m_strPage = (CType(cnode.SelectSingleNode("Page"), XmlElement).InnerText.ToString)
                                        m_strURL = ""
                                        If Not IsNothing(CType(cnode.SelectSingleNode("URL"), XmlElement)) Then
                                            m_strURL = (CType(cnode.SelectSingleNode("URL"), XmlElement).InnerText.ToString)
                                        End If
                                        TransCert = ""
                                        If Not IsNothing(CType(cnode.SelectSingleNode("TransCert"), XmlElement)) Then
                                            TransCert = (CType(cnode.SelectSingleNode("TransCert"), XmlElement).InnerText.ToString)
                                        End If
                                        m_strGUID = ""
                                        If Not IsNothing(CType(cnode.SelectSingleNode("GUID"), XmlElement)) Then
                                            m_strGUID = (CType(cnode.SelectSingleNode("GUID"), XmlElement).InnerText.ToString)
                                        End If

                                        If m_strCode2 = "R" Then '�e�󥢱�/���s����

                                            If m_strDocType = "null" Then
                                                sqlUpdate = " UPDATE " &
                                                                    p_strTableName & "Doc WITH (ROWLOCK) " &
                                                            " SET " &
                                                                    " SSTATUS = '" & m_strCode2 & "' " &
                                                                    ",SUBJECT = '" & m_strDesc & "' " &
                                                                    ",ASUBJECT = '" & m_strDesc2 & "' " &
                                                                    ",QueryStatus = '2' " &
                                                                    ",LastUpdateDate = GETDATE() " &
                                                            " WHERE " &
                                                                    " LoanKey = '" & m_strLoanKey & "' " &
                                                            " AND " &
                                                                     " House_AdmDataUkey = '" & m_strUKey & "' " &'" QueryKey = '" & m_strUKey & "' " &
                                                            " AND " &
                                                                    " IR00Code = '" & m_strIR00Code & "' "
                                                m_comd = moDB_ELOAN.GetSqlStringCommand(sqlUpdate)
                                                moDB_ELOAN.ExecuteNonQuery(m_comd)

                                            Else
                                                sqlUpdate = " UPDATE " &
                                                                    p_strTableName & "Doc WITH (ROWLOCK) " &
                                                            " SET " &
                                                                    " SSTATUS = '" & m_strCode2 & "' " &
                                                                    ",SUBJECT = '" & m_strDesc & "' " &
                                                                    ",ASUBJECT = '" & m_strDesc2 & "' " &
                                                                    ",QueryStatus = '2' " &
                                                                    ",LastUpdateDate = GETDATE() " &
                                                            " WHERE " &
                                                                    " LoanKey = '" & m_strLoanKey & "' " &
                                                            " AND " &
                                                                     " House_AdmDataUkey = '" & m_strUKey & "' " &'" QueryKey = '" & m_strUKey & "' " &
                                                            " AND " &
                                                                    " DocType = '" & m_strDocType & "' " &
                                                            " AND " &
                                                                    " IR00Code = '" & m_strIR00Code & "' "

                                                m_comd = moDB_ELOAN.GetSqlStringCommand(sqlUpdate)
                                                moDB_ELOAN.ExecuteNonQuery(m_comd)
                                            End If

                                        ElseIf m_strCode2 = "D" Or m_strCode2 = "E" Then '�w�U��  �w�s�b

                                            sqlUpdate = " UPDATE " &
                                                                p_strTableName & "Doc WITH (ROWLOCK) " &
                                                        " SET " &
                                                                " Page = '" & m_strPage & "' " &
                                                                ",DocPath = '" & m_strURL & "' " &
                                                                ",GUID = '" & m_strGUID & "' " &
                                                                ",TransCert = '" & TransCert & "' " &
                                                                ",SSTATUS = '" & m_strCode2 & "' " &
                                                                ",SUBJECT = '" & m_strDesc & "' " &
                                                                ",ASUBJECT = '" & m_strDesc2 & "' " &
                                                                ",QueryStatus = '2' " &
                                                                ",LastUpdateDate = GETDATE() " &
                                                        " WHERE " &
                                                                " LoanKey = '" & m_strLoanKey & "' " &
                                                        " AND " &
                                                                 " House_AdmDataUkey = '" & m_strUKey & "' " &'" QueryKey = '" & m_strUKey & "' " &
                                                        " AND " &
                                                                " DocType = '" & m_strDocType & "' " &
                                                        " AND " &
                                                                " IR00Code = '" & m_strIR00Code & "' "

                                            m_comd = moDB_ELOAN.GetSqlStringCommand(sqlUpdate)
                                            moDB_ELOAN.ExecuteNonQuery(m_comd)

                                        Else
                                            sqlUpdate = " UPDATE " &
                                                                p_strTableName & "Doc WITH (ROWLOCK) " &
                                                        " SET " &
                                                                " SSTATUS = '" & m_strCode2 & "' " &
                                                                ",SUBJECT = '" & m_strDesc & "' " &
                                                                ",ASUBJECT = '" & m_strDesc2 & "' " &
                                                                ",LastUpdateDate = GETDATE() " &
                                                        " WHERE " &
                                                                " LoanKey = '" & m_strLoanKey & "' " &
                                                        " AND " &
                                                                 " House_AdmDataUkey = '" & m_strUKey & "' " &'" QueryKey = '" & m_strUKey & "' " &
                                                        " AND " &
                                                                " DocType = '" & m_strDocType & "' " &
                                                        " AND " &
                                                                " IR00Code = '" & m_strIR00Code & "' "

                                            m_comd = moDB_ELOAN.GetSqlStringCommand(sqlUpdate)
                                            moDB_ELOAN.ExecuteNonQuery(m_comd)

                                        End If

                                    End If

                                Next

                                sqlSelect = " SELECT " &
                                                    " UKey " &
                                            " FROM " &
                                                    p_strTableName & "Doc (NOLOCK) " &
                                            " WHERE " &
                                                    " LoanKey = '" & m_strLoanKey & "' " &
                                            " AND " &
                                                     " House_AdmDataUkey = '" & m_strUKey & "' " &'" QueryKey = '" & m_strUKey & "' " &
                                            " AND " &
                                                    " QueryStatus = '0' "
                                m_comd = moDB_ELOAN.GetSqlStringCommand(sqlSelect)
                                m_ds = moDB_ELOAN.ExecuteDataSet(m_comd)

                                m_dt3 = m_ds.Tables(0)

                                If m_dt3 IsNot Nothing AndAlso m_dt3.Rows.Count > 0 Then
                                    sqlUpdate = " UPDATE " &
                                                        p_strTableName & " WITH (ROWLOCK) " &
                                                " SET " &
                                                        " ResultMsgNo = '" & m_strCode & "' " &
                                                        ",ResultMsg = '" & m_strMsg & "' " &
                                                        ",ResultXml = '" & m_strRetMsg & "' " &
                                                        ",LastUpdateDate = GETDATE() " &
                                                " WHERE " &
                                                        " LoanKey = '" & m_strLoanKey & "' " &
                                                " AND " &
                                                        " UKey = '" & m_strUKey & "' "
                                    m_comd = moDB_ELOAN.GetSqlStringCommand(sqlUpdate)
                                    moDB_ELOAN.ExecuteNonQuery(m_comd)
                                Else
                                    sqlUpdate = " UPDATE " &
                                                        p_strTableName & " WITH (ROWLOCK) " &
                                                " SET " &
                                                        " QueryStatus = '2' " &
                                                        ",ResultMsgNo = '" & m_strCode & "' " &
                                                        ",ResultMsg = '" & m_strMsg & "' " &
                                                        ",ResultXml = '" & m_strRetMsg & "' " &
                                                        ",LastUpdateDate = GETDATE() " &
                                                " WHERE " &
                                                        " LoanKey = '" & m_strLoanKey & "' " &
                                                " AND " &
                                                        " UKey = '" & m_strUKey & "' "
                                    m_comd = moDB_ELOAN.GetSqlStringCommand(sqlUpdate)
                                    moDB_ELOAN.ExecuteNonQuery(m_comd)
                                End If
                                g_writeLog.WriteErrorLog("[QueryStatus]=2")
                            Case Else
                                '-20   �W�L�̤j�s�u�ƶq,�еy��A����
                                '-5    �d�߱��󤣥i���ŭȩάOnull
                                '-4    ���ݰe��,�еy��A�d��
                                '-3    �d�L�ŦX���å��ӻ���
                                '-2    Ū���å��ӻ��Ƶo�Ϳ��~: ���ѭ�]
                                '-1    Ū���å��ӻ��Ƶo�Ϳ��~
                                sqlUpdate = " UPDATE " &
                                                    p_strTableName & " WITH (ROWLOCK) " &
                                            " SET " &
                                                    " ResultMsgNo = '" & m_strCode & "' " &
                                                    ",ResultMsg = '" & m_strMsg & "' " &
                                                    ",ResultXml = '" & m_strRetMsg & "' " &
                                                    ",LastUpdateDate = GETDATE() " &
                                            " WHERE " &
                                                    " LoanKey = '" & m_strLoanKey & "' " &
                                            " AND " &
                                                    " UKey = '" & m_strUKey & "' "
                                m_comd = moDB_ELOAN.GetSqlStringCommand(sqlUpdate)
                                moDB_ELOAN.ExecuteNonQuery(m_comd)
                        End Select
                    Catch ex As Exception
                        If Not (Date.Now.ToString("HHmm") >= "0350" And Date.Now.ToString("HHmm") <= "0700") Then
                            g_writeLog.WriteErrorLog("eLoanAdm GetADMData(2) Error : " & ex.Message)
                        End If
                    Finally
                        If m_comd IsNot Nothing Then
                            m_comd.Dispose()
                            m_comd = Nothing
                        End If
                    End Try
                Next
            End If

        Catch ex As Exception
            If Not (Date.Now.ToString("HHmm") >= "0350" And Date.Now.ToString("HHmm") <= "0700") Then
                g_writeLog.WriteErrorLog("eLoanAdm GetADMData(1) Error : " & ex.Message)
            End If
        Finally
            If m_dt IsNot Nothing Then
                m_dt.Dispose()
                m_dt = Nothing
            End If

            If m_comd IsNot Nothing Then
                m_comd.Dispose()
                m_comd = Nothing
            End If

            If m_GetData IsNot Nothing Then
                m_GetData.Dispose()
                m_GetData = Nothing
            End If
        End Try

    End Sub

    Private Sub ParserData(ByVal p_strTableName As String)
        '�s�u��Ʈw
        Dim moDB_eloan As Database = DBUtil.GetDB(g_strConnString_eloan)
        Dim moDB_Adm As Database = DBUtil.GetDB(g_strConnString_IMP_Adm)
        Dim sqlSelect As String = ""
        Dim sqlInsert As String = ""
        Dim sqlUpdate As String = ""
        Dim sqlDelete As String = ""
        Dim m_comd As SqlCommand = Nothing
        Dim m_strParse_Table_BuildREG() As String = {"BuildREG",
                                                "BuildREG_BTCLOR",
                                                "BuildREG_BTCLOR_BTTOGHC",
                                                "BuildREG_BTCLOR_TargetRegisterOrder",
                                                "BuildREG_BTEBOW",
                                                "BuildREG_BTEBOW_ORRegisterOrder",
                                                "BuildREG_BTEBOW_OtherRegister",
                                                "BuildREG_BTOD31",
                                                "BuildREG_BTOD31_ParkInfo",
                                                "BuildREG_BuildLocation",
                                                "BuildREG_FloorInfo",
                                                "BuildREG_OtherRegister"}
        Dim m_strParse_Table_LandREG() As String = {"LandREG",
                                                "LandREG_BTBLOW",
                                                "LandREG_BTBLOW_BTPRCE",
                                                "LandREG_BTBLOW_ORRegisterOrder",
                                                "LandREG_BTBLOW_OtherRegister",
                                                "LandREG_BTCLOR",
                                                "LandREG_BTCLOR_BTTOGHC",
                                                "LandREG_BTCLOR_OtherRegister",
                                                "LandREG_BTCLOR_TargetRegisterOrder",
                                                "LandREG_OtherRegister"}
        Dim m_strBuildREG_Uid As String = Nothing,
            m_strBTEBOW_Uid As String = Nothing,
            m_strBuildLocation_Uid As String = Nothing,
            m_strFloorInfo_Uid As String = Nothing,
            m_strBTOD31_Uid As String = Nothing,
            m_strBTCLOR_Uid As String = Nothing,
            m_strBTTOGHC_Uid As String = Nothing,
            m_strParkInfo_Uid As String = Nothing,
            m_strOtherRegister_Uid As String = Nothing,
            m_strORRegisterOrder_Uid As String = Nothing
        Dim m_strLandREG_Uid As String = Nothing,
            m_strBTBLOW_Uid As String = Nothing,
            m_strBTPRCE_Uid As String = Nothing,
            m_strBTCLOR_Uid2 As String = Nothing,
            m_strBTTOGHC_Uid2 As String = Nothing,
            m_strORRegisterOrder_Uid2 As String = Nothing
        Dim m_strUKey As String = Nothing,
            m_strLoanKey As String = Nothing,
            m_strDocUkey As String = Nothing,
            m_strDataSort As String = Nothing,
            m_strEmpRole As String = Nothing,
            m_strEmpID As String = Nothing,
            m_strBranchID As String = Nothing
        Dim m_dt As DataTable = Nothing
        Dim m_dt2 As DataTable = Nothing
        Dim m_dt3 As DataTable = Nothing
        Dim m_GetData As EDOCServiceService = Nothing
        Dim m_strRet As String = Nothing

        sqlSelect = " SELECT " &
                            " UKey " &
                            ",LoanKey " &
                            ",DataSort " &
                            ",CreateRoleNo " &
                            ",CreateEmpNo " &
                            ",CreateBranchNo " &
                    " FROM " &
                            p_strTableName & " (NOLOCK) " &
                    " WHERE " &
                            " QueryStatus = '2' " &
                    " AND " &
                            " ParseStatus = '0' "
        Dim m_ds As DataSet
        Try
            m_comd = moDB_eloan.GetSqlStringCommand(sqlSelect)

            m_ds = moDB_eloan.ExecuteDataSet(m_comd)
            m_dt = m_ds.Tables(0)

            If m_dt IsNot Nothing AndAlso m_dt.Rows.Count > 0 Then
                Dim m_objXML As New XmlDocument

                m_GetData = New EDOCServiceService
                m_GetData.Url = g_strAPI_EDOCService
                Dim m_nodeRespMsg, m_nodeEDOCData, m_cnode, m_ncode, m_ncode2, m_ncode3, m_nodeCoordinates As XmlNode
                Dim m_strCode, m_strCityID, m_strCityName, m_strAreaID, m_strAreaName, m_strSectionID, m_strSectionName As String
                Dim m_strBuildNo, m_strRegisterReasonDate, m_strRegisterReason, m_strTotalAreaSize, m_strAddress, m_strPurposeID, m_strPurpose As String
                Dim m_strMaterialID, m_strMaterial, m_strBuildLevel, m_strFinishDate As String
                Dim m_strBuildLocation_SectionID, m_strSection, m_strLandNo As String
                Dim m_strBuildTypeType, m_strBuildType, m_strPurposeID2, m_strPurpose2, m_strAreaSize As String
                Dim m_strMainBuildNoSectionID, m_strMainBuildNo, m_strCommonUseBuildNoSectionID, m_strCommonUseBuildNo, m_strRightsRange_Denominator2, m_strRightsRange_Numerator2 As String
                Dim m_strParkNum, m_strRightsRange_Denominator3, m_strRightsRange_Numerator3 As String
                Dim m_strOtherRegisterID, m_strOtherRegister, m_strRegisterOrder, m_strORRegisterOrder As String
                Dim m_strRegisterReasonDate2, m_strHRegisterReasonDate, m_strRegisterReason2, m_strOwnerID, m_strOwner, m_strOwnerAddress, m_strRightsRange_RightsReason, m_strRightsRange_Denominator, m_strRightsRange_Numerator As String
                Dim m_strB16, m_strRegisterOrderOrder, m_strReceiveNumber, m_strRegisterReasonDate3, m_strRegisterReason3, m_strObligeeID, m_strObligee, m_strObligeeAddress As String
                Dim m_strRightsValueRange_Denominator, m_strRightsValueRange_Numerator, m_strRightsTargetTypeID, m_strRightsTargetType, m_strExistPeriod_Start, m_strExistPeriod_End As String
                Dim m_strTargetRegisterOrder_Uid, m_strTargetRegisterOrder As String
                Dim m_strSectionID2, m_strSectionName2, m_strLandNo2, m_strBuildNo2 As String
                Dim m_strC16, m_strDebtor, m_strSetObligor, m_strRightsTypeID, m_strRightsType, m_strRightsValueType_type, m_strRightsValueType As String
                Dim m_strRightsValue, m_strRightsKind, m_strDischargeDate, m_strInterest, m_strDelayInterest, m_strPenalty, m_strRightsDate, m_strRightsOtherKind As String
                Dim m_strRightsQuota, m_strRightsPromise, m_strOutLineID, m_strOutLine, m_strUseTypeID, m_strUseType As String
                Dim m_strUseAreaID, m_strUseArea, m_strPublicValueDate, m_strPublicValue, m_strRegisterReasonHDate As String
                Dim m_strLastDate, m_strLastValue, m_strDenominator, m_strNumerator, m_strDeclaredValueDate, m_strDeclaredValue As String
                Dim m_strRegisterOrderOrder2, m_strRegisterOrder2, m_strPOI_X, m_strPOI_Y, m_strEMAP As String

                For i As Integer = 0 To m_dt.Rows.Count - 1

                    m_strUKey = m_dt.Rows(i)("UKey").ToString
                    m_strLoanKey = m_dt.Rows(i)("LoanKey").ToString
                    m_strDataSort = m_dt.Rows(i)("DataSort").ToString
                    m_strEmpRole = m_dt.Rows(i)("CreateRoleNo").ToString
                    m_strEmpID = m_dt.Rows(i)("CreateEmpNo").ToString
                    m_strBranchID = m_dt.Rows(i)("CreateBranchNo").ToString

                    sqlSelect = " SELECT " &
                                        " UKey " &
                                        ",DocType " &
                                        ",IR00Code " &
                                        ",GUID " &
                                " FROM " &
                                        p_strTableName & "Doc (NOLOCK) " &
                                " WHERE " &
                                        " LoanKey = '" & m_strLoanKey & "' " &
                                " AND " &
                                        " House_AdmDataUkey = '" & m_strUKey & "' " &'" QueryKey = '" & m_strUKey & "' " &
                                " AND " &
                                        " DocType = 'REG' " &
                                " AND " &
                                " ( " &
                                        " SStatus = 'D' " &
                                " OR " &
                                        " SSTatus = 'E' " &
                                " ) " &
                                " AND " &
                                        " QueryStatus = '2' " &
                                " AND " &
                                        " ParseStatus = '0' "

                    Try
                        m_comd = moDB_eloan.GetSqlStringCommand(sqlSelect)
                        m_ds = moDB_eloan.ExecuteDataSet(m_comd)
                        m_dt2 = m_ds.Tables(0)

                        If m_dt2 IsNot Nothing AndAlso m_dt2.Rows.Count > 0 Then

                            For j As Integer = 0 To m_dt2.Rows.Count - 1
                                m_strDocUkey = m_dt2.Rows(j)("UKey").ToString
                                g_writeLog.WriteErrorLog("****[Table]=" & p_strTableName & ",[LoanKey]=" & m_strLoanKey & ",[QueryUkey]=" & m_strUKey & ",[DocUkey]=m_strDocUkey***")
                                m_strRet = ""
                                m_strRet = m_GetData.exportEDOCData(m_dt2.Rows(j)("GUID").ToString)

                                m_objXML.LoadXml(m_strRet)

                                m_nodeRespMsg = m_objXML.DocumentElement.SelectSingleNode("RespMsg")
                                m_strCode = m_nodeRespMsg.Attributes("Code").InnerText
                                If m_strCode = "0" Then
                                    'Delete
                                    For k As Integer = 0 To UBound(m_strParse_Table_BuildREG)
                                        sqlDelete = " DELETE FROM " &
                                                            m_strParse_Table_BuildREG(k) & " WITH (ROWLOCK) " &
                                                    " WHERE " &
                                                            " LoanKey = '" & m_strLoanKey & "' " &
                                                    " AND " &
                                                            " QueryUkey = '" & m_strUKey & "' " &
                                                    " AND " &
                                                            " DocUkey = '" & m_strDocUkey & "' "
                                        m_comd = moDB_Adm.GetSqlStringCommand(sqlDelete)
                                        moDB_Adm.ExecuteNonQuery(m_comd)
                                    Next

                                    For k As Integer = 0 To UBound(m_strParse_Table_LandREG)
                                        sqlDelete = " DELETE FROM " &
                                                            m_strParse_Table_LandREG(k) & " WITH (ROWLOCK) " &
                                                    " WHERE " &
                                                            " LoanKey = '" & m_strLoanKey & "' " &
                                                    " AND " &
                                                            " QueryUkey = '" & m_strUKey & "' " &
                                                    " AND " &
                                                            " DocUkey = '" & m_strDocUkey & "' "
                                        m_comd = moDB_Adm.GetSqlStringCommand(sqlDelete)
                                        moDB_Adm.ExecuteNonQuery(m_comd)

                                    Next

                                    Select Case m_dt2.Rows(j)("DocType")
                                        Case "REG"

                                            m_nodeEDOCData = m_objXML.DocumentElement.SelectSingleNode("EDOCData")

                                            For k As Integer = 0 To m_nodeEDOCData.ChildNodes.Count - 1

                                                m_cnode = m_nodeEDOCData.ChildNodes.Item(k)

                                                Select Case m_cnode.Name
                                                    Case "BuildREG"

                                                        m_strBuildREG_Uid = Guid.NewGuid.ToString

                                                        m_strCityID = m_cnode.SelectSingleNode("City").Attributes("ID").InnerText
                                                        m_strCityName = m_cnode.SelectSingleNode("City").InnerText
                                                        m_strAreaID = m_cnode.SelectSingleNode("Area").Attributes("ID").InnerText
                                                        m_strAreaName = m_cnode.SelectSingleNode("Area").InnerText
                                                        m_strSectionID = m_cnode.SelectSingleNode("Section").Attributes("ID").InnerText
                                                        m_strSectionName = m_cnode.SelectSingleNode("Section").InnerText
                                                        m_strBuildNo = m_cnode.SelectSingleNode("BuildNo").InnerText
                                                        m_strRegisterReasonDate = m_cnode.SelectSingleNode("RegisterReason").Attributes("Date").InnerText
                                                        m_strRegisterReason = m_cnode.SelectSingleNode("RegisterReason").InnerText
                                                        m_strTotalAreaSize = m_cnode.SelectSingleNode("TotalAreaSize").InnerText
                                                        m_strAddress = m_cnode.SelectSingleNode("Address").InnerText
                                                        m_strPurposeID = ""
                                                        m_strPurpose = ""
                                                        If Not IsNothing(m_cnode.SelectSingleNode("Purpose")) Then
                                                            m_strPurposeID = m_cnode.SelectSingleNode("Purpose").Attributes("ID").InnerText
                                                            m_strPurpose = m_cnode.SelectSingleNode("Purpose").InnerText
                                                        End If
                                                        m_strMaterialID = m_cnode.SelectSingleNode("Material").Attributes("ID").InnerText
                                                        m_strMaterial = m_cnode.SelectSingleNode("Material").InnerText
                                                        m_strBuildLevel = m_cnode.SelectSingleNode("BuildLevel").InnerText
                                                        m_strFinishDate = m_cnode.SelectSingleNode("FinishDate").InnerText

                                                        sqlInsert = " INSERT INTO " &
                                                                            " BuildREG " &
                                                                    " VALUES " &
                                                                    " ( " &
                                                                            " '" & m_strBuildREG_Uid & "' " &
                                                                            ",'" & m_strLoanKey & "' " &
                                                                            ",'" & m_strUKey & "' " &
                                                                            ",'" & m_strDocUkey & "' " &
                                                                            ",'" & m_strCityID & "' " &
                                                                            ",'" & m_strCityName & "' " &
                                                                            ",'" & m_strAreaID & "' " &
                                                                            ",'" & m_strAreaName & "' " &
                                                                            ",'" & m_strSectionID & "' " &
                                                                            ",'" & m_strSectionName & "' " &
                                                                            ",'" & m_strBuildNo & "' " &
                                                                            ",'" & m_strRegisterReasonDate & "' " &
                                                                            ",'" & m_strRegisterReason & "' " &
                                                                            ",'" & m_strTotalAreaSize & "' " &
                                                                            ",'" & m_strAddress & "' " &
                                                                            ",'" & m_strPurposeID & "' " &
                                                                            ",'" & m_strPurpose & "' " &
                                                                            ",'" & m_strMaterialID & "' " &
                                                                            ",'" & m_strMaterial & "' " &
                                                                            ",'" & m_strBuildLevel & "' " &
                                                                            ",'" & m_strFinishDate & "' " &
                                                                            ",'" & m_strDataSort & "' " &
                                                                            ",'" & m_strEmpRole & "' " &
                                                                            ",'" & m_strEmpID & "' " &
                                                                            ",'" & m_strBranchID & "' " &
                                                                            ",DATEADD(SECOND, " & k & ", GETDATE()) " &
                                                                    " ) "
                                                        m_comd = moDB_Adm.GetSqlStringCommand(sqlInsert)
                                                        moDB_Adm.ExecuteNonQuery(m_comd)
                                                        For l As Integer = 0 To m_cnode.ChildNodes.Count - 1

                                                            m_ncode = m_cnode.ChildNodes.Item(l)

                                                            Select Case m_ncode.Name
                                                                Case "BuildLocation"
                                                                    m_strBuildLocation_SectionID = m_ncode.SelectSingleNode("Section").Attributes("ID").InnerText
                                                                    m_strSection = m_ncode.SelectSingleNode("Section").InnerText
                                                                    m_strLandNo = m_ncode.SelectSingleNode("LandNo").InnerText

                                                                    m_strBuildLocation_Uid = Guid.NewGuid.ToString

                                                                    sqlInsert = " INSERT INTO " &
                                                                                        " BuildREG_BuildLocation " &
                                                                                " VALUES " &
                                                                                " ( " &
                                                                                        " '" & m_strBuildLocation_Uid & "' " &
                                                                                        ",'" & m_strLoanKey & "' " &
                                                                                        ",'" & m_strUKey & "' " &
                                                                                        ",'" & m_strDocUkey & "' " &
                                                                                        ",'" & m_strBuildREG_Uid & "' " &
                                                                                        ",'" & m_strBuildLocation_SectionID & "' " &
                                                                                        ",'" & m_strSection & "' " &
                                                                                        ",'" & m_strLandNo & "' " &
                                                                                        ",'" & m_strDataSort & "' " &
                                                                                        ",'" & m_strEmpRole & "' " &
                                                                                        ",'" & m_strEmpID & "' " &
                                                                                        ",'" & m_strBranchID & "' " &
                                                                                        ",DATEADD(SECOND, " & l & ", GETDATE()) " &
                                                                                " ) "
                                                                    m_comd = moDB_Adm.GetSqlStringCommand(sqlInsert)
                                                                    moDB_Adm.ExecuteNonQuery(m_comd)

                                                                Case "FloorInfo"

                                                                    m_strFloorInfo_Uid = Guid.NewGuid.ToString

                                                                    m_strBuildTypeType = m_ncode.SelectSingleNode("BuildType").Attributes("Type").InnerText
                                                                    m_strBuildType = m_ncode.SelectSingleNode("BuildType").InnerText
                                                                    m_strPurposeID2 = m_ncode.SelectSingleNode("Purpose").Attributes("ID").InnerText
                                                                    m_strPurpose2 = m_ncode.SelectSingleNode("Purpose").InnerText
                                                                    m_strAreaSize = m_ncode.SelectSingleNode("AreaSize").InnerText

                                                                    sqlInsert = " INSERT INTO  " &
                                                                                        " BuildREG_FloorInfo " &
                                                                                " VALUES " &
                                                                                " ( " &
                                                                                        " '" & m_strFloorInfo_Uid & "' " &
                                                                                        ",'" & m_strLoanKey & "' " &
                                                                                        ",'" & m_strUKey & "' " &
                                                                                        ",'" & m_strDocUkey & "' " &
                                                                                        ",'" & m_strBuildREG_Uid & "' " &
                                                                                        ",'" & m_strBuildTypeType & "' " &
                                                                                        ",'" & m_strBuildType & "' " &
                                                                                        ",'" & m_strPurposeID2 & "' " &
                                                                                        ",'" & m_strPurpose2 & "' " &
                                                                                        ",'" & m_strAreaSize & "' " &
                                                                                        ",'" & m_strDataSort & "' " &
                                                                                        ",'" & m_strEmpRole & "' " &
                                                                                        ",'" & m_strEmpID & "' " &
                                                                                        ",'" & m_strBranchID & "' " &
                                                                                        ",DATEADD(SECOND, " & l & ", GETDATE()) " &
                                                                                " ) "
                                                                    m_comd = moDB_Adm.GetSqlStringCommand(sqlInsert)
                                                                    moDB_Adm.ExecuteNonQuery(m_comd)

                                                                Case "BTOD31"

                                                                    m_strBTOD31_Uid = Guid.NewGuid.ToString

                                                                    m_strMainBuildNoSectionID = m_ncode.SelectSingleNode("MainBuildNo").Attributes("SectionID").InnerText
                                                                    m_strMainBuildNo = m_ncode.SelectSingleNode("MainBuildNo").InnerText
                                                                    m_strCommonUseBuildNoSectionID = m_ncode.SelectSingleNode("CommonUseBuildNo").Attributes("SectionID").InnerText
                                                                    m_strCommonUseBuildNo = m_ncode.SelectSingleNode("CommonUseBuildNo").InnerText
                                                                    m_strAreaSize = m_ncode.SelectSingleNode("AreaSize").InnerText
                                                                    m_strRightsRange_Denominator2 = ""
                                                                    m_strRightsRange_Numerator2 = ""

                                                                    For m As Integer = 0 To m_ncode.ChildNodes.Count - 1

                                                                        m_ncode2 = m_ncode.ChildNodes.Item(m)

                                                                        Select Case m_ncode2.Name
                                                                            Case "RightsRange"
                                                                                m_strRightsRange_Denominator2 = m_ncode2.SelectSingleNode("Denominator").InnerText
                                                                                m_strRightsRange_Numerator2 = m_ncode2.SelectSingleNode("Numerator").InnerText
                                                                            Case "ParkInfo"

                                                                                m_strParkInfo_Uid = Guid.NewGuid.ToString

                                                                                m_strParkNum = m_ncode2.SelectSingleNode("ParkNum").InnerText
                                                                                m_strRightsRange_Denominator3 = ""
                                                                                m_strRightsRange_Numerator3 = ""

                                                                                For n As Integer = 0 To m_ncode2.ChildNodes.Count - 1

                                                                                    m_ncode3 = m_ncode2.ChildNodes.Item(n)

                                                                                    If m_ncode3.Name = "RightsRange" Then

                                                                                        m_strRightsRange_Denominator3 = m_ncode3.SelectSingleNode("Denominator").InnerText
                                                                                        m_strRightsRange_Numerator3 = m_ncode3.SelectSingleNode("Numerator").InnerText

                                                                                    End If

                                                                                Next

                                                                                sqlInsert = " INSERT INTO " &
                                                                                                    " BuildREG_BTOD31_ParkInfo " &
                                                                                            " VALUES " &
                                                                                            " ( " &
                                                                                                    " '" & m_strParkInfo_Uid & "' " &
                                                                                                    ",'" & m_strLoanKey & "' " &
                                                                                                    ",'" & m_strUKey & "' " &
                                                                                                    ",'" & m_strDocUkey & "' " &
                                                                                                    ",'" & m_strBuildREG_Uid & "' " &
                                                                                                    ",'" & m_strBTOD31_Uid & "' " &
                                                                                                    ",'" & m_strParkNum & "' " &
                                                                                                    ",'" & m_strRightsRange_Denominator3 & "' " &
                                                                                                    ",'" & m_strRightsRange_Numerator3 & "' " &
                                                                                                    ",'" & m_strDataSort & "' " &
                                                                                                    ",'" & m_strEmpRole & "' " &
                                                                                                    ",'" & m_strEmpID & "' " &
                                                                                                    ",'" & m_strBranchID & "' " &
                                                                                                    ",DATEADD(SECOND, " & m & ", GETDATE()) " &
                                                                                            " ) "
                                                                                m_comd = moDB_Adm.GetSqlStringCommand(sqlInsert)
                                                                                moDB_Adm.ExecuteNonQuery(m_comd)

                                                                        End Select
                                                                    Next

                                                                    sqlInsert = " INSERT INTO " &
                                                                                        " BuildREG_BTOD31 " &
                                                                                " VALUES " &
                                                                                " ( " &
                                                                                        " '" & m_strBTOD31_Uid & "' " &
                                                                                        ",'" & m_strLoanKey & "' " &
                                                                                        ",'" & m_strUKey & "' " &
                                                                                        ",'" & m_strDocUkey & "' " &
                                                                                        ",'" & m_strBuildREG_Uid & "' " &
                                                                                        ",'" & m_strMainBuildNoSectionID & "' " &
                                                                                        ",'" & m_strMainBuildNo & "' " &
                                                                                        ",'" & m_strCommonUseBuildNoSectionID & "' " &
                                                                                        ",'" & m_strCommonUseBuildNo & "' " &
                                                                                        ",'" & m_strAreaSize & "' " &
                                                                                        ",'" & m_strRightsRange_Denominator2 & "' " &
                                                                                        ",'" & m_strRightsRange_Numerator2 & "' " &
                                                                                        ",'" & m_strDataSort & "' " &
                                                                                        ",'" & m_strEmpRole & "' " &
                                                                                        ",'" & m_strEmpID & "' " &
                                                                                        ",'" & m_strBranchID & "' " &
                                                                                        ",DATEADD(SECOND, " & l & ", GETDATE()) " &
                                                                                " ) "
                                                                    m_comd = moDB_Adm.GetSqlStringCommand(sqlInsert)
                                                                    moDB_Adm.ExecuteNonQuery(m_comd)

                                                                Case "OtherRegister"

                                                                    m_strOtherRegister_Uid = Guid.NewGuid.ToString

                                                                    m_strOtherRegisterID = m_ncode.Attributes("ID").InnerText
                                                                    m_strOtherRegister = m_ncode.InnerText

                                                                    sqlInsert = " INSERT INTO " &
                                                                                        " BuildREG_OtherRegister " &
                                                                                " VALUES " &
                                                                                " ( " &
                                                                                        " '" & m_strOtherRegister_Uid & "' " &
                                                                                        ",'" & m_strLoanKey & "' " &
                                                                                        ",'" & m_strUKey & "' " &
                                                                                        ",'" & m_strDocUkey & "' " &
                                                                                        ",'" & m_strBuildREG_Uid & "' " &
                                                                                        ",'" & m_strOtherRegisterID & "' " &
                                                                                        ",'" & m_strOtherRegister & "' " &
                                                                                        ",'" & m_strDataSort & "' " &
                                                                                        ",'" & m_strEmpRole & "' " &
                                                                                        ",'" & m_strEmpID & "' " &
                                                                                        ",'" & m_strBranchID & "' " &
                                                                                        ",DATEADD(SECOND, " & l & ", GETDATE()) " &
                                                                                " ) "

                                                                    m_comd = moDB_Adm.GetSqlStringCommand(sqlInsert)
                                                                    moDB_Adm.ExecuteNonQuery(m_comd)
                                                                Case "BTEBOW"

                                                                    m_strBTEBOW_Uid = Guid.NewGuid.ToString
                                                                    m_strRegisterOrder = ""
                                                                    If Not IsNothing(m_ncode.SelectSingleNode("RegisterOrder")) Then
                                                                        m_strRegisterOrder = m_ncode.SelectSingleNode("RegisterOrder").InnerText
                                                                    End If

                                                                    m_strRegisterReasonDate2 = m_ncode.SelectSingleNode("RegisterReason").Attributes("Date").InnerText
                                                                    m_strHRegisterReasonDate = m_ncode.SelectSingleNode("RegisterReason").Attributes("HDate").InnerText.Replace("'", "''")
                                                                    m_strRegisterReason2 = m_ncode.SelectSingleNode("RegisterReason").InnerText
                                                                    m_strOwnerID = m_ncode.SelectSingleNode("Owner").Attributes("ID").InnerText
                                                                    m_strOwner = m_ncode.SelectSingleNode("Owner").InnerText
                                                                    m_strOwnerAddress = m_ncode.SelectSingleNode("OwnerAddress").InnerText
                                                                    m_strRightsRange_RightsReason = ""
                                                                    m_strRightsRange_Denominator = ""
                                                                    m_strRightsRange_Numerator = ""


                                                                    For m As Integer = 0 To m_ncode.ChildNodes.Count - 1

                                                                        m_ncode2 = m_ncode.ChildNodes.Item(m)

                                                                        Select Case m_ncode2.Name
                                                                            Case "RightsRange"
                                                                                If Not IsNothing(m_ncode2.SelectSingleNode("RightsReason")) Then
                                                                                    m_strRightsRange_RightsReason = m_ncode2.SelectSingleNode("RightsReason").InnerText
                                                                                End If

                                                                                m_strRightsRange_Denominator = m_ncode2.SelectSingleNode("Denominator").InnerText
                                                                                m_strRightsRange_Numerator = m_ncode2.SelectSingleNode("Numerator").InnerText
                                                                            Case "ORRegisterOrder"

                                                                                m_strORRegisterOrder_Uid = Guid.NewGuid.ToString

                                                                                m_strORRegisterOrder = m_ncode2.InnerText

                                                                                sqlInsert = " INSERT INTO " &
                                                                                                    " BuildREG_BTEBOW_ORRegisterOrder " &
                                                                                            " VALUES " &
                                                                                            " ( " &
                                                                                                    " '" & m_strORRegisterOrder_Uid & "' " &
                                                                                                    ",'" & m_strLoanKey & "' " &
                                                                                                    ",'" & m_strUKey & "' " &
                                                                                                    ",'" & m_strDocUkey & "' " &
                                                                                                    ",'" & m_strBuildREG_Uid & "' " &
                                                                                                    ",'" & m_strBTEBOW_Uid & "' " &
                                                                                                    ",'" & m_strORRegisterOrder & "' " &
                                                                                                    ",'" & m_strDataSort & "' " &
                                                                                                    ",'" & m_strEmpRole & "' " &
                                                                                                    ",'" & m_strEmpID & "' " &
                                                                                                    ",'" & m_strBranchID & "' " &
                                                                                                    ",DATEADD(SECOND, " & m & ", GETDATE()) " &
                                                                                            " ) "
                                                                                m_comd = moDB_Adm.GetSqlStringCommand(sqlInsert)
                                                                                moDB_Adm.ExecuteNonQuery(m_comd)

                                                                            Case "OtherRegister"

                                                                                m_strOtherRegister_Uid = Guid.NewGuid.ToString

                                                                                m_strOtherRegisterID = m_ncode2.Attributes("ID").InnerText
                                                                                m_strOtherRegister = m_ncode2.InnerText

                                                                                sqlInsert = " INSERT INTO " &
                                                                                                    " BuildREG_BTEBOW_OtherRegister " &
                                                                                            " VALUES " &
                                                                                            " ( " &
                                                                                                    " '" & m_strOtherRegister_Uid & "' " &
                                                                                                    ",'" & m_strLoanKey & "' " &
                                                                                                    ",'" & m_strUKey & "' " &
                                                                                                    ",'" & m_strDocUkey & "' " &
                                                                                                    ",'" & m_strBuildREG_Uid & "' " &
                                                                                                    ",'" & m_strBTEBOW_Uid & "' " &
                                                                                                    ",'" & m_strOtherRegisterID & "' " &
                                                                                                    ",'" & m_strOtherRegister & "' " &
                                                                                                    ",'" & m_strDataSort & "' " &
                                                                                                    ",'" & m_strEmpRole & "' " &
                                                                                                    ",'" & m_strEmpID & "' " &
                                                                                                    ",'" & m_strBranchID & "' " &
                                                                                                    ",DATEADD(SECOND, " & m & ", GETDATE()) " &
                                                                                            " ) "
                                                                                m_comd = moDB_Adm.GetSqlStringCommand(sqlInsert)
                                                                                moDB_Adm.ExecuteNonQuery(m_comd)

                                                                        End Select
                                                                    Next

                                                                    m_strB16 = m_ncode.SelectSingleNode("B16").InnerText

                                                                    sqlInsert = " INSERT INTO " &
                                                                                        " BuildREG_BTEBOW " &
                                                                                " VALUES " &
                                                                                " ( " &
                                                                                        " '" & m_strBTEBOW_Uid & "' " &
                                                                                        ",'" & m_strLoanKey & "' " &
                                                                                        ",'" & m_strUKey & "' " &
                                                                                        ",'" & m_strDocUkey & "' " &
                                                                                        ",'" & m_strBuildREG_Uid & "' " &
                                                                                        ",'" & m_strRegisterOrder & "' " &
                                                                                        ",'" & m_strRegisterReasonDate2 & "' " &
                                                                                        ",'" & m_strHRegisterReasonDate & "' " &
                                                                                        ",'" & m_strRegisterReason2 & "' " &
                                                                                        ",'" & m_strOwnerID & "' " &
                                                                                        ",'" & m_strOwner & "' " &
                                                                                        ",'" & m_strOwnerAddress.Replace("'", "''") & "' " &
                                                                                        ",'" & m_strRightsRange_RightsReason & "' " &
                                                                                        ",'" & m_strRightsRange_Denominator & "' " &
                                                                                        ",'" & m_strRightsRange_Numerator & "' " &
                                                                                        ",'" & m_strB16 & "' " &
                                                                                        ",'" & m_strDataSort & "' " &
                                                                                        ",'" & m_strEmpRole & "' " &
                                                                                        ",'" & m_strEmpID & "' " &
                                                                                        ",'" & m_strBranchID & "' " &
                                                                                        ",DATEADD(SECOND, " & l & ",GETDATE()) " &
                                                                                " ) "
                                                                    m_comd = moDB_Adm.GetSqlStringCommand(sqlInsert)
                                                                    moDB_Adm.ExecuteNonQuery(m_comd)

                                                                Case "BTCLOR"

                                                                    m_strBTCLOR_Uid = Guid.NewGuid.ToString

                                                                    m_strRegisterOrderOrder = m_ncode.SelectSingleNode("RegisterOrder").Attributes("Order").InnerText
                                                                    m_strRegisterOrder = m_ncode.SelectSingleNode("RegisterOrder").InnerText
                                                                    m_strReceiveNumber = m_ncode.SelectSingleNode("ReceiveNumber").InnerText
                                                                    m_strRegisterReasonDate3 = m_ncode.SelectSingleNode("RegisterReason").Attributes("Date").InnerText
                                                                    m_strRegisterReason3 = m_ncode.SelectSingleNode("RegisterReason").InnerText
                                                                    m_strObligeeID = m_ncode.SelectSingleNode("Obligee").Attributes("ID").InnerText
                                                                    m_strObligee = m_ncode.SelectSingleNode("Obligee").InnerText
                                                                    m_strObligeeAddress = ""
                                                                    If Not IsNothing(m_ncode.SelectSingleNode("ObligeeAddress")) Then
                                                                        m_strObligeeAddress = m_ncode.SelectSingleNode("ObligeeAddress").InnerText
                                                                    End If

                                                                    m_strRightsValueRange_Denominator = ""
                                                                    m_strRightsValueRange_Numerator = ""
                                                                    m_strRightsTargetTypeID = m_ncode.SelectSingleNode("RightsTargetType").Attributes("ID").InnerText
                                                                    m_strRightsTargetType = m_ncode.SelectSingleNode("RightsTargetType").InnerText
                                                                    m_strRightsRange_Denominator2 = ""
                                                                    m_strRightsRange_Numerator2 = ""
                                                                    m_strExistPeriod_Start = ""
                                                                    m_strExistPeriod_End = ""

                                                                    For m As Integer = 0 To m_ncode.ChildNodes.Count - 1

                                                                        m_ncode2 = m_ncode.ChildNodes.Item(m)

                                                                        Select Case m_ncode2.Name
                                                                            Case "RightsValueRange"

                                                                                m_strRightsValueRange_Denominator = m_ncode2.SelectSingleNode("Denominator").InnerText
                                                                                m_strRightsValueRange_Numerator = m_ncode2.SelectSingleNode("Numerator").InnerText

                                                                            Case "TargetRegisterOrder"

                                                                                m_strTargetRegisterOrder_Uid = Guid.NewGuid.ToString

                                                                                m_strTargetRegisterOrder = m_ncode2.InnerText

                                                                                sqlInsert = " INSERT INTO " &
                                                                                                    " BuildREG_BTCLOR_TargetRegisterOrder " &
                                                                                            " VALUES " &
                                                                                            " ( " &
                                                                                                    " '" & m_strTargetRegisterOrder_Uid & "' " &
                                                                                                    ",'" & m_strLoanKey & "' " &
                                                                                                    ",'" & m_strUKey & "' " &
                                                                                                    ",'" & m_strDocUkey & "' " &
                                                                                                    ",'" & m_strBuildREG_Uid & "' " &
                                                                                                    ",'" & m_strBTCLOR_Uid & "' " &
                                                                                                    ",'" & m_strTargetRegisterOrder & "' " &
                                                                                                    ",'" & m_strDataSort & "' " &
                                                                                                    ",'" & m_strEmpRole & "' " &
                                                                                                    ",'" & m_strEmpID & "' " &
                                                                                                    ",'" & m_strBranchID & "' " &
                                                                                                    ",DATEADD(SECOND, " & m & ", GETDATE()) " &
                                                                                            " ) "
                                                                                m_comd = moDB_Adm.GetSqlStringCommand(sqlInsert)
                                                                                moDB_Adm.ExecuteNonQuery(m_comd)

                                                                            Case "RightsRange"

                                                                                m_strRightsRange_Denominator2 = m_ncode2.SelectSingleNode("Denominator").InnerText
                                                                                m_strRightsRange_Numerator2 = m_ncode2.SelectSingleNode("Numerator").InnerText

                                                                            Case "ExistPeriod"

                                                                                m_strExistPeriod_Start = m_ncode2.SelectSingleNode("Start").InnerText
                                                                                m_strExistPeriod_End = m_ncode2.SelectSingleNode("End").InnerText

                                                                            Case "BTTOGHC"

                                                                                m_strBTTOGHC_Uid = Guid.NewGuid.ToString

                                                                                m_strSectionID2 = m_ncode2.SelectSingleNode("Section").Attributes("ID").InnerText
                                                                                m_strSectionName2 = m_ncode2.SelectSingleNode("Section").InnerText
                                                                                m_strLandNo2 = ""
                                                                                m_strBuildNo2 = ""
                                                                                If Not IsNothing(m_ncode2.SelectSingleNode("LandNo")) Then
                                                                                    m_strLandNo2 = m_ncode2.SelectSingleNode("LandNo").InnerText
                                                                                End If
                                                                                If Not IsNothing(m_ncode2.SelectSingleNode("BuildNo")) Then
                                                                                    m_strBuildNo2 = m_ncode2.SelectSingleNode("BuildNo").InnerText
                                                                                End If

                                                                                sqlInsert = " INSERT INTO " &
                                                                                                    " BuildREG_BTCLOR_BTTOGHC " &
                                                                                            " VALUES " &
                                                                                            " ( " &
                                                                                                    " '" & m_strBTTOGHC_Uid & "' " &
                                                                                                    ",'" & m_strLoanKey & "' " &
                                                                                                    ",'" & m_strUKey & "' " &
                                                                                                    ",'" & m_strDocUkey & "' " &
                                                                                                    ",'" & m_strBuildREG_Uid & "' " &
                                                                                                    ",'" & m_strBTCLOR_Uid & "' " &
                                                                                                    ",'" & m_strSectionID2 & "' " &
                                                                                                    ",'" & m_strSectionName2 & "' " &
                                                                                                    ",'" & m_strLandNo2 & "' " &
                                                                                                    ",'" & m_strBuildNo2 & "' " &
                                                                                                    ",'" & m_strDataSort & "' " &
                                                                                                    ",'" & m_strEmpRole & "' " &
                                                                                                    ",'" & m_strEmpID & "' " &
                                                                                                    ",'" & m_strBranchID & "' " &
                                                                                                    ",DATEADD(SECOND, " & m & ", GETDATE()) " &
                                                                                            " ) "
                                                                                m_comd = moDB_Adm.GetSqlStringCommand(sqlInsert)
                                                                                moDB_Adm.ExecuteNonQuery(m_comd)

                                                                        End Select

                                                                    Next

                                                                    m_strC16 = m_ncode.SelectSingleNode("C16").InnerText
                                                                    m_strDebtor = m_ncode.SelectSingleNode("Debtor").InnerText
                                                                    m_strSetObligor = m_ncode.SelectSingleNode("SetObligor").InnerText
                                                                    m_strRightsTypeID = m_ncode.SelectSingleNode("RightsType").Attributes("ID").InnerText
                                                                    m_strRightsType = m_ncode.SelectSingleNode("RightsType").InnerText
                                                                    m_strRightsValueType_type = m_ncode.SelectSingleNode("RightsValueType").Attributes("type").InnerText
                                                                    m_strRightsValueType = m_ncode.SelectSingleNode("RightsValueType").InnerText
                                                                    m_strRightsValue = m_ncode.SelectSingleNode("RightsValue").InnerText
                                                                    m_strRightsKind = m_ncode.SelectSingleNode("RightsKind").InnerText
                                                                    m_strDischargeDate = m_ncode.SelectSingleNode("DischargeDate").InnerText
                                                                    m_strInterest = m_ncode.SelectSingleNode("Interest").InnerText
                                                                    m_strDelayInterest = m_ncode.SelectSingleNode("DelayInterest").InnerText
                                                                    m_strPenalty = m_ncode.SelectSingleNode("Penalty").InnerText
                                                                    m_strRightsDate = m_ncode.SelectSingleNode("RightsDate").InnerText
                                                                    m_strRightsOtherKind = m_ncode.SelectSingleNode("RightsOtherKind").InnerText
                                                                    m_strRightsQuota = m_ncode.SelectSingleNode("RightsQuota").InnerText
                                                                    m_strRightsPromise = m_ncode.SelectSingleNode("RightsPromise").InnerText

                                                                    sqlInsert = " INSERT INTO " &
                                                                                        " BuildREG_BTCLOR " &
                                                                                " VALUES " &
                                                                                " ( " &
                                                                                        " '" & m_strBTCLOR_Uid & "' " &
                                                                                        ",'" & m_strLoanKey & "' " &
                                                                                        ",'" & m_strUKey & "' " &
                                                                                        ",'" & m_strDocUkey & "' " &
                                                                                        ",'" & m_strBuildREG_Uid & "' " &
                                                                                        ",'" & m_strRegisterOrderOrder & "' " &
                                                                                        ",'" & m_strRegisterOrder & "' " &
                                                                                        ",'" & m_strReceiveNumber & "' " &
                                                                                        ",'" & m_strRegisterReasonDate3 & "' " &
                                                                                        ",'" & m_strRegisterReason3 & "' " &
                                                                                        ",'" & m_strObligeeID & "' " &
                                                                                        ",'" & m_strObligee & "' " &
                                                                                        ",'" & m_strObligeeAddress & "' " &
                                                                                        ",'" & m_strRightsValueRange_Denominator & "' " &
                                                                                        ",'" & m_strRightsValueRange_Numerator & "' " &
                                                                                        ",'" & m_strRightsTargetTypeID & "' " &
                                                                                        ",'" & m_strRightsTargetType & "' " &
                                                                                        ",'" & m_strRightsRange_Denominator2 & "' " &
                                                                                        ",'" & m_strRightsRange_Numerator2 & "' " &
                                                                                        ",'" & m_strC16 & "' " &
                                                                                        ",'" & m_strDebtor & "' " &
                                                                                        ",'" & m_strSetObligor & "' " &
                                                                                        ",'" & m_strRightsTypeID & "' " &
                                                                                        ",'" & m_strRightsType & "' " &
                                                                                        ",'" & m_strRightsValueType_type & "' " &
                                                                                        ",'" & m_strRightsValueType & "' " &
                                                                                        ",'" & m_strRightsValue & "' " &
                                                                                        ",'" & m_strRightsKind & "' " &
                                                                                        ",'" & m_strExistPeriod_Start & "' " &
                                                                                        ",'" & m_strExistPeriod_End & "' " &
                                                                                        ",'" & m_strDischargeDate & "' " &
                                                                                        ",'" & m_strInterest & "' " &
                                                                                        ",'" & m_strDelayInterest & "' " &
                                                                                        ",'" & m_strPenalty & "' " &
                                                                                        ",'" & m_strRightsDate & "' " &
                                                                                        ",'" & m_strRightsOtherKind & "' " &
                                                                                        ",'" & m_strRightsQuota & "' " &
                                                                                        ",'" & m_strRightsPromise & "' " &
                                                                                        ",'" & m_strDataSort & "' " &
                                                                                        ",'" & m_strEmpRole & "' " &
                                                                                        ",'" & m_strEmpID & "' " &
                                                                                        ",'" & m_strBranchID & "' " &
                                                                                        ",DATEADD(SECOND, " & l & ", GETDATE()) " &
                                                                                " ) "
                                                                    m_comd = moDB_Adm.GetSqlStringCommand(sqlInsert)
                                                                    moDB_Adm.ExecuteNonQuery(m_comd)

                                                            End Select
                                                        Next

                                                    Case "LandREG"

                                                        m_strLandREG_Uid = Guid.NewGuid.ToString

                                                        m_strCityID = m_cnode.SelectSingleNode("City").Attributes("ID").InnerText
                                                        m_strCityName = m_cnode.SelectSingleNode("City").InnerText
                                                        m_strAreaID = m_cnode.SelectSingleNode("Area").Attributes("ID").InnerText
                                                        m_strAreaName = m_cnode.SelectSingleNode("Area").InnerText
                                                        m_strSectionID = m_cnode.SelectSingleNode("Section").Attributes("ID").InnerText
                                                        m_strSectionName = m_cnode.SelectSingleNode("Section").InnerText
                                                        m_strLandNo = m_cnode.SelectSingleNode("LandNo").InnerText
                                                        m_strRegisterReasonDate = m_cnode.SelectSingleNode("RegisterReason").Attributes("Date").InnerText
                                                        m_strRegisterReason = m_cnode.SelectSingleNode("RegisterReason").InnerText
                                                        m_strOutLineID = m_cnode.SelectSingleNode("OutLine").Attributes("ID").InnerText
                                                        m_strOutLine = m_cnode.SelectSingleNode("OutLine").InnerText
                                                        m_strUseTypeID = ""
                                                        m_strUseType = ""
                                                        m_strAreaSize = m_cnode.SelectSingleNode("AreaSize").InnerText
                                                        m_strUseAreaID = ""
                                                        m_strUseArea = ""

                                                        If Not IsNothing((CType(m_cnode.SelectSingleNode("UseType"), XmlElement))) Then
                                                            m_strUseTypeID = m_cnode.SelectSingleNode("UseType").Attributes("ID").InnerText
                                                            m_strUseType = m_cnode.SelectSingleNode("UseType").InnerText
                                                        End If

                                                        If Not IsNothing((CType(m_cnode.SelectSingleNode("UseArea"), XmlElement))) Then
                                                            m_strUseAreaID = m_cnode.SelectSingleNode("UseArea").Attributes("ID").InnerText
                                                            m_strUseArea = m_cnode.SelectSingleNode("UseArea").InnerText
                                                        End If

                                                        m_strPublicValueDate = m_cnode.SelectSingleNode("PublicValue").Attributes("Date").InnerText
                                                        m_strPublicValue = m_cnode.SelectSingleNode("PublicValue").InnerText

                                                        sqlInsert = " INSERT INTO " &
                                                                            " LandREG " &
                                                                    " VALUES " &
                                                                    " ( " &
                                                                            " '" & m_strLandREG_Uid & "' " &
                                                                            ",'" & m_strLoanKey & "' " &
                                                                            ",'" & m_strUKey & "' " &
                                                                            ",'" & m_strDocUkey & "' " &
                                                                            ",'" & m_strCityID & "' " &
                                                                            ",'" & m_strCityName & "' " &
                                                                            ",'" & m_strAreaID & "' " &
                                                                            ",'" & m_strAreaName & "' " &
                                                                            ",'" & m_strSectionID & "' " &
                                                                            ",'" & m_strSectionName & "' " &
                                                                            ",'" & m_strLandNo & "' " &
                                                                            ",'" & m_strRegisterReasonDate & "' " &
                                                                            ",'" & m_strRegisterReason & "' " &
                                                                            ",'" & m_strOutLineID & "' " &
                                                                            ",'" & m_strOutLine & "' " &
                                                                            ",'" & m_strUseTypeID & "' " &
                                                                            ",'" & m_strUseType & "' " &
                                                                            ",'" & m_strAreaSize & "' " &
                                                                            ",'" & m_strUseAreaID & "' " &
                                                                            ",'" & m_strUseArea & "' " &
                                                                            ",'" & m_strPublicValueDate & "' " &
                                                                            ",'" & m_strPublicValue & "' " &
                                                                            ",'" & m_strDataSort & "' " &
                                                                            ",'" & m_strEmpRole & "' " &
                                                                            ",'" & m_strEmpID & "' " &
                                                                            ",'" & m_strBranchID & "' " &
                                                                            ",DATEADD(SECOND, " & k & ", GETDATE()) " &
                                                                    " ) "
                                                        m_comd = moDB_Adm.GetSqlStringCommand(sqlInsert)
                                                        moDB_Adm.ExecuteNonQuery(m_comd)

                                                        For l As Integer = 0 To m_cnode.ChildNodes.Count - 1

                                                            m_ncode = m_cnode.ChildNodes.Item(l)

                                                            Select Case m_ncode.Name
                                                                Case "OtherRegister"

                                                                    m_strOtherRegister_Uid = Guid.NewGuid.ToString

                                                                    m_strOtherRegisterID = m_ncode.Attributes("ID").InnerText
                                                                    m_strOtherRegister = m_ncode.InnerText

                                                                    sqlInsert = " INSERT INTO " &
                                                                                        " LandREG_OtherRegister " &
                                                                                " VALUES " &
                                                                                " ( " &
                                                                                        " '" & m_strOtherRegister_Uid & "' " &
                                                                                        ",'" & m_strLoanKey & "' " &
                                                                                        ",'" & m_strUKey & "' " &
                                                                                        ",'" & m_strDocUkey & "' " &
                                                                                        ",'" & m_strLandREG_Uid & "' " &
                                                                                        ",'" & m_strOtherRegisterID & "' " &
                                                                                        ",'" & m_strOtherRegister & "' " &
                                                                                        ",'" & m_strDataSort & "' " &
                                                                                        ",'" & m_strEmpRole & "' " &
                                                                                        ",'" & m_strEmpID & "' " &
                                                                                        ",'" & m_strBranchID & "' " &
                                                                                        ",DATEADD(SECOND, " & l & ", GETDATE()) " &
                                                                                " ) "
                                                                    m_comd = moDB_Adm.GetSqlStringCommand(sqlInsert)
                                                                    moDB_Adm.ExecuteNonQuery(m_comd)

                                                                Case "BTBLOW"

                                                                    m_strBTBLOW_Uid = Guid.NewGuid.ToString

                                                                    m_strRegisterOrder = m_ncode.SelectSingleNode("RegisterOrder").InnerText
                                                                    m_strRegisterReasonDate2 = m_ncode.SelectSingleNode("RegisterReason").Attributes("Date").InnerText
                                                                    m_strRegisterReasonHDate = m_ncode.SelectSingleNode("RegisterReason").Attributes("HDate").InnerText.Replace("'", "''")
                                                                    m_strRegisterReason2 = m_ncode.SelectSingleNode("RegisterReason").InnerText
                                                                    m_strOwnerID = m_ncode.SelectSingleNode("Owner").Attributes("ID").InnerText
                                                                    m_strOwner = m_ncode.SelectSingleNode("Owner").InnerText
                                                                    m_strOwnerAddress = ""
                                                                    If Not IsNothing((CType(m_ncode.SelectSingleNode("OwnerAddress"), XmlElement))) Then
                                                                        m_strOwnerAddress = m_ncode.SelectSingleNode("OwnerAddress").InnerText
                                                                    End If
                                                                    m_strRightsRange_RightsReason = ""
                                                                    m_strRightsRange_Denominator = ""
                                                                    m_strRightsRange_Numerator = ""

                                                                    For m As Integer = 0 To m_ncode.ChildNodes.Count - 1

                                                                        m_ncode2 = m_ncode.ChildNodes.Item(m)

                                                                        Select Case m_ncode2.Name
                                                                            Case "RightsRange"

                                                                                m_strRightsRange_RightsReason = m_ncode2.SelectSingleNode("RightsReason").InnerText
                                                                                m_strRightsRange_Denominator = m_ncode2.SelectSingleNode("Denominator").InnerText
                                                                                m_strRightsRange_Numerator = m_ncode2.SelectSingleNode("Numerator").InnerText

                                                                            Case "ORRegisterOrder"

                                                                                m_strORRegisterOrder_Uid2 = Guid.NewGuid.ToString

                                                                                m_strORRegisterOrder = m_ncode2.InnerText

                                                                                sqlInsert = " INSERT INTO " &
                                                                                                    " LandREG_BTBLOW_ORRegisterOrder " &
                                                                                            " VALUES " &
                                                                                            " ( " &
                                                                                                    " '" & m_strORRegisterOrder_Uid2 & "' " &
                                                                                                    ",'" & m_strLoanKey & "' " &
                                                                                                    ",'" & m_strUKey & "' " &
                                                                                                    ",'" & m_strDocUkey & "' " &
                                                                                                    ",'" & m_strLandREG_Uid & "' " &
                                                                                                    ",'" & m_strBTBLOW_Uid & "' " &
                                                                                                    ",'" & m_strORRegisterOrder & "' " &
                                                                                                    ",'" & m_strDataSort & "' " &
                                                                                                    ",'" & m_strEmpRole & "' " &
                                                                                                    ",'" & m_strEmpID & "' " &
                                                                                                    ",'" & m_strBranchID & "' " &
                                                                                                    ",DATEADD(SECOND, " & m & ", GETDATE()) " &
                                                                                            " ) "
                                                                                m_comd = moDB_Adm.GetSqlStringCommand(sqlInsert)
                                                                                moDB_Adm.ExecuteNonQuery(m_comd)

                                                                            Case "BTPRCE"

                                                                                m_strBTPRCE_Uid = Guid.NewGuid.ToString

                                                                                m_strLastDate = m_ncode2.SelectSingleNode("LastDate").InnerText
                                                                                m_strLastValue = m_ncode2.SelectSingleNode("LastValue").InnerText
                                                                                m_strDenominator = m_ncode2.SelectSingleNode("Denominator").InnerText
                                                                                m_strNumerator = m_ncode2.SelectSingleNode("Numerator").InnerText

                                                                                sqlInsert = " INSERT INTO " &
                                                                                                    " LandREG_BTBLOW_BTPRCE " &
                                                                                            " VALUES " &
                                                                                            " ( " &
                                                                                                    " '" & m_strBTPRCE_Uid & "' " &
                                                                                                    ",'" & m_strLoanKey & "' " &
                                                                                                    ",'" & m_strUKey & "' " &
                                                                                                    ",'" & m_strDocUkey & "' " &
                                                                                                    ",'" & m_strLandREG_Uid & "' " &
                                                                                                    ",'" & m_strBTBLOW_Uid & "' " &
                                                                                                    ",'" & m_strLastDate & "' " &
                                                                                                    ",'" & m_strLastValue & "' " &
                                                                                                    ",'" & m_strDenominator & "' " &
                                                                                                    ",'" & m_strNumerator & "' " &
                                                                                                    ",'" & m_strDataSort & "' " &
                                                                                                    ",'" & m_strEmpRole & "' " &
                                                                                                    ",'" & m_strEmpID & "' " &
                                                                                                    ",'" & m_strBranchID & "' " &
                                                                                                    ",DATEADD(SECOND, " & m & ", GETDATE()) " &
                                                                                            " ) "
                                                                                m_comd = moDB_Adm.GetSqlStringCommand(sqlInsert)
                                                                                moDB_Adm.ExecuteNonQuery(m_comd)

                                                                            Case "OtherRegister"

                                                                                m_strOtherRegister_Uid = Guid.NewGuid.ToString

                                                                                m_strOtherRegisterID = m_ncode2.Attributes("ID").InnerText
                                                                                m_strOtherRegister = m_ncode2.InnerText

                                                                                sqlInsert = " INSERT INTO " &
                                                                                                    " LandREG_BTBLOW_OtherRegister " &
                                                                                            " VALUES " &
                                                                                            " ( " &
                                                                                                    " '" & m_strOtherRegister_Uid & "' " &
                                                                                                    ",'" & m_strLoanKey & "' " &
                                                                                                    ",'" & m_strUKey & "' " &
                                                                                                    ",'" & m_strDocUkey & "' " &
                                                                                                    ",'" & m_strLandREG_Uid & "' " &
                                                                                                    ",'" & m_strBTBLOW_Uid & "' " &
                                                                                                    ",'" & m_strOtherRegisterID & "' " &
                                                                                                    ",'" & m_strOtherRegister & "' " &
                                                                                                    ",'" & m_strDataSort & "' " &
                                                                                                    ",'" & m_strEmpRole & "' " &
                                                                                                    ",'" & m_strEmpID & "' " &
                                                                                                    ",'" & m_strBranchID & "' " &
                                                                                                    ",DATEADD(SECOND, " & m & ", GETDATE()) " &
                                                                                            " ) "
                                                                                m_comd = moDB_Adm.GetSqlStringCommand(sqlInsert)
                                                                                moDB_Adm.ExecuteNonQuery(m_comd)
                                                                        End Select
                                                                    Next

                                                                    m_strB16 = m_ncode.SelectSingleNode("B16").InnerText
                                                                    m_strDeclaredValueDate = m_ncode.SelectSingleNode("DeclaredValue").Attributes("Date").InnerText
                                                                    m_strDeclaredValue = m_ncode.SelectSingleNode("DeclaredValue").InnerText

                                                                    sqlInsert = " INSERT INTO " &
                                                                                        " LandREG_BTBLOW " &
                                                                                " VALUES " &
                                                                                " ( " &
                                                                                        " '" & m_strBTBLOW_Uid & "' " &
                                                                                        ",'" & m_strLoanKey & "' " &
                                                                                        ",'" & m_strUKey & "' " &
                                                                                        ",'" & m_strDocUkey & "' " &
                                                                                        ",'" & m_strLandREG_Uid & "' " &
                                                                                        ",'" & m_strRegisterOrder & "' " &
                                                                                        ",'" & m_strRegisterReasonDate2 & "' " &
                                                                                        ",'" & m_strRegisterReasonHDate & "' " &
                                                                                        ",'" & m_strRegisterReason2 & "' " &
                                                                                        ",'" & m_strOwnerID & "' " &
                                                                                        ",'" & m_strOwner & "' " &
                                                                                        ",'" & m_strOwnerAddress.Replace("'", "''") & "' " &
                                                                                        ",'" & m_strRightsRange_RightsReason & "' " &
                                                                                        ",'" & m_strRightsRange_Denominator & "' " &
                                                                                        ",'" & m_strRightsRange_Numerator & "' " &
                                                                                        ",'" & m_strB16 & "' " &
                                                                                        ",'" & m_strDeclaredValueDate & "' " &
                                                                                        ",'" & m_strDeclaredValue & "' " &
                                                                                        ",'" & m_strDataSort & "' " &
                                                                                        ",'" & m_strEmpRole & "' " &
                                                                                        ",'" & m_strEmpID & "' " &
                                                                                        ",'" & m_strBranchID & "' " &
                                                                                        ",DATEADD(SECOND, " & l & ", GETDATE()) " &
                                                                                " ) "
                                                                    m_comd = moDB_Adm.GetSqlStringCommand(sqlInsert)
                                                                    moDB_Adm.ExecuteNonQuery(m_comd)
                                                                Case "BTCLOR"

                                                                    m_strBTCLOR_Uid2 = Guid.NewGuid.ToString

                                                                    m_strRegisterOrderOrder2 = m_ncode.SelectSingleNode("RegisterOrder").Attributes("Order").InnerText
                                                                    m_strRegisterOrder2 = m_ncode.SelectSingleNode("RegisterOrder").InnerText
                                                                    m_strReceiveNumber = m_ncode.SelectSingleNode("ReceiveNumber").InnerText
                                                                    m_strRegisterReasonDate3 = m_ncode.SelectSingleNode("RegisterReason").Attributes("Date").InnerText
                                                                    m_strRegisterReason3 = m_ncode.SelectSingleNode("RegisterReason").InnerText
                                                                    m_strObligeeID = m_ncode.SelectSingleNode("Obligee").Attributes("ID").InnerText
                                                                    m_strObligee = m_ncode.SelectSingleNode("Obligee").InnerText
                                                                    m_strObligeeAddress = m_ncode.SelectSingleNode("ObligeeAddress").InnerText
                                                                    m_strRightsValueRange_Denominator = ""
                                                                    m_strRightsValueRange_Numerator = ""
                                                                    m_strRightsTargetTypeID = m_ncode.SelectSingleNode("RightsTargetType").Attributes("ID").InnerText
                                                                    m_strRightsTargetType = m_ncode.SelectSingleNode("RightsTargetType").InnerText
                                                                    m_strRightsRange_Denominator2 = ""
                                                                    m_strRightsRange_Numerator2 = ""
                                                                    m_strExistPeriod_Start = ""
                                                                    m_strExistPeriod_End = ""

                                                                    For m As Integer = 0 To m_ncode.ChildNodes.Count - 1

                                                                        m_ncode2 = m_ncode.ChildNodes.Item(m)

                                                                        Select Case m_ncode2.Name
                                                                            Case "RightsValueRange"

                                                                                m_strRightsValueRange_Denominator = m_ncode2.SelectSingleNode("Denominator").InnerText
                                                                                m_strRightsValueRange_Numerator = m_ncode2.SelectSingleNode("Numerator").InnerText

                                                                            Case "TargetRegisterOrder"

                                                                                m_strTargetRegisterOrder_Uid = Guid.NewGuid.ToString

                                                                                m_strTargetRegisterOrder = m_ncode2.InnerText

                                                                                sqlInsert = " INSERT INTO " &
                                                                                                    " LandREG_BTCLOR_TargetRegisterOrder " &
                                                                                            " VALUES " &
                                                                                            " ( " &
                                                                                                    " '" & m_strTargetRegisterOrder_Uid & "' " &
                                                                                                    ",'" & m_strLoanKey & "' " &
                                                                                                    ",'" & m_strUKey & "' " &
                                                                                                    ",'" & m_strDocUkey & "' " &
                                                                                                    ",'" & m_strLandREG_Uid & "' " &
                                                                                                    ",'" & m_strBTCLOR_Uid2 & "' " &
                                                                                                    ",'" & m_strTargetRegisterOrder & "' " &
                                                                                                    ",'" & m_strDataSort & "' " &
                                                                                                    ",'" & m_strEmpRole & "' " &
                                                                                                    ",'" & m_strEmpID & "' " &
                                                                                                    ",'" & m_strBranchID & "' " &
                                                                                                    ",DATEADD(SECOND, " & m & ", GETDATE()) " &
                                                                                            " ) "
                                                                                m_comd = moDB_Adm.GetSqlStringCommand(sqlInsert)
                                                                                moDB_Adm.ExecuteNonQuery(m_comd)
                                                                            Case "RightsRange"

                                                                                m_strRightsRange_Denominator2 = m_ncode2.SelectSingleNode("Denominator").InnerText
                                                                                m_strRightsRange_Numerator2 = m_ncode2.SelectSingleNode("Numerator").InnerText

                                                                            Case "ExistPeriod"

                                                                                m_strExistPeriod_Start = m_ncode2.SelectSingleNode("Start").InnerText
                                                                                m_strExistPeriod_End = m_ncode2.SelectSingleNode("End").InnerText

                                                                            Case "BTTOGHC"

                                                                                m_strBTTOGHC_Uid2 = Guid.NewGuid.ToString

                                                                                m_strSectionID2 = m_ncode2.SelectSingleNode("Section").Attributes("ID").InnerText
                                                                                m_strSectionName2 = m_ncode2.SelectSingleNode("Section").InnerText

                                                                                m_strLandNo2 = ""
                                                                                m_strBuildNo2 = ""
                                                                                If Not IsNothing(m_ncode2.SelectSingleNode("LandNo")) Then
                                                                                    m_strLandNo2 = m_ncode2.SelectSingleNode("LandNo").InnerText
                                                                                End If
                                                                                If Not IsNothing(m_ncode2.SelectSingleNode("BuildNo")) Then
                                                                                    m_strBuildNo2 = m_ncode2.SelectSingleNode("BuildNo").InnerText
                                                                                End If

                                                                                sqlInsert = " INSERT INTO " &
                                                                                                    " LandREG_BTCLOR_BTTOGHC " &
                                                                                            " VALUES " &
                                                                                            " ( " &
                                                                                                    " '" & m_strBTTOGHC_Uid2 & "' " &
                                                                                                    ",'" & m_strLoanKey & "' " &
                                                                                                    ",'" & m_strUKey & "' " &
                                                                                                    ",'" & m_strDocUkey & "' " &
                                                                                                    ",'" & m_strLandREG_Uid & "' " &
                                                                                                    ",'" & m_strBTCLOR_Uid2 & "' " &
                                                                                                    ",'" & m_strSectionID2 & "' " &
                                                                                                    ",'" & m_strSectionName2 & "' " &
                                                                                                    ",'" & m_strLandNo2 & "' " &
                                                                                                    ",'" & m_strBuildNo2 & "' " &
                                                                                                    ",'" & m_strDataSort & "' " &
                                                                                                    ",'" & m_strEmpRole & "' " &
                                                                                                    ",'" & m_strEmpID & "' " &
                                                                                                    ",'" & m_strBranchID & "' " &
                                                                                                    ",DATEADD(SECOND, " & m & ", GETDATE()) " &
                                                                                            " ) "
                                                                                m_comd = moDB_Adm.GetSqlStringCommand(sqlInsert)
                                                                                moDB_Adm.ExecuteNonQuery(m_comd)
                                                                            Case "OtherRegister"

                                                                                m_strOtherRegister_Uid = Guid.NewGuid.ToString

                                                                                m_strOtherRegisterID = m_ncode2.Attributes("ID").InnerText
                                                                                m_strOtherRegister = m_ncode2.InnerText

                                                                                sqlInsert = " INSERT INTO " &
                                                                                                    " LandREG_BTCLOR_OtherRegister " &
                                                                                            " VALUES " &
                                                                                            " ( " &
                                                                                                    " '" & m_strOtherRegister_Uid & "' " &
                                                                                                    ",'" & m_strLoanKey & "' " &
                                                                                                    ",'" & m_strUKey & "' " &
                                                                                                    ",'" & m_strDocUkey & "' " &
                                                                                                    ",'" & m_strLandREG_Uid & "' " &
                                                                                                    ",'" & m_strBTCLOR_Uid2 & "' " &
                                                                                                    ",'" & m_strOtherRegisterID & "' " &
                                                                                                    ",'" & m_strOtherRegister & "' " &
                                                                                                    ",'" & m_strDataSort & "' " &
                                                                                                    ",'" & m_strEmpRole & "' " &
                                                                                                    ",'" & m_strEmpID & "' " &
                                                                                                    ",'" & m_strBranchID & "' " &
                                                                                                    ",DATEADD(SECOND, " & m & ", GETDATE()) " &
                                                                                            " ) "
                                                                                m_comd = moDB_Adm.GetSqlStringCommand(sqlInsert)
                                                                                moDB_Adm.ExecuteNonQuery(m_comd)
                                                                        End Select
                                                                    Next

                                                                    m_strC16 = m_ncode.SelectSingleNode("C16").InnerText
                                                                    m_strDebtor = m_ncode.SelectSingleNode("Debtor").InnerText
                                                                    m_strSetObligor = m_ncode.SelectSingleNode("SetObligor").InnerText
                                                                    m_strRightsTypeID = m_ncode.SelectSingleNode("RightsType").Attributes("ID").InnerText
                                                                    m_strRightsType = m_ncode.SelectSingleNode("RightsType").InnerText
                                                                    m_strRightsValueType_type = m_ncode.SelectSingleNode("RightsValueType").Attributes("type").InnerText
                                                                    m_strRightsValueType = m_ncode.SelectSingleNode("RightsValueType").InnerText
                                                                    m_strRightsValue = m_ncode.SelectSingleNode("RightsValue").InnerText
                                                                    m_strRightsKind = m_ncode.SelectSingleNode("RightsKind").InnerText
                                                                    m_strRightsDate = m_ncode.SelectSingleNode("RightsDate").InnerText
                                                                    m_strRightsOtherKind = m_ncode.SelectSingleNode("RightsOtherKind").InnerText
                                                                    m_strRightsQuota = m_ncode.SelectSingleNode("RightsQuota").InnerText
                                                                    m_strRightsPromise = m_ncode.SelectSingleNode("RightsPromise").InnerText
                                                                    m_strDischargeDate = m_ncode.SelectSingleNode("DischargeDate").InnerText
                                                                    m_strInterest = m_ncode.SelectSingleNode("Interest").InnerText
                                                                    m_strDelayInterest = m_ncode.SelectSingleNode("Interest").InnerText
                                                                    m_strPenalty = m_ncode.SelectSingleNode("Interest").InnerText

                                                                    sqlInsert = " INSERT INTO " &
                                                                                        " LandREG_BTCLOR " &
                                                                                " VALUES " &
                                                                                " ( " &
                                                                                        " '" & m_strBTCLOR_Uid2 & "' " &
                                                                                        ",'" & m_strLoanKey & "' " &
                                                                                        ",'" & m_strUKey & "' " &
                                                                                        ",'" & m_strDocUkey & "' " &
                                                                                        ",'" & m_strLandREG_Uid & "' " &
                                                                                        ",'" & m_strRegisterOrderOrder2 & "' " &
                                                                                        ",'" & m_strRegisterOrder2 & "' " &
                                                                                        ",'" & m_strReceiveNumber & "' " &
                                                                                        ",'" & m_strRegisterReasonDate3 & "' " &
                                                                                        ",'" & m_strRegisterReason3 & "' " &
                                                                                        ",'" & m_strObligeeID & "' " &
                                                                                        ",'" & m_strObligee & "' " &
                                                                                        ",'" & m_strObligeeAddress & "' " &
                                                                                        ",'" & m_strRightsValueRange_Denominator & "' " &
                                                                                        ",'" & m_strRightsValueRange_Numerator & "' " &
                                                                                        ",'" & m_strRightsTargetTypeID & "' " &
                                                                                        ",'" & m_strRightsTargetType & "' " &
                                                                                        ",'" & m_strRightsRange_Denominator2 & "' " &
                                                                                        ",'" & m_strRightsRange_Numerator2 & "' " &
                                                                                        ",'" & m_strC16 & "' " &
                                                                                        ",'" & m_strDebtor & "' " &
                                                                                        ",'" & m_strSetObligor & "' " &
                                                                                        ",'" & m_strRightsTypeID & "' " &
                                                                                        ",'" & m_strRightsType & "' " &
                                                                                        ",'" & m_strRightsValueType_type & "' " &
                                                                                        ",'" & m_strRightsValueType & "' " &
                                                                                        ",'" & m_strRightsValue & "' " &
                                                                                        ",'" & m_strRightsKind & "' " &
                                                                                        ",'" & m_strExistPeriod_Start & "' " &
                                                                                        ",'" & m_strExistPeriod_End & "' " &
                                                                                        ",'" & m_strDischargeDate & "' " &
                                                                                        ",'" & m_strInterest & "' " &
                                                                                        ",'" & m_strDelayInterest & "' " &
                                                                                        ",'" & m_strPenalty & "' " &
                                                                                        ",'" & m_strRightsDate & "' " &
                                                                                        ",'" & m_strRightsOtherKind & "' " &
                                                                                        ",'" & m_strRightsQuota & "' " &
                                                                                        ",'" & m_strRightsPromise & "' " &
                                                                                        ",'" & m_strDataSort & "' " &
                                                                                        ",'" & m_strEmpRole & "' " &
                                                                                        ",'" & m_strEmpID & "' " &
                                                                                        ",'" & m_strBranchID & "' " &
                                                                                        ",DATEADD(SECOND, " & l & ", GETDATE()) " &
                                                                                " ) "
                                                                    m_comd = moDB_Adm.GetSqlStringCommand(sqlInsert)
                                                                    moDB_Adm.ExecuteNonQuery(m_comd)
                                                            End Select
                                                        Next
                                                End Select
                                            Next

                                        Case "PIC1"

                                            sqlDelete = " DELETE FROM " &
                                                                " PIC1 WITH (ROWLOCK) " &
                                                        " WHERE " &
                                                                " Loan_Uid = '" & m_strLoanKey & "' " &
                                                        " AND " &
                                                                " Query_Uid = '" & m_strUKey & "' " &
                                                        " AND " &
                                                                " Doc_Uid = '" & m_strDocUkey & "' "
                                            m_comd = moDB_Adm.GetSqlStringCommand(sqlDelete)
                                            moDB_Adm.ExecuteNonQuery(m_comd)

                                            m_nodeCoordinates = m_objXML.DocumentElement.SelectSingleNode("EDOCData")
                                            m_strPOI_X = m_nodeCoordinates.SelectSingleNode("Coordinates").SelectSingleNode("POI_X").InnerText
                                            m_strPOI_Y = m_nodeCoordinates.SelectSingleNode("Coordinates").SelectSingleNode("POI_Y").InnerText
                                            m_strEMAP = m_nodeCoordinates.SelectSingleNode("EMAP").InnerText

                                            sqlInsert = " INSERT INTO " &
                                                                " PIC1 " &
                                                        " VALUES " &
                                                        " ( " &
                                                                " '" & Guid.NewGuid.ToString & "' " &
                                                                ",'" & m_strLoanKey & "' " &
                                                                ",'" & m_strUKey & "' " &
                                                                ",'" & m_strDocUkey & "' " &
                                                                ",'" & m_strPOI_X & "' " &
                                                                ",'" & m_strPOI_Y & "' " &
                                                                ",'" & m_strEMAP & "' " &
                                                                ",'" & m_strDataSort & "' " &
                                                                ",'" & m_strEmpRole & "' " &
                                                                ",'" & m_strEmpID & "' " &
                                                                ",'" & m_strBranchID & "' " &
                                                                ",GETDATE() " &
                                                        " ) "

                                            m_comd = moDB_Adm.GetSqlStringCommand(sqlInsert)
                                            moDB_Adm.ExecuteNonQuery(m_comd)

                                    End Select

                                    sqlUpdate = " UPDATE " &
                                                        p_strTableName & "Doc WITH (ROWLOCK) " &
                                                " SET " &
                                                        " ParseStatus = '2' " &
                                                        ",ParseResultXml = '" & m_strRet.Replace("'", "''") & "' " &
                                                        ",LastUpdateDate = GETDATE() " &
                                                " WHERE " &
                                                        " UKey = '" & m_strDocUkey & "' " &
                                                " AND " &
                                                        " LoanKey = '" & m_strLoanKey & "' " &
                                                " AND " &
                                                        " House_AdmDataUkey = '" & m_strUKey & "' " '" QueryKey = '" & m_strUKey & "' "
                                    m_comd = moDB_eloan.GetSqlStringCommand(sqlUpdate)
                                    moDB_eloan.ExecuteNonQuery(m_comd)

                                ElseIf m_strCode = "-6" Then
                                    sqlUpdate = " UPDATE " &
                                                        p_strTableName & "Doc WITH (ROWLOCK) " &
                                                " SET " &
                                                        " ParseStatus = '3' " &
                                                        ",ParseResultXml = '" & m_strRet.Replace("'", "''") & "' " &
                                                        ",LastUpdateDate = GETDATE() " &
                                                " WHERE " &
                                                        " UKey = '" & m_strDocUkey & "' " &
                                                " AND " &
                                                        " LoanKey = '" & m_strLoanKey & "' " &
                                                " AND " &
                                                        " House_AdmDataUkey = '" & m_strUKey & "' " '" QueryKey = '" & m_strUKey & "' "
                                    m_comd = moDB_eloan.GetSqlStringCommand(sqlUpdate)
                                    moDB_eloan.ExecuteNonQuery(m_comd)
                                End If

                            Next
                            g_writeLog.WriteErrorLog("insert data success !!!")
                        End If

                        sqlSelect = " SELECT " &
                                            " UKey " &
                                    " FROM " &
                                            p_strTableName & "Doc (NOLOCK) " &
                                    " WHERE " &
                                            " LoanKey = '" & m_strLoanKey & "' " &
                                    " AND " &
                                            " House_AdmDataUkey = '" & m_strUKey & "' " &
                                    " AND " &
                                            " DocType = 'REG' " &
                                    " AND " &
                                    " ( " &
                                            " SStatus = 'D' " &
                                    " OR " &
                                            " SSTatus = 'E' " &
                                    " ) " &
                                    " AND " &
                                            " QueryStatus = 2 " &
                                    " AND " &
                                            " ParseStatus = '0' "
                        m_comd = moDB_eloan.GetSqlStringCommand(sqlSelect)
                        m_ds = moDB_eloan.ExecuteDataSet(m_comd)

                        m_dt3 = m_ds.Tables(0)

                        If Not (m_dt3 IsNot Nothing AndAlso m_dt3.Rows.Count > 0) Then
                            sqlUpdate = " UPDATE " &
                                                p_strTableName & " WITH (ROWLOCK) " &
                                        " SET " &
                                                " ParseStatus = '2' " &
                                                ",LastUpdateDate = GETDATE() " &
                                        " WHERE " &
                                                " LoanKey = '" & m_strLoanKey & "' " &
                                        " AND " &
                                                " UKey = '" & m_strUKey & "' "
                            m_comd = moDB_eloan.GetSqlStringCommand(sqlUpdate)
                            moDB_eloan.ExecuteNonQuery(m_comd)
                            g_writeLog.WriteErrorLog(" ParseStatus = '2'  !!!")
                        End If
                    Catch ex As Exception
                        If Not (Date.Now.ToString("HHmm") >= "0350" And Date.Now.ToString("HHmm") <= "0700") Then
                            g_writeLog.WriteErrorLog("eLoanAdm ParserData(2) Error : " & ex.Message & " - " & sqlInsert)
                        End If
                    Finally
                        If m_comd IsNot Nothing Then
                            m_comd.Dispose()
                            m_comd = Nothing
                        End If
                    End Try
                Next
            End If

        Catch ex As Exception
            If Not (Date.Now.ToString("HHmm") >= "0350" And Date.Now.ToString("HHmm") <= "0700") Then
                g_writeLog.WriteErrorLog("eLoanAdm ParserData(1) Error : " & ex.Message)
            End If
        Finally
            If m_comd IsNot Nothing Then
                m_comd.Dispose()
                m_comd = Nothing
            End If
            If m_GetData IsNot Nothing Then
                m_GetData.Abort()
                m_GetData.Dispose()
                m_GetData = Nothing
            End If
        End Try

    End Sub

#End Region

End Class
