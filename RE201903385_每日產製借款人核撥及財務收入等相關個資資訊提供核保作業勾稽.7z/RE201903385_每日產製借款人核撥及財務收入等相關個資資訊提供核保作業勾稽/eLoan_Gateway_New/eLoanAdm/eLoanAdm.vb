Imports System.Windows.Forms
Imports eLoan_Gateway
Imports System.IO

Module eLoanAdm
    Private g_objSettings As ClassLib.Settings
    Private g_strLogPath As String = Nothing
    Private g_writeLog As eLoan_Gateway.ClassLib.WriteLog
    Private Crypt As New ClassLib.Cryptography
    Private g_strDBConnString As String = Nothing
    Private g_strDBConnString_IMP_ADM As String = Nothing 
    Private g_strAPI_EDOCService As String = Nothing
    Private g_blnAdmEnable As Boolean = False
    Private g_strAdmTables As String = Nothing
    Private g_intAdmInterval As Integer = 0
    Private g_outSourceHandler As New ArrayList()

    Sub Main()
        g_objSettings = New ClassLib.Settings(Application.StartupPath)

        Try
            '�O���ɥؿ�
            g_strLogPath = CStr(g_objSettings.ReadSetting("AdmLogPath")).TrimEnd("\") & "\"

            g_writeLog = New eLoan_Gateway.ClassLib.WriteLog(g_strLogPath)

            '��Ʈw�s������
            g_strDBConnString = CStr(g_objSettings.ReadSetting("DBConnString_LOAN"))
            'g_strDBConnString = g_strDBConnString.ToString.Split(New String() {";pwd="}, StringSplitOptions.None)(0) & ";pwd=" & Crypt.Dec(g_strDBConnString.ToString.Split(New String() {";pwd="}, StringSplitOptions.None)(1))
            g_strDBConnString_IMP_ADM = CStr(g_objSettings.ReadSetting("DBConnString_IMP_ADM"))
            'g_strDBConnString_IMP_ADM = g_strDBConnString_IMP_ADM.ToString.Split(New String() {";pwd="}, StringSplitOptions.None)(0) & ";pwd=" & Crypt.Dec(g_strDBConnString_IMP_ADM.ToString.Split(New String() {";pwd="}, StringSplitOptions.None)(1))

            '�a�F��X������}
            g_strAPI_EDOCService = CStr(g_objSettings.ReadSetting("API_EDOCService")).Trim

            '�O�_�ҥΦa�F��Ƭd��
            g_blnAdmEnable = CBool(g_objSettings.ReadSetting("AdmEnable"))
            '�a�F�ӷ���ƪ�
            g_strAdmTables = CStr(g_objSettings.ReadSetting("AdmTables"))
            '�a�F�B�z���j�ɶ�
            g_intAdmInterval = CInt(g_objSettings.ReadSetting("AdmInterval"))

            Dim m_strLifeFile As String = Application.StartupPath.TrimEnd("\") & "\eLoanAdm.life"
            Try
                File.WriteAllText(m_strLifeFile, "LIFE")
            Catch ex As Exception
            End Try

            '�Ұʦa�F�d��
            If g_blnAdmEnable Then
                g_outSourceHandler.Add(New AdmHandler(g_strDBConnString, g_strAPI_EDOCService, g_strAdmTables, g_intAdmInterval, g_strLogPath, g_strDBConnString_IMP_ADM))
            End If

            For i As Integer = 0 To g_outSourceHandler.Count - 1
                CType(g_outSourceHandler(i), IOutSourceHandler).StartThread()
            Next

            g_writeLog.WriteErrorLog("Adm:�B�z�`���w�Ұ�...")

            While File.Exists(m_strLifeFile)
                Threading.Thread.Sleep(5000)
            End While

        Catch ex As Exception
            If g_writeLog IsNot Nothing Then
                g_writeLog.WriteErrorLog("Adm:Failed to Load Settings, " & ex.Message)
            End If
            Exit Sub
        Finally

            For i As Integer = 0 To g_outSourceHandler.Count - 1
                CType(g_outSourceHandler(i), IOutSourceHandler).StopThread()
            Next
            g_outSourceHandler.Clear()

            g_writeLog.WriteErrorLog("Adm:�B�z�`���w����.")

        End Try

    End Sub

End Module
