Imports System.Windows.Forms
Imports System.Xml
Imports System.Data.SqlClient
Imports eLoan_Gateway
Imports eLoan_Gateway.ClassLib
Imports Microsoft.Practices.EnterpriseLibrary.Data

Module Get_Adm_Parameter
    Private g_objSettings As ClassLib.Settings = Nothing
    Private g_strLogPath As String = Nothing
    Private g_writeLog As eLoan_Gateway.ClassLib.WriteLog
    Private g_strAPI_EDOCService As String = Nothing
    Private g_strDBConnString As String = Nothing
    Private Crypt As New ClassLib.Cryptography
    Private SqlStr As New System.Text.StringBuilder
    Private i, j, k As Integer
    Private comd As SqlCommand
    Private comdTemptable As SqlCommand
    Private dt As DataTable = Nothing
    Private dr As DataSet = Nothing

    Sub Main()

        'eLoan��Ʈw�s�u�r��
        g_objSettings = New ClassLib.Settings(Application.StartupPath)

        Try
            g_strLogPath = CStr(g_objSettings.ReadSetting("AdmLogPath")).TrimEnd("\") & "\"

            g_writeLog = New eLoan_Gateway.ClassLib.WriteLog(g_strLogPath)

            g_strDBConnString = CStr(g_objSettings.ReadSetting("DBConnString_LOAN"))
            'g_strDBConnString = g_strDBConnString.ToString.Split(New String() {";pwd="}, StringSplitOptions.None)(0) & ";pwd=" & Crypt.Dec(g_strDBConnString.ToString.Split(New String() {";pwd="}, StringSplitOptions.None)(1))

            g_strAPI_EDOCService = CStr(g_objSettings.ReadSetting("API_EDOCService"))

            ''�a�F�Ѽ�(�����B�ϡB�q�p�q)
            GetAdmParameterNew()

        Catch ex As Exception
            If g_writeLog IsNot Nothing Then
                g_writeLog.WriteErrorLog("Adm_Paramenter:Failed to Load Settings, " & ex.Message)
            End If
            Exit Sub
        End Try

    End Sub

    Private Sub GetAdmParameterNew()
        Try
            Dim moDB_ELOAN As Database = DBUtil.GetDB(g_strDBConnString)
            '�I�sWebService
            Dim GetData As New Adm_Parameter.EDOCService.EPaperServiceService(g_strAPI_EDOCService)
            GetData.Url = g_strAPI_EDOCService

            Dim objXML As New XmlDocument
            Dim objXML2 As New XmlDocument

            Dim str As String = GetData.getCity

            objXML.LoadXml(str)
            Dim RespMsg_node As XmlNode = objXML.DocumentElement.SelectSingleNode("RespMsg")
            Dim node As XmlNode = objXML.DocumentElement.SelectSingleNode("Result")

            Dim RespMsg_Code As String = CType(RespMsg_node, XmlElement).GetAttribute("Code").ToString
            Dim RespMsg As String = CType(RespMsg_node, XmlElement).InnerText.ToString
            '1.���Ʈw�إߦ@�Ϊ�City Area Ir����ƪ��åB�N�a�F��XML��Ʒs�W��@�Ϊ�City Area Ir����ƪ�
            If RespMsg_Code = "0" Then
                SqlStr.Append("IF EXISTS(SELECT * FROM tempdb.sys.all_objects WHERE name = '##Paras_Adm_City') ")
                SqlStr.Append(" BEGIN ")
                SqlStr.Append(" DROP TABLE ##Paras_Adm_City; ")
                SqlStr.Append(" END; ")
                SqlStr.Append(" CREATE TABLE ##Paras_Adm_City ( ")
                SqlStr.Append(" CityID VARCHAR(50) ")
                SqlStr.Append(",CityName NVARCHAR(100) ")
                SqlStr.Append(" ); ")
                SqlStr.Append("IF EXISTS(SELECT * FROM tempdb.sys.all_objects WHERE name = '##Paras_Adm_Area') ")
                SqlStr.Append(" BEGIN ")
                SqlStr.Append(" DROP TABLE ##Paras_Adm_Area; ")
                SqlStr.Append(" END; ")
                SqlStr.Append(" CREATE TABLE ##Paras_Adm_Area ( ")
                SqlStr.Append(" CityID VARCHAR(50) ")
                SqlStr.Append(",AreaID VARCHAR(50) ")
                SqlStr.Append(",AreaName NVARCHAR(100) ")
                SqlStr.Append(" ); ")
                SqlStr.Append("IF EXISTS(SELECT * FROM tempdb.sys.all_objects WHERE name = '##Paras_Adm_Ir') ")
                SqlStr.Append(" BEGIN ")
                SqlStr.Append(" DROP TABLE ##Paras_Adm_Ir; ")
                SqlStr.Append(" END; ")
                SqlStr.Append(" CREATE TABLE ##Paras_Adm_Ir ( ")
                SqlStr.Append(" CityID VARCHAR(50) ")
                SqlStr.Append(",AreaID VARCHAR(50) ")
                SqlStr.Append(",LnID VARCHAR(50) ")
                SqlStr.Append(",LnName NVARCHAR(100) ")
                SqlStr.Append(",IrID VARCHAR(50) ")
                SqlStr.Append(",IrName NVARCHAR(100) ")
                SqlStr.Append(" ); ")


                Dim cnode, node2, cnode2, ccnode2, cccnode2 As XmlNode
                Dim CityID, CityName, str2, AreaID, AreaName, IrID, IrName, LN, LNName As String
                For i = 0 To node.ChildNodes.Count - 1 '����
                    cnode = node.ChildNodes.Item(i)
                    CityID = CType(cnode, XmlElement).GetAttribute("ID").ToString
                    CityName = CType(cnode, XmlElement).GetAttribute("Name").ToString

                    SqlStr.Append("INSERT INTO ##Paras_Adm_City VALUES ('" + CityID + "', '" + CityName + "');") '����
                    str2 = GetData.getSection(CityID)
                    objXML2.LoadXml(str2)

                    node2 = objXML2.DocumentElement.SelectSingleNode("Result")
                    cnode2 = node2.SelectSingleNode("City") '����
                    For j = 0 To cnode2.ChildNodes.Count - 1
                        ccnode2 = cnode2.ChildNodes.Item(j) '��
                        AreaID = CType(ccnode2, XmlElement).GetAttribute("ID").ToString
                        AreaName = CType(ccnode2, XmlElement).GetAttribute("Name").ToString

                        SqlStr.Append("INSERT INTO ##Paras_Adm_Area VALUES ('" + CityID + "', '" + AreaID + "','" + AreaName + "');")

                        For k = 0 To ccnode2.ChildNodes.Count - 1
                            cccnode2 = ccnode2.ChildNodes.Item(k) '�q

                            IrID = CType(cccnode2, XmlElement).GetAttribute("ID").ToString
                            IrName = CType(cccnode2, XmlElement).InnerText.ToString
                            LN = CType(cccnode2, XmlElement).GetAttribute("LN").ToString
                            LNName = CType(cccnode2, XmlElement).GetAttribute("LNName").ToString
                            SqlStr.Append("INSERT INTO ##Paras_Adm_Ir VALUES ('" + CityID + "', '" + AreaID + "', '" + LN + "', '" + LNName + "', '" + IrID + "', '" + IrName + "');")
                        Next
                    Next
                Next

                GetData.Dispose()
                '2.�ϥ�##City Area Ir��ƪ� ��sELOAN���
                SqlStr.Append("UPDATE a ")
                SqlStr.Append(" SET a.Disable = 1")
                SqlStr.Append(",a.LastUpdateDate=getdate() ")
                SqlStr.Append(" FROM dbo.Paras_Adm_City2 a ")
                SqlStr.Append(" LEFT JOIN ##Paras_Adm_City b ")
                SqlStr.Append(" ON a.CityCode = b.CityID ")
                SqlStr.Append(" WHERE b.CityID IS NULL AND a.Disable = 0;")

                SqlStr.Append("UPDATE a ")
                SqlStr.Append(" SET a.Disable = 0 ")
                SqlStr.Append(",a.CityItem = b.CityName ")
                SqlStr.Append(",a.LastUpdateDate=getdate() ")
                SqlStr.Append(" FROM dbo.Paras_Adm_City2 a ")
                SqlStr.Append(" INNER JOIN ##Paras_Adm_City b ")
                SqlStr.Append(" ON a.CityCode = b.CityID ")
                SqlStr.Append(" WHERE a.Disable = 1;")

                SqlStr.Append("INSERT INTO dbo.Paras_Adm_City2 (CityCode,CityItem,TelArea,CoreLoclNo,LastUpdateRoleNo,LastUpdateEmpNo,LastUpdateBranchNo,LastUpdateDate,DataSort,Disable)")
                SqlStr.Append(" SELECT ")
                SqlStr.Append(" a.CityID ")
                SqlStr.Append(",a.CityName ")
                SqlStr.Append(",NULL ")
                SqlStr.Append(",NULL ")
                SqlStr.Append(",'sys' ")
                SqlStr.Append(",'sys' ")
                SqlStr.Append(",'sys' ")
                SqlStr.Append(",GETDATE() ")
                SqlStr.Append(",99 ")
                SqlStr.Append(",0 ")
                SqlStr.Append(" FROM ##Paras_Adm_City a ")
                SqlStr.Append(" LEFT JOIN dbo.Paras_Adm_City2 b ")
                SqlStr.Append(" ON a.CityID = b.CityCode ")
                SqlStr.Append(" WHERE b.CityCode IS NULL;")

                SqlStr.Append("UPDATE a ")
                SqlStr.Append(" SET a.Disable = 1 ")
                SqlStr.Append(",a.LastUpdateDate=getdate() ")
                SqlStr.Append(" FROM dbo.Paras_Adm_Area2 a ")
                SqlStr.Append(" LEFT JOIN ##Paras_Adm_Area b ")
                SqlStr.Append(" ON a.CityCode = b.CityID AND a.AreaCode = b.AreaID ")
                SqlStr.Append(" WHERE b.CityID IS NULL AND a.Disable = 0;")

                SqlStr.Append("UPDATE a ")
                SqlStr.Append(" SET a.Disable = 0 ")
                SqlStr.Append(",a.AreaItem = b.AreaName ")
                SqlStr.Append(",a.LastUpdateDate=getdate() ")
                SqlStr.Append(" FROM dbo.Paras_Adm_Area2 a ")
                SqlStr.Append(" INNER JOIN ##Paras_Adm_Area b ")
                SqlStr.Append(" ON a.CityCode = b.CityID AND a.AreaCode = b.AreaID ")
                SqlStr.Append(" WHERE a.Disable = 1;")

                SqlStr.Append("INSERT INTO dbo.Paras_Adm_Area2 (CityCode,AreaCode,AreaItem,Zip,LastUpdateRoleNo,LastUpdateEmpNo,LastUpdateBranchNo,LastUpdateDate,Disable)")
                SqlStr.Append(" SELECT ")
                SqlStr.Append(" a.CityID ")
                SqlStr.Append(",a.AreaID ")
                SqlStr.Append(",a.AreaName ")
                SqlStr.Append(",'' ")
                SqlStr.Append(",'sys' ")
                SqlStr.Append(",'sys' ")
                SqlStr.Append(",'sys' ")
                SqlStr.Append(",GETDATE() ")
                SqlStr.Append(",0 ")
                SqlStr.Append(" FROM ##Paras_Adm_Area a ")
                SqlStr.Append(" LEFT JOIN dbo.Paras_Adm_Area2 b ")
                SqlStr.Append(" ON a.CityID = b.CityCode AND a.AreaID = b.AreaCode ")
                SqlStr.Append(" WHERE b.CityCode IS NULL;")

                SqlStr.Append("UPDATE a ")
                SqlStr.Append(" SET a.Disable = 1 ")
                SqlStr.Append(",a.LastUpdateDate=getdate() ")
                SqlStr.Append(" FROM dbo.Paras_Adm_Ir2 a ")
                SqlStr.Append(" LEFT JOIN ##Paras_Adm_Ir b ")
                SqlStr.Append(" ON a.CityCode = b.CityID AND a.AreaCode = b.AreaID AND a.LnCode = b.LnID AND a.IrCode = b.IrID ")
                SqlStr.Append(" WHERE b.CityID IS NULL AND a.Disable = 0;")

                SqlStr.Append("UPDATE a ")
                SqlStr.Append(" SET a.Disable = 0 ")
                SqlStr.Append(",a.LnItem = b.LnName ")
                SqlStr.Append(",a.IrItem = b.IrName ")
                SqlStr.Append(",a.LastUpdateDate=getdate() ")
                SqlStr.Append(" FROM dbo.Paras_Adm_Ir2 a ")
                SqlStr.Append(" INNER JOIN ##Paras_Adm_Ir b ")
                SqlStr.Append(" ON a.CityCode = b.CityID AND a.AreaCode = b.AreaID AND a.LnCode = b.LnID AND a.IrCode = b.IrID ")
                SqlStr.Append(" WHERE a.Disable = 1;")

                SqlStr.Append("INSERT INTO dbo.Paras_Adm_Ir2 (CityCode,AreaCode,LnCode,LnItem,IrCode,IrItem,LastUpdateRoleNo,LastUpdateEmpNo,LastUpdateBranchNo,LastUpdateDate,Disable)")
                SqlStr.Append(" SELECT ")
                SqlStr.Append(" a.CityID ")
                SqlStr.Append(",a.AreaID ")
                SqlStr.Append(",a.LnID ")
                SqlStr.Append(",a.LnName ")
                SqlStr.Append(",a.IrID ")
                SqlStr.Append(",a.IrName ")
                SqlStr.Append(",'sys' ")
                SqlStr.Append(",'sys' ")
                SqlStr.Append(",'sys' ")
                SqlStr.Append(",GETDATE() ")
                SqlStr.Append(",0 ")
                SqlStr.Append(" FROM ##Paras_Adm_Ir a ")
                SqlStr.Append(" LEFT JOIN dbo.Paras_Adm_Ir2 b ")
                SqlStr.Append(" ON a.CityID = b.CityCode AND a.AreaID = b.AreaCode AND a.LnID = b.LnCode AND a.IrID = b.IrCode ")
                SqlStr.Append(" WHERE b.CityCode IS NULL;")
                SqlStr.Append("DROP TABLE ##Paras_Adm_City;")
                SqlStr.Append("DROP TABLE ##Paras_Adm_Area;")
                SqlStr.Append("DROP TABLE ##Paras_Adm_Ir;")
                comd = moDB_ELOAN.GetSqlStringCommand(SqlStr.ToString)
                moDB_ELOAN.ExecuteNonQuery(comd)

            End If

        Catch ex As Exception
            g_writeLog.WriteErrorLog("Adm_Paramenter:GetAdmParameterNew Error, " & ex.Message)
        End Try

    End Sub



End Module
