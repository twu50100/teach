﻿var PAGE_SIZE = 10;

var ddlStatusCode = [
    { CheckStatusName: "列管", CheckStatusID: "1" },
    { CheckStatusName: "解除", CheckStatusID: "0" }
];

var ddlCustType = [
    { CustTypeName: "自然人", CustTypeID: "1" },
    { CustTypeName: "法人", CustTypeID: "2" },
    { CustTypeName: "OIU", CustTypeID: "3" }
];

var genData = function (Arg) {

    console.info(Arg);
    var G_DATA = Arg.data.Table;

    var tableArg = {
        theadValue: [[
            { Text: "資料來源" },
            { Text: "流水號" },          
            { Text: "客戶類型" },
            { Text: "客戶統編" },
            { Text: "客戶名稱" },
            { Text: "機構名稱" },
            { Text: "觀察類型" },
            { Text: "通報日期" },
            { Text: "列管原因" },
            { Text: "解除日期"},
            { Text: "解除原因" },
            { Text: "更新時間" },
            { Text: "更新人員" },
            { Text: "hide列管原因", Style: { "display": "none" } },
            { Text: "hide解除原因", Style: { "display": "none" } },
            { Text: "hide ID", Style: { "display": "none" } },
            { Text: "hide Status code", Style: { "display": "none" } },
            { Text: "hide createDate ", Style: { "display": "none" } },
            { Text: "維護" }
            //PutIntoListDate "LastUpdateDate",
        ]],
        tbodyValue: {
            Value: [
                     "SourceType",  "SerialNum",
                     {
                         t: function (e) {

                             var record = $.map(ddlCustType, function (o) {
                                 if (o["CustTypeID"] == e['CustType']) {
                                     return o;
                                 }
                             });
                             //console.log(record);
                             return record[0]['CustTypeName'];
                         } 
                     },
                     "CustID", "CustName", "BlacklistBank",
                    {
                        t: function (e) {

                            var record = $.map(ddlStatusCode, function (o) {
                                if (o["CheckStatusID"] == e['StatusCode']) {
                                    return o;
                                }
                            });

                            return (record[0]) ? record[0]['CheckStatusName'] : "";
                        }
                    },
                    "ReleaseTime",
                    { t: function (e) { return (e['PutIntoListResaon']) ? e['PutIntoListResaon'] : ""; } },
                    "ReleaseListDate",
                    { t: function (e) { return (e['ReleaseListResaon']) ? e['ReleaseListResaon'] : ""; } },
                    "LastUpdateDate", "EmpName",
                    "PutIntoListResaon", "ReleaseListResaon", "CustID", "StatusCode", "CreateDate"

            ],
            Style: [{}, {}, {}, {}, {}, {}, {}, {}, {"width":"20%"}, {}, {}, {}, {}, { "display": "none" }, { "display": "none" }, { "display": "none" }, { "display": "none" }, { "display": "none" }]

        },
        Data: G_DATA,
        Style: {
            tbody_odd: "rowodd",
            tbody_even: "roweven"
        },
        tbodyEdit:
        {
            Ctrl:
                [

                     { Type: "label", ID: "td_SourceType" }
                    , { Type: "label", ID: "td_SerialNum" }
                    , { Type: "label", ID: "td_CustType" }
                    , { Type: "label", ID: "td_CustID" }
                    , { Type: "label", ID: "td_CustName" }
                    , { Type: "label", ID: "td_BlacklistBank" }
                    , {
                        Type: "radio", Text: "CheckStatusName", Value: "CheckStatusID", Name: "StatusCode", Data: ddlStatusCode,
                        Event: function (a) {
                            console.log(a);
                            //console.warn($(this).val());
                            var choice = $(this).val();


                            var hid_PutIntoListResaon = ($("#hid_PutIntoListResaon").val() && $("#hid_PutIntoListResaon").val() != "null") ? $("#hid_PutIntoListResaon").val() : "";
                            var hid_ReleaseListResaon = ($("#hid_ReleaseListResaon").val() && $("#hid_ReleaseListResaon").val() != "null") ? $("#hid_ReleaseListResaon").val() : "";

                            var rCtrl, rCtrl1;
                            if (choice == "1") {
                                rCtrl = $("#td_PutIntoListResaon").closest("td");
                                rCtrl.find("label").remove();
                                rCtrl.find("textarea").remove();
                                rCtrl.append("<textarea id='td_PutIntoListResaon' name='PutIntoListResaon'>" + hid_PutIntoListResaon + "</textarea>");

                                rCtrl1 = $("#td_ReleaseListResaon").closest("td");
                                rCtrl1.find("textarea").remove();
                                rCtrl1.find("label").remove();
                                rCtrl1.append("<label id='td_ReleaseListResaon' name='ReleaseListResaon'>" + hid_ReleaseListResaon + "</label>");
                                $("#td_ReleaseListDate").text("");
                            } else
                                if (choice == "0") {
                                rCtrl = $("#td_ReleaseListResaon").closest("td");
                                rCtrl.find("label").remove();
                                rCtrl.find("textarea").remove();
                                rCtrl.append("<textarea id='td_ReleaseListResaon' name='ReleaseListResaon'>" + hid_ReleaseListResaon + "</textarea>");

                                rCtrl1 = $("#td_PutIntoListResaon").closest("td");
                                rCtrl1.find("label").remove();
                                rCtrl1.find("textarea").remove();
                                rCtrl1.append("<label id='td_PutIntoListResaon' name='PutIntoListResaon'>" + hid_PutIntoListResaon + "</label>");
                                var myDate = new Date;
                                var year = myDate.getFullYear() - 1911;//获取当前年
                                var yue = myDate.getMonth() + 1;//获取当前月
                                if (yue.toString().length == 1) {
                                    yue = "0" + yue;
                                }
                                var date = myDate.getDate();//获取当前日
                                $("#td_ReleaseListDate").text(year + "/" + yue + "/" + date);
                            }
                        }
                    }
                    , { Type: "label", ID: "td_ReleaseTime" }
                    , { Type: "label", ID: "td_PutIntoListResaon", Name: "PutIntoListResaon" }
                    , { Type: "label", ID: "td_ReleaseListDate" }
                    , [
                        { Type: "label", ID: "td_ReleaseListResaon", Name: "ReleaseListResaon" },
                        { Type: "hidden", ID: "hid_PutIntoListResaon" },
                        { Type: "hidden", ID: "hid_ReleaseListResaon" },
                        { Type: "hidden", ID: "hid_CustID", Name: "CustID" },
                        { Type: "hidden", ID: "hid_StatusCode", Name: "StatusCode_o" },
                        { Type: "hidden", ID: "hid_CreateDate", Name: "CreateDate_o" }

                    ],
                      { Type: "label", ID: "td_LastUpdateDate", Name: "LastUpdateDate" }
                    , { Type: "label", ID: "td_LastUpdateEmpNo", Name: "EmpName" }                   
                ]
        },
        Plugin: [
            { Event: EditFunc, UpdateEvent: UpdateFunc, Class: "button _Edit", Name: "修改", Tooltip: "修改" },
            { Event: DeleteFunc, Class: "button _Delete", Name: "刪除", Tooltip: "刪除" }

        ],
        PluginSite: true
        //資料全取的分頁方式
        , PageSetting: {
            ShowPageCtrl: true,
            PageSize: PAGE_SIZE,
            Event: genPageChg
        }
    };

    $("#scDataView").find("input").off('click');
    $("#scDataView").find("thead,tbody").remove();
    $("#scDataView").SexyTable(tableArg);
    $("#CustID").on("keyup", function () {
        var CustID = $('#CustID').val();
        $('#CustID').val(CustID.toUpperCase());
    });
    //hide or disable
    $.each($("#scDataView").find("tbody > tr"), function (Idx, Item) {
        var actionFlag = $(Item).find("td").eq(0).text(); //取得資料來源
        var ReleaseListDate = $(Item).find("td").eq(9).text(); //解除日期
        var ReleaseListResaon = $(Item).find("td").eq(10).text(); //解除原因
        var editElm = $(Item).find("._Edit"); //取得修改元素按鈕
        var delElm = $(Item).find("._Delete"); //取得刪除元素按鈕
        var myDate = new Date;
        var year = myDate.getFullYear();//获取当前年
        var yue = myDate.getMonth() + 1;//获取当前月
        if (yue.toString().length == 1) {
            yue = "0" + yue;
        }
        var date = myDate.getDate();//获取当前日
        if (actionFlag == "JCIC") {
            editElm.hide();
            delElm.hide();
        }
        else {
            // 人工新增來源僅解除日期及解除原因空白時可修改觀察類型、解除日期及解除原因
            if (ReleaseListDate != "" && ReleaseListResaon != "") {
                editElm.hide();               
            }
          
            var createDate = $(Item).find("td").eq(17).text(); //創建時間
            //人工新增來源僅同日建檔資料可開放做刪除
            if (createDate != (year + "" + yue+""+date)) {
                delElm.hide();
            }
        }
    });
};

function genPageChg(pageIdx) {
    //只取部份資料的分頁方式
    OrdersQry();
}

var EditFunc = function (ArgData) {

    console.info(ArgData);
    $("#td_ReleaseTime").text(ArgData[0]);
    $("#td_SourceType").text(ArgData[0]);//來源
    $("#td_SerialNum").text(ArgData[1]);//流水號
    var record = $.map(ddlCustType, function (o) {
        if (o["CustTypeName"] == ArgData[2]) {
            return o;
        }
    });
    $("#td_CustType").text(record[0]['CustTypeName']);

    $("#td_CustID").text(ArgData[3]);
    $("#td_CustName").text(ArgData[4]);
    $("#td_BlacklistBank").text(ArgData[5]);
    var temp_val = "";
    if (ArgData[6] == "列管") {
        temp_val = "1";
    } else {
        temp_val = "0";
    }

    var tr = $("#td_ReleaseTime").closest("tr");
    tr.find("input:radio[name='StatusCode" + ArgData[19]["radioEditName"] + "'][value='" + temp_val + "']").prop("checked", true);

    $("#td_ReleaseTime").text(ArgData[7]);
    $("#td_ReleaseListDate").text(ArgData[9]);
    var td_PutIntoListResaon = (ArgData[8] && ArgData[8] != "null") ? ArgData[8] : "";
    var td_ReleaseListResaon = (ArgData[10] && ArgData[10] != "null") ? ArgData[10] : "";
    $("#td_PutIntoListResaon").text(td_PutIntoListResaon);
    // edit initial
    var rCtrl, rCtrl1;
    if (temp_val == "1") {
        rCtrl = $("#td_PutIntoListResaon").closest("td");
        rCtrl.find("label").remove();
        rCtrl.find("textarea").remove();
        rCtrl.append("<textarea id='td_PutIntoListResaon' name='PutIntoListResaon'>" + td_PutIntoListResaon + "</textarea>");

        rCtrl1 = $("#td_ReleaseListResaon").closest("td");
        rCtrl1.find("textarea").remove();
        rCtrl1.find("label").remove();
        rCtrl1.append("<label id='td_ReleaseListResaon' name='ReleaseListResaon'>" + td_ReleaseListResaon + "</label>");
        $("#td_ReleaseListDate").text("");

    } else
        if (temp_val == "0") {
        rCtrl = $("#td_ReleaseListResaon").closest("td");
        rCtrl.find("label").remove();
        rCtrl.find("textarea").remove();
        rCtrl.append("<textarea id='td_ReleaseListResaon' name='ReleaseListResaon'>" + td_ReleaseListResaon + "</textarea>");

        rCtrl1 = $("#td_PutIntoListResaon").closest("td");
        rCtrl1.find("textarea").remove();
        rCtrl1.find("label").remove();
        rCtrl1.append("<label id='td_PutIntoListResaon' name='PutIntoListResaon'>" + td_PutIntoListResaon + "</label>");
        var myDate = new Date;
        var year = myDate.getFullYear()-1911;//获取当前年
        var yue = myDate.getMonth() + 1;//获取当前月
        if (yue.toString().length == 1) {
            yue = "0" + yue;
        }
        var date = myDate.getDate();//获取当前日
        $("#td_ReleaseListDate").text(year + "/" + yue + "/" + date);
    }

    //$("#td_PutIntoListResaon").text(ArgData[5]);
    //$("#td_ReleaseListResaon").text(ArgData[6]);

    $("#hid_PutIntoListResaon").val(ArgData[13]);
    $("#hid_ReleaseListResaon").val(ArgData[14]);
    $("#hid_CustID").val(ArgData[15]);
    $("#hid_StatusCode").val(temp_val);
    $("#hid_CreateDate").val(ArgData[17]);
    $("#td_LastUpdateDate").text(ArgData[11]);
    $("#td_LastUpdateEmpNo").text(ArgData[12]);
};



// 修改按下確定
var UpdateFunc = function (ArgData) {
    if ($(this).closest("tr").find("textarea").val() == "") {
        //console.error($(this).closest("tr").find("textarea").val());
        SexyAlert("提示", "原因不可為空！", "ERROR", "OKONLY", function () {
            return;
        });
    } else {
        var jsonData = new Object();
        jsonData = $.valToJson($(this).closest("tr"));
        jsonData["CustName"] = "aaaa";
        console.log(jsonData);
        console.log(ArgData);
        var AjaxInputObj =
            {
                url: "SKL_1_2_Query_ReCheckList/ReCheckList_Upd",
                data: jsonData,
                oMethod: function () {
                    SexyAlert("提示", "修改成功！", "OK", "OKONLY", function () {
                        OrdersQry();
                    });
                }
            };
        //call ajax
        docCore.ajax(AjaxInputObj, true, true);
    }
}



//刪除
var DeleteFunc = function (ArgData) {
    //console.log(ArgData);
    var jsonData = new Object();
    jsonData["CustID"] = ArgData[3];

    SexyAlert("提示", "是否刪除" + ArgData[4], "QUESTION", "YESNO", function () {
        var AjaxInputObj =
    {
        url: "SKL_1_2_Query_ReCheckList/ReCheckList_Delete",
        data: jsonData,
        oMethod: function () {
            SexyAlert("提示", "刪除成功！", "OK", "OKONLY", function () {
                OrdersQry();
            });
        }
    };
        //call ajax
        docCore.ajax(AjaxInputObj, true, true);

    });
}


//一開始取得頁面資料
function OrdersQry() {
    var rCtrl = $.valToJson($("#btnQry").closest("caption"));

    var DataArgs =
    {
        method: "post",
        url: "SKL_1_2_Query_ReCheckList/init_ReCheckList",
        data: rCtrl,
        oMethod: getInitSelector,
        eMethod: showError
    };
    docCore.ajax(DataArgs, true, true);

}

function getInitSelector(res) {

    //ddlCustType = G_DATA["ddlCustType"];
    //console.log(ddlCustType);
    $("#CustType").empty();
    $("#CustType").SexyCtrl({ Type: "radio", Text: "CustTypeName", Value: "CustTypeID", Name: "CustType" }, ddlCustType);

    //ddlStatusCode = G_DATA["ddlStatusCode"];

    genData(res);
}



function showError() {
    SexyAlert("提示", "資料讀取失敗，請重試！", "alert", "okonly");
}

//function showSuccess(response) {

//    SexyAlert("提示", "資料儲存成功！", "SUCCESS", "okonly", function () {
//        genData(response);
//    });

//}


$(document).ready(function () {
    OrdersQry();
    $("#btnConfirm").click(function () {

        var jsonData = $.valToJson("insertDiv");

        console.info(jsonData);
        var validList = [
            { Field: "CustType", FieldName: "客戶類型", CheckType: "string", IsEmpty: "false" },
            { Field: "CustID", FieldName: "客戶統編", CheckType: "string", IsEmpty: "false" },
            { Field: "CustName", FieldName: "客戶名稱", CheckType: "string", IsEmpty: "false" },
            { Field: "PutIntoListResaon", FieldName: "列管原因", CheckType: "string", IsEmpty: "false" }
        ];

        var valid = $.FormValidation(jsonData, validList);

        if (valid) {
            var DataArgs =
            {
                method: "post",
                url: "SKL_1_2_Query_ReCheckList/ReCheckList_Save",
                data: jsonData,
                oMethod: function () {
                    $('#insertDiv :input').not(':button, :submit, :reset, :hidden, :radio, select').val('').removeAttr('checked').removeAttr('selected');
                    $('#insertDiv :input[type="radio"]').removeAttr('checked');
                    OrdersQry();
                },
                eMethod: showError
            };
            docCore.ajax(DataArgs, true, true);
        } else {
            var errMsg = $.FormValidationErrorMessage().join("<br/>");
            var warnMsg = $.FormValidationWarningMessage().join("<br/>");
            SexyAlert("提示", errMsg.length > 0 ? errMsg : warnMsg, "TIP", "OKONLY");
        }
    });

    $("#btnQry").click(function () {

        var rCtrl = $.valToJson($(this).closest("caption"));
        console.info(rCtrl);

        var DataArgs =
        {
            method: "post",
            url: "SKL_1_2_Query_ReCheckList/ReCheckList_Query",
            data: $.valToJson($(this).closest("caption")),
            oMethod: function (res) {
                $('#insertDiv :input').not(':button, :submit, :reset, :hidden, :radio, select').val('').removeAttr('checked').removeAttr('selected');
                $('#insertDiv :input[type="radio"]').removeAttr('checked');
                genData(res);
            },
            eMethod: showError
        };
        docCore.ajax(DataArgs, true, true);
    });

    // 上傳按鈕單繫事件
    $("#btnUpLoad").click(function () {

        //取得上傳檔案資料，與塞入參數值
        var formData = $.getUpLoadFormData("txtFileUpload", {});
        var AjaxInputObj =
        {
            url: "SKL_1_2_Query_ReCheckList/upLoadFile",
            data: formData,
            oMethod: function (Arg) {
                //成功後，清除file
                var file = $("#txtFileUpload");
                file.after(file.clone().val(""));
                file.remove();
                SexyAlert("提示", G_Convert.msg(Arg.data.msg), "OK", "OKONLY");
                if (Arg.data.msgFlag) {
                    OrdersQry();
                }
            },
            cache: false,
            contentType: false,
            processData: false //告訴jQuery不要處理資料
        };
        //call ajax
        docCore.ajax(AjaxInputObj, true, true);
    });


});