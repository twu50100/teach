USE [SKL_LOAN]
GO
/****** Object:  StoredProcedure [dbo].[USP_House_QryInsCheckData_eloan]    Script Date: 2019/11/12 上午 09:57:31 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
  -- Author:EC0416
  -- Create date: 2019/11/11
  -- Description:	查詢上線首日之前六個月的個資相關資訊已提供核保作業勾稽資料。
-- =============================================
CREATE PROCEDURE [dbo].[USP_House_QryInsCheckData_eloan]

AS
BEGIN
		declare @SourceDB varchar(50)  select top 1 @SourceDB=SourceDB FROM [SKL_CORE].[dbo].[Core_QueryItem] 
		declare @cmd nvarchar(MAX) set @cmd=''
		declare @GetDate varchar(10) set @GetDate = convert(varchar(8),dateadd(m,-6,getdate()),112)
		declare @EtlDate varchar(8) set @EtlDate = convert(varchar(8),dateadd(m,0,getdate()),112)

		create table #TempLNLMSP(
		 LMSLLD varchar(8)   --撥款日
		,LMSFLA varchar(15)  --撥款金額
		,LMSACN varchar(20)  --戶號
		,LMSAPN varchar(3)   --額度
		)

		--篩選AS400撥款日上線首日6個月內資料
		set @cmd = N''+
		' insert into #TempLNLMSP'+
		' select * from openquery(AS400,''select LMSLLD,LMSFLA,LMSACN,LMSAPN from '+@SourceDB+'.LA$LMSP'
		+' where LMSLLD between '  + @GetDate + ' and ' + @EtlDate + ''')'
		print @cmd
	    exec(@cmd)

		insert into house_insCheckData 
		select 
		     CONVERT(varchar(8), GETDATE(),112)  as DataDate --資料日期(年月日)
			,m.CustNo--借款人戶號
			,m.CustName--借款人姓名
			,f.CaseNO--放款案號
            ,CONVERT(date, m.ApproveDate) as ApproveDate--核貸日
			,m.CheckAmount as CheckAmount --核貸金額
			,tempLN.LMSLLD --撥款日
			,tempLN.LMSFLA--撥款金額
			,FLOOR(i.IncomeSalary/10000) as IncomeSalary
			,FLOOR(i.IncomeWork/10000) as IncomeWork
			,FLOOR(i.IncomeBusiness/10000) as IncomeBusiness
			,FLOOR(i.IncomeRant/10000)  as IncomeRant 
			,FLOOR(i.IncomeInterest/10000) as IncomeInterest
			,FLOOR(i.IncomeOther/10000) as IncomeOther
			,FLOOR(i.IncomeYear/10000) as IncomeYear
			,FLOOR((i.EstimateCust+i.EstimateMate+i.EstimateOther)/10000) as Estimate
			,t.AngentEmpName as AngentEmpName  --介紹人
			,t.AngentEmpNo as AngentEmpNo  --員工代號
			,t.AngentUnitNo as AngentUnitNo  --單位代號			
			,CONVERT(date, getdate()) as LastUpdateDate--產製時間
			from skl_loan.dbo.flow_house f 
			inner join skl_loan.dbo.House_CustMain m on f.LoanKey=m.LoanKey
			inner join skl_loan.dbo.House_CustIncome i on m.LoanKey=i.LoanKey
			inner join skl_loan.dbo.House_Introduce t on t.LoanKey=m.LoanKey
			left join (
			  select 
				fh.CaseNO as CaseNO   --案號
				,MAX(tn.LMSLLD) as LMSLLD  --撥款日
				,SUM(CAST(tn.LMSFLA  as float))as LMSFLA  --撥款金額
			  from skl_loan.dbo.flow_house fh
			  inner join skl_loan.dbo.Book_Account ba on ba.LoanKey=fh.LoanKey
			  inner join skl_loan.dbo.House_CustMain m on fh.LoanKey=m.LoanKey
			  inner join #TempLNLMSP tn on m.CustNo= tn.LMSACN and ba.AccNo=tn.LMSAPN
			  group by fh.CaseNO						
			)tempLN ON tempLN.CaseNO=f.CaseNO
			where  ApproveDate >=DateAdd(M,-6,GetDate())

			drop table #TempLNLMSP

end