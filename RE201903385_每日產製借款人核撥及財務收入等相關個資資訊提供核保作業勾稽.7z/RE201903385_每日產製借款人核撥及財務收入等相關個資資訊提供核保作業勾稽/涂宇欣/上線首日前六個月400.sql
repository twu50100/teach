declare @SourceDB varchar(50)  select top 1 @SourceDB=SourceDB FROM [SKL_CORE].[dbo].[Core_QueryItem] 
declare @cmd nvarchar(MAX) set @cmd=''
set @cmd = N'select * from openquery(AS400,''select LMSLLD,LMSFLA,LMSACN,LMSAPN from '+@SourceDB+'.LA$LMSP'')'
exec(@cmd)