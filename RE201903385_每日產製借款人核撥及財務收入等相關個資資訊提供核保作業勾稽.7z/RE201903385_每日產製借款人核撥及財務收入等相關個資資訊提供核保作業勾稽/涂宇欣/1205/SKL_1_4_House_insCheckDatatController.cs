﻿using System;
using System.Web.Http;
using Gemfor.Mvc;
using System.Data;
using Gemfor.Util;
using Gemfor.Auth;
using App_Code;
using System.Net.Http;
using static App_Code.clsCommon;
using System.Collections.Generic;

namespace SKL_LOAN.Controllers.Api.eLoan.Query
{
    public class SKL_1_4_House_insCheckDatatController : BasePageController
    {


        clsDate g_clsDate = new clsDate();
        clsData g_clsData = new clsData();
        clsSelect g_clsSlt = new clsSelect();
        clsHouse g_clsHouse = new clsHouse();
                
        [HttpPost]
        public StdRet Init()
        {
            StdRet ret = new StdRet();
            HashMap Hm = new HashMap();
            try
            {
                DataSet ds = GetBranchList();
                Hm.Put("CreateBranchNo", ds.Tables["CreateBranch"]);
                Hm.Put("FlowBranchNo", ds.Tables["FlowBranch"]);
                Hm.Put("IsHeadOffice", g_clsSessionSecurity.IsHeadOffice);
                Hm.Put("BranchNo", g_clsSessionSecurity.BranchNo);
                Hm.Put("EmpNo", g_clsSessionSecurity.EmpNo);
                Hm.Put("RoleNo", g_clsSessionSecurity.RoleNo);
                ret.data = Hm;
            }
            catch (Exception ex)
            {
                ret.setRc(StdRet.RC.INTERNAL_ERR, ex.Message);
            }
            return ret;
        }

        /// <summary>
        /// 匯出excel查詢結果 add by jessie 2019/3/5
        /// </summary>
        /// <param name="cmd">查詢參數</param>
        /// <returns>Response</returns>
        public HttpResponseMessage Export_Excel([FromBody]SKL_8_3_QryAccess_Book_Cmd cmd)
        {
            if (!g_clsSessionSecurity.IsHeadOffice)
            {
                return null;
            }
            try
            {
                cmd.p_Row_S = "";
                cmd.p_Row_E = "";
                //取資料。使用和原查詢同方法。
                var dt = QryData_dt(cmd);

                //資料處理
                foreach (DataRow row in dt.Rows)
                {
                    if (row["FlowType"].ToString() == "Flow_House_CloseDoc")
                        row["CaseNO"] = "批覆書階段" + row["CaseNO"];

                    row["CreateBranchName"] = row["OriginBranchNo"].ToString() + row["CreateBranchName"].ToString();
                    row["CreateEmpName"] = row["CreateEmpNo"].ToString() + row["CreateEmpName"].ToString();
                    row["FlowEmpName"] = row["FlowEmpNo"].ToString() + row["FlowEmpName"].ToString();
                }

                //命名資料表，此值等同檔名與頁籤名。
                dt.TableName = "房貸對保作業進度查詢";

                #region 定義欄位與來源
                List<ExcelCells> cells = new List<ExcelCells>();
                cells.Add(new ExcelCells() { Seq = 1, CellName = "案件編號", CellValue = "CaseNO", CellWidth = 5000 });
                cells.Add(new ExcelCells() { Seq = 2, CellName = "授信方式", CellValue = "LoanWay", JsonConvertValue = "House_LoanWay", CellWidth = 4000 });
                cells.Add(new ExcelCells() { Seq = 3, CellName = "身分類別", CellValue = "CustType", JsonConvertValue = "Common_CustType" });
                cells.Add(new ExcelCells() { Seq = 4, CellName = "統編/身分證字號", CellValue = "CustId" });
                cells.Add(new ExcelCells() { Seq = 5, CellName = "授信戶名稱", CellValue = "CustName" });
                cells.Add(new ExcelCells() { Seq = 6, CellName = "進件日期", CellValue = "NewDate", CellWidth = 6000 });
                cells.Add(new ExcelCells() { Seq = 7, CellName = "進件單位", CellValue = "CreateBranchName", CellWidth = 6000 });
                cells.Add(new ExcelCells() { Seq = 8, CellName = "進件者", CellValue = "CreateEmpName", CellWidth = 4000 });
                cells.Add(new ExcelCells() { Seq = 9, CellName = "目前經辦(准駁)人員", CellValue = "FlowEmpName" });
                cells.Add(new ExcelCells() { Seq = 10, CellName = "案件狀態", CellValue = "FlowPreviousDecisionDesc" });
                cells.Add(new ExcelCells() { Seq = 11, CellName = "案件審理狀況", CellValue = "CaseStatus" });
                cells.Add(new ExcelCells() { Seq = 12, CellName = "停留時間", CellValue = "FlowDuration", AddDataEnd = "天" });
                cells.Add(new ExcelCells() { Seq = 13, CellName = "擬貸金額", CellValue = "NewAmt", AddDataEnd = "仟元", ShowZero = false, CellWidth = 5000 });
                #endregion

                var common = new clsCommon();
                return common.Export_Excel_SingleSheet(dt, cells);
            }
            catch (Exception e)
            {
                throw e;
            }
        }


        //送件單位&目前經辦(准駁)人員所屬單位
        private DataSet GetBranchList()
        {
            //先不考慮流程版本問題
            DataSet dsRoleId = new DataSet();
            String mIsBeginRoleid = "";//起案的角色
            String mAllRoleid = "";//流程所有的角色

            //取得最新流程對應的安控角色   
            String sqlSelect = @"SELECT RoleMapRoleidSecurity 
                                from dbo.FN_Flow_NodeStatus ('Flow_House_Book','') 
                                where statusIsBegin=1 
                                Group by RoleMapRoleidSecurity;
                                SELECT RoleMapRoleidSecurity 
                                from dbo.FN_Flow_NodeStatus ('Flow_House_Book','') 
                                where StatusId < 999
                                Group by RoleMapRoleidSecurity";
            HashMap input = new HashMap();
            dsRoleId = DBUtil.QryDataSet(sqlSelect, input);
            if (dsRoleId.Tables.Count > 0)
            {
                mIsBeginRoleid = g_clsData.DataTableToSpiltString(dsRoleId.Tables[0], "RoleMapRoleidSecurity", ",");
                mAllRoleid = g_clsData.DataTableToSpiltString(dsRoleId.Tables[1], "RoleMapRoleidSecurity", ",");
            }
            else
            {
                throw new Exception("無法取得送件單位!");
            }


            //使用安控API取得目前的角色人員清單
            clsWSSecurity wsSecurity = new clsWSSecurity();
            wsSecurityParam param = new wsSecurityParam();
            param.appNo = System.Web.Configuration.WebConfigurationManager.AppSettings["AppNo"];
            param.apiMethod = clsWSSecurity.apiMethod.QueryRoleEmpDt.ToString();
            Boolean execWs = false; String msErrMsg = ""; DataTable dtRoleEmpAll = new DataTable();
            execWs = wsSecurity.callWebAPI(param, ref msErrMsg, ref dtRoleEmpAll);
            if (execWs == false) { throw new Exception(msErrMsg); };
            //回傳角色對應的單位資料
            DataSet dsReturn = new DataSet();
            if (dtRoleEmpAll.Rows.Count > 0)
            {
                DataRow[] mdr = dtRoleEmpAll.Select("RoleNo in (" + mIsBeginRoleid + ")");
                DataView dataView = mdr.CopyToDataTable().DefaultView;
                dsReturn.Tables.Add(dataView.ToTable(true, "BranchNo", "BranchName"));
                dsReturn.Tables[0].TableName = "CreateBranch";

                mdr = dtRoleEmpAll.Select("RoleNo in (" + mAllRoleid + ")");
                dataView = mdr.CopyToDataTable().DefaultView;
                dsReturn.Tables.Add(dataView.ToTable(true, "BranchNo", "BranchName"));
                dsReturn.Tables[1].TableName = "FlowBranch";
            }
            return dsReturn;
        }


        /// <summary>
        /// 查詢Data 取值
        /// p_CreateBranchNo;     送件單位
        /// p_CreateDate_S;       進件日期起日
        /// p_CreateDate_E;       進件日期迄日  
        /// p_LoanWay;            授信方式
        /// p_CustType;           身分別
        /// p_CustId;             客戶統編/身分證字號
        /// p_Guar_CustId;        保證人統編/身分證字號
        /// p_CaseNo;             案件編號 
        /// p_FlowBranchNo;      目前承辦(准駁)人員所屬分行別
        /// p_FlowEmpNo;         目前承辦(准駁)人員的員編
        /// p_LoanCloseStatus;    案件狀態
        /// p_LoanCloseDecision;  案件狀態    
        /// p_Row_S;              分頁筆數起
        /// p_Row_E;              分頁筆數迄       
        /// </summary>
        /// <param name="cmd"></param>
        /// <returns></returns>
        [HttpPost]
        public StdRet DataQry([FromBody]SKL_8_3_QryAccess_Book_Cmd cmd)
        {
            StdRet ret = new StdRet();
            HashMap Hm = new HashMap();
            try
            {
                Hm.Put("QryAccess", QryData_dt(cmd));
                ret.data = Hm;
            }
            catch (Exception ex)
            {
                ret.setRc(StdRet.RC.INTERNAL_ERR, ex.Message);
            }
            return ret;
        }

        /// <summary>
        /// 查詢Data 取值
        /// p_CreateBranchNo;     送件單位
        /// p_CreateDate_S;       進件日期起日
        /// p_CreateDate_E;       進件日期迄日  
        /// p_LoanWay;            授信方式
        /// p_CustType;           身分別
        /// p_CustId;             客戶統編/身分證字號
        /// p_Guar_CustId;        保證人統編/身分證字號
        /// p_CaseNo;             案件編號 
        /// p_FlowBranchNo;      目前承辦(准駁)人員所屬分行別
        /// p_FlowEmpNo;         目前承辦(准駁)人員的員編
        /// p_LoanCloseStatus;    案件狀態
        /// p_LoanCloseDecision;  案件狀態    
        /// p_Row_S;              分頁筆數起
        /// p_Row_E;              分頁筆數迄       
        /// </summary>
        /// <param name="cmd"></param>
        /// <returns></returns>
        private DataTable QryData_dt(SKL_8_3_QryAccess_Book_Cmd cmd)
        {
            DataSet ds = new DataSet();
            HashMap Input = new HashMap();
            HashMap Output = new HashMap();
            String Count = "";


            Input.Put("p_CreateBranchNo", (cmd.p_CreateBranchNo == null) ? "" : cmd.p_CreateBranchNo);
            Input.Put("p_CreateDate_S", (cmd.p_CreateDate_S == null) ? "" : g_clsDate.getDate_West(cmd.p_CreateDate_S));
            Input.Put("p_CreateDate_E", (cmd.p_CreateDate_E == null) ? "" : g_clsDate.getDate_West(cmd.p_CreateDate_E));
            Input.Put("p_CreateEmpNo", (cmd.p_CreateEmpNo == null) ? "" : cmd.p_CreateEmpNo);


            Input.Put("p_LoanWay", (cmd.p_LoanWay == null) ? "" : cmd.p_LoanWay);
            Input.Put("p_CustType", (cmd.p_CustType == null) ? "" : cmd.p_CustType);
            Input.Put("p_CustId", (cmd.p_CustId == null) ? "" : cmd.p_CustId);
            Input.Put("p_Guar_CustId", (cmd.p_Guar_CustId == null) ? "" : cmd.p_Guar_CustId);
            Input.Put("p_CaseNo", (cmd.p_CaseNo == null) ? "" : cmd.p_CaseNo);
            Input.Put("p_FlowBranchNo", (cmd.p_FlowBranchNo == null) ? "" : cmd.p_FlowBranchNo);
            Input.Put("p_FlowEmpNo", (cmd.p_FlowEmpNo == null) ? "" : cmd.p_FlowEmpNo);
            Input.Put("p_LoanCloseStatus", (cmd.p_LoanCloseStatus == null) ? "" : cmd.p_LoanCloseStatus);


            Input.Put("p_LoanCloseDecision", "");

            Input.Put("p_Row_S", cmd.p_Row_S);
            Input.Put("p_Row_E", cmd.p_Row_E);


            Output.Put("r_TotalNum", Count);
            try
            {
                ds = DBUtil.ExecSP("dbo.USP_Book_QryAccess", Input, Output);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    ds.Tables[0].Columns.Add("NewDate", typeof(String));
                    ds.Tables[0].Columns.Add("NewAmt", typeof(String));
                    ds.Tables[0].Columns.Add("TotalNum", typeof(String));
                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {
                        ds.Tables[0].Rows[i]["TotalNum"] = Output.Get("r_TotalNum").ToString();
                        ds.Tables[0].Rows[i]["NewDate"] = g_clsDate.TransFormDataTime(ds.Tables[0].Rows[i]["CreateDate"].ToString());//FlowCreateDate
                        Int32 iTemp = 0;
                        Double dTemp = 0;
                        Double.TryParse(ds.Tables[0].Rows[i]["ApplyAmount"].ToString(), out dTemp);
                        //Double.TryParse((dTemp / 1000).ToString(), out dTemp);

                        ds.Tables[0].Rows[i]["NewAmt"] = Math.Round(dTemp).ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return ds.Tables[0];
        }

        /// <summary>
        /// 案件編號 and 鑑價編號 點選超連結存入Session
        /// CustID
        /// CaseNo
        /// LoanKey
        /// FlowType
        /// LoanCloseStatus
        /// BusType
        /// VersionFlowType
        /// FlowStatus
        /// CreateRoleNo
        /// CreateEmpNo
        /// CreateBranchNo
        /// CreateDate
        /// </summary>
        /// <param name="cmd"></param>
        /// <returns></returns>
        public StdRet Insert_Session([FromBody]SKL_8_3_QryAccess_Book_Cmd cmd)
        {
            StdRet ret = new StdRet();
            try
            {

                //將案件資訊放入session
                g_clsSessionCaseData.BusType = cmd.BusType;
                g_clsSessionCaseData.CaseNo = cmd.CaseNo;
                g_clsSessionCaseData.CreateBranchNo = cmd.CreateBranchNo;
                g_clsSessionCaseData.CreateEmpNo = cmd.CreateEmpNo;
                g_clsSessionCaseData.CreateRoleNo = cmd.CreateRoleNo;
                g_clsSessionCaseData.FlowStatus = cmd.FlowStatus;
                g_clsSessionCaseData.LoanCloseStatus = cmd.LoanCloseStatus;
                g_clsSessionCaseData.LoanKey = cmd.LoanKey;
                g_clsSessionCaseData.VersionFlowType = cmd.VersionFlowType;
                g_clsSessionCaseData.CustID = cmd.CustID;
                g_clsSessionCaseData.FlowType = cmd.FlowType;
                g_clsSessionCaseData.Entry = "Q";
                g_clsSessionCaseData.LoanWay = cmd.LoanWay;

                //取出此案是否為貸後授變
                String m_strIsAfterChange = "";
                m_strIsAfterChange = g_clsHouse.getIsAfterChange(g_clsSessionCaseData.LoanKey);
                g_clsSessionCaseData.IsAfterChange = m_strIsAfterChange;
                g_clsSessionCaseData.CustCondition1 = m_strIsAfterChange;
                g_clsSessionCaseData.CustCondition2 = "";
                g_clsSessionCaseData.CustCondition3 = "";

                HashMap hmapOut = new HashMap();
                //顯示成功訊息並且導入XXX頁(有TREE的那一頁)
                //如何取得TREE
                DataTable dt = new DataTable();
                dt = g_clsFlow.getLoanTree(g_clsSessionCaseData);

                hmapOut.Put("Tree", dt);
              
             
                //預設頁
                Int32 mFlowStatus = Int32.Parse(g_clsSessionCaseData.FlowStatus);

                
                //以下為關卡預設頁
                if (cmd.LoanWay != "07")
                {
                    hmapOut.Put("TreeDefaultPage", "eLoan\\InputCase\\Book\\SKL_5_1_Book_LoanContractView.html");                   

                }
                else 
                {

                    if (m_strIsAfterChange == "0" )
                    {
                        hmapOut.Put("TreeDefaultPage", "eLoan\\InputCase\\Book\\SKL_5_1_Book_LoanContractView.html");

                    }
                    
                    //貸後授變
                    if (m_strIsAfterChange == "1")
                    {
                        hmapOut.Put("TreeDefaultPage", "eLoan\\InputCase\\Book\\SKL_5_8_Book_AfterChangeDocView.html");

                    }                  
                    
                }

                
                ret.data = hmapOut;


            }
            catch (Exception ex)
            {
                ret.setRc(StdRet.RC.INTERNAL_ERR, ex.Message);
            }

            return ret;
        }

        public class SKL_8_3_QryAccess_Book_Cmd
        {
            public String p_CreateEmpNo;
            public String p_CreateBranchNo;         //送件單位
            public String p_CreateDate_S;           //進件日期起日
            public String p_CreateDate_E;           //進件日期迄日  
            public String p_LoanWay;                //授信方式
            public String p_CustType;               //身分別
            public String p_CustId;                 //客戶統編/身分證字號
            public String p_Guar_CustId;            //保證人統編/身分證字號
            public String p_CaseNo;                 //案件編號 
            public String p_FlowBranchNo;          //目前承辦(准駁)人員所屬分行別
            public String p_FlowEmpNo;             //目前承辦(准駁)人員的員編
            public String p_LoanCloseStatus;        //案件狀態
            public String p_LoanCloseDecision;      //案件審理狀況  
            public String p_Row_S;                  //分頁筆數起
            public String p_Row_E;                  //分頁筆數迄

            public String CustID;                  //客戶統編/身分證字號
            public String CaseNo;                  //案件編號 
            public String LoanKey;                 //
            public String FlowType;                //
            public String LoanCloseStatus;         //案件狀態
            public String BusType;                 //
            public String VersionFlowType;         //
            public String FlowStatus;              //
            public String CreateRoleNo;            //
            public String CreateEmpNo;             //
            public String CreateBranchNo;          //
            public String CreateDate;              //
            public String LoanWay;                 //授信方式
        }
    }
}
