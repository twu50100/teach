USE [SKL_LOAN]
GO
/****** Object:  StoredProcedure [dbo].[USP_House_QryInsCheckData_eloan]    Script Date: 2019/11/12 上午 09:57:31 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
  -- Author:EC0416
  -- Create date: 2019/11/11
  -- Description:	查詢上線首日之前六個月的個資相關資訊已提供核保作業勾稽資料。
-- =============================================
CREATE PROCEDURE [dbo].[USP_House_QryInsCheckData_eloan]
     @p_CustNo varchar(20)--放款案號
	,@p_CustId varchar(20)--借款人身分證字號
	,@p_CustName nvarchar(70)--借款人姓名
	,@p_ApproveDate varchar(8)--核貸日
	,@p_IncomeSalary varchar(13)--薪資收入
	,@p_IncomeWork varchar(13)--執行業務收入
	,@p_IncomeBusiness varchar(13)--營業收入
	,@p_IncomeRant varchar(13)--租金收入
	,@p_IncomeInterest varchar(13)--利息收入
	,@p_IncomeOther varchar(13)--其他收入
	,@p_IncomeYear varchar(13)--借款人年收入
	,@p_EstimateIncomeYear varchar(20)--本案推估年收入
	,@p_AngentEmpName nvarchar(80)--介紹人
	,@p_AngentEmpNo varchar(6)--員工代號
	,@p_AngentUnitNo varchar(6)--單位代號
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    --1.	建立表格
	CREATE TABLE #tmpTable
	(
	 CaseNO varchar(20)
	--,LoanKey uniqueidentifier
	,CustId varchar(20)
	,CustName nvarchar(70)
	,CustNo varchar(10)
	,ApproveDate varchar(8)
	,CheckAmount varchar(18)
	,IncomeSalary  varchar(13)
	,IncomeWork  varchar(13)
	,IncomeBusiness varchar(13)
	,IncomeRant varchar(13)
	,IncomeInterest varchar(13)
	,IncomeOther varchar(13)
	,IncomeYear varchar(13)
	,EstimateIncomeYear varchar(20)
	,AngentEmpName nvarchar(80)
	,AngentEmpNo varchar(6)
	,AngentUnitNo varchar(6)
	,AccNo varchar(3)
	)
	Begin
			--篩選ELAON案件核貸日上線首日六個月內資料
			INSERT INTO  #tmpTable 
			select 
			f.CaseNO,--放款案號
			--f.LoanKey,
			m.CustId,--借款人身分證字號
			m.CustName,--借款人姓名
			m.CustNo,--戶號
			CONVERT(date, m.ApproveDate) as ApproveDate,--核貸日
			m.CheckAmount as CheckAmount,
			i.IncomeSalary as IncomeSalary,
			i.IncomeWork as IncomeWork,
			i.IncomeBusiness as IncomeBusiness,
			i.IncomeRant  as IncomeRant ,
			i.IncomeInterest as IncomeInterest,
			i.IncomeOther as IncomeOther,
			i.IncomeYear as IncomeYear,
			(i.EstimateCust+i.EstimateMate+i.EstimateOther) as EstimateIncomeYear,
			t.AngentEmpName as AngentEmpName,--介紹人
			t.AngentEmpNo as AngentEmpNo,--員工代號
			t.AngentUnitNo as AngentUnitNo,--單位代號
			b.AccNo as AccNo--額度編號
			from skl_loan.dbo.flow_house f 
			inner join skl_loan.dbo.House_CustMain m on f.LoanKey=m.LoanKey
			inner join skl_loan.dbo.House_CustIncome i on m.LoanKey=i.LoanKey
			inner join skl_loan.dbo.House_Introduce t on t.LoanKey=m.LoanKey
			inner join Book_Account b on b.LoanKey=f.LoanKey
			where  ApproveDate <=DateAdd(M,-6,GetDate())

	end			


--drop table #tmpTable
--select*from #tmpTable
	Begin
		declare @SourceDB varchar(50)  select top 1 @SourceDB=SourceDB FROM [SKL_CORE].[dbo].[Core_QueryItem] 
		declare @cmd nvarchar(MAX) set @cmd=''
		declare @GetDate varchar(10) set @GetDate = convert(varchar(8),dateadd(m,-6,getdate()),112)
		declare @EtlDate varchar(8) set @EtlDate = convert(varchar(8),dateadd(m,0,getdate()),112)

		create table #TempLNLMSP(
		 LMSLLD varchar(8)
		,LMSFLA varchar(15)
		,LMSACN varchar(20)
		,LMSAPN varchar(3)
		)

		--篩選AS400撥款日上線首日6個月內資料
		set @cmd = N''+
		' insert into #TempLNLMSP'+
		' select * from openquery(AS400,''select LMSLLD,LMSFLA,LMSACN,LMSAPN from '+@SourceDB+'.LA$LMSP'
		+' where LMSLLD between '   + convert(varchar(8),@GetDate) + ' and ' + @EtlDate + ''')'
		print(@cmd)
	    exec(@cmd)

--drop table #TempLNLMSP
--select*from #TempLNLMSP
		
		select
		#tmpTable.CaseNO,--放款案號
		--f.LoanKey,
		#tmpTable.CustId,--借款人身分證字號
		#tmpTable.CustName,--借款人姓名
		#tmpTable.CustNo,--戶號
		CONVERT(date, #tmpTable.ApproveDate) as ApproveDate,--核貸日
		#tmpTable.CheckAmount as CheckAmount,--核貸金額
		temp.LMSLLD as LMSLLD,--撥款日
		temp.LMSFLA as LMSFLA,--撥款金額
		FLOOR(#tmpTable.IncomeSalary/10000) as IncomeSalary,
		FLOOR(#tmpTable.IncomeWork/10000) as IncomeWork,
		FLOOR(#tmpTable.IncomeBusiness /10000 )as IncomeBusiness,
		FLOOR(#tmpTable.IncomeRant /10000) as IncomeRant ,
		FLOOR(#tmpTable.IncomeInterest /10000 )as IncomeInterest,
		FLOOR(#tmpTable.IncomeOther /10000 )as IncomeOther,
		FLOOR(#tmpTable.IncomeYear/10000) as IncomeYear,
		FLOOR((#tmpTable.EstimateIncomeYear)/10000) as EstimateIncomeYear,
		#tmpTable.AngentEmpName as AngentEmpName,--介紹人
		#tmpTable.AngentEmpNo as AngentEmpNo,--員工代號
		#tmpTable.AngentUnitNo as AngentUnitNo,--單位代號
		#tmpTable.AccNo as AccNo--額度編號		
		from #tmpTable
		inner join (
		select
		#tmpTable.CustNo
		,MAX(#TempLNLMSP.LMSLLD) as LMSLLD
		,SUM(CAST(#TempLNLMSP.LMSFLA  as float))as LMSFLA
		from #tmpTable 
		inner join #TempLNLMSP on #tmpTable.CustNo= #TempLNLMSP.LMSACN
		where  #TempLNLMSP.LMSAPN=#tmpTable.AccNo
		group by #tmpTable.CustNo,#TempLNLMSP.LMSFLA
		)temp on temp.CustNo=#tmpTable.CustNo
	
	end

end