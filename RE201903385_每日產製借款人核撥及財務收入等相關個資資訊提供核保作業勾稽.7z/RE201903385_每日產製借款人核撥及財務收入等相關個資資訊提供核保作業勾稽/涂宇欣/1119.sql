	select
		''
		,''
		,''
		,''
		,''
		,''
		,''
		,#TempLNLMSP.LMSLLD--撥款日
		,#TempLNLMSP.LMSFLA--撥款金額
		,''
		,''
		,''
		,''
		,''
		,''
		,''
		,''
		,''
		,''
		,''
		,''
		from #TempLNLMSP	
		inner join skl_loan.dbo.Temp_House_CustMain m on m.CustNo=#TempLNLMSP.LMSACN
		inner join skl_loan.dbo.temp_Book_Account ba on  ba.AccNo=#TempLNLMSP.LMSAPN	
		inner join skl_loan.dbo.Temp_Flow_House fh on fh.LoanKey=m.LoanKey
	    union
		select
		 GETDATE() --資料日期(年月日)
		,m.LoanKey
		,m.CustNo--借款人戶號
		,m.CustName--借款人姓名
		,f.CaseNO--放款案號
		,m.ApproveDate as ApproveDate--核貸日
		,m.CheckAmount as CheckAmount --核貸金額
		,''
		,''
		,FLOOR(i.IncomeSalary/10000) as IncomeSalary
		,FLOOR(i.IncomeWork/10000) as IncomeWork
		,FLOOR(i.IncomeBusiness/10000) as IncomeBusiness
		,FLOOR(i.IncomeRant/10000)  as IncomeRant 
		,FLOOR(i.IncomeInterest/10000) as IncomeInterest
		,FLOOR(i.IncomeOther/10000) as IncomeOther
		,FLOOR(i.IncomeYear/10000) as IncomeYear
		,FLOOR((i.EstimateCust+i.EstimateMate+i.EstimateOther)/10000) as Estimate
		,t.AngentEmpName as AngentEmpName  --介紹人
		,t.AngentEmpNo as AngentEmpNo  --員工代號
		,t.AngentUnitNo as AngentUnitNo  --單位代號			
		,getdate() as LastUpdateDate--產製時間
		from skl_loan.dbo.Temp_Flow_House f 
		inner join skl_loan.dbo.Temp_House_CustMain m on f.LoanKey=m.LoanKey
		inner join skl_loan.dbo.Temp_House_CustIncome i on m.LoanKey=i.LoanKey
		inner join skl_loan.dbo.Temp_House_Introduce t on t.LoanKey=m.LoanKey
		where m.ApproveDate =GetDate() 
		