
		declare @SourceDB1 varchar(50)  select top 1 @SourceDB1=SourceDB FROM [SKL_CORE].[dbo].[Core_QueryItem] 
		declare @cmd1 nvarchar(MAX) set @cmd1=''
		--當天資料
		declare @GetDate1 varchar(10) set @GetDate1 = convert(varchar(8),dateadd(m,0,getdate()),112)		
		
		create table #TempLNLMSP(
		 LMSLLD varchar(8)   --撥款日
		,LMSFLA varchar(15)  --撥款金額
		,LMSACN varchar(20)  --戶號
		,LMSAPN varchar(3)   --額度
		)

		set @cmd1 = N''+
		' insert into #TempLNLMSP'+
		'select * from openquery(AS400,'' select LMSLLD,LMSFLA,LMSACN,LMSAPN from '+@SourceDB1+'.LA$LMSP'
		+' where LMSLLD = '+  +@GetDate1+''')'
		print @cmd1
	    exec(@cmd1)
