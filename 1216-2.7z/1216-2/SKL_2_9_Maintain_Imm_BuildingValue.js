﻿var PAGE_SIZE = 10;
var PAGE_IDX = -1;
var PAGE_CNT = -1;
var EDIT_DATA = new Array();
var G_BuildMaterial = new Array();
var G_City = new Array();
var G_BuildingValue = new Array();

genData = function (Arg_Data) {
    //console.log(Arg_Data.data["Table"]);
    //console.log(Arg_Data.data["City"]);
    //console.log(Arg_Data.data["Paras_Adm_Material"]);
  
    G_BuildingValue = Arg_Data.data["Table"];
    G_City = Arg_Data.data["City"];
    G_BuildMaterial = Arg_Data.data["Paras_Adm_Material"];
    Material = Arg_Data.data["Paras_Adm_Material"];
    Material.unshift({ "ItemText": "请選擇", "ItemValue": "" });
    G_City.unshift({ "ItemText": "请選擇", "ItemValue": "" });
    BuildBox(Arg_Data.data["Paras_Adm_Material"], Arg_Data.data["City"]);
    TableBuild(Arg_Data.data["Table"]);

};

var BuildBox = function (Material,City) {

    $("#BuildBox").SexyBox({
        boxCtrl: [{
            ID: "Build",
            HeadForm: "BuildForm",
            HeadRow: [],
            Head: [],
            BodyForm: "BuildForm",
            BodyRow: [],
            Body: [
                {
                    Row: "2col",
                    ColumnClass: ["align_left required", "align_left"],
                    Ctrl: ["結構材質", { Type: "select", Text: "ItemText", Value: "ItemValue", Name: "MaterialCode", ID: "slcMaterialCode", Data: Material }]
                },
                {
                    Row: "2col",
                    ColumnClass: ["align_left required", "align_left "],
                    Ctrl: ["縣市",
                        {
                            f: function () {
                                var newDiv = $("<div></div>");
                      
                                newDiv.SexyDbSelect(City, "CityCode", "ItemText", "ItemValue");
                                //console.log(City, newDiv)
                                return newDiv;
                            }
                        }
                    ]
                },
                {
                    Row: "2col",
                    ColumnClass: ["align_left required", "align_left"],
                    // Ctrl: ["層次", { Type: "text", Name: "Storey", ID: "txtStorey", MaxLength: 9 }]
                    // simon add 20190328:原本層次欄位須改為區間輸入
                    Ctrl: ["層次"
                        , [
                        { Type: "text", Name: "StoreyStart", ID: "txtStoreyStart", MaxLength: 9 }
                        , "&nbsp;~&nbsp;"
                        , { Type: "text", Name: "StoreyEnd", ID: "txtStoreyEnd", MaxLength: 9 }
                        ]
                    ]
                },
                {
                    Row: "2col",
                    ColumnClass: ["align_left required", "align_left"],
                    Ctrl: ["造價", [{ Type: "text", Name: "Value", ID: "txtValue", MaxLength: 9}, "元"]]
                },
                {
                    Row: "2col",
                    ColumnClass: ["align_left required", "align_left"],
                    Ctrl: ["火險金額", [{ Type: "text", Name: "FireInsuranceValue", ID: "txtFireInsuranceValue", MaxLength: 9 }, "元"]]
                },
                {
                    Row: "2col",
                    ColumnClass: ["align_left", "align_left"],
                    Ctrl: ["狀態", { Type: "select", Text: "ItemText", Value: "ItemValue", Name: "Status", ID: "slcStatus", Data: Status }]
                },
                {
                    Row: "2col",
                    ColumnClass: ["align_left required", "align_left"],
                    Ctrl: ["版本日期"
                        , [
                        { Type: "datepicker", Name: "Version", ID: "Version" }
                        //, "<br \>"
                        //, "<br \>"
                        //, { Type: "checkbox", Name: "ckVersion", ID: "txtckVersion", Text: "ItemText", Value: "ItemValue", Data: Version }
                        //, { Type: "datepicker", Name: "Version_n", ID: "txtVersion_n"}
                        ]
                    ]
                },
            ],
            Foot:[
                     {
                         Row: "",
                         RowClass: "align_center",
                         Ctrl: [{ Type: "a", Data: "確定", Class: "button add",Action:[true], Event: Data_Save }]
                     }
            ]
        },
         {
             ID: "searchForm",
             BodyForm: "BuildForm",
             ChangeName:false,
             Body: [
                 {
                     Row: "col",
                     RowClass: "bg_gray",
                     Ctrl: [
                         [
                             "篩選條件 : 版本日期 ",
                              { Type: "datepicker", Name: "Version", ID: "SearchVersion" },
                             " 結構材質 ",
                              { Type: "select", Text: "ItemText", Value: "ItemValue", Name: "MaterialCode", ID: "SearchMaterialCode", Data: Material },
                             " 縣市 ",
                              { Type: "select", Text: "ItemText", Value: "ItemValue", Name: "SearchCityCode", ID: "SearchCityCode", Data: City },
                              { Type: "a", Data: "查詢", Class: "button add", Event: DataSearch }
                         ]
                     ]
                 }
             ],
         }
        ],

    });

}

var Status = [{ "ItemText": "啟用", "ItemValue": "1" }, { "ItemText": "停用", "ItemValue": "0" }]
//var Version = [{ "ItemText": "複製為新版本日期", "ItemValue": "1" }];


var TableBuild = function (Build) {

    var tableArg = {
        theadValue: [[
            { Text: "版本日期"},
            { Text: "CityCode", Style: { "display": "none" } },
            { Text: "縣市" },
            { Text: "MaterialCode", Style: { "display": "none" } },
            { Text: "結構材質" },
            { Text: "層次" },
            { Text: "hid_Value", Style: { "display": "none" } },
            { Text: "造價" },
            { Text: "hid_Fire", Style: { "display": "none" } },
            { Text: "火險金額" },
            { Text: "狀態" },
            { Text: "維護" }

        ]],
        tbodyValue: {
            Value: ["Version", "CityCode", "CityItem", "MaterialCode", "MaterialItem", "Storey", "Value",
                { t: function (e) { return "新台幣" + thousandSeparator(e["Value"]) + "元"; } }, "FireInsuranceValue",
                { t: function (e) { return "新台幣" + thousandSeparator(e["FireInsuranceValue"]) + "元"; } },
                { t: function (e) { return (e["Status"] == "1") ? "啟用" : "停用"; } }],
            Style: [{}, { "display": "none" }, {}, { "display": "none" }, {}, {}, { "display": "none" }, {}, { "display": "none" }, {}, {}, {}]
        },
        Data: Build,
        Style: {
            tbody_odd: "rowodd",
            tbody_even: "roweven"
        },
        tbodyEdit:
        {
            Ctrl:
                [
                    [  { Type: "label", ID: "uVersion", Name: "Version" }
                     , { Type: "hidden", ID: "Version_o", Name: "Version_o" }]
                    , [{ Type: "select", ID: "uCityCode", Name: "CityCode", Text: "ItemText", Value: "ItemValue", Data: G_City }
                     , { Type: "hidden", ID: "CityCode_o", Name: "CityCode_o" }]
                    , [{ Type: "select", ID: "uMaterialCode", Name: "MaterialCode", Text: "ItemText", Value: "ItemValue", Data: G_BuildMaterial }
                     , { Type: "hidden", ID: "MaterialCode_o", Name: "MaterialCode_o" }]
                    , [{ Type: "text", ID: "uStorey", Name: "Storey" }
                     , { Type: "hidden", ID: "Storey_o", Name: "Storey_o" }]
                    , { Type: "text", ID: "uValue", Name: "Value" }
                    , [{ Type: "text", ID: "uFireInsuranceValue", Name: "FireInsuranceValue" }, "元"]
                    , { Type: "select", ID: "uStatus", Name: "Status", Text: "ItemText", Value: "ItemValue", Data: Status }
                ],
        },
        Plugin: [

            { Event: EditFunc, UpdateEvent: saveData, Class: "button", Name: "修改", Tooltip: "修改" }

        ],
        PluginStyle: { "width": "150px", "text-align": "center" },
        PageSetting: {
            ShowPageCtrl: true,
            PageSize: PAGE_SIZE,
        },
        PluginSite: true
    };

    $("#scDataView").find("input").unbind('click');
    $("#scDataView").find("thead,tbody").remove();
    $("#scDataView").SexyTable(tableArg);
}

EditFunc = function (ArgData) {
    //console.info(ArgData);

    $("#uVersion").text(ArgData[0]);
    $("#Version_o").val(ArgData[0]);
    $("#uCityCode").val(ArgData[1]);
    $("#CityCode_o").val(ArgData[1]);
    $("#uMaterialCode").val(ArgData[3]);
    $("#MaterialCode_o").val(ArgData[3]);
    $("#uStorey").val(ArgData[5]);
    $("#Storey_o").val(ArgData[5]);
    $("#uValue").val(ArgData[6]);
    $("#uFireInsuranceValue").val(ArgData[8]);

    if (ArgData[10] == "啟用") {
        $("#uStatus").val("1");
    } else {
        $("#uStatus").val("0");
    }

};

// 修改按下確定
saveData = function () {

    var jsonData = $.valToJson($(this).closest("tr"))
    //console.log(jsonData);

	var DataArgs =
	{
		method: "post",
    	url: "SKL_2_9_Maintain_Imm_BuildingValue/update_BuildingValue",
		data: jsonData,
		oMethod: function (Data) {
		    SexyAlert("提示", G_Convert.msg("000003"), "OK", "OKONLY", function () {
		        DataSearch(1);
		        //TableBuild(Data.data["Table"]);
		      //  BuildBox(G_BuildMaterial, G_City);
		    });
		},
	};
	docCore.ajax(DataArgs, true, true);
}

//確定
var Data_Save = function (Arg) {
    //console.log(Arg);
    var jsonObj = Arg.data["boxData"];
    var id = Arg.data["oldBoxID"];
    
    var list = new Array();
    $.each($("select[name='CityCode|" + id + "']").find("option"),function (Idx, Item) {
            list.push($(Item).val());
   });

    jsonObj["CityCode"] = list.join(",");
    jsonObj["aryCityID"] = list.join("','");

    //if (jsonObj["ckVersion"] == 1) {
    //    jsonObj["ckVersion"] = true
    //} else {
    //    jsonObj["ckVersion"] = false
    //}

    jsonObj['Currency'] = "TWD";
    //console.log(jsonObj);

    var validList = [];
    // 資料驗證
    validList.push({ Field: "MaterialCode", FieldName: "結構材質", CheckType: "string", sEmpty: "false" });
    if (list.length <= 0) {
        validList.push({ Field: "CityCode", FieldName: "縣市", CheckType: "string", sEmpty: "false" });
    }
    //validList.push({ Field: "Storey", FieldName: "層次", CheckType: "pureintegerNotZero", sEmpty: "false", Length: "9" });
    validList.push({ Field: "StoreyStart", FieldName: "層次起", CheckType: "pureintegerNotZero", sEmpty: "false", Length: "9", MaxValue: jsonObj.StoreyEnd, TipMsg: { A5: "層次止需大於等於層次起！" } });
    validList.push({ Field: "StoreyEnd", FieldName: "層次止", CheckType: "pureintegerNotZero", sEmpty: "false", Length: "9" });
    validList.push({ Field: "Value", FieldName: "造價", CheckType: "pureintegerNotZero", sEmpty: "false", Length: "9" });
    validList.push({ Field: "FireInsuranceValue", FieldName: "火險金額", CheckType: "pureintegerNotZero", sEmpty: "false", Length: "9" });
    validList.push({ Field: "Version", FieldName: "版本日期", CheckType: "string", sEmpty: "false" });
    //if (jsonObj["ckVersion"]) {
    //    validList.push({ Field: "Version_n", FieldName: "新版本日期", CheckType: "string", sEmpty: "false" });
    //}
   
    var valid = $.FormValidation(jsonObj, validList);
    var errMsg = $.FormValidationErrorMessage().join("<br/>");
    var warnMsg = $.FormValidationWarningMessage().join("<br/>")
    if (valid) {

        var DataArgs =
        {
            url: "SKL_2_9_Maintain_Imm_BuildingValue/Save_BuildingValue",
            data: jsonObj,
            oMethod: function (Data) {
                SexyAlert("提示", G_Convert.msg("000011"), "OK", "OKONLY", function () {
                    BuildBox(G_BuildMaterial, G_City)
                    DataSearch();
                });
            },
        };
        docCore.ajax(DataArgs, true, true);
    }
    else {
        SexyAlert("提示", errMsg.length > 0 ? errMsg : warnMsg, "TIP", "OKONLY");
    }
}


//一開始取得頁面資料
function OrdersQry() {

	var DataArgs =
	{
		url: "SKL_2_9_Maintain_Imm_BuildingValue/init_BuildingValue",
		oMethod: genData,
	};
	docCore.ajax(DataArgs, true, true);

}


//將取回來的資料裡面日期重新格式化為 民國年/月/日
function reformatData(ArgData) {

	var newData = [];
	var arg_data = ArgData.data;
	var table = arg_data['Table'];

	$.each(table, function (index, data) {
		newData.push({
			CityCode: data['CityCode'],
			CityItem: data['CityItem'],
			DataSort: data['DataSort'],
			LastUpdateDate: fullDateToChinse(data['LastUpdateDate'])
		});
	});

	//console.log(newData);

	genData(newData);
}

//將西元日期轉成國曆
function fullDateToChinse(input_date) {

	//console.log(input_date);
	var date = new Date(input_date);

	var year = date.getFullYear() - 1911;
	var month = date.getMonth() + 1;
	var day = date.getDate();

	return year + "/" + leftPad(month, 2) + "/" + leftPad(day, 2);
}


// 位數補0
// 例如：
// var month = 2;
// console.log(leftPad(month,2)) // 02
function leftPad(val, length) {
	var str = '' + val;
	while (str.length < length) {
		str = '0' + str;
	}
	return str;
}

function thousandSeparator(nStr) {

    nStr += '';
    x = nStr.split('.');
    x1 = x[0];
    x2 = x.length > 1 ? '.' + x[1] : '';
    var rgx = /(\d+)(\d{3})/;
    while (rgx.test(x1)) {
        x1 = x1.replace(rgx, '$1' + ',' + '$2');
    }
    return x1 + x2;

}

var DataSearch = function (isGoPage) {
    var jsonData = $.valToJson("searchForm");
    jsonData["CityCode"] = $("#SearchCityCode").val();
    var DataArgs =
    {
        url: "SKL_2_9_Maintain_Imm_BuildingValue/BuildingValue_Qry",
        data:jsonData,
        oMethod: function (Arg) {
           // G_City = Arg.data["City"];
            TableBuild(Arg.data["Table"]);
            $("[id^=slcMaterialCode]").SexySelectValChange("");
            $("[name^=CityCode]").find("option").remove();
            $("[id^=txtStorey]").val("");
            $("[id^=txtValue]").val("");
            $("[id^=txtFireInsuranceValue]").val("");
            $("[id^=Version]").val("");
            //$("[name^=ckVersion]").prop("checked", false);
            $("[id^=slcStatus]").SexySelectValChange(1);
            //$("[id^=txtVersion_n]").val("");
            if (isGoPage != 1) {
                $("#scDataView").SexyPageCtrl(Arg.data["Table"].length, 10, null, "scDataView", 1);
            }
        },
    };
    docCore.ajax(DataArgs, true, true);
}

$(document).ready(function () {
    OrdersQry();

    $("#btnConfirm").click(function () {

        var jsonData = FormDataToJSON("formData");

        var cities = [];
        $("#city_right option").each(function (index, data) {
            
            cities.push(data.value);
        });
        
        //if ($("#ckVersion").prop("checked")) {
        //    jsonData['ckVersion'] = true;
        //} else {
        //    jsonData['ckVersion'] = false;
        //}

        jsonData['aryCityID'] = cities;
        jsonData['Currency'] = "TWD";
        
        //console.log(jsonData);

		var DataArgs =
		{
			method: "post",
	    	url: "SKL_2_9_Maintain_Imm_BuildingValue/Save_BuildingValue",
			data: jsonData,
			oMethod: DataSearch,
			eMethod: showError
		};
		docCore.ajax(DataArgs, true, true);
    });

});