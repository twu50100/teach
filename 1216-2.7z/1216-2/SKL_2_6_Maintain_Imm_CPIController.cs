﻿using System;
using System.Web.Http;
using Gemfor.Mvc;
using System.Data;
using Gemfor.Util;
using Gemfor.Auth;
using App_Code;
using System.Collections;
using System.Web;
using System.Collections.Generic;
using System.IO;
using static SKL_LOAN.Controllers.Api.eLoan.Manage.Book.SKL_5_1_Maintain_Book_DocDataController;
using NPOI.SS.UserModel;
using System.Data.Common;

namespace SKL_LOAN.Controllers.Api.eLoan.Manage.Imm
{
    /// <summary>
    /// 物價指數表維護... 
    /// </summary>
    public class SKL_2_6_Maintain_Imm_CPIController : BasePageController
    {

        /// <summary>
        /// 物價指數表維護... 
        /// 初始化
        /// </summary>
        /// <returns>物價指數表維護　資料</returns>
        [HttpPost]
        public StdRet init_CPI()
        {
            StdRet ret = new StdRet();

            try
            {
                HashMap hmapOut = new HashMap();
                hmapOut.Put("CPI", getCPI());

                ret.data = hmapOut;
            }
            catch (Exception e)
            {
                ret.setRc(StdRet.RC.INTERNAL_ERR, e.Message);
            }

            return ret;
        }

        /// <summary>
        /// add by jessie 2018/04/04
        /// 物價指數表維護... 
        /// 查詢／篩選條件
        /// </summary>
        /// <param name="cmd">
        /// Year 基期-年 &#13;
        /// Month 基期-月 &#13;
        /// </param>
        /// <returns>物價指數表維護　資料</returns>
        [HttpPost]
        public StdRet Maintain_CL_StkNo_Qry([FromBody]CPI_Cmd cmd)
        {
            StdRet ret = new StdRet();
            if (cmd == null)
            {
                ret.setRc(StdRet.RC.INTERNAL_ERR, "請輸入參數值 cmd！");
                return ret;
            }

            try
            {
                HashMap hmapOut = new HashMap();
                hmapOut.Put("CPI", getCPI(cmd));

                ret.data = hmapOut;
            }
            catch (Exception e)
            {
                ret.setRc(StdRet.RC.INTERNAL_ERR, e.Message);
            }

            return ret;
        }
        /// <summary>
        /// 物價指數表維護... 
        /// 新增
        /// </summary>
        /// <param name="cmd">
        /// Year 基期-年 &#13;
        /// Month 基期-月 &#13;
        /// CPI 指數 &#13;
        /// Status 狀態(1:啟用,0:停用) &#13;
        /// </param>
        /// <returns>物價指數表維護　資料</returns>
        public StdRet Save_CPI([FromBody]CPI_Cmd cmd)
        {
            StdRet ret = new StdRet();
            DataTable dt = new DataTable();
            if (cmd == null)
            {
                ret.data = "cmd is null";
            }
            else
            {
                string strMsg = " 基期重複，請確認後重新輸入";
                try
                {
                    if (count_CPI(cmd) > 0)
                    {
                        ret.setRc(StdRet.RC.INTERNAL_ERR, strMsg);
                    }
                    else
                    {
                        dt = doInsert_CPI(cmd);
                    }

                    HashMap hmapOut = new HashMap();
                    hmapOut.Put("CPI", dt);

                    ret.data = hmapOut;
                }
                catch (Exception e)
                {
                    if (e.Message.IndexOf("重複的索引鍵") < 0)
                        strMsg = e.Message;

                    ret.setRc(StdRet.RC.INTERNAL_ERR, strMsg);
                }
            }

            return ret;
        }

        /// <summary>
        /// 讀取上傳excel文件 并新增表數據 add by jessie 2018/4/20
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public StdRet Upload_ExcelFileToInsert() {
            StdRet m_ret = new StdRet();
            clsFtp ftp = new clsFtp();
            clsLog.RESULT_TYPE ResultType = clsLog.RESULT_TYPE.Success;
            CPI_Cmd cmd = new CPI_Cmd();

            string m_strMsg;

            HashMap m_hm = new HashMap();
            IWorkbook m_workbook;
            if (ftp.ReadExcel(out m_strMsg, out m_workbook))
            {
                m_hm = InsertTableByExcel(m_workbook);
            }
            if (m_strMsg != null)
            {
                string[] m_msg = m_strMsg.Split(',');
                foreach (var item in m_msg)
                {
                    if (!string.IsNullOrEmpty(item))
                    {
                        if (item == "000086")
                        {
                            m_hm.Put("CoverItem", "000086");
                        }
                        else
                        {
                            m_hm.Put("ErrorMsg", item);
                        }
                    }
                }
            }
            m_ret.data =  m_hm;

            return m_ret;
        }
        private HashMap InsertTableByExcel(IWorkbook p_workbook)
        {
            HashMap m_hm = new HashMap();
            string m_strInsrtCPI = "";
            string m_strDeleteSql = "";

            // 判斷語句是否執行
            bool isExecFlag = true;
            DbConnection m_conn = DBUtil.GetConn();
            m_conn.Open();
            DbTransaction m_tran = m_conn.BeginTransaction();
        
            try {
                // 判斷是否只有一個sheet
                if (p_workbook.NumberOfSheets == 1)
                {
                    //取得第一個工作表
                    ISheet m_sheet = p_workbook.GetSheetAt(0);
                    if (m_sheet.SheetName == "稅務專用")
                    {
                        // 從第5列開始寫入數據
                        int m_iRow = 4;
                        int m_rowNo = m_sheet.LastRowNum;
                        for (int J = m_iRow; J < m_rowNo; J++)
                        {
                            IRow m_row = m_sheet.GetRow(J);
                            // 先判斷當前行是否是空行 
                            if (!m_row.GetCell(0).ToString().StartsWith("註"))
                            {
                                Double m_double;
                                if (m_row.GetCell(0).ToString() != "" && Double.TryParse(m_row.GetCell(0).ToString(), out m_double))
                                {
                                    string m_strYear = m_row.GetCell(0).ToString();
                                    for (int k = 1; k < 13; k++)
                                    {                                        
                                        if (m_row.GetCell(k).ToString() != "")
                                        {
                                            if (Double.TryParse(m_row.GetCell(k).ToString(), out m_double))
                                            {                                               
                                                m_strInsrtCPI += @" insert into Maintain_Imm_CPI"
                                                                 + " select  " + m_strYear + "," +
                                                                 k + ", " + m_row.GetCell(k).ToString() +
                                                                 ",'1','sys' ,'sys' ,'sys',getdate() ";
                                            }
                                            else
                                            {
                                                m_hm.Put("CoverItem", "000086");

                                                isExecFlag = false;

                                                break;
                                            }
                                        }
                                    }

                                    // 跳出第一層迴圈
                                    if (!isExecFlag)
                                    {
                                        break;
                                    }
                                }
                                else
                                {
                                    m_hm.Put("CoverItem", "000086");
                                    isExecFlag = false;

                                    break;
                                }
                            }
                            else
                            {
                                // 若是空行則跳出組字串的迴圈
                                break;
                            }                            
                        }                       
                    }
                    else
                    {
                       m_hm.Put("CoverItem", "000086");

                        isExecFlag = false;
                    }
                }
                else
                {
                    m_hm.Put("CoverItem", "000086");

                    isExecFlag = false;
                }

                //  對於拼好的sql語句 做出刪除與新增操作
                if (m_strInsrtCPI != "" && isExecFlag)
                {
                    m_strDeleteSql = @"delete from Maintain_Imm_CPI";
                    DBUtil.ExecNonQry(m_strDeleteSql, null, m_tran);
                    DBUtil.ExecNonQry(m_strInsrtCPI, null, m_tran);
                    m_tran.Commit();
                }

            } catch (Exception ex) {

                m_tran.Rollback();
                m_hm.Put("ErrorMsg", ex.Message);
            }
            finally
            {
                m_conn.Close();
                m_tran.Dispose();
                m_conn.Dispose();
            }

            return m_hm;
        }

        /// <summary>
        /// 物價指數表維護... 
        /// 更新
        /// </summary>
        /// <param name="cmd">
        /// Year 基期-年 &#13;
        /// Year\_o 基期-年\_原值 &#13;
        /// Month 基期-月 &#13;
        /// Month\_o 基期-月\_原值 &#13;
        /// CPI 指數 &#13;
        /// Status 狀態(1:啟用,0:停用) &#13;
        /// </param>
        /// <returns>物價指數表維護　資料</returns>
        public StdRet update_CPI([FromBody]CPI_Cmd cmd)
        {
            StdRet ret = new StdRet();
            DataTable dt = new DataTable();

            if (cmd == null)
            {
                ret.data = "cmd is null";
            }
            else
            {
                string strMsg = " 基期重複，請確認後重新輸入";
                try
                {
                    if ((cmd.Year != cmd.Year_o && cmd.Month != cmd.Month_o))
                    {
                        if (count_CPI(cmd) > 0)
                        {
                            ret.setRc(StdRet.RC.INTERNAL_ERR, " * 資料重複，請查明！");
                        }
                    }
                    else
                    {
                        dt = doUpdate_CPI(cmd);
                    }

                    HashMap hmapOut = new HashMap();
                    hmapOut.Put("CPI", dt);

                    ret.data = hmapOut;
                }
                catch (Exception e)
                {
                    if (e.Message.IndexOf("重複的索引鍵") < 0)
                        strMsg = e.Message;

                    ret.setRc(StdRet.RC.INTERNAL_ERR, strMsg);
                }
            }

            return ret;
        }

        private DataTable getCPI([FromBody]CPI_Cmd cmd = null)
        {
            DataTable dtbOut = new DataTable();
            int m_TotalNum = 0;

            string strSql = @"  SELECT 
                                    LastUpdateRoleNo
	                                ,LastUpdateEmpNo
	                                ,LastUpdateBranchNo
                                    ,Convert(varchar, LastUpdateDate ,20)as LastUpdateDate
	                                ,Year
	                                ,Month
	                                ,CPI
	                                ,Status
                                FROM 
                                    Maintain_Imm_CPI m
                                {0}
                                ORDER BY 
                                    Year DESC, Month
                                ;";
            try
            {
                HashMap inputParam = new HashMap();
                string m_strWhere = "";

                if (cmd != null)
                {
                    inputParam = getInputParam(cmd);
                    ArrayList al = new ArrayList();
                    if (!string.IsNullOrEmpty(cmd.Year))
                    {
                        al.Add("m.Year = @Year");
                    }
                    if (!string.IsNullOrEmpty(cmd.Month))
                    {
                        al.Add("m.Month = @Month");
                    }
                    if (al.Count > 0)
                    {
                        m_strWhere = " WHERE " + string.Join(" AND ", (string[])al.ToArray(typeof(string)));
                    }
                }

                dtbOut = DBUtil.Qry(string.Format(strSql, m_strWhere), inputParam);
                m_TotalNum = dtbOut.Rows.Count;

                for (int i = 0; i <= dtbOut.Rows.Count - 1; i++)
                {
                    if (dtbOut.Rows.Count > 0)
                    {
                        String ss = dtbOut.Rows[i]["LastUpdateDate"] + "";
                        String First = ss.Substring(0, 4);
                        String Final = ss.Substring(5, 14);
                        int Year = int.Parse(First) - 1911;
                        String s = Year.ToString() + "-" + Final;
                        dtbOut.Rows[i]["LastUpdateDate"] = s;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return dtbOut;
        }

        private int count_CPI(CPI_Cmd cmd)
        {
            int intCount = 0;

            string strSql = @"  SELECT 
                                    count(*)
                                FROM 
                                    Maintain_Imm_CPI
                                WHERE 
                                    Year = @Year
                                AND 
                                    Month = @Month
                                ;";
            HashMap inputParam = getInputParam(cmd);

            intCount = (int)DBUtil.ExecuteScalar(strSql, inputParam);
            return intCount;
        }

        private DataTable doUpdate_CPI(CPI_Cmd cmd)
        {
            DataTable dt = new DataTable();
            String strSql = @"  UPDATE 
                                    Maintain_Imm_CPI
                                SET 
                                    LastUpdateRoleNo = @LastUpdateRoleNo
                                    ,LastUpdateEmpNo = @LastUpdateEmpNo
                                    ,LastUpdateBranchNo = @LastUpdateBranchNo
                                    ,LastUpdateDate = GETDATE()
                                    ,Year = @Year
                                    ,Month = @Month
                                    ,CPI = @CPI
                                    ,Status = @Status
                                WHERE 
									Year = @Year_o
                                AND 
									Month = @Month_o
                                    ;";

            HashMap inputParam = getInputParam(cmd);
            inputParam.Put("@Year_o", cmd.Year_o);
            inputParam.Put("@Month_o", cmd.Month_o);

            DBUtil.ExecNonQry(strSql, inputParam);
            dt = getCPI();
            return dt;
        }

        private DataTable doInsert_CPI(CPI_Cmd cmd)
        {
            DataTable dt = new DataTable();
            String strSql = @"  INSERT 
                                    INTO Maintain_Imm_CPI 
                                    (
	                                    LastUpdateRoleNo
	                                    ,LastUpdateEmpNo
	                                    ,LastUpdateBranchNo
	                                    ,LastUpdateDate
                                        ,Year
                                        ,Month
                                        ,CPI
                                        ,Status
	                                )
                                    VALUES 
                                    (
		                                @LastUpdateRoleNo
                                        ,@LastUpdateEmpNo
                                        ,@LastUpdateBranchNo
                                        ,GETDATE()
                                        ,@Year
                                        ,@Month
                                        ,@CPI
                                        ,@Status
		                            );";

            HashMap inputParam = getInputParam(cmd);

            DBUtil.ExecNonQry(strSql, inputParam);
            dt = getCPI();
            return dt;
        }
        
        private HashMap getInputParam(CPI_Cmd cmd)
        {
            HashMap inputParam = new HashMap();
                        
            inputParam.Put("@Year", string.IsNullOrEmpty(cmd.Year) ? null : cmd.Year.Trim());
            inputParam.Put("@Month", string.IsNullOrEmpty(cmd.Month) ? null : cmd.Month.Trim());
            inputParam.Put("@CPI", cmd.CPI);
            inputParam.Put("@Status", cmd.Status);

            inputParam.Put("@LastUpdateEmpNo", g_clsSessionSecurity.EmpNo);
            inputParam.Put("@LastUpdateRoleNo", g_clsSessionSecurity.RoleNo);
            inputParam.Put("@LastUpdateBranchNo", g_clsSessionSecurity.BranchNo);

            return inputParam;
        }


        /// <summary>
        /// 物價指數表維護... 
        /// 傳入參數
        /// </summary>
        public class CPI_Cmd
        {
            public String FileNameOrigial;
            public String AspxFileName = "SKL_2_6_Maintain_Imm_CPI.html";
            public String FolderName = "Manage/Imm/SKL_2_6_Maintain_Imm_CPI/";
            public String Year;
            public String Month;
            public String Year_o;
            public String Month_o;
            public String CPI;
            public String Status;
        }

    }
}
