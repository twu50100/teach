﻿using System;
using System.Web.Http;
using Gemfor.Mvc;
using System.Data;
using Gemfor.Util;
using Gemfor.Auth;
using App_Code;

namespace SKL_LOAN.Controllers.Api.eLoan.Manage.Imm
{
    /// <summary>
    /// 土地增值稅的計算方法... 
    /// </summary>
    public class SKL_2_12_Maintain_Imm_LandIncrementTaxController : BasePageController
    {
        clsDate CDate = new clsDate();

        /// <summary>
        /// 土地增值稅的計算方法... 
        /// 初始化
        /// </summary>
        /// <returns>土地增值稅的計算方法　資料</returns>
        [HttpPost]
        public StdRet Init()
        {
            StdRet ret = new StdRet();
            
            try
            {
                HashMap hmapOut = new HashMap();
                hmapOut.Put("IncrementTax", getLandIncrementTax());

                ret.data = hmapOut;
            }
            catch (Exception e)
            {
                ret.setRc(StdRet.RC.INTERNAL_ERR, e.Message);
            }

            return ret;
        }

        /// <summary>
        /// 土地增值稅的計算方法... 
        /// 儲存
        /// </summary>
        /// <param name="cmd">
        /// Version 版本日期 &#13;
        /// Level1_20_Below_1 (A*B*C)*Level1_20_Below_1 &#13;
        /// Level2_20_Below_1 A*Level2_20_Below_1-B*Level2_20_Below_2 &#13;
        /// Level2_20_Below_2   &#13;
        /// Level3_20_Below_1 A*Level3_20_Below_1-B*Level3_20_Below_2 &#13;
        /// Level3_20_Below_2 A*Level3_20_Below_1-B*Level3_20_Below_2 &#13;
        /// Level1_20_Above_1 (A*B*C)*Level1_20_Above_1 &#13;
        /// Level2_20_Above_1 A*Level2_20_Above_1-B*Level2_20_Above_2 &#13;
        /// Level2_20_Above_2   &#13;
        /// Level3_20_Above_1 A*Level3_20_Above_1-B*Level3_20_Above_2 &#13;
        /// Level3_20_Above_2 A*Level3_20_Above_1-B*Level3_20_Above_2 &#13;
        /// Level1_30_Above_1 (A*B*C)*Level1_30_Above_1 &#13;
        /// Level2_30_Above_1 A*Level2_30_Above_1-B*Level2_30_Above_2 &#13;
        /// Level2_30_Above_2 A*Level2_30_Above_1-B*Level2_30_Above_2 &#13;
        /// Level3_30_Above_1 A*Level3_30_Above_1-B*Level3_30_Above_2 &#13;
        /// Level3_30_Above_2 A*Level3_30_Above_1-B*Level3_30_Above_2 &#13;
        /// Level1_40_Above_1 (A*B*C)*Level1_40_Above_1 &#13;
        /// Level2_40_Above_1 A*Level2_40_Above_1-B*Level2_40_Above_2 &#13;
        /// Level2_40_Above_2 A*Level2_40_Above_1-B*Level2_40_Above_2 &#13;
        /// Level3_40_Above_1 A*Level3_40_Above_1-B*Level3_40_Above_2 &#13;
        /// Level3_40_Above_2 A*Level3_40_Above_1-B*Level3_40_Above_2 &#13;
        /// </param>
        /// <returns>土地增值稅的計算方法　資料</returns>
        public StdRet Data_Save([FromBody]LandIncrementTax_Cmd cmd)
        {
            StdRet ret = new StdRet();
            
            if (cmd == null)
            {
                ret.data = "cmd is null";
            }
            else
            {
                try
                {
                    if (count_LandIncrementTax(cmd) > 0)
                    {
                        doUpdate_LandIncrementTax(cmd);
                    }
                    else
                    {
                        doInsert_LandIncrementTax(cmd);
                    }

                    HashMap hmapOut = new HashMap();
                    hmapOut.Put("IncrementTax", getLandIncrementTax());

                    ret.data = hmapOut;
                }
                catch (Exception e)
                {
                    ret.setRc(StdRet.RC.INTERNAL_ERR, e.Message);
                }
            }

            return ret;
        }

        private DataTable getLandIncrementTax()
        {
            DataTable dtbOut = new DataTable();

            string strSql = @"SELECT Top 1 
                                CONVERT(char(8), Version, 11) as Version
	                            ,LastUpdateRoleNo
	                            ,LastUpdateEmpNo
	                            ,LastUpdateBranchNo
	                            ,LastUpdateDate
	                            ,Level1_20_Below_1
	                            ,Level2_20_Below_1
	                            ,Level2_20_Below_2
	                            ,Level3_20_Below_1
	                            ,Level3_20_Below_2
	                            ,Level1_20_Above_1
	                            ,Level2_20_Above_1
	                            ,Level2_20_Above_2
	                            ,Level3_20_Above_1
	                            ,Level3_20_Above_2
	                            ,Level1_30_Above_1
	                            ,Level2_30_Above_1
	                            ,Level2_30_Above_2
	                            ,Level3_30_Above_1
	                            ,Level3_30_Above_2
	                            ,Level1_40_Above_1
	                            ,Level2_40_Above_1
	                            ,Level2_40_Above_2
	                            ,Level3_40_Above_1
	                            ,Level3_40_Above_2
                            FROM 
                                Maintain_Imm_LandIncrementTax
                            ORDER BY 
                                LastUpdateDate DESC
                            ;";

            dtbOut = DBUtil.Qry(strSql);

            if (dtbOut.Rows.Count > 0)
            {
                dtbOut.Columns.Add(new DataColumn("New_Version", typeof(String)));
                dtbOut.Rows[0]["New_Version"] = CDate.TransFormDataTime(dtbOut.Rows[0]["Version"].ToString());

            }
            return dtbOut;
        }

        private int count_LandIncrementTax(LandIncrementTax_Cmd cmd)
        {
            int intCount = 0;

            string strSql = @"SELECT count(*)
                                FROM Maintain_Imm_LandIncrementTax
                                WHERE Version = @Version
                                ;";
            HashMap inputParam = new HashMap();
            inputParam.Put("@Version", cmd.Version);

            intCount = (int)DBUtil.ExecuteScalar(strSql, inputParam);
            return intCount;
        }

        private DataTable doUpdate_LandIncrementTax(LandIncrementTax_Cmd cmd)
        {
            DataTable dt = new DataTable();
            String strSql = @" UPDATE 
                                    Maintain_Imm_LandIncrementTax
                               SET LastUpdateRoleNo = @LastUpdateRoleNo
                                    ,LastUpdateEmpNo = @LastUpdateEmpNo
                                    ,LastUpdateBranchNo = @LastUpdateBranchNo
                                    ,LastUpdateDate = GETDATE()
                                    ,Level1_20_Below_1 = @Level1_20_Below_1
                                    ,Level2_20_Below_1 = @Level2_20_Below_1
                                    ,Level2_20_Below_2 = @Level2_20_Below_2
                                    ,Level3_20_Below_1 = @Level3_20_Below_1
                                    ,Level3_20_Below_2 = @Level3_20_Below_2
                                    ,Level1_20_Above_1 = @Level1_20_Above_1
                                    ,Level2_20_Above_1 = @Level2_20_Above_1
                                    ,Level2_20_Above_2 = @Level2_20_Above_2
                                    ,Level3_20_Above_1 = @Level3_20_Above_1
                                    ,Level3_20_Above_2 = @Level3_20_Above_2
                                    ,Level1_30_Above_1 = @Level1_30_Above_1
                                    ,Level2_30_Above_1 = @Level2_30_Above_1
                                    ,Level2_30_Above_2 = @Level2_30_Above_2
                                    ,Level3_30_Above_1 = @Level3_30_Above_1
                                    ,Level3_30_Above_2 = @Level3_30_Above_2
                                    ,Level1_40_Above_1 = @Level1_40_Above_1
                                    ,Level2_40_Above_1 = @Level2_40_Above_1
                                    ,Level2_40_Above_2 = @Level2_40_Above_2
                                    ,Level3_40_Above_1 = @Level3_40_Above_1
                                    ,Level3_40_Above_2 = @Level3_40_Above_2
                                WHERE Version = @Version 
                                    ;";

            HashMap inputParam = getInputParam(cmd);

            DBUtil.ExecNonQry(strSql, inputParam);
            dt = getLandIncrementTax();
            return dt;
        }

        private DataTable doInsert_LandIncrementTax(LandIncrementTax_Cmd cmd)
        {
            DataTable dt = new DataTable();
            String strSql = @"INSERT INTO 
                                Maintain_Imm_LandIncrementTax 
                                (
	                                LastUpdateRoleNo
	                                ,LastUpdateEmpNo
	                                ,LastUpdateBranchNo
	                                ,LastUpdateDate
                                    ,Version
	                                ,Level1_20_Below_1
	                                ,Level2_20_Below_1
	                                ,Level2_20_Below_2
	                                ,Level3_20_Below_1
	                                ,Level3_20_Below_2
	                                ,Level1_20_Above_1
	                                ,Level2_20_Above_1
	                                ,Level2_20_Above_2
	                                ,Level3_20_Above_1
	                                ,Level3_20_Above_2
	                                ,Level1_30_Above_1
	                                ,Level2_30_Above_1
	                                ,Level2_30_Above_2
	                                ,Level3_30_Above_1
	                                ,Level3_30_Above_2
	                                ,Level1_40_Above_1
	                                ,Level2_40_Above_1
	                                ,Level2_40_Above_2
	                                ,Level3_40_Above_1
	                                ,Level3_40_Above_2
	                            )
                            VALUES 
                                (
		                            @LastUpdateRoleNo
                                    ,@LastUpdateEmpNo
                                    ,@LastUpdateBranchNo
                                    ,GETDATE()
                                    ,@Version
	                                ,@Level1_20_Below_1
	                                ,@Level2_20_Below_1
	                                ,@Level2_20_Below_2
	                                ,@Level3_20_Below_1
	                                ,@Level3_20_Below_2
	                                ,@Level1_20_Above_1
	                                ,@Level2_20_Above_1
	                                ,@Level2_20_Above_2
	                                ,@Level3_20_Above_1
	                                ,@Level3_20_Above_2
	                                ,@Level1_30_Above_1
	                                ,@Level2_30_Above_1
	                                ,@Level2_30_Above_2
	                                ,@Level3_30_Above_1
	                                ,@Level3_30_Above_2
	                                ,@Level1_40_Above_1
	                                ,@Level2_40_Above_1
	                                ,@Level2_40_Above_2
	                                ,@Level3_40_Above_1
	                                ,@Level3_40_Above_2
		                        );";

            HashMap inputParam = getInputParam(cmd);

            DBUtil.ExecNonQry(strSql, inputParam);
            dt = getLandIncrementTax();
            return dt;
        }

        private HashMap getInputParam(LandIncrementTax_Cmd cmd)
        {
            HashMap inputParam = new HashMap();
                        
            String Ver = cmd.Version;
            if (cmd.Version.IndexOf("/") != -1)
            {
                Ver = (CDate.getDate_West(cmd.Version).ToString()).Replace(@"/", "");
            }

            inputParam.Put("@Version", Ver);
            inputParam.Put("@Level1_20_Below_1", cmd.Level1_20_Below_1);
            inputParam.Put("@Level2_20_Below_1", cmd.Level2_20_Below_1);
            inputParam.Put("@Level2_20_Below_2", cmd.Level2_20_Below_2);
            inputParam.Put("@Level3_20_Below_1", cmd.Level3_20_Below_1);
            inputParam.Put("@Level3_20_Below_2", cmd.Level3_20_Below_2);
            inputParam.Put("@Level1_20_Above_1", cmd.Level1_20_Above_1);
            inputParam.Put("@Level2_20_Above_1", cmd.Level2_20_Above_1);
            inputParam.Put("@Level2_20_Above_2", cmd.Level2_20_Above_2);
            inputParam.Put("@Level3_20_Above_1", cmd.Level3_20_Above_1);
            inputParam.Put("@Level3_20_Above_2", cmd.Level3_20_Above_2);
            inputParam.Put("@Level1_30_Above_1", cmd.Level1_30_Above_1);
            inputParam.Put("@Level2_30_Above_1", cmd.Level2_30_Above_1);
            inputParam.Put("@Level2_30_Above_2", cmd.Level2_30_Above_2);
            inputParam.Put("@Level3_30_Above_1", cmd.Level3_30_Above_1);
            inputParam.Put("@Level3_30_Above_2", cmd.Level3_30_Above_2);
            inputParam.Put("@Level1_40_Above_1", cmd.Level1_40_Above_1);
            inputParam.Put("@Level2_40_Above_1", cmd.Level2_40_Above_1);
            inputParam.Put("@Level2_40_Above_2", cmd.Level2_40_Above_2);
            inputParam.Put("@Level3_40_Above_1", cmd.Level3_40_Above_1);
            inputParam.Put("@Level3_40_Above_2", cmd.Level3_40_Above_2);

            inputParam.Put("@LastUpdateEmpNo", g_clsSessionSecurity.EmpNo);
            inputParam.Put("@LastUpdateRoleNo", g_clsSessionSecurity.RoleNo);
            inputParam.Put("@LastUpdateBranchNo", g_clsSessionSecurity.BranchNo);

            return inputParam;
        }

        /// <summary>
        /// 土地增值稅的計算方法... 
        /// 傳入參數
        /// </summary>
        public class LandIncrementTax_Cmd
        {
            public String Version;
            public String Level1_20_Below_1;
            public String Level2_20_Below_1;
            public String Level2_20_Below_2;
            public String Level3_20_Below_1;
            public String Level3_20_Below_2;
            public String Level1_20_Above_1;
            public String Level2_20_Above_1;
            public String Level2_20_Above_2;
            public String Level3_20_Above_1;
            public String Level3_20_Above_2;
            public String Level1_30_Above_1;
            public String Level2_30_Above_1;
            public String Level2_30_Above_2;
            public String Level3_30_Above_1;
            public String Level3_30_Above_2;
            public String Level1_40_Above_1;
            public String Level2_40_Above_1;
            public String Level2_40_Above_2;
            public String Level3_40_Above_1;
            public String Level3_40_Above_2;

        }

    }
}
