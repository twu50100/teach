﻿var PAGE_SIZE = 10;
var PAGE_IDX = -1;
var PAGE_CNT = -1;
var EDIT_DATA = new Array();
var G_CPI = new Array();

genData = function (Data) {
    //console.log(Data);
    G_CPI = Data
    CPIBox();
    CPITable(Data);
};

var CPIBox = function () {

    $("#CPIBox").SexyBox({
        boxCtrl: [{
            ID: "CPI",
            HeadForm: "CPIForm",
            HeadRow: [],
            Head: [],
            BodyForm: "CPIForm",
            BodyRow: [],
            Body: [
                {
                    Row: "2col",
                    ColumnClass: ["align_left required", "align_left"],
                    Ctrl: ["基期-年", { Type: "textbox", Name: "Year", ID: "txtYear" }]
                },
                {
                    Row: "2col",
                    ColumnClass: ["align_left required", "align_left"],
                    Ctrl: ["基期-月", { Type: "textbox", Name: "Month", ID: "txtMonth" }]
                },
                {
                    Row: "2col",
                    ColumnClass: ["align_left required", "align_left"],
                    Ctrl: ["指數", { Type: "textbox", Name: "CPI", ID: "txtCPI" }]
                },
                {
                    Row: "2col",
                    ColumnClass: ["align_left", "align_left"],
                    Ctrl: ["狀態", { Type: "select", Text: "ItemText", Value: "ItemValue", Name: "Status", ID: "slcStatus", Data: Status }]
                },
            ],
            Data: []
        },
        {
            Body: [
                {
                    Row: "",
                    RowClass: "align_center",
                    Ctrl: [{ Type: "a", Data: "確定", Class: "button add", Event: Data_Save }]
                }
            ]
        },
        {
            ID: "uploadFile",
            HeadForm: "CPIForm",
            HeadRow: [],
            Head: [],
            BodyForm: "CPIForm",
            BodyRow: [],
            ChangeName:false,
            Body: [{

            Row: "2col",
            ColumnClass: ["align_left", "align_left"],
            Ctrl: [
                { Type: "span", Data: "上傳檔案位置", Class: "required" },
                [{ Type: "file", Name: "FileNameOrigial", ID: "FileNameOrigial" },
                    { Type: "a", Data: "上傳", Class: "button add", Event: Upload_ExcelFile }
                ]
            ]
        }]
        },
        {
            // 添加查詢條件 add by jessie 2018/04/02
            ID: "searchForm",
            BodyForm: "CPIForm",
            Body: [
                    {
                        Row: "col",
                        RowClass: "bg_gray",
                        Ctrl: [
                            [
                                "篩選條件 : 基期-年 ",
                                { Type: "textbox", Name: "Year", ID: "searchYear" },
                                " 基期-月 ",
                                { Type: "textbox", Name: "Month", ID: "searchMonth" },
                                { Type: "a", Data: "查詢", Class: "button add", Event: searchData }
                            ]
                        ]
                    }
                ],
           }

        ],

    });
    $("#slcStatus\\|0ICPI").SexySelectValChange("1");
}


var Status = [{ "ItemText": "啟用", "ItemValue": "1" }, { "ItemText": "停用", "ItemValue": "0" }]


var CPITable = function (CPI) {
    var tableArg = {
        theadValue: [[
            { Text: "基期-年(old)", Style: { "display": "none" } },
            { Text: "基期-年" },
            { Text: "基期-月(old)", Style: { "display": "none" } },
            { Text: "基期-月" },
            { Text: "指數" },
            { Text: "狀態" },
            { Text: "最近修改日期" },
            { Text: "維護" }

        ]],
        tbodyValue: {
            Value: ["Year", "Year", "Month", "Month", "CPI",
                { t: function (e) { return (e["Status"] == "1") ? "啟用" : "停用"; } }, "LastUpdateDate"],
            Style: [{ "display": "none" }, {}, { "display": "none" }]
        },
        Data: CPI,
        Style: {
            tbody_odd: "rowodd",
            tbody_even: "roweven"
        },
        tbodyEdit:
		{
		    Ctrl:
                [
                     [{ Type: "hidden", ID: "hid_year", Name: "Year_o" }, { Type: "text", ID: "td_year", Name: "Year", maxLength:3 }]
                     , [{ Type: "hidden", ID: "hid_month", Name: "Month_o" }, { Type: "text", ID: "td_month", Name: "Month", maxLength: 2 }]
                     , { Type: "text", ID: "td_cpi", Name: "CPI" }
                     , { Type: "select", Text: "ItemText", Value: "ItemValue", Name: "Status", ID: "uslcStatus", Data: Status }
                     , { Type: "label", ID: "td_lastUpdate" }
                ],
		},
        Plugin: [

			{Event: EditFunc, UpdateEvent: saveData, Class: "button", Name: "修改", Tooltip: "修改" }

        ],
        PluginStyle: { "width": "200px", "text-align": "center" },
        PageSetting: {
            ShowPageCtrl: true,
            PageSize: PAGE_SIZE,
        },
        PluginSite: true
    };

    $("#scDataView").find("input").unbind('click');
    $("#scDataView").find("thead,tbody").remove();
    $("#scDataView").SexyTable(tableArg);
}

EditFunc = function (ArgData) {

    //console.info(ArgData);

    $("#hid_year").val(ArgData[0]);
    $("#td_year").val(ArgData[1]);
    $("#hid_month").val(ArgData[2]);
    $("#td_month").val(ArgData[3]);
    $("#td_cpi").val(ArgData[4]);
   // $("#td_status").val(ArgData[5]);
    $("#td_lastUpdate").text(ArgData[6]);

    if (ArgData[5] == "啟用") {
        $("#uslcStatus").val("1");
    } else {
        $("#uslcStatus").val("0");
    }
};

var Upload_ExcelFile = function () {
    var jsonData = {};
    jsonData.FileNameOrigial = $("#FileNameOrigial").val();
    var validList = [
        { Field: "FileNameOrigial", FieldName: "上傳檔案位置", CheckType: "string", IsEmpty: "false" }
    ];
    var valid = $.FormValidation(jsonData, validList);

    if (valid) {
        var formData = $.getUpLoadFormData("FileNameOrigial", jsonData);
        var DataArgs =
       {
           url: "SKL_2_6_Maintain_Imm_CPI/Upload_ExcelFileToInsert",
           data: formData,
           oMethod: function (rtn) {

               var errorMsg = G_Convert.msg(rtn.data.CoverItem);

               if (errorMsg == undefined) {

                   errorMsg = rtn.data.ErrorMsg;
               }
               // 若提示訊息存在 則彈出提示訊息 若不存在則直接查詢資料顯示
               if (errorMsg != undefined) {

                   SexyAlert("提示", errorMsg, "error", "OKONLY", function () {

                   })
               }
               else {
                   var file = $("#FileNameOrigial");
                   file.after(file.clone().val(""));
                   file.remove();
                   searchData();
               }
           },
           cache: false,
           contentType: false,
           processData: false //告訴jQuery不要處理資料
       };
        docCore.ajax(DataArgs, true, true);
    }
    else {
        var errMsg = $.FormValidationErrorMessage().join("<br/>");
        var warnMsg = $.FormValidationWarningMessage().join("<br/>");
        SexyAlert("提示", errMsg != "" ? errMsg : warnMsg, "TIP", "OKONLY");
    }   
}

// 修改按下確定
saveData = function () {
    var jsonData = $.valToJson($(this).closest("tr"))
    //console.log(jsonData);
    var DataArgs =
    {
    	url: "SKL_2_6_Maintain_Imm_CPI/update_CPI",
    	data: jsonData,
    	oMethod: function (Data) {
    	    SexyAlert("提示", G_Convert.msg("000003"), "OK", "OKONLY", function () {
    	        searchData(1);
    	    });
    	},
    };
    docCore.ajax(DataArgs, true, true);
}

//確定
var Data_Save = function () {
    var jsonObj = $.valToJson("CPI");
    var validList = [];
    // 資料驗證
    validList.push({ Field: "Year", FieldName: "基期-年", CheckType: "pureintegerNotZero", sEmpty: "false", Length: "3" });
    validList.push({ Field: "Month", FieldName: "基期-月", CheckType: "pureintegerNotZero", sEmpty: "false", Length: "2" });
    validList.push({ Field: "CPI", FieldName: "指數", CheckType: "decimal", sEmpty: "false", Length: "8.2" });

    var valid = $.FormValidation(jsonObj, validList);
    var errMsg = $.FormValidationErrorMessage().join("<br/>");
    var warnMsg = $.FormValidationWarningMessage().join("<br/>")
 
    if (parseInt($("[id^=txtCPI]").val()) <= 0) {
        errMsg += "<br/> 指數需大於零，請重新輸入﹗﹗";
    }
    if (valid && errMsg.length <= 0) {
        var DataArgs =
           {
               url: "SKL_2_6_Maintain_Imm_CPI/Save_CPI",
               data: jsonObj,
               oMethod: function (Data) {
                   SexyAlert("提示", G_Convert.msg("000011"), "OK", "OKONLY", function () {
                       //console.log(Data.data["CPI"]);
                       CPIBox();
                       searchData();
                       $("#scDataView").SexyPageCtrl(Data.data.CPI.length, 10, null, "scDataView", 1);
                   });
               },
           };
        docCore.ajax(DataArgs, true, true);
    }
    else {
        SexyAlert("提示", errMsg.length > 0 ? errMsg : warnMsg, "TIP", "OKONLY");
    }
   
}

//一開始取得頁面資料
function OrdersQry() {

    var DataArgs =
	{
	    url: "SKL_2_6_Maintain_Imm_CPI/init_CPI",
	    oMethod: reformatData,
	};
    docCore.ajax(DataArgs, true, true);

}

// 根據條件篩選資料
var searchData = function (isGoPage) {
    var jsonData = $.valToJson("searchForm");
    var DataArgs =
    {
        url: "SKL_2_6_Maintain_Imm_CPI/Maintain_CL_StkNo_Qry",
        data: jsonData,
        oMethod: function (Arg) {
            CPITable(Arg.data["CPI"]);
            $("[id^=txtYear]").val("");
            $("[id^=txtMonth]").val("");
            $("[id^=txtCPI]").val("");
            $("[id^=slcStatus]").SexySelectValChange(1);
            if (isGoPage != 1) {

                $("#scDataView").SexyPageCtrl(Arg.data.CPI.length, 10, null, "scDataView", 1);
            }
        },
    };
    docCore.ajax(DataArgs, true, true);
}

//將取回來的資料裡面日期重新格式化為 民國年/月/日
var reformatData = function(ArgData) {
    //console.info(ArgData);
 
    var newData = [];
    var arg_data = ArgData.data;
    var table = arg_data['CPI'];



    $.each(table, function (index, data) {
        newData.push({
            CPI: data['CPI'],
            LastUpdateBranchNo: data['LastUpdateBranchNo'],
            LastUpdateDate: data['LastUpdateDate'],
            LastUpdateEmpNo: data['LastUpdateEmpNo'],
            LastUpdateRoleNo: data['LastUpdateRoleNo'],
            Month: data['Month'],
            Status: data['Status'],
            Year: data['Year']
            
        });
    });

    //console.log(newData);

    genData(newData);
}

//將西元日期轉成國曆
var fullDateToChinse = function (input_date) {

    //console.log(input_date);
    var date = new Date(input_date);

    var year = date.getFullYear() - 1911;
    var month = date.getMonth() + 1;
    var day = date.getDate();

    return year + "/" + leftPad(month, 2) + "/" + leftPad(day, 2);
}

// 位數補0
// 例如：
// var month = 2;
// console.log(leftPad(month,2)) // 02
var leftPad = function(val, length) {
    var str = '' + val;
    while (str.length < length) {
        str = '0' + str;
    }
    return str;
}


$(document).ready(function () {
    OrdersQry();

});