﻿var PAGE_SIZE = 10;
var PAGE_IDX = -1;
var G_FormulaBind = new Array();
var G_LOAD_Waitting_Msg;

var Init = function () {

    var AjaxInputObj =
      {
          url: "SKL_2_11_Maintain_Imm_OtherFormula/Init",
          oMethod: genData,
      };

    //call ajax
    docCore.ajax(AjaxInputObj, true, true, G_LOAD_Waitting_Msg);
}

var genData = function (Data) {
    //console.log(Data.data["FormulaBind"]);
    G_FormulaBind = Data.data["FormulaBind"]

    FormulaBox(Data.data["FormulaBind"]);
}

var FormulaBox = function (Formula) {
    //console.log(Formula)
    $("#FormulaBox").SexyBox({
        boxCtrl: [
            {
                ID: "Formula",
                HeadForm: "FormulaForm",
                HeadRow: [],
                Head: [
                         {
                             Row: "caption",
                             Ctrl: [
                                     [{ Type: "Label", Data: ["估價報告書"] }]
                             ]
                         },
                ],
                BodyForm: "FormulaForm",
                BodyRow: [],
                Body: [
                    {
                        Row: "2col",
                        ColumnClass: ["align_left", "align_left bg_white"],
                        Ctrl: ["折舊金額", ["(1)當折舊率大於"
                             , { Type: "textbox", Name: "DepreciationRate", Data: ["DepreciationRate"] }, "時，<br>"
                             , "= (建物單價(查造價表) + 調整加成 - 殘值(查表)) <br>"
                             , "&nbsp;&nbsp;&nbsp;* 建坪數(建物所有面積) <br>"
                             , "&nbsp;&nbsp;&nbsp;* (1-實際殘值率(調整後殘值率或是殘值率)) <br>"
                             , "(2)反之，則 <br>"
                             , "= (建物單價(查造價表) + 調整加成 - 殘值(查表)) <br>"
                             , "&nbsp;&nbsp;&nbsp;* 建坪數(建物所有面積) <br>"
                             , "&nbsp;&nbsp;&nbsp;* 折舊率 <br>"
                        ]]

                    },
                ],
                Data: Formula
            },
            {
            ID: "Formula",
            HeadForm: "FormulaForm",
            HeadRow: [],
            Head: [
                    {
                        Row: "caption",
                        Ctrl: [
                                [{ Type: "Label", Data: ["土地開發分析表"] }]
                        ]
                    },
            ],
            BodyForm: "FormulaForm",
            BodyRow: [],
            Body: [
                {
                    Row: "2col",
                    ColumnClass: ["align_left", "align_left bg_white"],
                    Ctrl: ["附 屬 建 物 面 積(坪) <br> ﻿(數值取至小數位後2位)"
                        , ["= (地 面 層 樓 地 板 面 積(坪) *"
                            , { Type: "textbox", Name: "AttachGroundParam", Data: ["AttachGroundParam"] },
                            , "* 興 建 樓 層 ) <br>"
                            , "&nbsp;&nbsp; + (主 建 物 樓 地 板 面 積(坪) *"
                            , { Type: "textbox", Name: "AttachMainBuildParam", Data: ["AttachMainBuildParam"] }, ") <br>"
                            , "&nbsp;&nbsp; + (地 下 室 樓 地 板 面 積(坪) *"
                            , { Type: "textbox", Name: "AttachBasementParam", Data: ["AttachBasementParam"] }, ")"
                    ]]
                },
                {
                    Row: "2col",
                    ColumnClass: ["align_left", "align_left bg_white"],
                    Ctrl: ["屋 突 等 面 積(坪) <br> ﻿(數值取至小數位後2位)"
                        , ["= 地 面 層 樓 地 板 面 積(坪) /&nbsp;"
                            , { Type: "textbox", Name: "HouseParam1", Data: ["HouseParam1"] }
                            , "*"
                            , { Type: "textbox", Name: "HouseParam2", Data: ["HouseParam2"] }
                        ]]
                },
                {
                    Row: "2col",
                    ColumnClass: ["align_left", "align_left bg_white"],
                    Ctrl: ["獎勵停車位數 <br> ﻿(數值取至整數位)"
                        , ["= 基 地 面 積(坪) * 容 積 率(%) * 獎勵停車(%) <br>"
                            , "&nbsp;&nbsp;&nbsp;&nbsp; / 0.3025 /&nbsp;"
                            , { Type: "textbox", Name: "RewardParkingSpace", Data: ["RewardParkingSpace"] }
                        ]]
                },
                {
                    Row: "2col",
                    ColumnClass: ["align_left", "align_left bg_white"],
                    Ctrl: ["實設停車位數 <br> ﻿(數值取至整數位)"
                        , ["= (地 下 室 樓 地 板 面 積(坪) / 0.3025) <br>"
                            , "&nbsp;&nbsp;&nbsp; *"
                            , { Type: "textbox", Name: "RealParkingSpaceParam1", Data: ["RealParkingSpaceParam1"] }
                            , "&nbsp;&nbsp;/&nbsp;"
                            , { Type: "textbox", Name: "RealParkingSpaceParam2", Data: ["RealParkingSpaceParam2"] }
                        ]]
                },
                {
                    Row: "2col",
                    ColumnClass: ["align_left", "align_left bg_white"],
                    Ctrl: [["平 均 土 地 單 價 (元/坪) <br> (數值四捨五入至小數點左邊第"
                            , { Type: "textbox", Name: "DecimalLeftPlace", Data: ["DecimalLeftPlace"] }, "位)"]
                        , ["= 土 地 開 發 分 析 價 格(Ｖ) / 基 地 面 積(坪)"]]
                },

            ],
            Data: Formula
        },
            {
                    ID: "Formula",
                    HeadForm: "FormulaForm",
                    HeadRow: [],
                    Head: [
                            {
                                Row: "caption",
                                Ctrl: [
                                        [{ Type: "Label", Data: ["間接成本之法定比例"] }]
                                ]
                            },
                    ],
                    BodyForm: "FormulaForm",
                    BodyRow: [],
                    Body: [
                        {
                            Row: "2col",
                            ColumnClass: ["align_left", "align_left bg_white"],
                            Ctrl: ["規劃設計費用(元)"
                                , [
                                 , { Type: "textbox", Name: "ExpensesDesignS", Data: ["ExpensesDesignS"] },
                                 , "&nbsp;%&nbsp;~&nbsp;"
                                 , { Type: "textbox", Name: "ExpensesDesignE", Data: ["ExpensesDesignE"] }
                                 , "&nbsp;%"
                                ]]
                        },
                        {
                            Row: "2col",
                            ColumnClass: ["align_left", "align_left bg_white"],
                            Ctrl: ["廣告銷售費用(元)"
                                , [
                                 , { Type: "textbox", Name: "ExpensesCommercialS", Data: ["ExpensesCommercialS"] },
                                 , "&nbsp;%&nbsp;~&nbsp;"
                                 , { Type: "textbox", Name: "ExpensesCommercialE", Data: ["ExpensesCommercialE"] }
                                 , "&nbsp;%"
                                ]]
                        },
                        {
                            Row: "2col",
                            ColumnClass: ["align_left", "align_left bg_white"],
                            Ctrl: ["管理費用(元)"
                                , [
                                 , { Type: "textbox", Name: "ExpensesManageS", Data: ["ExpensesManageS"] },
                                 , "&nbsp;%&nbsp;~&nbsp;"
                                 , { Type: "textbox", Name: "ExpensesManageE", Data: ["ExpensesManageE"] }
                                 , "&nbsp;%"
                                ]]
                        },
                        {
                            Row: "2col",
                            ColumnClass: ["align_left", "align_left bg_white"],
                            Ctrl: ["稅捐費用(元)"
                                , [
                                 , { Type: "textbox", Name: "ExpensesTaxS", Data: ["ExpensesTaxS"] },
                                 , "&nbsp;%&nbsp;~&nbsp;"
                                 , { Type: "textbox", Name: "ExpensesTaxE", Data: ["ExpensesTaxE"] }
                                 , "&nbsp;%"
                                ]]
                        },
                    ],
                    Data: Formula
        },
            {
                ID: "Formula",
                HeadForm: "FormulaForm",
                HeadRow: [],
                Head: [
                        {
                            Row: "caption",
                            Ctrl: [
                                    [{ Type: "Label", Data: ["參考利潤率（實際應視個案調整）"] }]
                            ]
                        },
                ],
                BodyForm: "FormulaForm",
                BodyRow: [],
                Body: [
                    {
                        Row: "2col",
                        ColumnClass: ["align_left", "align_left bg_white"],
                        Ctrl: ["開發工期一年以內者"
                            , [
                             , { Type: "textbox", Name: "DevelopPeriod1S", Data: ["DevelopPeriod1S"] },
                             , "&nbsp;%&nbsp;~&nbsp;"
                             , { Type: "textbox", Name: "DevelopPeriod1E", Data: ["DevelopPeriod1E"] }
                             , "&nbsp;%"
                            ]]
                    },
                    {
                        Row: "2col",
                        ColumnClass: ["align_left", "align_left bg_white"],
                        Ctrl: ["開發工期一年至二年者"
                            , [
                             , { Type: "textbox", Name: "DevelopPeriod2S", Data: ["DevelopPeriod2S"] },
                             , "&nbsp;%&nbsp;~&nbsp;"
                             , { Type: "textbox", Name: "DevelopPeriod2E", Data: ["DevelopPeriod2E"] }
                             , "&nbsp;%"
                            ]]
                    },
                    {
                        Row: "2col",
                        ColumnClass: ["align_left", "align_left bg_white"],
                        Ctrl: ["開發工期二年至三年者"
                            , [
                             , { Type: "textbox", Name: "DevelopPeriod3S", Data: ["DevelopPeriod3S"] },
                             , "&nbsp;%&nbsp;~&nbsp;"
                             , { Type: "textbox", Name: "DevelopPeriod3E", Data: ["DevelopPeriod3E"] }
                             , "&nbsp;%"
                            ]]
                    },
                    {
                        Row: "2col",
                        ColumnClass: ["align_left", "align_left bg_white"],
                        Ctrl: ["開發工期三年至四年者"
                            , [
                             , { Type: "textbox", Name: "DevelopPeriod4S", Data: ["DevelopPeriod4S"] },
                             , "&nbsp;%&nbsp;~&nbsp;"
                             , { Type: "textbox", Name: "DevelopPeriod4E", Data: ["DevelopPeriod4E"] }
                             , "&nbsp;%"
                            ]]
                    },
                ],
                Data: Formula
            },
            
            {
                ID: "Formula",
                HeadForm: "FormulaForm",
                HeadRow: [],
                Head: [
                        {
                            Row: "caption",
                            Ctrl: [
                                    [{ Type: "Label", Data: ["資本利息綜合利率表"] }]
                            ]
                        },
                ],
                BodyForm: "FormulaForm",
                BodyRow: [],
                Body: [
                    {
                        Row: "2col",
                        ColumnClass: ["align_left", "align_left bg_white"],
                        Ctrl: ["建築投資資本利息（利率）"
                            , [
                               "= (自有資金之比例 * 自有資金之利率 <br>"
                             , "&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;+ 借貸資金之比例 * 借貸資金之利率) <br>"
                             , "&nbsp;&nbsp;&nbsp; * 土地開發分析表.興建期限(年)&nbsp; <br>"
                             , "&nbsp;&nbsp;&nbsp; / <br>"
                             , { Type: "textbox", Name: "CapitalInterestBuild", Data: ["CapitalInterestBuild"] },
                            ]]
                    },
                    {
                        Row: "2col",
                        ColumnClass: ["align_left", "align_left bg_white"],
                        Ctrl: ["土地投資資本利息（利率）"
                            , [
                                "= (自有資金之比例 * 自有資金之利率 <br>"
                             , "&nbsp;&nbsp;&nbsp;&nbsp; + 借貸資金之比例 * 借貸資金之利率) <br>"
                             , "&nbsp;&nbsp;*&nbsp;(土地開發分析表.興建期限(年)&nbsp;+&nbsp;<br>"
                             , { Type: "textbox", Name: "CapitalInterestLand", Data: ["CapitalInterestLand"] },
                            ]]
                    },
                ],
                Data: Formula
            },
            {
                Body: [
                         {
                             Row: "",
                             RowClass: "align_center",
                             Ctrl: [{ Type: "a", Data: "儲存", Class: "button add", Event: Data_Save }]
                         }
                ]
            }
        ],
    });

}

var Data_Save = function () {
    var jsonObj = $.valToJson("FormulaBox");
    //console.log(jsonObj);

    var AjaxInputObj =
    {
        url: "SKL_2_11_Maintain_Imm_OtherFormula/Data_Save",
        data: jsonObj,
        oMethod: function (Data) {
            SexyAlert("提示", G_Convert.msg("000011"), "OK", "OKONLY", function () {
                 FormulaBox(Data.data["FormulaBind"]);
            });
        },
    };

    //call ajax
    docCore.ajax(AjaxInputObj, true, true, G_LOAD_Waitting_Msg);

}

$(document).ready(function () {
    Init();
});