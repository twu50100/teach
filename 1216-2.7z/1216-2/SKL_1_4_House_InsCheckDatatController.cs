﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Gemfor.Mvc;
using System.Data;
using Gemfor.Util;
using Gemfor.Auth;
using App_Code;
using static App_Code.clsCommon;
using System.Globalization;

namespace SKL_LOAN.Controllers.Api.eLoan.InputCase.Imm
{
    public class SKL_1_4_House_InsCheckDataController : BasePageController
    {
        clsSelect CDrop = new clsSelect();
        clsDate g_clsDate = new clsDate();
        clsSelect g_clsSlt = new clsSelect();
        clsHouse g_clsHouse = new clsHouse();

        /// <summary>
        /// 核保作業勾稽資料查詢
        /// </summary>
        /// <param name="cmd">
        /// @DateS		--資料日期起
        /// @DateE		--資料日期迄
        /// @CaseNo			--放款案號
        /// @Agent_EmpNo	--介紹人員工代號
        /// </param>
        /// <returns></returns>
        [HttpPost]
        public StdRet Qry([FromBody]SKL_1_4_House_InsCheckDataControllerCmd cmd)
        {
            StdRet ret = new StdRet();
            HashMap Hm = new HashMap();

            try
            {
                Hm.Put("ResultData", House_InsCheckData_Qry(cmd));
                ret.data = Hm;
            }
            catch (Exception e)
            {
                ret.setRc(StdRet.RC.INTERNAL_ERR, e.Message);
            }

            return ret;
        }

        private DataTable House_InsCheckData_Qry(SKL_1_4_House_InsCheckDataControllerCmd cmd)
        {
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            HashMap HmParam = new HashMap();
            HashMap HmOut = new HashMap();

            HmParam.Put("@DateS", g_clsDate.getDate_West(cmd.DateS));
            HmParam.Put("@DateE", g_clsDate.getDate_West(cmd.DateE));
            HmParam.Put("@CaseNo", (cmd.CaseNo == null) ? "" : cmd.CaseNo);
            HmParam.Put("@AgentEmpNo", (cmd.Agent_EmpNo == null) ? "" : cmd.Agent_EmpNo);
            HmOut.Put("@r_TotalNum", "");

            ds = DBUtil.ExecSP("dbo.USP_House_QryInsCheckData", HmParam, HmOut);

            if (ds.Tables[0].Rows.Count > 0)
            {
                dt = ds.Tables[0].Copy();
            }

            return dt;
        }

        /// <summary>
        /// 匯出excel查詢結果 
        /// </summary>
        /// <param name="cmd">查詢參數</param>
        /// <returns>Response</returns>
        public HttpResponseMessage Export_Excel([FromBody]SKL_1_4_House_InsCheckDataControllerCmd cmd)
        {
            if (!g_clsSessionSecurity.IsHeadOffice)
            {
                return null;
            }
            try
            {
                //取資料。使用和原查詢同方法。
                var dt = House_InsCheckData_Qry(cmd);

                //命名資料表，此值等同檔名與頁籤名。
                dt.TableName = "核保作業勾稽資料查詢";

                #region 定義欄位與來源
                List<ExcelCells> cells = new List<ExcelCells>();
                cells.Add(new ExcelCells() { Seq = 1, CellName = "資料日期", CellValue = "DataDate", CellWidth = 6000 });
                cells.Add(new ExcelCells() { Seq = 2, CellName = "借款人戶號", CellValue = "CustNo", CellWidth = 6000 });
                cells.Add(new ExcelCells() { Seq = 3, CellName = "借款人姓名", CellValue = "CustName", CellWidth = 4000 });
                cells.Add(new ExcelCells() { Seq = 4, CellName = "放款案號", CellValue = "CaseNo", CellWidth = 6000 });
                cells.Add(new ExcelCells() { Seq = 5, CellName = "核貸日", CellValue = "ApproveDate", CellWidth = 6000 });
                cells.Add(new ExcelCells() { Seq = 6, CellName = "核貸金額(單位：元)", CellValue = "CheckAmount", AddDataEnd = "元", ShowZero = false, CellWidth = 6000 });
                cells.Add(new ExcelCells() { Seq = 7, CellName = "撥款日", CellValue = "LMSLLD", CellWidth = 6000 });
                cells.Add(new ExcelCells() { Seq = 8, CellName = "撥款金額(單位：元)", CellValue = "LMSFLA", AddDataEnd = "元", ShowZero = false, CellWidth = 6000 });
                cells.Add(new ExcelCells() { Seq = 9, CellName = "薪資收入(單位：萬元)", CellValue = "IncomeSalary", AddDataEnd = "萬元", ShowZero = false, CellWidth = 6000 });
                cells.Add(new ExcelCells() { Seq = 10, CellName = "執行業務收入(單位：萬元)", CellValue = "IncomeWork", AddDataEnd = "萬元", ShowZero = false, CellWidth = 6000 });
                cells.Add(new ExcelCells() { Seq = 11, CellName = "營業收入(單位：萬元)", CellValue = "IncomeBusiness", AddDataEnd = "萬元", ShowZero = false, CellWidth = 6000 });
                cells.Add(new ExcelCells() { Seq = 12, CellName = "租金收入(單位：萬元)", CellValue = "IncomeRant", AddDataEnd = "萬元", ShowZero = false, CellWidth = 6000 });
                cells.Add(new ExcelCells() { Seq = 13, CellName = "利息收入(單位：萬元)", CellValue = "IncomeInterest", AddDataEnd = "萬元", ShowZero = false, CellWidth = 6000 });
                cells.Add(new ExcelCells() { Seq = 14, CellName = "其他收入(單位：萬元)", CellValue = "IncomeOther", AddDataEnd = "萬元", ShowZero = false, CellWidth = 6000 });
                cells.Add(new ExcelCells() { Seq = 15, CellName = "借款人年收入(單位：萬元)", CellValue = "IncomeYear", AddDataEnd = "萬元", ShowZero = false, CellWidth = 6000 });
                cells.Add(new ExcelCells() { Seq = 16, CellName = "本案推估年收入(單位：萬元)", CellValue = "Estimate", AddDataEnd = "萬元", ShowZero = false, CellWidth = 6000 });
                cells.Add(new ExcelCells() { Seq = 17, CellName = "介紹人", CellValue = "AngentEmpName", CellWidth = 4000 });
                cells.Add(new ExcelCells() { Seq = 18, CellName = "介紹人員工代號", CellValue = "AngentEmpNo", CellWidth = 5000 });
                cells.Add(new ExcelCells() { Seq = 19, CellName = "單位代號", CellValue = "AngentUnitNo", CellWidth = 5000 });
                #endregion

                var common = new clsCommon();
                return common.Export_Excel_SingleSheet(dt, cells);
            }
            catch (Exception e)
            {
                throw e;
            }
        }


        /// <summary>
        /// 傳入參數
        /// </summary>
        /// <remarks>
        /// @DateS		--資料日期起
        /// @DateE		--資料日期迄
        /// @CaseNo			--放款案號
        /// @Agent_EmpNo	--介紹人員工代號
        /// </remarks>
        public class SKL_1_4_House_InsCheckDataControllerCmd
        {
            public string DateS = "";
            public string DateE = "";
            public string CaseNo = "";
            public string Agent_EmpNo = "";
        }
    }
}