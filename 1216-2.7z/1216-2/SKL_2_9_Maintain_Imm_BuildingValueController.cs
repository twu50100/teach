﻿using System;
using System.Web.Http;
using Gemfor.Mvc;
using System.Data;
using Gemfor.Util;
using Gemfor.Auth;
using App_Code;
using System.Data.Common;
using System.Collections;

namespace SKL_LOAN.Controllers.Api.eLoan.Manage.Imm
{
    /// <summary>
    /// 建物造價參考標準表維護... 
    /// </summary>
    public class SKL_2_9_Maintain_Imm_BuildingValueController : BasePageController
    {
        clsDate CDate = new clsDate();
        /// <summary>
        /// 建物造價參考標準表維護... 
        /// 初始化
        /// </summary>
        /// <returns>建物造價參考標準表維護　資料、ddlCity</returns>
        [HttpPost]
        public StdRet init_BuildingValue()
        {
            StdRet ret = new StdRet();
            try
            {
                HashMap hmapOut = new HashMap();
                hmapOut.Put("Table", getBuildingValue());
                hmapOut.Put("City", get_City());
                hmapOut.Put("Paras_Adm_Material", get_ddlBindData(1));
                
                ret.data = hmapOut;
            }
            catch (Exception e)
            {
                ret.setRc(StdRet.RC.INTERNAL_ERR, e.Message);
            }

            return ret;
        }

        /// <summary>
        /// 建物造價參考標準表維護... 
        /// 新增
        /// </summary>
        /// <param name="cmd">
        /// Version 版本日期 &#13;
        /// Version\_new 版本日期\_新值 &#13;
        /// ckVersion 是否執行 複製為新版本日期 &#13;
        /// ID 結構材質代碼 &#13;
        /// CityID 縣市代碼 &#13;
        /// aryCityID 多筆縣市代碼 &#13;
        /// Storey 層次 &#13;
        /// Value 造價 &#13;
        /// FireInsuranceValue 火險金額 &#13;
        /// Status 狀態(1:啟用,0:停用) &#13;
        /// </param>
        /// <returns>建物造價參考標準表維護　資料</returns>
        public StdRet Save_BuildingValue([FromBody]BuildingValue_Cmd cmd)
        {
            StdRet ret = new StdRet();
            DataTable dt = new DataTable();

            if (cmd == null)
            {
                ret.data = "cmd is null";
            }
            else
            {
                string strMsg = " 結構材質重複，請確認後重新輸入";
                try
                {
                    if (cmd.ckVersion)
                    {
                        dt = doInsert_BuildingValue_by_Version(cmd);
                    }
                    else
                    {
                        // simon add 20190328:原本層次欄位須改為區間輸入
                        int count = 0;
                        for (int i = cmd.StoreyStart; i <= cmd.StoreyEnd; i++)
                        {
                            cmd.Storey = i.ToString();
                            count = count_BuildingValue(cmd);
                            if (count > 0)
                            {
                                break;
                            }
                        }
                        if (count > 0)
                        {
                            ret.setRc(StdRet.RC.INTERNAL_ERR, strMsg);
                        }
                        else
                        {
                            dt = doInsert_BuildingValue(cmd);
                        }
                    }

                    HashMap hmapOut = new HashMap();
                    hmapOut.Put("Table", dt);

                    ret.data = hmapOut;
                }
                catch (Exception e)
                {
                    if (e.Message.IndexOf("重複的索引鍵") < 0)
                        strMsg = e.Message;

                    ret.setRc(StdRet.RC.INTERNAL_ERR, strMsg);
                }
            }

            return ret;
        }

        /// <summary>
        /// 建物造價參考標準表維護... 
        /// 更新
        /// </summary>
        /// <param name="cmd">
        /// Version 版本日期 &#13;
        /// Version\_o 版本日期\_原值 &#13;
        /// ID 結構材質代碼 &#13;
        /// ID\_o 結構材質代碼\_原值 &#13;
        /// CityID 縣市代碼 &#13;
        /// CityID\_o 縣市代碼\_原值 &#13;
        /// Storey 層次 &#13;
        /// Storey\_o 層次\_原值 &#13;
        /// Value 造價 &#13;
        /// FireInsuranceValue 火險金額 &#13;
        /// Status 狀態(1:啟用,0:停用) &#13;
        /// </param>
        /// <returns>建物造價參考標準表維護　資料</returns>
        public StdRet update_BuildingValue([FromBody]BuildingValue_Cmd cmd)
        {
            StdRet ret = new StdRet();
            DataTable dt = new DataTable();

            if (cmd == null)
            {
                ret.data = "cmd is null";
            }
            else
            {
                string strMsg = " 結構材質重複，請確認後重新輸入";
                try
                {
                    dt = doUpdate_BuildingValue(cmd);

                    HashMap hmapOut = new HashMap();
                    hmapOut.Put("Table", dt);

                    ret.data = hmapOut;
                }
                catch (Exception e)
                {
                    if (e.Message.IndexOf("重複的索引鍵") < 0)
                        strMsg = e.Message;

                    ret.setRc(StdRet.RC.INTERNAL_ERR, strMsg);
                }
            }

            return ret;
        }

        /// <summary>
        /// 建物造價參考標準表維護... 
        /// 查詢／篩選條件
        /// </summary>
        /// <param name="cmd"></param>
        /// Version 版本日期 &#13;
        /// MaterialCode 結構材質 &#13;
        /// CityCode 縣市代碼 &#13;
        /// <returns></returns>
        [HttpPost]
        public StdRet BuildingValue_Qry([FromBody]BuildingValue_Cmd cmd) {
            StdRet ret = new StdRet();
            if (cmd == null)
            {
                ret.setRc(StdRet.RC.INTERNAL_ERR, "請輸入參數值 cmd！");
                return ret;
            }

            try
            {
                HashMap hmapOut = new HashMap();
                hmapOut.Put("Table", getBuildingValue(cmd));
                hmapOut.Put("City", get_City());
                ret.data = hmapOut;
            }
            catch (Exception e)
            {
                ret.setRc(StdRet.RC.INTERNAL_ERR, e.Message);
            }

            return ret;

        }
        private DataTable getBuildingValue([FromBody]BuildingValue_Cmd cmd = null)
        {
            DataTable dtbOut = new DataTable();
            int m_TotalNum = 0;
            string strSql = @"WITH TEMP
                                AS (
	                                SELECT CityCode
		                                ,CityItem
		                                ,DataSort
	                                FROM Paras_Adm_City
	                                )
                                SELECT Version
	                                    ,m.MaterialCode
	                                    ,a.MaterialItem
                                        ,m.CityCode
                                        ,TEMP.CityItem
                                        ,Storey
                                        ,Currency
                                        ,Value
                                        ,FireInsuranceValue
	                                    ,Status
	                                    ,m.LastUpdateDate
                                    FROM Maintain_Imm_BuildingValue m
                                    LEFT JOIN Paras_Adm_Material a ON a.MaterialCode = m.MaterialCode
                                    LEFT JOIN TEMP ON TEMP.CityCode = m.CityCode
                                    {0}
                                    ORDER BY Version DESC, MaterialCode
	                                        ,TEMP.DataSort
                                ;";
            try
            {
                HashMap inputParam = new HashMap();
                string strWhere = "";

                if (cmd != null)
                {
                    inputParam = getInputParam(cmd);
                    inputParam.Put("@Version", CDate.getDate_West(cmd.Version).Replace("/", ""));
                    ArrayList al = new ArrayList();
                    if (!string.IsNullOrEmpty(cmd.Version))
                        al.Add("m.Version = @Version");
                    if (!string.IsNullOrEmpty(cmd.MaterialCode))
                        al.Add("m.MaterialCode = @MaterialCode");
                    if (!string.IsNullOrEmpty(cmd.CityCode))
                        al.Add("m.CityCode = @CityCode");
                    if (al.Count > 0)
                        strWhere = " WHERE " + string.Join(" AND ", (string[])al.ToArray(typeof(string)));
                }

                dtbOut = DBUtil.Qry(string.Format(strSql, strWhere), inputParam);
                m_TotalNum = dtbOut.Rows.Count;
            }
            catch (Exception ex)
            {
                throw ex;
            }
           
            return dtbOut;
        }

        private DataTable get_ddlBindData(int Type)
        {
            DataTable dtb = new DataTable();
            string strSql = "";

            switch (Type)
            {
                case 1:
                    strSql = @"SELECT 
                                    MaterialCode as ItemValue
	                                ,MaterialItem as ItemText
                               FROM 
                                    Paras_Adm_Material
                               ORDER BY 
                                    MaterialCode";
                    break;

            }

            dtb = DBUtil.Qry(strSql);
            return dtb;
        }

        private int count_BuildingValue(BuildingValue_Cmd cmd)
        {
            DataTable dt = new DataTable();
            int intCount;
            string strCityIDs = cmd.aryCityID;
            string strSql = @"  SELECT 
                                    count(*) as Count
                                FROM 
                                    Maintain_Imm_BuildingValue
                                WHERE 
                                    Version = @Version
                                AND 
                                    MaterialCode = @MaterialCode
                                AND 
                                    Storey = @Storey
                            	AND 
                                    CityCode IN ('"+strCityIDs+"');";

            HashMap inputParam = new HashMap();
            inputParam.Put("@Version", CDate.getDate_West(cmd.Version).Replace("/", ""));
            inputParam.Put("@MaterialCode", cmd.MaterialCode);
            inputParam.Put("@Storey", cmd.Storey);


            dt = DBUtil.Qry(strSql, inputParam);
            String Str = dt.Rows[0]["Count"].ToString();
            if (Str == "0")
            {
                intCount = 0;
            }
            else
            {
                intCount = 1;
            }
            return intCount;
        }

        private DataTable doUpdate_BuildingValue(BuildingValue_Cmd cmd)
        {
            DataTable dt = new DataTable();
            String strSql = @"  UPDATE 
                                    Maintain_Imm_BuildingValue
                                SET   
                                    LastUpdateRoleNo = @LastUpdateRoleNo
                                    ,LastUpdateEmpNo = @LastUpdateEmpNo
                                    ,LastUpdateBranchNo = @LastUpdateBranchNo
                                    ,LastUpdateDate = GETDATE()
                                    ,MaterialCode = @MaterialCode
                                    ,CityCode = @CityCode
                                    ,Storey = @Storey
                                    ,Currency = @Currency
                                    ,Value = @Value
                                    ,FireInsuranceValue = @FireInsuranceValue
                                    ,Status = @Status
                                WHERE 
                                    Version = @Version_o
                                AND 
                                    MaterialCode = @MaterialCode_o
                                AND 
                                    CityCode = @CityCode_o
                                AND 
                                    Storey = @Storey_o
                                    ;";

            HashMap inputParam = getInputParam(cmd);
            inputParam.Put("@Version_o", cmd.Version_o);
            inputParam.Put("@MaterialCode_o", cmd.MaterialCode_o);
            inputParam.Put("@Storey_o", cmd.Storey_o);
            inputParam.Put("@CityCode_o", cmd.CityCode_o);

            DBUtil.ExecNonQry(strSql, inputParam);
            dt = getBuildingValue();
            return dt;

        }

        private DataTable doInsert_BuildingValue(BuildingValue_Cmd cmd)
        {
            DataTable dt = new DataTable();
                        
            DbConnection conn = DBUtil.GetConn();
            conn.Open();
            DbTransaction tran = conn.BeginTransaction();
            HashMap MainInput = new HashMap();

            String strCityCode = cmd.CityCode;
            String[] City = strCityCode.Split(',');
            String mainupdate = "";
            try
            {
                for (int i = 0; i < City.Length; i++)
                {
                    // simon add 20190328:原本層次欄位須改為區間輸入
                    for (int j = cmd.StoreyStart; j <= cmd.StoreyEnd; j++)
                    {
                        if (MainInput.Count >= 2000)
                        {
                            DBUtil.ExecNonQry(mainupdate, MainInput, tran);
                            mainupdate = "";
                            MainInput = new HashMap();
                        }

                        if (MainInput.Count < 2000)
                        {
                            cmd.Storey = j.ToString();

                            mainupdate += @"INSERT INTO 
                                            Maintain_Imm_BuildingValue 
                                            (
	                                            LastUpdateRoleNo
	                                            ,LastUpdateEmpNo
	                                            ,LastUpdateBranchNo
	                                            ,LastUpdateDate
                                                ,Version
                                                ,MaterialCode
                                                ,CityCode
                                                ,Storey
                                                ,Currency
                                                ,Value
                                                ,FireInsuranceValue
                                                ,Status
	                                        )
                                            VALUES 
                                            (
		                                        @LastUpdateRoleNo
                                                ,@LastUpdateEmpNo
                                                ,@LastUpdateBranchNo
                                                ,GETDATE()
                                                ,@Version
                                                ,@MaterialCode
                                                ,'" + City[i] + @"'
                                                ,'" + cmd.Storey + @"'
                                                ,@Currency
                                                ,@Value
                                                ,@FireInsuranceValue
                                                ,@Status
		                                    )
                                            ;";

                            MainInput.Put("@Version", CDate.getDate_West(cmd.Version).Replace("/", ""));

                            MainInput.Put("@MaterialCode", cmd.MaterialCode);
                            //MainInput.Put("@Storey", cmd.Storey);
                            MainInput.Put("@Currency", cmd.Currency);
                            MainInput.Put("@Value", cmd.Value);
                            MainInput.Put("@FireInsuranceValue", cmd.FireInsuranceValue);
                            MainInput.Put("@Status", cmd.Status);

                            MainInput.Put("@LastUpdateEmpNo", g_clsSessionSecurity.EmpNo);
                            MainInput.Put("@LastUpdateRoleNo", g_clsSessionSecurity.RoleNo);
                            MainInput.Put("@LastUpdateBranchNo", g_clsSessionSecurity.BranchNo);
                        }
                    }
                }

                if (mainupdate != "")
                {
                    DBUtil.ExecNonQry(mainupdate, MainInput);
                }

                tran.Commit();
                dt = getBuildingValue();
            }
            catch (Exception ex)
            {
                if (tran != null)
                    tran.Rollback();
                throw ex;
            }
            return dt;
        }

        private DataTable doInsert_BuildingValue_by_Version(BuildingValue_Cmd cmd)
        {
            DataTable dt = new DataTable();
            String strSql = @"  INSERT INTO 
                                    Maintain_Imm_BuildingValue 
	                                        SELECT 
	                                             @Version_n
                                                ,MaterialCode
                                                ,CityCode
                                                ,Storey
                                                ,Currency
                                                ,Value
                                                ,FireInsuranceValue
                                                ,Status
	                                            ,@LastUpdateRoleNo
	                                            ,@LastUpdateEmpNo
	                                            ,@LastUpdateBranchNo
	                                            ,GETDATE()
                                            FROM Maintain_Imm_BuildingValue
                                            WHERE Version = @Version
                                            ;";

            HashMap inputParam = getInputParam(cmd);
            inputParam.Put("@Version", CDate.getDate_West(cmd.Version).Replace("/", ""));
            inputParam.Put("@Version_n", CDate.getDate_West(cmd.Version_n).Replace("/",""));

            DBUtil.ExecNonQry(strSql, inputParam);
            dt = getBuildingValue();
            return dt;

        }

        private DataTable get_City()
        {
            String strSql = @"  SELECT 
                                    CityCode as ItemValue
	                                ,CityItem as ItemText
                                FROM 
                                    PARAS_ADM_CITY city
                                WHERE (
		                                city.Disable = '0'
		                                OR '0' = ''
		                                )
                                ORDER BY 
                                    DataSort
	                                ,CityCode
                                ;";

            DataTable dtb = new DataTable();
            HashMap inputParam = new HashMap();
            dtb = DBUtil.Qry(strSql, inputParam);
            //dtb.TableName = p_ControlName;
            return dtb;
        }

        private HashMap getInputParam(BuildingValue_Cmd cmd)
        {
            HashMap inputParam = new HashMap();
                        
            inputParam.Put("@Version", cmd.Version);

            inputParam.Put("@MaterialCode", cmd.MaterialCode);
            inputParam.Put("@CityCode", cmd.CityCode);
            inputParam.Put("@Storey", cmd.Storey);
            inputParam.Put("@Currency", cmd.Currency);
            inputParam.Put("@Value", cmd.Value);
            inputParam.Put("@FireInsuranceValue", cmd.FireInsuranceValue);
            inputParam.Put("@Status", cmd.Status);

            inputParam.Put("@LastUpdateEmpNo", g_clsSessionSecurity.EmpNo);
            inputParam.Put("@LastUpdateRoleNo", g_clsSessionSecurity.RoleNo);
            inputParam.Put("@LastUpdateBranchNo", g_clsSessionSecurity.BranchNo);

            return inputParam;
        }

        /// <summary>
        /// 建物造價參考標準表維護... 
        /// 傳入參數
        /// </summary>
        public class BuildingValue_Cmd
        {
            public String Version_o; //原來的版本日期
            public String Version_n; //新的版本日期
            public String MaterialCode_o;      //原來的ID
            public String Storey_o;  //原來的層次
            public String CityCode_o;  //原來的縣市代碼
            public String Currency = "TWD";
            public bool ckVersion;   //UI checkbox：是否執行 複製為新版本日期
            public String aryCityID;

            public String Version;
            public String MaterialCode;
            public String CityCode;
            public String Storey;
            public String Value;
            public String FireInsuranceValue;
            public String Status;

            public int StoreyStart;
            public int StoreyEnd;
        }

    }

}
