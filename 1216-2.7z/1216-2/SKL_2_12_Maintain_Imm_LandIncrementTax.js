﻿var PAGE_SIZE = 10;
var PAGE_IDX = -1;
var G_IncrementTax = new Array();
var G_LOAD_Waitting_Msg;

var Init = function () {

    var AjaxInputObj =
      {
          url: "SKL_2_12_Maintain_Imm_LandIncrementTax/Init",
          oMethod: genData,
      };

    //call ajax
    docCore.ajax(AjaxInputObj, true, true, G_LOAD_Waitting_Msg);
}

var genData = function (Data) {
    //console.log(Data.data["IncrementTax"]);
    G_IncrementTax = Data.data["IncrementTax"]
    IncrementTaxBox(Data.data["IncrementTax"]);
}

var IncrementTaxBox = function (IncrementTax) {

    $("#IncrementTaxBox").SexyBox({
        boxCtrl: [{
            ID: "IncrementTax",
            HeadForm: "IncrementTaxForm",
            HeadRow: [],
            Head: [],
            BodyForm: "IncrementTaxForm",
            BodyRow: [],
            Body: [
                {
                    Row: "tbCol",
                    ColumnClass: ["align_left bg_White"],
                    Ctrl: [["土地增值稅之計算方法： <br >"
                        , "於計算土地增值稅時，前次移轉現值得以物價指數調整，另土地持有期間之起算點，<br>"
                        , "以土地登記謄本所有權部記載所有權人取得土地所有權之登記日期為準，但有繼承、<br>"
                        , "強制執行、公用徵收或法院判決等情形者，應依主管機關之規定辦理。"]]
                },
                {
                    Row: "tb5Colth",
                    ColumnClass: ["align_left", "align_left bg_gray", "align_left bg_gray", "align_left bg_gray", "align_left bg_gray"],
                    Ctrl: ["稅級別 \<br >持有年限", "20年以下", "20年以上", "30年以上","40年以上"]
                },
                {
                    Row: "tb5Col",
                    ColumnClass: ["align_left", "align_left bg_white", "align_left bg_white", "align_left bg_white", "align_left bg_white"],
                    Ctrl: ["第1級"
                        , ["A&nbsp;-&nbsp;B&nbsp;*&nbsp;C) &nbsp;<br>*"
                            , { Type: "textbox", Name: "Level1_20_Below_1", Data: ["Level1_20_Below_1"] }]
                        , ["A&nbsp;-&nbsp;B&nbsp;*&nbsp;C) &nbsp;<br>*"
                            , { Type: "textbox", Name: "Level1_20_Above_1", Data: ["Level1_20_Above_1"] }]
                        , ["A&nbsp;-&nbsp;B&nbsp;*&nbsp;C) &nbsp;<br>*"
                            , { Type: "textbox", Name: "Level1_30_Above_1", Data: ["Level1_30_Above_1"] }]
                        , ["A&nbsp;-&nbsp;B&nbsp;*&nbsp;C) &nbsp;<br>*"
                            , { Type: "textbox", Name: "Level1_40_Above_1", Data: ["Level1_40_Above_1"] }]
                        ]
                },
                {
                    Row: "tb5Col",
                    ColumnClass: ["align_left", "align_left bg_white", "align_left bg_white", "align_left bg_white", "align_left bg_white"],
                    Ctrl: ["第2級"
                        , ["A&nbsp;*&nbsp;"
                            , { Type: "textbox", Name: "Level2_20_Below_1", Data: ["Level2_20_Below_1"] }, "&nbsp;<br>"
                            , "-&nbsp;B&nbsp;* C&nbsp;*&nbsp;"
                            , { Type: "textbox", Name: "Level2_20_Below_2", Data: ["Level2_20_Below_2"] }
                        ]
                        , ["A&nbsp;*&nbsp;"
                            , { Type: "textbox", Name: "Level2_20_Above_1", Data: ["Level2_20_Above_1"] }, "&nbsp;<br>"
                            , "-&nbsp;B&nbsp;* C&nbsp;*&nbsp;"
                            , { Type: "textbox", Name: "Level2_20_Above_2", Data: ["Level2_20_Above_2"] }
                        ]
                        , ["A&nbsp;*&nbsp;"
                            , { Type: "textbox", Name: "Level2_30_Above_1", Data: ["Level2_30_Above_1"] }, "&nbsp;<br>"
                            , "-&nbsp;B&nbsp;* C&nbsp;*&nbsp;"
                            , { Type: "textbox", Name: "Level2_30_Above_2", Data: ["Level2_30_Above_2"] }
                        ]
                        , ["A&nbsp;*&nbsp;"
                            , { Type: "textbox", Name: "Level2_40_Above_1", Data: ["Level2_40_Above_1"] }, "&nbsp;<br>"
                            , "-&nbsp;B&nbsp;* C&nbsp;*&nbsp;"
                            , { Type: "textbox", Name: "Level2_40_Above_2", Data: ["Level2_40_Above_2"] }
                        ]
                    ]
                },
                {
                    Row: "tb5Col",
                    ColumnClass: ["align_left", "align_left bg_white", "align_left bg_white", "align_left bg_white", "align_left bg_white"],
                    Ctrl: ["第3級"
                        , ["A&nbsp;*"
                            , { Type: "textbox", Name: "Level3_20_Below_1", Data: ["Level3_20_Below_1"] }, "&nbsp;<br>"
                            , "-&nbsp;B&nbsp;* C *"
                            , { Type: "textbox", Name: "Level3_20_Below_2", Data: ["Level3_20_Below_2"] }
                        ]
                        , ["A&nbsp;*"
                            , { Type: "textbox", Name: "Level3_20_Above_1", Data: ["Level3_20_Above_1"] }, "&nbsp;<br>"
                            , "-&nbsp;B&nbsp;* C *"
                            , { Type: "textbox", Name: "Level3_20_Above_2", Data: ["Level3_20_Above_2"] }
                        ]
                        , ["A&nbsp;*"
                            , { Type: "textbox", Name: "Level3_30_Above_1", Data: ["Level3_30_Above_1"] }, "&nbsp;<br>"
                            , "-&nbsp;B&nbsp;* C *"
                            , { Type: "textbox", Name: "Level3_30_Above_2", Data: ["Level3_30_Above_2"] }
                        ]
                        , ["A&nbsp;*"
                            , { Type: "textbox", Name: "Level3_40_Above_1", Data: ["Level3_40_Above_1"] }, "&nbsp;<br>"
                            , "-&nbsp;B&nbsp;* C *"
                            , { Type: "textbox", Name: "Level3_40_Above_2", Data: ["Level3_40_Above_2"] }
                        ]
                    ]
                },
                {
                    Row: "tbCol",
                    ColumnClass: ["align_left bg_White"],
                    Ctrl: [["註：A：當期公告土地現值；B：前次移轉現值；C：物價指數。<br>"
                        , "第1級：1≦A/B＜2。   第2級：2≦A/B＜3。   第3級：3≦A/B。<br>"
                        , "土地登記謄本未表明前次移轉現值時，以原規定地價為前次移轉現值。"
                        ]]
                },
                {
                    Row: "tb2Col",
                    ColumnClass: ["align_left", "align_left"],
                    Ctrl: ["第1級：", "1 ≦ A / ( B * C ) ＜2"]
                },
                {
                    Row: "tb2Col",
                    ColumnClass: ["align_left", "align_left"],
                    Ctrl: ["第2級：", "2&nbsp;≦&nbsp;A / ( B *&nbsp;C&nbsp;)&nbsp;＜3 "]
                },
                {
                    Row: "tb2Col",
                    ColumnClass: ["align_left", "align_left"],
                    Ctrl: ["第3級：", "3&nbsp;≦&nbsp;A / ( B *&nbsp;C&nbsp;)"]
                },
                {
                    Row: "tbCol",
                    ColumnClass: ["align_center bg_White"],
                    Ctrl: [["版本日期", { Type: "textbox", Name: "Version", ID: "Version", Data: ["Version"] }]]
                },
            ],
            Data: IncrementTax
        }, {
            Body: [
                     {
                         Row: "",
                         RowClass: "align_center",
                         Ctrl: [{ Type: "a", Data: "儲存", Class: "button add", Event: Data_Save }]
                     }
            ]
        }

        ],

    });

    $("#Version\\|0IIncrementTax").datepicker({ changeYear: true, changeMonth: true, currentText: "Now", dateFormat: "R/mm/dd", showButtonPanel: false });

}

var Data_Save = function () {
    var jsonObj = $.valToJson("IncrementTaxBox");
    //console.log(jsonObj);

    var AjaxInputObj =
    {
        url: "SKL_2_12_Maintain_Imm_LandIncrementTax/Data_Save",
        data: jsonObj,
        oMethod: function (Data) {
            SexyAlert("提示", G_Convert.msg("000011"), "OK", "OKONLY", function () {
                IncrementTaxBox(Data.data["IncrementTax"]);
            });
        },
    };

    //call ajax
    docCore.ajax(AjaxInputObj, true, true, G_LOAD_Waitting_Msg);

}


$(document).ready(function () {
    Init();
});