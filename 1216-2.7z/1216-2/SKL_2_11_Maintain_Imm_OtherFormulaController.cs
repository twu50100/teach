﻿using System;
using System.Web.Http;
using Gemfor.Mvc;
using System.Data;
using Gemfor.Util;
using Gemfor.Auth;
using App_Code;

namespace SKL_LOAN.Controllers.Api.eLoan.Manage.Imm
{
    /// <summary>
    /// 不動產鑑價報告_公式及參數設定... 
    /// </summary>
    public class SKL_2_11_Maintain_Imm_OtherFormulaController : BasePageController
    {
        /// <summary>
        /// 不動產鑑價報告_公式及參數設定... 
        /// 初始化
        /// </summary>
        /// <returns>不動產鑑價報告_公式及參數設定　資料</returns>
        [HttpPost]
        public StdRet Init()
        {
            StdRet ret = new StdRet();
            try
            {
                HashMap hmapOut = new HashMap();
                hmapOut.Put("FormulaBind", getOtherFormula());

                ret.data = hmapOut;
            }
            catch (Exception e)
            {
                ret.setRc(StdRet.RC.INTERNAL_ERR, e.Message);
            }

            return ret;
        }

        /// <summary>
        /// 不動產鑑價報告_公式及參數設定... 
        /// 儲存
        /// </summary>
        /// <param name="cmd">
        /// DepreciationRate 當折舊率大於 DepreciationRate 時 &#13;
        /// Attach_Ground_Param 附屬建物-地面層樓地板面積 * Attach_Ground_Param * 興建樓層 &#13;
        /// Attach_MainBuild_Param 附屬建物-主建物樓地板面積(坪)  * Attach_MainBuild_Param  &#13;
        /// Attach_Basement_Param 附屬建物-地下室樓地板面積(坪)  * Attach_Basement_Param &#13;
        /// House_Param_1 屋突等面積=地面層樓地板面積 * House_Param_1/House_Param_2 &#13;
        /// House_Param_2 屋突等面積=地面層樓地板面積 * House_Param_1/House_Param_2 &#13;
        /// Reward_ParkingSpace 獎勵停車位數 &#13;
        /// Real_ParkingSpace_Param_1 實設停車位數=(地下室樓地板面積(坪)/0.3025)*Real_ParkingSpace_Param_1/Real_ParkingSpace__Param_2 &#13;
        /// Real_ParkingSpace_Param_2 實設停車位數=(地下室樓地板面積(坪)/0.3025)*Real_ParkingSpace_Param_1/Real_ParkingSpace__Param_2 &#13;
        /// DecimalLeftPlace 數值四捨五入至小數點左邊第N位 &#13;
        /// Expenses_Design_S 規劃設計費用法定比例起 &#13;
        /// Expenses_Design_E 規劃設計費用法定比例迄 &#13;
        /// Expenses_Commercial_S 廣告銷售費用法定比例起 &#13;
        /// Expenses_Commercial_E 廣告銷售費用法定比例迄 &#13;
        /// Expenses_Manage_S 管理費用法定比例起 &#13;
        /// Expenses_Manage_E 管理費用法定比例迄 &#13;
        /// Expenses_Tax_S 稅捐費用法定比例起 &#13;
        /// Expenses_Tax_E 稅捐費用法定比例迄 &#13;
        /// DevelopPeriod_1_S 開發工期一年以內者起 &#13;
        /// DevelopPeriod_1_E 開發工期一年以內者迄 &#13;
        /// DevelopPeriod_2_S 開發工期一年至二年者起 &#13;
        /// DevelopPeriod_2_E 開發工期一年至二年者迄 &#13;
        /// DevelopPeriod_3_S 開發工期二年至三年者起 &#13;
        /// DevelopPeriod_3_E 開發工期二年至三年者迄 &#13;
        /// DevelopPeriod_4_S 發工期三年至四年者起 &#13;
        /// DevelopPeriod_4_E 開發工期三年至四年者迄 &#13;
        /// CapitalInterest_Build 建築投資資本利息 &#13;
        /// CapitalInterest_Land 土地投資資本利息 &#13;
        /// </param>
        /// <returns>不動產鑑價報告_公式及參數設定　資料</returns>
        public StdRet Data_Save([FromBody]SKL_2_11_Maintain_Imm_OtherFormulaCmd cmd)
        {
            StdRet ret = new StdRet();
            DataTable dt = new DataTable();

            if (cmd == null)
            {
                ret.data = "cmd is null";
            }
            else
            {
                try
                {
                    if (count_OtherFormula() > 0)
                    {
                        dt = doUpdate_OtherFormula(cmd);
                    }
                    else
                    {
                        dt = doInsert_OtherFormula(cmd);
                    }

                    HashMap hmapOut = new HashMap();
                    hmapOut.Put("FormulaBind", dt);

                    ret.data = hmapOut;
                }
                catch (Exception e)
                {
                    ret.setRc(StdRet.RC.INTERNAL_ERR, e.Message);
                }
            }

            return ret;
        }

        private DataTable getOtherFormula()
        {
            DataTable dtbOut = new DataTable();

            string strSql = @"SELECT 
                                 LastUpdateRoleNo
                                ,LastUpdateEmpNo
                                ,LastUpdateBranchNo
                                ,LastUpdateDate
                                ,DepreciationRate
                                ,AttachGroundParam
                                ,AttachMainBuildParam
                                ,AttachBasementParam
                                ,HouseParam1
                                ,HouseParam2
                                ,RewardParkingSpace
                                ,RealParkingSpaceParam1
                                ,RealParkingSpaceParam2
                                ,DecimalLeftPlace
                                ,ExpensesDesignS
                                ,ExpensesDesignE
                                ,ExpensesCommercialS
                                ,ExpensesCommercialE
                                ,ExpensesManageS
                                ,ExpensesManageE
                                ,ExpensesTaxS
                                ,ExpensesTaxE
                                ,DevelopPeriod1S
                                ,DevelopPeriod1E
                                ,DevelopPeriod2S
                                ,DevelopPeriod2E
                                ,DevelopPeriod3S
                                ,DevelopPeriod3E
                                ,DevelopPeriod4S
                                ,DevelopPeriod4E
                                ,CapitalInterestBuild
                                ,CapitalInterestLand
                            FROM 
                                Maintain_Imm_OtherFormula
                        ;";

            dtbOut = DBUtil.Qry(strSql);
            return dtbOut;
        }

        private int count_OtherFormula()
        {
            int intCount = 0;

            string strSql = @"SELECT count(*)
                                FROM Maintain_Imm_OtherFormula
                                ";

            intCount = (int)DBUtil.ExecuteScalar(strSql);
            return intCount;
        }

        private DataTable doUpdate_OtherFormula(SKL_2_11_Maintain_Imm_OtherFormulaCmd cmd)
        {
            DataTable dt = new DataTable();
            String strSql = @" UPDATE 
                                    Maintain_Imm_OtherFormula
                               SET 
                                     LastUpdateRoleNo = @LastUpdateRoleNo
									,LastUpdateEmpNo = @LastUpdateEmpNo
									,LastUpdateBranchNo = @LastUpdateBranchNo
									,LastUpdateDate = GETDATE()
                                    ,DepreciationRate = @DepreciationRate
                                    ,AttachGroundParam = @AttachGroundParam
                                    ,AttachMainBuildParam = @AttachMainBuildParam
                                    ,AttachBasementParam = @AttachBasementParam
                                    ,HouseParam1 = @HouseParam1
                                    ,HouseParam2 = @HouseParam2
                                    ,RewardParkingSpace = @RewardParkingSpace
                                    ,RealParkingSpaceParam1= @RealParkingSpaceParam1
                                    ,RealParkingSpaceParam2= @RealParkingSpaceParam2
                                    ,DecimalLeftPlace = @DecimalLeftPlace
                                    ,ExpensesDesignS = @ExpensesDesignS
                                    ,ExpensesDesignE = @ExpensesDesignE
                                    ,ExpensesCommercialS = @ExpensesCommercialS
                                    ,ExpensesCommercialE = @ExpensesCommercialE
                                    ,ExpensesManageS = @ExpensesManageS
                                    ,ExpensesManageE = @ExpensesManageE
                                    ,ExpensesTaxS = @ExpensesTaxS
                                    ,ExpensesTaxE = @ExpensesTaxE
                                    ,DevelopPeriod1S = @DevelopPeriod1S
                                    ,DevelopPeriod1E = @DevelopPeriod1E
                                    ,DevelopPeriod2S = @DevelopPeriod2S
                                    ,DevelopPeriod2E = @DevelopPeriod2E
                                    ,DevelopPeriod3S = @DevelopPeriod3S
                                    ,DevelopPeriod3E = @DevelopPeriod3E
                                    ,DevelopPeriod4S = @DevelopPeriod4S
                                    ,DevelopPeriod4E = @DevelopPeriod4E
                                    ,CapitalInterestBuild = @CapitalInterestBuild
                                    ,CapitalInterestLand = @CapitalInterestLand
                                                                ;";

            HashMap inputParam = getInputParam(cmd);

            DBUtil.ExecNonQry(strSql, inputParam);
            dt = getOtherFormula();
            return dt;

        }

        private DataTable doInsert_OtherFormula(SKL_2_11_Maintain_Imm_OtherFormulaCmd cmd)
        {
            DataTable dt = new DataTable();
            String strSql = @"INSERT INTO 
                                Maintain_Imm_OtherFormula (
	                                LastUpdateRoleNo
	                                ,LastUpdateEmpNo
	                                ,LastUpdateBranchNo
	                                ,LastUpdateDate
	                                ,DepreciationRate
	                                ,AttachGroundParam
	                                ,AttachMainBuildParam
	                                ,AttachBasementParam
	                                ,HouseParam1
	                                ,HouseParam2
	                                ,RewardParkingSpace
	                                ,RealParkingSpaceParam1
	                                ,RealParkingSpaceParam2
	                                ,DecimalLeftPlace
	                                ,ExpensesDesignS
	                                ,ExpensesDesignE
	                                ,ExpensesCommercialS
	                                ,ExpensesCommercialE
	                                ,ExpensesManageS
	                                ,ExpensesManageE
	                                ,ExpensesTaxS
	                                ,ExpensesTaxE
	                                ,DevelopPeriod1S
	                                ,DevelopPeriod1E
	                                ,DevelopPeriod2S
	                                ,DevelopPeriod2E
	                                ,DevelopPeriod3S
	                                ,DevelopPeriod3E
	                                ,DevelopPeriod4S
	                                ,DevelopPeriod4E
	                                ,CapitalInterestBuild
	                                ,CapitalInterestLand
	                                )
                                VALUES (
		                            @LastUpdateRoleNo
                                    ,@LastUpdateEmpNo
                                    ,@LastUpdateBranchNo
                                    ,GETDATE()
                                    ,@DepreciationRate
                                    ,@AttachGroundParam
                                    ,@AttachMainBuildParam
                                    ,@AttachBasementParam
                                    ,@HouseParam1
                                    ,@HouseParam2
                                    ,@RewardParkingSpace
                                    ,@RealParkingSpaceParam1
                                    ,@RealParkingSpaceParam2
                                    ,@DecimalLeftPlace
                                    ,@ExpensesDesignS
                                    ,@ExpensesDesignE
                                    ,@ExpensesCommercialS
                                    ,@ExpensesCommercialE
                                    ,@ExpensesManageS
                                    ,@ExpensesManageE
                                    ,@ExpensesTaxS
                                    ,@ExpensesTaxE
                                    ,@DevelopPeriod1S
                                    ,@DevelopPeriod1E
                                    ,@DevelopPeriod2S
                                    ,@DevelopPeriod2E
                                    ,@DevelopPeriod3S
                                    ,@DevelopPeriod3E
                                    ,@DevelopPeriod4S
                                    ,@DevelopPeriod4E
                                    ,@CapitalInterestBuild
                                    ,@CapitalInterestLand
		                            )
                            ;";

            HashMap inputParam = getInputParam(cmd);

            DBUtil.ExecNonQry(strSql, inputParam);
            dt = getOtherFormula();
            return dt;
        }

        private HashMap getInputParam(SKL_2_11_Maintain_Imm_OtherFormulaCmd cmd)
        {
            HashMap inputParam = new HashMap();
                        
            inputParam.Put("@DepreciationRate", cmd.DepreciationRate);
            inputParam.Put("@AttachGroundParam", cmd.AttachGroundParam);
            inputParam.Put("@AttachMainBuildParam", cmd.AttachMainBuildParam);
            inputParam.Put("@AttachBasementParam", cmd.AttachBasementParam);
            inputParam.Put("@HouseParam1", cmd.HouseParam1);
            inputParam.Put("@HouseParam2", cmd.HouseParam2);
            inputParam.Put("@RewardParkingSpace", cmd.RewardParkingSpace);
            inputParam.Put("@RealParkingSpaceParam1", cmd.RealParkingSpaceParam1);
            inputParam.Put("@RealParkingSpaceParam2", cmd.RealParkingSpaceParam2);
            inputParam.Put("@DecimalLeftPlace", cmd.DecimalLeftPlace);
            inputParam.Put("@ExpensesDesignS", cmd.ExpensesDesignS);
            inputParam.Put("@ExpensesDesignE", cmd.ExpensesDesignE);
            inputParam.Put("@ExpensesCommercialS", cmd.ExpensesCommercialS);
            inputParam.Put("@ExpensesCommercialE", cmd.ExpensesCommercialE);
            inputParam.Put("@ExpensesManageS", cmd.ExpensesManageS);
            inputParam.Put("@ExpensesManageE", cmd.ExpensesManageE);
            inputParam.Put("@ExpensesTaxS", cmd.ExpensesTaxS);
            inputParam.Put("@ExpensesTaxE", cmd.ExpensesTaxE);
            inputParam.Put("@DevelopPeriod1S", cmd.DevelopPeriod1S);
            inputParam.Put("@DevelopPeriod1E", cmd.DevelopPeriod1E);
            inputParam.Put("@DevelopPeriod2S", cmd.DevelopPeriod2S);
            inputParam.Put("@DevelopPeriod2E", cmd.DevelopPeriod2E);
            inputParam.Put("@DevelopPeriod3S", cmd.DevelopPeriod3S);
            inputParam.Put("@DevelopPeriod3E", cmd.DevelopPeriod3E);
            inputParam.Put("@DevelopPeriod4S", cmd.DevelopPeriod4S);
            inputParam.Put("@DevelopPeriod4E", cmd.DevelopPeriod4E);
            inputParam.Put("@CapitalInterestBuild", cmd.CapitalInterestBuild);
            inputParam.Put("@CapitalInterestLand", cmd.CapitalInterestLand);

            //補Session
            inputParam.Put("@LastUpdateEmpNo", g_clsSessionSecurity.EmpNo);
            inputParam.Put("@LastUpdateRoleNo", g_clsSessionSecurity.RoleNo);
            inputParam.Put("@LastUpdateBranchNo", g_clsSessionSecurity.BranchNo);

            return inputParam;
        }

        /// <summary>
        /// 不動產鑑價報告_公式及參數設定... 
        /// 傳入參數
        /// </summary>
        public class SKL_2_11_Maintain_Imm_OtherFormulaCmd
        {
            public String DepreciationRate;
            public String AttachGroundParam;
            public String AttachMainBuildParam;
            public String AttachBasementParam;
            public String HouseParam1;
            public String HouseParam2;
            public String RewardParkingSpace;
            public String RealParkingSpaceParam1;
            public String RealParkingSpaceParam2;
            public String DecimalLeftPlace;
            public String ExpensesDesignS;
            public String ExpensesDesignE;
            public String ExpensesCommercialS;
            public String ExpensesCommercialE;
            public String ExpensesManageS;
            public String ExpensesManageE;
            public String ExpensesTaxS;
            public String ExpensesTaxE;
            public String DevelopPeriod1S;
            public String DevelopPeriod1E;
            public String DevelopPeriod2S;
            public String DevelopPeriod2E;
            public String DevelopPeriod3S;
            public String DevelopPeriod3E;
            public String DevelopPeriod4S;
            public String DevelopPeriod4E;
            public String CapitalInterestBuild;
            public String CapitalInterestLand;
        }

    }
}
