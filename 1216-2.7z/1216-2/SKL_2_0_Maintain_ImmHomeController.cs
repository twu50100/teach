﻿using System;
using System.Web.Http;
using Gemfor.Mvc;
using System.Data;
using Gemfor.Util;
using System.IO;
using System.Xml;
using System.Collections.Generic;
using System.Linq;

namespace SKL_LOAN.Controllers.Api.eLoan.Manage.Imm
{
    /// <summary>
    /// 鑑價維護清單頁面  
    /// </summary>
    public class SKL_2_0_Maintain_ImmHomeController : BasePageController
    {
        /// <summary>
        /// 鑑價維護清單頁面  
        /// </summary>
        /// <param name="cmd">
        /// LocationPath 鑑價維護清單頁面路徑 &#13;
        /// ex. /eLoan/Manage/Imm/ &#13;
        /// EnterPageName 鑑價維護清單頁面名稱 &#13;
        /// ex. SKL_1_0_Maintain_ImmHome.html &#13;
        /// </param>
        /// <returns>鑑價維護清單 資料</returns>
        [HttpPost]
        public StdRet init_ImmHome_List([FromBody]ImmHomeList_Cmd cmd)
        {
            StdRet ret = new StdRet();
            try
            {
                HashMap hmapOut = new HashMap();
                hmapOut.Put("Table", getFileList(cmd));

                ret.data = hmapOut;
            }
            catch (Exception e)
            {
                ret.setRc(StdRet.RC.INTERNAL_ERR, e.Message);
            }

            return ret;
        }
        private DataTable getFileList(ImmHomeList_Cmd cmd)
        {
            //Logger.Debug(cmd.LocationPath.IndexOf("/"));
            String strWebPagePath = cmd.LocationPath.Replace(cmd.EnterPageName, "");//@"eLoan/Manage/Imm/";
            strWebPagePath = (cmd.LocationPath.IndexOf("/") == 0) ? strWebPagePath.Substring(1) : strWebPagePath;

            string strFileExt = cmd.EnterPageName.Substring(cmd.EnterPageName.LastIndexOf("."));
            //String g_strHidePageName = "35_0_ImmList.aspx;35_2_Maintain_Relation_Type.aspx;35_2_Maintain_Restrict_Alter.aspx;35_2_Maintain_Restrict_Refund.aspx";
            string strDomainBase = AppDomain.CurrentDomain.BaseDirectory;
            //D:\Proj\GemFor\SVN\A04系統開發\程式\Web\LOAN_MVC\SKL_LOAN\
            // /eLoan/Manage/Imm/SKL_1_1_Maintain_CountCode.html

            string strFilePath = string.Format("{0}{1}", strDomainBase, strWebPagePath.Replace(@"/", @"\"));

            Logger.Debug(">>> " + strFilePath);

            DataTable dtFileInfo = new DataTable();
            var dtColns = dtFileInfo.Columns;
            dtColns.Add("ID", typeof(System.Int32)).AllowDBNull = false;
            dtColns.Add("TitleName", typeof(System.String));
            dtColns.Add("PgName", typeof(System.String));
            dtColns.Add("Url", typeof(System.String));
            dtColns["ID"].Unique = true;
            dtColns["ID"].AutoIncrement = true;
            dtColns["ID"].AutoIncrementSeed = 1;

            cmd.FilePath = strFilePath;
            cmd.WebPagePath = strWebPagePath;
            cmd.FileExt = strFileExt;

            FindFiles(ref dtFileInfo, cmd);

            return dtFileInfo;
        }
        // 添加弱點掃描 add by jessie 2019/3/14
        private void FindFiles(ref DataTable dt, ImmHomeList_Cmd cmd)//, string g_strHidePageName=null)
        {
            string[] strFiles = Directory.GetFiles(MyHTMLEncode(cmd.FilePath), string.Format("*{0}", MyHTMLEncode(cmd.FileExt)));

            //string[] m_strHidePageNameArray = g_strHidePageName.Split(';');

            //例外清單
            var IgnoreFileList = GetIgnoreFile();

            for (int i = 0; i <= strFiles.Length - 1; i++)
            {
                string strFileData = strFiles[i];

                string[] aryFileName = strFiles[i].Split('\\');
                string strFileName = aryFileName[aryFileName.Length - 1];
                Logger.Debug(">>>>> " + strFileName);

                bool isOk = true;
                if (cmd.EnterPageName.Equals(strFileName)) isOk = false;

                //比對例外清單
                if (IgnoreFileList.Any(strFileName.Contains))
                    isOk = false;
                //for (int j = 0; j <= m_strHidePageNameArray.Length - 1; j++)
                //{
                //    if (strFiles[i].ToLower().IndexOf(m_strHidePageNameArray[j].ToLower()) > 0)
                //    {
                //        m_bolFlag = false;
                //        break; // TODO: might not be correct. Was : Exit For
                //    }
                //}

                if (isOk)
                {
                    DataRow dr = dt.NewRow();
                    dr["TitleName"] = getTitle(strFileData);
                    dr["PgName"] = strFileName;
                    dr["Url"] = cmd.WebPagePath.Replace("\\", "/");
                    Logger.Debug(">>>>> " + dr["Url"].ToString());
                    dt.Rows.Add(dr);
                }

            }
        }

        private string getTitle(string filepath)
        {
            string result = "";
            StreamReader reader = new StreamReader(filepath, System.Text.Encoding.GetEncoding("utf-8"));
            while (!reader.EndOfStream)
            {
                string strLineData = reader.ReadLine();
                if (strLineData.IndexOf("<title>") > 0)
                {
                    XmlDocument xmlparse = new XmlDocument();
                    xmlparse.LoadXml(strLineData);

                    XmlNodeList elemlist = xmlparse.GetElementsByTagName("title");

                    result = elemlist[0].InnerXml;

                }
            }
            reader.Close();
            Logger.Debug(result);
            return result;
        }


        /// <summary>
        /// 鑑價維護清單頁面 維護... 
        /// 傳入參數
        /// </summary>
        public class ImmHomeList_Cmd
        {
            public String LocationPath = "/eLoan/Manage/Imm/SKL_1_0_Maintain_ImmHome.html";
            public String EnterPageName = "SKL_1_0_Maintain_ImmHome.html";

            public String FilePath;
            public String WebPagePath;
            public String FileExt;
        }

        /// <summary>
        /// 例外清單
        /// </summary>
        /// <returns></returns>
        private List<string> GetIgnoreFile()
        {
            var RoleNo = g_clsSessionSecurity.RoleNo;
            var IgnoreFL = new List<string>();

            switch (RoleNo)
            {
                case "80":
                case "90":
                    //沒擋
                    break;
                default:
                    //估價報告書公式及參數設定
                    IgnoreFL.Add("SKL_2_11_Maintain_Imm_OtherFormula.html");
                    //土地增值稅的計算方法
                    IgnoreFL.Add("SKL_2_12_Maintain_Imm_LandIncrementTax.html");
                    //物價指數表維護
                    IgnoreFL.Add("SKL_2_6_Maintain_Imm_CPI.html");
                    //建物造價參考標準維護(建物造價參考標準表維護)
                    IgnoreFL.Add("SKL_2_9_Maintain_Imm_BuildingValue.html");
                    break;
            }
            return IgnoreFL;
        }
    }
}
