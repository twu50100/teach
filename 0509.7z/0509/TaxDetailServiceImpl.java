package tw.com.skl.exp.kernel.model6.logic.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import tw.com.skl.common.model6.logic.impl.BaseServiceImpl;
import tw.com.skl.exp.kernel.model6.bo.AccClassType.AccClassTypeCode;
import tw.com.skl.exp.kernel.model6.bo.AccKindType.AccKindTypeCode;
import tw.com.skl.exp.kernel.model6.bo.AccTitle;
import tw.com.skl.exp.kernel.model6.bo.AccTitle.AccTitleCode;
import tw.com.skl.exp.kernel.model6.bo.ApplInfo;
import tw.com.skl.exp.kernel.model6.bo.Area;
import tw.com.skl.exp.kernel.model6.bo.BigType.BigTypeCode;
import tw.com.skl.exp.kernel.model6.bo.Department;
import tw.com.skl.exp.kernel.model6.bo.Entry;
import tw.com.skl.exp.kernel.model6.bo.EntryExpGroup;
import tw.com.skl.exp.kernel.model6.bo.EntryType.EntryTypeCode;
import tw.com.skl.exp.kernel.model6.bo.ExpapplB;
import tw.com.skl.exp.kernel.model6.bo.ExpapplC;
import tw.com.skl.exp.kernel.model6.bo.ExpapplD;
import tw.com.skl.exp.kernel.model6.bo.GainPerson;
import tw.com.skl.exp.kernel.model6.bo.GeneralExp;
import tw.com.skl.exp.kernel.model6.bo.Hospital;
import tw.com.skl.exp.kernel.model6.bo.ImmovExp;
import tw.com.skl.exp.kernel.model6.bo.IncomeIdType;
import tw.com.skl.exp.kernel.model6.bo.IncomeIdType.IncomeIdTypeCode;
import tw.com.skl.exp.kernel.model6.bo.IncomeUser;
import tw.com.skl.exp.kernel.model6.bo.InvestExp;
import tw.com.skl.exp.kernel.model6.bo.ManualAccountAppl;
import tw.com.skl.exp.kernel.model6.bo.ManualAccountDetail;
import tw.com.skl.exp.kernel.model6.bo.MedicalExp;
import tw.com.skl.exp.kernel.model6.bo.MedicalWithholdFmt.MedicalWithholdFmtCode;
import tw.com.skl.exp.kernel.model6.bo.MiddleType.MiddleTypeCode;
import tw.com.skl.exp.kernel.model6.bo.PaybackType.PaybackTypeCode;
import tw.com.skl.exp.kernel.model6.bo.PaymentType.PaymentTypeCode;
import tw.com.skl.exp.kernel.model6.bo.Proof;
import tw.com.skl.exp.kernel.model6.bo.ProofState.ProofStateCode;
import tw.com.skl.exp.kernel.model6.bo.ProofType.ProofTypeCode;
import tw.com.skl.exp.kernel.model6.bo.PubAffCarExp;
import tw.com.skl.exp.kernel.model6.bo.RemitMoney;
import tw.com.skl.exp.kernel.model6.bo.RentContract;
import tw.com.skl.exp.kernel.model6.bo.RentExp;
import tw.com.skl.exp.kernel.model6.bo.RentExpDetail;
import tw.com.skl.exp.kernel.model6.bo.RosterDetail;
import tw.com.skl.exp.kernel.model6.bo.SalDepOfficeExp;
import tw.com.skl.exp.kernel.model6.bo.TaxDetail;
import tw.com.skl.exp.kernel.model6.bo.User;
import tw.com.skl.exp.kernel.model6.common.ErrorCode;
import tw.com.skl.exp.kernel.model6.common.exception.ExpRuntimeException;
import tw.com.skl.exp.kernel.model6.common.util.AAUtils;
import tw.com.skl.exp.kernel.model6.common.util.MessageUtils;
import tw.com.skl.exp.kernel.model6.common.util.NumberUtils;
import tw.com.skl.exp.kernel.model6.common.util.StringUtils;
import tw.com.skl.exp.kernel.model6.common.util.time.DateUtils;
import tw.com.skl.exp.kernel.model6.dao.TaxDetailDao;
import tw.com.skl.exp.kernel.model6.dto.DailyCloseBTaxDetailDto;
import tw.com.skl.exp.kernel.model6.facade.TaxDetailFacade;
import tw.com.skl.exp.kernel.model6.logic.TaxDetailService;

public class TaxDetailServiceImpl extends BaseServiceImpl<TaxDetail, String, TaxDetailDao> implements TaxDetailService {
    protected Log logger = LogFactory.getLog(this.getClass());
    private TaxDetailFacade facade;

    public List<String> exportTaxDetail(Calendar startDate, Calendar endDate, String incomeForm) {
        // B 6.1 稅檔下載 - 檔案匯出。
        List<TaxDetail> list = findTaxDetail(startDate, endDate, incomeForm);
        List<String> exportTaxDetail = new ArrayList<String>();
        if (!list.isEmpty()) {
            for (TaxDetail taxDetail : list) {
                StringBuffer strBuff = new StringBuffer();
                strBuff.append(",");
                if (taxDetail.getWithholdId() != null) {
                    if (taxDetail.getWithholdId().length() > 10) {
                        strBuff.append(StringUtils.leftPad(taxDetail.getWithholdId(), 10));
                    } else {
                        strBuff.append(taxDetail.getWithholdId());
                    }
                }
                strBuff.append(",");
                if (taxDetail.getEmpId() != null) {
                    if (taxDetail.getEmpId().length() > 10) {
                        strBuff.append(StringUtils.leftPad(taxDetail.getEmpId(), 10));
                    } else {
                        strBuff.append(taxDetail.getEmpId());
                    }
                }
                strBuff.append(",");
                if (taxDetail.getTaxId() != null) {
                    if (taxDetail.getTaxId().length() > 10) {
                        strBuff.append(StringUtils.leftPad(taxDetail.getTaxId(), 10));
                    } else {
                        strBuff.append(taxDetail.getTaxId());
                    }
                }
                strBuff.append(",");
                if (taxDetail.getTaxName() != null) {
                    if (taxDetail.getTaxName().length() > 40) {
                        strBuff.append(StringUtils.leftPad(taxDetail.getTaxName(), 40));
                    } else {
                        strBuff.append(taxDetail.getTaxName());
                    }
                }
                strBuff.append(",");
                // 序號空白。
                strBuff.append(",");
                if (taxDetail.getIncomeForm() != null) {
                    if (taxDetail.getIncomeForm().length() > 2) {
                        strBuff.append(StringUtils.leftPad(taxDetail.getIncomeForm(), 2));
                    } else {
                        strBuff.append(taxDetail.getIncomeForm());
                    }
                }
                strBuff.append(",");
                if (taxDetail.getMemo() != null) {
                    if (taxDetail.getMemo().length() > 1) {
                        strBuff.append(StringUtils.leftPad(taxDetail.getMemo(), 1));
                    } else {
                        strBuff.append(taxDetail.getMemo());
                    }
                }
                strBuff.append(",");
                if (taxDetail.getSourceKind() != null) {
                    if (taxDetail.getSourceKind().length() > 4) {
                        strBuff.append(StringUtils.leftPad(taxDetail.getSourceKind(), 4));
                    } else {
                        strBuff.append(taxDetail.getSourceKind());
                    }
                }
                strBuff.append(",");
                // 福利品來源別空白。
                strBuff.append(",");
                // 補助金類別空白。
                strBuff.append(",");
                if (taxDetail.getPayCertNo() != null) {
                    if (taxDetail.getPayCertNo().length() > 20) {
                        strBuff.append(StringUtils.leftPad(taxDetail.getPayCertNo(), 20));
                    } else {
                        strBuff.append(taxDetail.getPayCertNo());
                    }
                }
                strBuff.append(",");
                strBuff.append(StringUtils.substring(DateUtils.getRocDateStrByCalendar(taxDetail.getSubpoenaDate()), 0,
                        5));
                strBuff.append(",");
                strBuff.append(StringUtils.substring(DateUtils.getRocDateStrByCalendar(taxDetail.getSubpoenaDate()), 0,
                        5));
                strBuff.append(",");
                if (taxDetail.getHouseTaxNo() != null) {
                    if (taxDetail.getHouseTaxNo().length() > 12) {
                        strBuff.append(StringUtils.leftPad(taxDetail.getHouseTaxNo(), 12));
                    } else {
                        strBuff.append(taxDetail.getHouseTaxNo());
                    }
                }
                strBuff.append(",");
                if (taxDetail.getHouseAdr() != null) {
                    if (taxDetail.getHouseAdr().length() > 30) {
                        strBuff.append(StringUtils.leftPad(taxDetail.getHouseAdr(), 30));
                    } else {
                        strBuff.append(taxDetail.getHouseAdr());
                    }
                }
                strBuff.append(",");
                // 退職服務年資年空白。
                strBuff.append(",");
                // 退職服務年資月空白。
                strBuff.append(",");
                if (taxDetail.getTaxbizCode() != null) {
                    if (taxDetail.getTaxbizCode().length() > 2) {
                        strBuff.append(StringUtils.leftPad(taxDetail.getTaxbizCode(), 2));
                    } else {
                        strBuff.append(taxDetail.getTaxbizCode());
                    }
                }
                strBuff.append(",");
                // 分配次數
                strBuff.append(",");
                // 每股面額
                strBuff.append(",");
                // 除權除息日期
                strBuff.append(",");
                // 稅額扣抵比率
                strBuff.append(",");
                // 稅額扣繳比率
                strBuff.append(",");
                if (taxDetail.getCrossIncome() != null) {
                    if (taxDetail.getCrossIncome().compareTo(BigDecimal.ZERO) >= 0) {
                        strBuff.append("+");
                    } else {
                        strBuff.append("-");
                    }
                    int i = taxDetail.getCrossIncome().abs().intValue();
                    String str = StringUtils.leftPad(String.valueOf(i), 9, '0');
                    if (StringUtils.length(str) <= 9) {
                        strBuff.append(str);
                    }
                }
                strBuff.append(",");
                if (taxDetail.getTaxRate() != null) {
                    strBuff.append(NumberUtils.formatNumericStr((taxDetail.getTaxRate().multiply(new BigDecimal(100)))
                            .toString(), 0, 2, '0'));
                }
                strBuff.append(",");
                if (taxDetail.getWithholdingTax() != null) {
                    if (taxDetail.getWithholdingTax().compareTo(BigDecimal.ZERO) >= 0) {
                        strBuff.append("+");
                    } else {
                        strBuff.append("-");
                    }
                    int i = taxDetail.getWithholdingTax().abs().intValue();
                    String str = StringUtils.leftPad(String.valueOf(i), 9, '0');
                    if (StringUtils.length(str) <= 9) {
                        strBuff.append(str);
                    }
                }
                strBuff.append(",");
                // 銀行別
                strBuff.append(",");
                // 帳號
                strBuff.append(",");
                // 薪資項目代號
                strBuff.append(",");
                // 備註
                strBuff.append(",");
                if (taxDetail.getCostUnitCode() != null) {
                    if (taxDetail.getCostUnitCode().length() > 2) {
                        strBuff.append(StringUtils.leftPad(taxDetail.getCostUnitCode(), 2));
                    } else {
                        strBuff.append(taxDetail.getCostUnitCode());
                    }
                }
                strBuff.append(",");
                if (taxDetail.getCostUnitName() != null) {
                    if (taxDetail.getCostUnitName().length() > 2) {
                        strBuff.append(StringUtils.leftPad(taxDetail.getCostUnitName(), 2));
                    } else {
                        strBuff.append(taxDetail.getCostUnitName());
                    }
                }
                strBuff.append(",");
                // 匯款日期
                strBuff.append(",");
                // 勞退自提金額
                strBuff.append(",");
                // 員工分紅面額
                strBuff.append(",");
                // 股數
                strBuff.append(",");
                // 可處分日次日日期
                strBuff.append(",");
                // 可處分日次日之時價
                strBuff.append(",");
                // 基本所得額申報數

                exportTaxDetail.add(strBuff.toString());
            }
        }
        return exportTaxDetail;
    }

    public List<TaxDetail> findTaxDetail(Calendar startDate, Calendar endDate, String incomeForm) {
        // B 6.1 稅檔下載 - 查詢。
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("start_date", startDate);
        params.put("end_date", endDate);
        params.put("income_form", incomeForm);
        return getDao()
                .findByNamedParams(
                        "SELECT t FROM TaxDetail t WHERE t.subpoenaDate BETWEEN :start_date AND :end_date AND t.incomeForm = :income_form",
                        params);
    }

    public void createByExpapplB(ExpapplB expapplB) {
        Department department = expapplB.getApplUser().getDepartment();
        Department costUnit = department.isVirtualUnit() ? department.getVirtualDepartment() : (department
                .getDepartmentCost() == null ? department : department.getDepartmentCost());
        String withholdId = getFacade().getAreaService().findByZip(costUnit.getZip()).getCity().getCompId();
        List<Proof> proofs = expapplB.getProofs();
        if (!CollectionUtils.isEmpty(proofs)) {
            for (Proof proof : proofs) {
                // 若憑證被退回，不處理該筆資料。
                if (ProofStateCode.REJECTED.getCode().equals(proof.getProofState().getCode())) {
                    continue;
                }
                List<TaxDetail> taxDetails = new ArrayList<TaxDetail>();
                List<DailyCloseBTaxDetailDto> taxDetailDtos = new ArrayList<DailyCloseBTaxDetailDto>();
                if (getFacade().getAccTitleService().isWithholdType(proof.getAccTitle())) {
                    RosterDetail rosterDetail = proof.getRosterDetail();
                    Set<Entry> entries = proof.getEntries();
                    Entry expEntry = null;
                    Entry entryTax = null;
                    if (!CollectionUtils.isEmpty(entries)) {
                        AccTitle expAccTitle = null;
                        for (Entry entry : entries) {
                            AccTitle accTitle = entry.getAccTitle();
                            if (accTitle != null) {
                                String accTitleCode = accTitle.getCode();
                                if (accTitleCode.startsWith("6")) {
                                    expEntry = entry;
                                    expAccTitle = accTitle;
                                    break;
                                }
                            }
                        }
                        if (expAccTitle != null) {
                            AccTitle withHold = expAccTitle.getWithhold();
                            if (withHold != null) {
                                String withHoldCode = withHold.getCode();
                                for (Entry entry : entries) {
                                    AccTitle accTitle = entry.getAccTitle();
                                    if (accTitle != null) {
                                        String accTitleCode = accTitle.getCode();
                                        if (accTitleCode.equals(withHoldCode)) {
                                            entryTax = entry;
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if (expEntry == null) {
                        throw new ExpRuntimeException(ErrorCode.B10070, new String[] { expapplB.getExpApplNo() });
                    }
                    if (rosterDetail != null) {
                        // 有使用名冊
                        if (!proof.isProofAdded()) {
                            List<GainPerson> gainPersons = rosterDetail.getGainPersons();
                            if (!CollectionUtils.isEmpty(gainPersons)) {
                                for (GainPerson gainPerson : gainPersons) {
                                    if (gainPerson.getGainUserId() != null) {
                                        User user = getFacade().getUserService().findByCode(gainPerson.getGainUserId());
                                        DailyCloseBTaxDetailDto taxDetailDto = new DailyCloseBTaxDetailDto();
                                        taxDetailDto.setRosterNo(rosterDetail.getRosterNo());
                                        taxDetailDto.setEntryExp(expEntry);
                                        taxDetailDto.setEntryTax(entryTax);
                                        taxDetailDto.setAccTitle(rosterDetail.getAccTitle());
                                        taxDetailDto.setAmt(gainPerson.getGainAmt());
                                        taxDetailDto.setTaxAmt(gainPerson.getTaxAmt2());
                                        taxDetailDto.setWithholdId(withholdId);
                                        taxDetailDto.setUserCode(user.getCode());
                                        taxDetailDto.setIncomeId(user.getIdentityId());
                                        taxDetailDto.setIncomeName(user.getName());
                                        taxDetailDtos.add(taxDetailDto);
                                    } else {
                                        DailyCloseBTaxDetailDto taxDetailDto = new DailyCloseBTaxDetailDto();
                                        taxDetailDto.setRosterNo(rosterDetail.getRosterNo());
                                        taxDetailDto.setEntryExp(expEntry);
                                        taxDetailDto.setEntryTax(entryTax);
                                        taxDetailDto.setAccTitle(rosterDetail.getAccTitle());
                                        taxDetailDto.setAmt(gainPerson.getGainAmt());
                                        taxDetailDto.setTaxAmt(gainPerson.getTaxAmt2());
                                        taxDetailDto.setWithholdId(withholdId);
                                        taxDetailDto.setUserCode(null);
                                        taxDetailDto.setIncomeId(gainPerson.getIncomeUser().getIdentityId());
                                        taxDetailDto.setIncomeName(gainPerson.getIncomeUser().getName());
                                        taxDetailDtos.add(taxDetailDto);
                                    }
                                }
                            }
                        }
                    } else {
                        DailyCloseBTaxDetailDto taxDetailDto = new DailyCloseBTaxDetailDto();
                        taxDetailDto.setRosterNo(null);
                        taxDetailDto.setEntryExp(expEntry);
                        taxDetailDto.setEntryTax(entryTax);
                        taxDetailDto.setAccTitle(proof.getAccTitle());
                        taxDetailDto.setAmt(proof.getProofAmt());
                        taxDetailDto.setTaxAmt(proof.getTaxFileAmt());
                        taxDetailDto.setWithholdId(withholdId);
                        IncomeIdType incomeIdType = proof.getIncomeIdType();
                        String userCode = "";
                        String incomeId = "";
                        String incomeName = "";
                        if (incomeIdType != null) {
                            IncomeIdTypeCode incomeIdTypeCode = IncomeIdTypeCode.getByValue(incomeIdType);
                            switch (incomeIdTypeCode) {
                            case COMP_ID:
                            case IDENTITY_ID:
                                IncomeUser incomeUser = facade.getIncomeUserService().findIncomeUser(incomeIdTypeCode,
                                        proof.getIncomeId());
                                if (incomeUser != null) {
                                    userCode = "";
                                    incomeId = incomeUser.getIdentityId();
                                    incomeName = incomeUser.getName();
                                }
                                break;
                            case EMP_SALARY_ID:
                            case EMP_ID:
                                User user = facade.getUserService().findByCode(proof.getIncomeId());
                                if (user != null) {
                                    userCode = user.getCode();
                                    incomeId = user.getIdentityId();
                                    incomeName = user.getName();
                                }
                                break;
                            }
                        }
                        taxDetailDto.setUserCode(userCode);
                        taxDetailDto.setIncomeId(incomeId);
                        taxDetailDto.setIncomeName(incomeName);
                        taxDetailDtos.add(taxDetailDto);
                    }

                    for (DailyCloseBTaxDetailDto taxDetailDto : taxDetailDtos) {
                        TaxDetail taxDetail = new TaxDetail();
                        AccTitle accTitle = taxDetailDto.getAccTitle();
                        String accKindTypeCode = accTitle.getAccKindType().getCode();
                        if (!(AccKindTypeCode.NORMAL.getCode().equals(accKindTypeCode) && taxDetailDto.getEntryTax() == null)) {
                            String empId = taxDetailDto.getUserCode();
                            String taxId = taxDetailDto.getIncomeId();
                            String taxName = taxDetailDto.getIncomeName();
                            String incomeForm = accTitle.getIncomeForm();
                            String houseTaxNo = "";
                            String memo = ("51".equals(incomeForm) && "".equals(houseTaxNo)) ? "L" : "";
                            String sourceKind = incomeForm;
                            //RE201501570_醫檢及稅務作業修改 CU3178 2015/7/9 START
                        	//假如費用大分類為非廠商費用，會計科目為材料用品-獎勵費-獎品(本)，所得來源類別為G3
                        	if(AccTitleCode.REWARD_OTHER_AWARD_EXP.getCode().equals(taxDetailDto.getAccTitle().getCode())){
                        		sourceKind="G3";
                        	}	//假如費用大分類為非廠商費用，會計科目為材料用品-獎勵費-其他獎金(本)，所得來源類別為G2
                        	else if(AccTitleCode.REWARD_OTHER_REWARD_EXP.getCode().equals(taxDetailDto.getAccTitle().getCode())){
                        		sourceKind="G2";
                        	}
                            //RE201501570_醫檢及稅務作業修改 CU3178 2015/7/9 END
                            String payCertNo = expapplB.getSubpoena().getSubpoenaNo();
                            Calendar subpoenaDate = expapplB.getSubpoena().getSubpoenaDate();
                            String subpoenaNo = expapplB.getSubpoena().getSubpoenaNo();
                            String houseAdr = "";
                            String taxbizCode = accTitle.getIncomeBiz();
                            String rosterNo = taxDetailDto.getRosterNo();
                            BigDecimal crossIncome = taxDetailDto.getAmt();
                            BigDecimal taxRate = accTitle.getTaxRate();
                            BigDecimal withholdingTax = taxDetailDto.getTaxAmt();
                            BigDecimal begWithholdAmt = accTitle.getBegWithholdAmt() == null ? BigDecimal.ZERO
                                    : accTitle.getBegWithholdAmt();
                            String costUnitCode = costUnit.getCode();
                            String costUnitName = costUnit.getName();
                            String taxRemit = (PaymentTypeCode.B_CHECK.getCode().equals(
                                    expapplB.getPaymentType().getCode())
                                    && (AccKindTypeCode.PAY.getCode().equals(accTitle.getAccKindType().getCode()) || AccKindTypeCode.PAY_FOREIGNER
                                            .getCode().equals(accTitle.getAccKindType().getCode())) && (crossIncome
                                    .compareTo(begWithholdAmt) >= 0)) ? "2" : "1";
                            String createUserId = ((User) AAUtils.getLoggedInUser()).getIdentityId();
                            Calendar createDate = Calendar.getInstance();
                            taxDetail.setCostUnitCode(costUnitCode);
                            taxDetail.setCostUnitName(costUnitName);
                            taxDetail.setCreateDate(createDate);
                            taxDetail.setCreateUserId(createUserId);
                            taxDetail.setCrossIncome(crossIncome);
                            taxDetail.setEmpId(empId);
                            EntryExpGroup entryExpGroup = new EntryExpGroup();
                            entryExpGroup.setEntry(taxDetailDto.getEntryExp());
                            String groupId = UUID.randomUUID().toString();
                            entryExpGroup.setGroupId(groupId);
                            facade.getEntryExpGroupService().create(entryExpGroup);
                            taxDetail.setGroupId(groupId);
                            taxDetail.setEntryTax(taxDetailDto.getEntryTax());
                            taxDetail.setHouseAdr(houseAdr);
                            taxDetail.setHouseTaxNo(houseTaxNo);
                            taxDetail.setIncomeForm(incomeForm);
                            taxDetail.setMemo(memo);
                            taxDetail.setPayCertNo(payCertNo);
                            taxDetail.setProofs(proofs);
                            taxDetail.setRosterNo(rosterNo);
                            taxDetail.setSourceKind(sourceKind);
                            taxDetail.setSubpoenaDate(subpoenaDate);
                            taxDetail.setSubpoenaNo(subpoenaNo);
                            taxDetail.setTaxbizCode(taxbizCode);
                            taxDetail.setTaxId(taxId);
                            taxDetail.setTaxName(taxName);
                            taxDetail.setTaxRate(taxRate);
                            taxDetail.setTaxRemit(taxRemit);
                            taxDetail.setWithholdId(withholdId);
                            taxDetail.setWithholdingTax(withholdingTax);
                            taxDetail = getDao().create(taxDetail);
                            taxDetails.add(taxDetail);
                        }
                    }
                }
                proof.setTaxDetails(taxDetails);
                proof = facade.getProofService().update(proof);
            }
        }
    }

    /** 處理稅金匯回時，名冊資料的取得，和稅務明細的產生 */
    private List<TaxDetail> doProcessRosterDetailAndGainPerson(RosterDetail rd, String costUnitCode,
            String costUnitName, List<TaxDetail> tdList) {
        List<GainPerson> gpList = facade.getGainPersonService().findByRosterDetail(rd);
        if (CollectionUtils.isEmpty(gpList)) {
            throw new ExpRuntimeException(ErrorCode.A20002, new String[] { MessageUtils.getAccessor().getMessage(
                    "tw_com_skl_exp_kernel_model6_bo_RosterDetail_gain_persons") });
        }
        TaxDetail taxd = null;
        for (GainPerson gp : gpList) {
            taxd = new TaxDetail();
            taxd.setEmpId(gp.getGainUserId());
            // 2009/12/22,IR#1454,因為所得人資料不一定會抓得到，所以要分開處理
            if (StringUtils.isNotBlank(gp.getGainUserId())) {
                User u = facade.getUserService().findByCode(gp.getGainUserId());
                taxd.setTaxName(u.getName()); // 是放姓名，不是放員工代號
                taxd.setTaxId(u.getIdentityId());
            } else {
                IncomeUser iu = null;
                if (gp.getIncomeUser() != null)
                    iu = gp.getIncomeUser();
                else
                    iu = facade.getIncomeUserService().findIncomeUserByGainPerson(gp);
                if (iu != null) {
                    taxd.setTaxName(iu.getName());
                    taxd.setTaxId(iu.getIdentityId());
                }
            }
            taxd.setRosterNo(rd.getRosterNo());
            taxd.setCrossIncome(gp.getGainAmt());
            taxd.setWithholdingTax(gp.getTaxAmt2());
            taxd.setCostUnitCode(costUnitCode);
            taxd.setCostUnitName(costUnitName);
            taxd.setTaxRemit("2");
            taxd.setEntryTax(null); // 所得稅分錄=固定 空白
            tdList.add(taxd);
        }
        return tdList;
    }

    /** 處理稅金匯回資料(行政費用) */
    private List<TaxDetail> doProcessNeedTaxRemit(ExpapplC eac, String costUnitCode, String costUnitName) {
        List<TaxDetail> tdList = new ArrayList<TaxDetail>();
        //RE201500829_發文獎勵費用申請流程優化 CU3178 2015/5/20 START
        //C1.5.13名冊輸入方式從TBEXP_EXPAPPL_C.LIST1、LIST2改為TBEXP_ROSTER_DETAIL.TBEXP_EXPAPPL_C的方式
        if(eac.getMiddleType().getCode().equals(MiddleTypeCode.CODE_N10.getCode())){
          	List<RosterDetail> ros = facade.getRosterDetailService().findRosterDetail(eac);
        	for(RosterDetail rosterDetail : ros){
        		tdList = doProcessRosterDetailAndGainPerson(rosterDetail, costUnitCode, costUnitName, tdList);
        	}
        }else{
        	RosterDetail rd1 = facade.getRosterDetailService().findByRosterNoFetchRelation(eac.getListNo1());
        	RosterDetail rd2 = facade.getRosterDetailService().findByRosterNoFetchRelation(eac.getListNo2());
        	if (rd1 != null)
        		tdList = doProcessRosterDetailAndGainPerson(rd1, costUnitCode, costUnitName, tdList);
        	if (rd2 != null)
        		tdList = doProcessRosterDetailAndGainPerson(rd2, costUnitCode, costUnitName, tdList);
        }
        //RE201500829_發文獎勵費用申請流程優化 CU3178 2015/5/20 END
        return tdList;
    }

    /** 處理行政費用，產生稅務明細時的分錄資料 */
    private Map<String, Object> doProcessExpapplCEntries(ExpapplC eac) {
        boolean hasRosterDetailAcct = false;
        Entry payableWithHoldingEn = new Entry();
        BigDecimal totalDbtAmt = BigDecimal.ZERO;
        BigDecimal totalCrdtAmt = BigDecimal.ZERO;
        String costUnitCode = "";
        String costUnitName = "";
        Map<String, Object> result = new HashMap<String, Object>();
        List<Entry> expEntries = new ArrayList<Entry>();
        List<Entry> crdtTaxEntries = new ArrayList<Entry>();
        payableWithHoldingEn = null; // 先清掉，如果有值，才會有資料
        for (Entry en : eac.getEntryGroup().getEntries()) {
            if (facade.getAccTitleService().isRosterDetail(en.getAccTitle())) {
                hasRosterDetailAcct = true; // 表示有名冊資料的會計科目分錄
            }
            //RE201503288_獎勵費(92所得)之名冊建檔及所得稅功能檢核 CU3178  2015/9/11 START
            //63300703材料用品-獎勵費-獎勵費冊號可不為空值 
            if(AccTitleCode.INCENTIE_FEE_63300703.getCode().equals(en.getAccTitle().getCode())&&!StringUtils.isBlank(eac.getListNo1())){
            	hasRosterDetailAcct=true;
            }
            //RE201503288_獎勵費(92所得)之名冊建檔及所得稅功能檢核 CU3178  2015/9/11 END
            if (EntryTypeCode.TYPE_1_C.getValue().equals(en.getEntryType().getValue())
                    && facade.getAccTitleService().isIncomeTaxAccTitle(en.getAccTitle().getCode())) {
                payableWithHoldingEn = en; // 必須是"貸方"的應付代扣
                totalCrdtAmt = totalCrdtAmt.add(en.getAmt());
                result.put("payableWithHoldingEn", payableWithHoldingEn);
                crdtTaxEntries.add(en);
            }
            if (EntryTypeCode.TYPE_1_D.getValue().equals(en.getEntryType().getValue())) {
                totalDbtAmt = totalDbtAmt.add(en.getAmt());
                // 並且把費用科目的分錄記起來
                if (StringUtils.startsWith(en.getAccTitle().getCode(), "6")) {
                    expEntries.add(en);
                }
                if (StringUtils.isNotBlank(en.getCostUnitCode())) {
                    costUnitCode = en.getCostUnitCode();
                }
                if (StringUtils.isNotBlank(en.getCostUnitName())) {
                    costUnitName = en.getCostUnitName();
                }
            }
        }
        result.put("hasRosterDetailAcct", hasRosterDetailAcct);
        result.put("totalDbtAmt", totalDbtAmt);
        result.put("totalCrdtAmt", totalCrdtAmt);
        result.put("expEntries", expEntries);
        result.put("crdtTaxEntries", crdtTaxEntries);
        result.put("costUnitCode", costUnitCode);
        result.put("costUnitName", costUnitName);
        return result;
    }

    /** 處理辦公費的稅務明細 */
    @SuppressWarnings("unchecked")
    private Map<String, Object> doProcessOfficeExp(ExpapplC eac, TaxDetail td) {
        // 要回傳的Map
        Map<String, Object> result = new HashMap<String, Object>();
        Map<String, Object> rsltMap = doProcessExpapplCEntries(eac);
        boolean hasRosterDetailAcct = (Boolean) rsltMap.get("hasRosterDetailAcct");
        Entry payableWithHoldingEn = (Entry) rsltMap.get("payableWithHoldingEn");
        BigDecimal totalDbtAmt = (BigDecimal) rsltMap.get("totalDbtAmt");
        // BigDecimal totalCrdtAmt = (BigDecimal)rsltMap.get("totalCrdtAmt");
        String costUnitCode = (String) rsltMap.get("costUnitCode");
        String costUnitName = (String) rsltMap.get("costUnitName");
        List<Entry> expEntries = (List<Entry>) rsltMap.get("expEntries");
        List<TaxDetail> tdList = new ArrayList<TaxDetail>();
        // 設定EntryExpGroup
        String groupId = genEntryExpGroupAndUUID(expEntries);
        // 稅金匯回==true && 有名冊科目的分錄資料
        if (eac.isNeedTaxRemit() && hasRosterDetailAcct) {
            // 產生EntryExpGroup的UUID資料搬到上面作
            tdList = doProcessNeedTaxRemit(eac, costUnitCode, costUnitName);
            for (TaxDetail taxd : tdList) {
                taxd.setTaxRemit("2");
                taxd.setGroupId(groupId);
            }
            // 存起來，待回傳
            result.put("taxDetailList", tdList);
        } else if (hasRosterDetailAcct && !eac.isNeedTaxRemit()) {
            List<Entry> crdtTaxEntries = (List<Entry>) rsltMap.get("crdtTaxEntries");
            // 產生EntryExpGroup的UUID資料搬到上面作
            tdList = doProcessNeedTaxRemit(eac, costUnitCode, costUnitName);
            for (TaxDetail taxd : tdList) {
                // ◎所得稅分錄 = 貸方應付代扣分錄ID (分錄.所得人證號 = 領款人.身份證字號/統編 或 領獎人員工代號) ;
                // 若貸方無該所得人之應付代扣科目則放0
                for (Entry en : crdtTaxEntries) {
                    if (taxd.getTaxId() != null && taxd.getTaxId().equals(en.getIncomeId()))
                        taxd.setEntryTax(en);
                } // ◎稅金匯回=1不需稅金匯回
                taxd.setTaxRemit("1");
                taxd.setGroupId(groupId);
            } // 存起來，待回傳
            result.put("taxDetailList", tdList);
        } else { // 如果不是獎金、獎金品，那只有一筆所得人資料吧!?
            List<TaxDetail> taxDetailList = new ArrayList<TaxDetail>();
            /*** @Chang No:RE201302778  [Start]****/
            /* 因調查費M10由大分類辦公費轉到已附，因此這段註解 
            if(eac.getMiddleType().getCode().compareTo(MiddleTypeCode.CODE_M10.getCode())==0){
            	// RE201000814針對調查費加入產生稅檔的動作
	            // 產生EntryExpGroup的UUID資料搬到上面作
            	InvestExp iexp = facade.getInvestExpService().findByExpApplNoFetchRelation(eac.getExpApplNo());
	            // 是員工、工員工資，就去抓員工資料
	            if (IncomeIdTypeCode.EMP_SALARY_ID.getCode().equals(iexp.getIncomeIdType().getCode())
	                    || IncomeIdTypeCode.EMP_ID.getCode().equals(iexp.getIncomeIdType().getCode())) {
	                User u = facade.getUserService().findByCode(iexp.getIncomeUserId());
	                td.setEmpId(iexp.getIncomeUserId());
	                td.setTaxId(u.getIdentityId());
	                td.setTaxName(u.getName());
	            } else {
	                IncomeUser iu = facade.getIncomeUserService().findByIdentityIdFetchRelation(iexp.getIncomeUserId());
	                td.setEmpId("");
	                td.setTaxId(iexp.getIncomeUserId());
	                td.setTaxName(iu.getName());
	            }
            }else{//N10原本的程式碼
            /*** @Chang No:RE201302778  [End]****/
            	// 產生EntryExpGroup的UUID資料搬到上面作
	            SalDepOfficeExp sexp = facade.getSalDepOfficeExpService().findByExpApplNoFetchRelation(eac.getExpApplNo());
	            // 是員工、工員工資，就去抓員工資料
	            if (IncomeIdTypeCode.EMP_SALARY_ID.getCode().equals(sexp.getIncomeIdType().getCode())
	                    || IncomeIdTypeCode.EMP_ID.getCode().equals(sexp.getIncomeIdType().getCode())) {
	                User u = facade.getUserService().findByCode(sexp.getIncomeUserId());
	                td.setEmpId(sexp.getIncomeUserId());
	                td.setTaxId(u.getIdentityId());
	                td.setTaxName(u.getName());
	            } else {
	                IncomeUser iu = facade.getIncomeUserService().findByIdentityIdFetchRelation(sexp.getIncomeUserId());
	                td.setEmpId("");
	                td.setTaxId(sexp.getIncomeUserId());
	                td.setTaxName(iu.getName());
	            }
	        //} RE201302778 將原本的else N10 部分註解
            td.setCrossIncome(totalDbtAmt);
            if (payableWithHoldingEn != null && StringUtils.isNotBlank(payableWithHoldingEn.getId()))
                td.setWithholdingTax(payableWithHoldingEn.getAmt());
            else
                td.setWithholdingTax(BigDecimal.ZERO);
            td.setTaxRemit("1");
            td.setGroupId(groupId);
            td.setCostUnitCode(costUnitCode);
            td.setCostUnitName(costUnitName);
            // 存起來，待回傳
            taxDetailList.add(td);
            result.put("taxDetailList", taxDetailList);
        }
        // 存起來，待回傳
        result.put("expEntries", expEntries);
        return result;
    }

    /** 處理廠商費用的稅務明細 */
    @SuppressWarnings("unchecked")
    private Map<String, Object> doProcessVendorExp(ExpapplC eac, TaxDetail td) {
        // 要回傳的Map
        Map<String, Object> result = new HashMap<String, Object>();
        Map<String, Object> rsltMap = doProcessExpapplCEntries(eac);
        boolean hasRosterDetailAcct = (Boolean) rsltMap.get("hasRosterDetailAcct");
        Entry payableWithHoldingEn = (Entry) rsltMap.get("payableWithHoldingEn");
        BigDecimal totalDbtAmt = (BigDecimal) rsltMap.get("totalDbtAmt");
        BigDecimal totalCrdtAmt = (BigDecimal) rsltMap.get("totalCrdtAmt");
        String costUnitCode = (String) rsltMap.get("costUnitCode");
        String costUnitName = (String) rsltMap.get("costUnitName");
        List<Entry> expEntries = (List<Entry>) rsltMap.get("expEntries");
        List<TaxDetail> tdList = new ArrayList<TaxDetail>();
        // 設定EntryExpGroup
        // 呼叫產生EntryExpGroup的method
        String groupId = genEntryExpGroupAndUUID(expEntries);
        if (hasRosterDetailAcct) { // 只要有獎金品科目的時候，就要跑稅金匯回的程式
            /** 《費用申請單.稅金需匯回 = TRUE》 */
            tdList = doProcessNeedTaxRemit(eac, costUnitCode, costUnitName);
            for (TaxDetail taxd : tdList) {
                taxd.setTaxRemit("2");
                taxd.setGroupId(groupId);
            }// 存起來，待回傳
            result.put("taxDetailList", tdList);
        } else {
            String incomeUserId = "";
            String incomeIdType = "";
            for (Entry en : eac.getEntryGroup().getEntries()) {
                if (StringUtils.isNotBlank(en.getIncomeId())) {
                    incomeUserId = en.getIncomeId();
                }
                if (StringUtils.isNotEmpty(en.getIncomeIdType())) {
                    incomeIdType = en.getIncomeIdType();
                }
            }
            String iuName = "";
            String iuId = "";
            if (IncomeIdTypeCode.EMP_SALARY_ID.getCode().equals(incomeIdType)
                    || IncomeIdTypeCode.EMP_ID.getCode().equals(incomeIdType)) {
                User u = facade.getUserService().findByCode(incomeUserId);
                if (u == null) {
                    throw new ExpRuntimeException(ErrorCode.A20002, new String[] { MessageUtils.getAccessor()
                            .getMessage("tw_com_skl_exp_kernel_model6_bo_User") });
                } else {
                    iuId = incomeUserId;
                    iuName = u.getName();
                }
            } else {
                IncomeUser iu = facade.getIncomeUserService().findByIdentityIdFetchRelation(incomeUserId);
                if (iu == null) {
                    throw new ExpRuntimeException(ErrorCode.A20002, new String[] { MessageUtils.getAccessor()
                            .getMessage("tw_com_skl_exp_kernel_model6_bo_IncomeUser") });
                } else {
                    iuId = incomeUserId;
                    iuName = iu.getName();
                }
            }
            td.setEmpId("");
            td.setTaxId(iuId);
            td.setTaxName(iuName);
            td.setCrossIncome(totalDbtAmt);
            td.setWithholdingTax(totalCrdtAmt);
            td.setCostUnitCode(costUnitCode);
            td.setCostUnitName(costUnitName);
            td.setTaxRemit("1");
            if (payableWithHoldingEn != null && StringUtils.isNotBlank(payableWithHoldingEn.getId()))
                td.setEntryTax(payableWithHoldingEn);
            td.setGroupId(groupId);
            tdList.add(td);
            result.put("taxDetailList", tdList);
        }
        result.put("expEntries", expEntries);
        return result;
    }

    /** 處理不動產費用相關稅務明細 */
    @SuppressWarnings("unchecked")
    private Map<String, Object> doProcessImmovExp (ExpapplC eac, TaxDetail td) {
    	Map<String, Object> result = new HashMap<String, Object>();
        Map<String, Object> rsltMap = doProcessExpapplCEntries(eac);
        
        Entry payableWithHoldingEn = (Entry) rsltMap.get("payableWithHoldingEn");
        BigDecimal totalDbtAmt = (BigDecimal) rsltMap.get("totalDbtAmt");
        // BigDecimal totalCrdtAmt = (BigDecimal)rsltMap.get("totalCrdtAmt");
        String costUnitCode = (String) rsltMap.get("costUnitCode");
        String costUnitName = (String) rsltMap.get("costUnitName");
        List<TaxDetail> tdList = new ArrayList<TaxDetail>();
        List<Entry> expEntries = (List<Entry>) rsltMap.get("expEntries");
        // 呼叫產生EntryExpGroup的method
        
        String groupId = genEntryExpGroupAndUUID(expEntries);
            
        
        //GeneralExp gexp = facade.getGeneralExpService().findByExpApplNoFetchRelation(eac.getExpApplNo());  
        
        ImmovExp iexp = facade.getImmovExpService().findByExpApplNo(eac.getExpApplNo());
            // 是員工、工員工資，就去抓員工資料
        if (IncomeIdTypeCode.EMP_SALARY_ID.getCode().equals(iexp.getIncomeIdType().getCode())
            		|| IncomeIdTypeCode.EMP_ID.getCode().equals(iexp.getIncomeIdType().getCode())) {
        	User u = facade.getUserService().findByCode(iexp.getIncomeUserId());
            td.setEmpId(iexp.getIncomeUserId());
            td.setTaxId(u.getIdentityId());
            td.setTaxName(u.getName());
        } else {
        	IncomeUser iu = facade.getIncomeUserService().findByIdentityIdFetchRelation(iexp.getIncomeUserId());
            td.setEmpId("");
            td.setTaxId(iexp.getIncomeUserId());
            td.setTaxName(iu.getName());
        }
        td.setCrossIncome(totalDbtAmt);
        if (payableWithHoldingEn != null && StringUtils.isNotBlank(payableWithHoldingEn.getId()))
        	td.setWithholdingTax(payableWithHoldingEn.getAmt());
        else
        	td.setWithholdingTax(BigDecimal.ZERO);
        td.setCostUnitCode(costUnitCode);
        td.setCostUnitName(costUnitName);
        td.setTaxRemit("1");
        td.setGroupId(groupId);
        // 存起來，待回傳
        tdList.add(td);
        result.put("taxDetailList", tdList);

        result.put("expEntries", expEntries);
        return result;
	}

    
    
    /** 處理已付費用相關稅務明細 */
    @SuppressWarnings("unchecked")
    private Map<String, Object> doProcessApidExp(ExpapplC eac, TaxDetail td) {
        Map<String, Object> result = new HashMap<String, Object>();
        Map<String, Object> rsltMap = doProcessExpapplCEntries(eac);
        boolean hasRosterDetailAcct = (Boolean) rsltMap.get("hasRosterDetailAcct");
        Entry payableWithHoldingEn = (Entry) rsltMap.get("payableWithHoldingEn");
        BigDecimal totalDbtAmt = (BigDecimal) rsltMap.get("totalDbtAmt");
        // BigDecimal totalCrdtAmt = (BigDecimal)rsltMap.get("totalCrdtAmt");
        String costUnitCode = (String) rsltMap.get("costUnitCode");
        String costUnitName = (String) rsltMap.get("costUnitName");
        List<TaxDetail> tdList = new ArrayList<TaxDetail>();
        List<Entry> expEntries = (List<Entry>) rsltMap.get("expEntries");
        // 呼叫產生EntryExpGroup的method
        String groupId = genEntryExpGroupAndUUID(expEntries);
        // 租賃費用的處理
        if (MiddleTypeCode.CODE_D00.getCode().equals(eac.getMiddleType().getCode())) {
            tdList = doProcessD00RentExp(tdList, eac, groupId, payableWithHoldingEn, costUnitCode, costUnitName);
            result.put("taxDetailList", tdList);
        } else {
            /*
             * 有獎金、獎品的會計科目分錄 處理方式與《費用申請單.稅金需匯回 = TRUE》相同，僅 ◎稅金匯回=1不需稅金匯回 ◎所得稅分錄
             * = 貸方應付代扣分錄ID (分錄.所得人證號 = 領款人.身份證字號/統編 或 領獎人員工代號)
             */
            if (hasRosterDetailAcct) {
                List<Entry> crdtTaxEntries = (List<Entry>) rsltMap.get("crdtTaxEntries");
                // 產生EntryExpGroup的UUID資料搬到上面作
                tdList = doProcessNeedTaxRemit(eac, costUnitCode, costUnitName);
                for (TaxDetail taxd : tdList) {
                    for (Entry en : crdtTaxEntries) {
                        if (taxd.getTaxId() != null && taxd.getTaxId().equals(en.getIncomeId()))
                            taxd.setEntryTax(en);
                    }
                    // ◎稅金匯回=1不需稅金匯回
                    taxd.setTaxRemit("1");
                    taxd.setGroupId(groupId);
                }
                // 存起來，待回傳
                result.put("taxDetailList", tdList);
            } else {
                // 產生EntryExpGroup的UUID資料搬到上面作
                GeneralExp gexp = facade.getGeneralExpService().findByExpApplNoFetchRelation(eac.getExpApplNo());
                // 是員工、工員工資，就去抓員工資料
                /*** @Chang RE201302778 針對調查費無法寫入稅檔  [Start]****/               
                if(eac.getMiddleType().getCode().compareTo(MiddleTypeCode.CODE_M10.getCode())==0){
                	// RE201000814針對調查費加入產生稅檔的動作
    	            // 產生EntryExpGroup的UUID資料搬到上面作
                	InvestExp iexp = facade.getInvestExpService().findByExpApplNoFetchRelation(eac.getExpApplNo());
    	            // 是員工、工員工資，就去抓員工資料
    	            if (IncomeIdTypeCode.EMP_SALARY_ID.getCode().equals(iexp.getIncomeIdType().getCode())
    	                    || IncomeIdTypeCode.EMP_ID.getCode().equals(iexp.getIncomeIdType().getCode())) {
    	                User u = facade.getUserService().findByCode(iexp.getIncomeUserId());
    	                td.setEmpId(iexp.getIncomeUserId());
    	                td.setTaxId(u.getIdentityId());
    	                td.setTaxName(u.getName());
    	            } else {
    	                IncomeUser iu = facade.getIncomeUserService().findByIdentityIdFetchRelation(iexp.getIncomeUserId());
    	                td.setEmpId("");
    	                td.setTaxId(iexp.getIncomeUserId());
    	                td.setTaxName(iu.getName());
    	            }
                }
                /*** @Chang No:RE201302778  [End]****/       
                else if (IncomeIdTypeCode.EMP_SALARY_ID.getCode().equals(gexp.getIncomeIdType().getCode())   //No:RE201302778原本的判斷式 如果不是M10就繼續找
                        || IncomeIdTypeCode.EMP_ID.getCode().equals(gexp.getIncomeIdType().getCode())) {
                    User u = facade.getUserService().findByCode(gexp.getIncomeUserId());
                    td.setEmpId(gexp.getIncomeUserId());
                    td.setTaxId(u.getIdentityId());
                    td.setTaxName(u.getName());
                } else {
                    IncomeUser iu = facade.getIncomeUserService().findByIdentityIdFetchRelation(gexp.getIncomeUserId());
                    td.setEmpId("");
                    td.setTaxId(gexp.getIncomeUserId());
                    td.setTaxName(iu.getName());
                }
                td.setCrossIncome(totalDbtAmt);
                if (payableWithHoldingEn != null && StringUtils.isNotBlank(payableWithHoldingEn.getId()))
                    td.setWithholdingTax(payableWithHoldingEn.getAmt());
                else
                    td.setWithholdingTax(BigDecimal.ZERO);
                td.setCostUnitCode(costUnitCode);
                td.setCostUnitName(costUnitName);
                td.setTaxRemit("1");
                td.setGroupId(groupId);
                // 存起來，待回傳
                tdList.add(td);
                result.put("taxDetailList", tdList);
            }
        }
        result.put("expEntries", expEntries);
        return result;
    }

    /** 處理研修差旅的稅務明細 */
    private Map<String, Object> doProcessTrvlLrn(ExpapplC eac) {
        Map<String, Object> result = new HashMap<String, Object>();
        Entry payableWithHoldingEn = new Entry();
        BigDecimal crossAmt = BigDecimal.ZERO;
        BigDecimal totalCrdtAmt = BigDecimal.ZERO;
        String costUnitCode = "";
        String costUnitName = "";
        List<TaxDetail> tdList = new ArrayList<TaxDetail>();
        TaxDetail taxd = new TaxDetail();
        List<Entry> expEntries = new ArrayList<Entry>();
        for (Entry en : eac.getEntryGroup().getEntries()) {
            if (AccTitleCode.GIFT_FUNERAL_MONEY.getCode().equals(en.getAccTitle().getCode())) {
                crossAmt = crossAmt.add(en.getAmt());
                costUnitCode = en.getCostUnitCode();
                costUnitName = en.getCostUnitName();
                expEntries.add(en);
            }
            if (EntryTypeCode.TYPE_1_C.getValue().equals(en.getEntryType().getValue())
                    && facade.getAccTitleService().isIncomeTaxAccTitle(en.getAccTitle().getCode())) {
                payableWithHoldingEn = en; // 必須是"貸方"的應付代扣
                totalCrdtAmt = totalCrdtAmt.add(en.getAmt());
            }
        }
        // 呼叫產生EntryExpGroup的method
        String groupId = genEntryExpGroupAndUUID(expEntries);
        ApplInfo applUserInfo = eac.getApplyUserInfo();
        taxd.setEmpId(applUserInfo.getUserId());
        // 2010/1/29，defect1978 1/28修改SDD的內容
        taxd.setTaxId(applUserInfo.getIdentityId() != null ? applUserInfo.getIdentityId() : "");
        taxd.setTaxName(applUserInfo.getUserName());
        taxd.setCrossIncome(crossAmt);
        taxd.setWithholdingTax(totalCrdtAmt);
        taxd.setCostUnitCode(costUnitCode);
        taxd.setCostUnitName(costUnitName);
        taxd.setTaxRemit("1");
        if (payableWithHoldingEn != null && StringUtils.isNotBlank(payableWithHoldingEn.getId()))
            taxd.setEntryTax(payableWithHoldingEn);
        taxd.setGroupId(groupId);
        // 存起來，待回傳
        tdList.add(taxd);
        result.put("expEntries", expEntries);
        result.put("taxDetailList", tdList);
        return result;
    }

    /** 處理醫檢費用的稅務明細 */
    private Map<String, Object> doProcessMedicalExp(ExpapplC eac) {
        Map<String, Object> result = new HashMap<String, Object>();
        // 規格書沒寫什麼條件不用產生稅檔
        Entry payableWithHoldingEn = null;
        BigDecimal totalDbtAmt = BigDecimal.ZERO;
        BigDecimal totalCrdtAmt = BigDecimal.ZERO;
        String costUnitCode = "";
        String costUnitName = "";
        // 存費用分錄
        List<Entry> expEntries = new ArrayList<Entry>();
        // 存稅務明細資料
        List<TaxDetail> tdList = new ArrayList<TaxDetail>();
        for (Entry en : eac.getEntryGroup().getEntries()) {
            if (EntryTypeCode.TYPE_1_D.getValue().equals(en.getEntryType().getValue())) {
                totalDbtAmt = totalDbtAmt.add(en.getAmt());
                if (StringUtils.startsWith(en.getAccTitle().getCode(), "6")) {
                    expEntries.add(en);
                }
                if (StringUtils.isNotBlank(en.getCostUnitCode()))
                    costUnitCode = en.getCostUnitCode();
                if (StringUtils.isNotBlank(en.getCostUnitName()))
                    costUnitName = en.getCostUnitName();
            }
            if (EntryTypeCode.TYPE_1_C.getValue().equals(en.getEntryType().getValue())
                    && facade.getAccTitleService().isIncomeTaxAccTitle(en.getAccTitle().getCode())) {
                payableWithHoldingEn = en; // 必須是"貸方"的應付代扣
                totalCrdtAmt = totalCrdtAmt.add(en.getAmt());
            }
        }
        // 呼叫產生EntryExpGroup的method
        String groupId = genEntryExpGroupAndUUID(expEntries);
        MedicalExp mexp = facade.getMedicalExpService().findByExpapplC(eac);
        Hospital hospital = mexp.getHospital();
        TaxDetail taxd = new TaxDetail();
        if (hospital != null) {
            taxd.setEmpId("");
            if (MedicalWithholdFmtCode.HOSPITAL.getCode().equals(hospital.getMedicalWithholdFmt().getCode())) {
                taxd.setTaxId(hospital.getCompId());
                taxd.setTaxName(hospital.getChinesesName());
            } else {
                taxd.setTaxId(hospital.getPersonIdentityId());
                taxd.setTaxName(hospital.getPersonName());
            }
            taxd.setCrossIncome(totalDbtAmt);
            taxd.setWithholdingTax(totalCrdtAmt);
            if (payableWithHoldingEn != null)
                taxd.setEntryTax(payableWithHoldingEn);
            taxd.setTaxRemit("1");
            taxd.setGroupId(groupId);
        } else {
            throw new ExpRuntimeException(ErrorCode.A20002, new String[] { MessageUtils.getAccessor().getMessage(
                    "tw_com_skl_exp_kernel_model6_bo_Hospital") });
        }
        taxd.setCostUnitCode(costUnitCode);
        taxd.setCostUnitName(costUnitName);
        // 存起來，待回傳
        tdList.add(taxd);
        result.put("expEntries", expEntries);
        result.put("taxDetailList", tdList);
        return result;
    }

    /** 處理公務車的稅務明細 */
    private Map<String, Object> doProcessPubAffCar(ExpapplC eac) {
        Map<String, Object> result = new HashMap<String, Object>();
        // 規格書沒寫什麼條件不用產生稅檔
        Entry payableWithHoldingEn = null;
        BigDecimal totalDbtAmt = BigDecimal.ZERO;
        BigDecimal totalCrdtAmt = BigDecimal.ZERO;
        List<Entry> expEntries = new ArrayList<Entry>();
        String costUnitCode = "";
        String costUnitName = "";
        // 存稅務明細資料
        List<TaxDetail> tdList = new ArrayList<TaxDetail>();
        for (Entry en : eac.getEntryGroup().getEntries()) {
            if (EntryTypeCode.TYPE_1_D.getValue().equals(en.getEntryType().getValue())) {
                totalDbtAmt = totalDbtAmt.add(en.getAmt());
                if (StringUtils.startsWith(en.getAccTitle().getCode(), "6"))
                    expEntries.add(en);
                if (StringUtils.isNotBlank(en.getCostUnitCode()))
                    costUnitCode = en.getCostUnitCode();
                if (StringUtils.isNotBlank(en.getCostUnitName()))
                    costUnitName = en.getCostUnitName();
            }
            if (EntryTypeCode.TYPE_1_C.getValue().equals(en.getEntryType().getValue())
                    && facade.getAccTitleService().isIncomeTaxAccTitle(en.getAccTitle().getCode())) {
                payableWithHoldingEn = en; // 必須是"貸方"的應付代扣
                totalCrdtAmt = totalCrdtAmt.add(en.getAmt());
            }
        }
        // 呼叫產生EntryExpGroup的method
        String groupId = genEntryExpGroupAndUUID(expEntries);
        PubAffCarExp pexp = facade.getPubAffCarExpService().findPubAffCarExpByExpapplC(eac);
        TaxDetail taxd = new TaxDetail();
        if (IncomeIdTypeCode.EMP_SALARY_ID.getCode().equals(pexp.getIncomeIdType().getCode())
                || IncomeIdTypeCode.EMP_ID.getCode().equals(pexp.getIncomeIdType().getCode())) {
            taxd.setEmpId(pexp.getIncomeUserId());
            User u = facade.getUserService().findByCode(pexp.getIncomeUserId());
            taxd.setTaxId(u.getIdentityId());
            taxd.setTaxName(u.getName());
        } else {
            IncomeUser iu = facade.getIncomeUserService().findByIdentityIdFetchRelation(pexp.getIncomeUserId());
            taxd.setEmpId("");
            taxd.setTaxId(pexp.getIncomeUserId());
            taxd.setTaxName(iu.getName());
        }
        taxd.setCrossIncome(totalDbtAmt);
        taxd.setWithholdingTax(totalCrdtAmt);
        taxd.setTaxRemit("1");
        taxd.setGroupId(groupId);
        if (payableWithHoldingEn != null) {
            taxd.setEntryTax(payableWithHoldingEn);
        }
        taxd.setCostUnitCode(costUnitCode);
        taxd.setCostUnitName(costUnitName);
        // 存起來，待回傳
        tdList.add(taxd);
        result.put("expEntries", expEntries);
        result.put("taxDetailList", tdList);
        return result;
    }

    /** 處理調整費用的稅務明細 */
    @SuppressWarnings("unchecked")
    private Map<String, Object> doProcessAdjustmentCharge(ExpapplC eac) {
        Map<String, Object> result = new HashMap<String, Object>();
        RemitMoney rm = facade.getRemitMoneyService().findByExpApplNoFetchRelation(eac.getExpApplNo());
        // 存稅務明細資料
        List<TaxDetail> tdList = new ArrayList<TaxDetail>();
        // 存貸方的4、123費用科目
        List<Entry> expEntries = new ArrayList<Entry>();
        // 處理匯回款項的分錄資料
        Map<String, Object> rsltMap = doProcessRemitMoenyEntries(eac, expEntries);
        TaxDetail taxd = new TaxDetail();
        String costUnitCode = (String) rsltMap.get("costUnitCode");
        String costUnitName = (String) rsltMap.get("costUnitName");
        // 預付費用、溢付費用
        if (PaybackTypeCode.CODE_2.getCode().equals(rm.getPaybackType().getCode())
                || PaybackTypeCode.CODE_3.getCode().equals(rm.getPaybackType().getCode())) {
            return doProcessEacAdjustOnPrePayorOverPay(result, rsltMap, taxd, rm, expEntries, costUnitCode,
                    costUnitName, tdList);
        }
        // 補入稅款
        else if (PaybackTypeCode.CODE_7.getCode().equals(rm.getPaybackType().getCode())) {
            return doProcessEacAdjustOnAddTax(result, rsltMap, taxd, rm, costUnitCode, costUnitName, tdList);
        }
        
        //RE201800605_匯回款項修改 EC0416 20180416 start 
        //因還款類別為"其他"的會計科目與外部系統匯回的會計科目雷同，參考外部系統費用匯回規則寫入稅檔
        //外部系統費用匯回
        else if(PaybackTypeCode.CODE_11.getCode().equals(rm.getPaybackType().getCode())||
        		PaybackTypeCode.CODE_999.getCode().equals(rm.getPaybackType().getCode())){
        	return doProcessEacAdjustOnOutsideSystem(result, rsltMap, taxd, rm, costUnitCode, costUnitName, tdList);
        }
        //RE201800605_匯回款項修改 EC0416 20180416 end
        
        // 稅金匯回，***更新稅務明細條件：為匯回款項之應付代扣科目的所得人證號需與稅務明細的「原申請單號、所得人證號」相符
        else if (PaybackTypeCode.CODE_9.getCode().equals(rm.getPaybackType().getCode())) {
            // 2009/12/25,CR#259，加入有核定的處理
            List<Entry> crdtPblWHEns = (ArrayList<Entry>) rsltMap.get("crdtPblWHEns");
            // "貸方"應付代扣科目的分錄
            Entry crdtPblWthHldgEn = (Entry) rsltMap.get("crdtPblWthHldgEn");
            String nowIncomeUserId = "";
            if (rm.getOldExpapplB() != null) {
                // 2009/12/25,有核定的申請單稅務明細關聯處理
                ExpapplB oldEab = rm.getOldExpapplB();
                List<TaxDetail> totalOldTaxdList = new ArrayList<TaxDetail>();
                if (CollectionUtils.isNotEmpty(oldEab.getProofs())) {
                    // 一張有核定會對到多張憑證，憑證裡才有稅務明細
                    for (Proof proof : oldEab.getProofs()) {
                        List<TaxDetail> taxdList = proof.getTaxDetails();
                        if (CollectionUtils.isEmpty(proof.getTaxDetails())) {
                            // 如果憑證關聯到空的orNull的稅務明細，就用proof去找稅務明細資料
                            findTaxDetailForRemitTaxOnExpapplB(proof);
                        }
                        if (CollectionUtils.isEmpty(taxdList))
                            throw new ExpRuntimeException(ErrorCode.C10384, new String[] { oldEab.getExpApplNo() });
                        for (TaxDetail oldTaxd : taxdList) {
                            // 先把所有元申請單的稅務明細加總起來
                            totalOldTaxdList.add(oldTaxd);
                        }
                    }
                    // 處理完所有對應的憑證後，再來比對現有的匯回款項的應付代扣分錄的所得人證號
                    for (Entry nowCrdtPbWHEn : crdtPblWHEns) {
                        // 2010/01/02,所得人證號比對處理-->必須判斷所得人證號類別
                        nowIncomeUserId = doGetIncomeUserId(nowCrdtPbWHEn, nowIncomeUserId);
                        for (TaxDetail oldTaxd : totalOldTaxdList) {
                            if (nowIncomeUserId.equals(oldTaxd.getTaxId())) {
                                oldTaxd.setEntryTax(crdtPblWthHldgEn);
                                oldTaxd.setTaxRemit("3");
                                oldTaxd.setUpdateDate(Calendar.getInstance());
                                oldTaxd.setUpdateUserId(getLoginUser().getCode());
                                oldTaxd = getDao().update(oldTaxd);
                            }
                        }
                    }
                }
            }
            if (rm.getOldExpapplC() != null) {
                ExpapplC oldEac = rm.getOldExpapplC();
                oldEac = facade.getExpapplCService().findByExpApplNoFetchData(oldEac.getExpApplNo());
                // 查詢該申請單原本的稅務明細資料，並且作修改
                List<TaxDetail> taxdList = findTaxDetailForRemitTax(oldEac);
                if (CollectionUtils.isEmpty(taxdList))
                    throw new ExpRuntimeException(ErrorCode.C10384, new String[] { oldEac.getExpApplNo() });
                // 目前的匯回款項的應付代扣分錄集合
                for (Entry nowCrdtPbWHEn : crdtPblWHEns) {
                    // 2010/01/02,所得人證號比對處理-->必須判斷所得人證號類別
                    nowIncomeUserId = doGetIncomeUserId(nowCrdtPbWHEn, nowIncomeUserId);
                    // 要跟原申請單的稅務明細資料比對，相同所得人證號，才需要更新稅金匯回
                    for (TaxDetail oldTaxd : taxdList) {
                        if (nowIncomeUserId.equals(oldTaxd.getTaxId())) {
                            oldTaxd.setEntryTax(crdtPblWthHldgEn);
                            oldTaxd.setTaxRemit("3");
                            oldTaxd.setUpdateDate(Calendar.getInstance());
                            oldTaxd.setUpdateUserId(getLoginUser().getCode());
                            oldTaxd = getDao().update(oldTaxd);
                        }
                    }
                }
            }
        }
        return result;
    }

    /** 2010/01/02,所得人證號比對處理-->必須判斷所得人證號類別 */
    private String doGetIncomeUserId(Entry en, String nowIncomeUserId) {
        try {
            if (IncomeIdTypeCode.IDENTITY_ID.getCode().equals(en.getIncomeIdType())) {
                nowIncomeUserId = en.getIncomeId() != null ? en.getIncomeId() : "";
            } else if (IncomeIdTypeCode.EMP_ID.getCode().equals(en.getIncomeIdType())
                    || IncomeIdTypeCode.EMP_SALARY_ID.getCode().equals(en.getIncomeIdType())) {
                User u = facade.getUserService().findByCode(en.getIncomeId());
                if (u != null)
                    nowIncomeUserId = u.getIdentityId();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            nowIncomeUserId = "";
        }
        return nowIncomeUserId;
    }

    /** 行政匯回款項，預付費用和溢付費用 */
    private Map<String, Object> doProcessEacAdjustOnPrePayorOverPay(Map<String, Object> result,
            Map<String, Object> rsltMap, TaxDetail taxd, RemitMoney rm, List<Entry> expEntries, String costUnitCode,
            String costUnitName, List<TaxDetail> tdList) {
        // "借方"應付代扣科目的分錄
        Entry dbtPblWthHldgEn = (Entry) rsltMap.get("dbtPblWthHldgEn");
        // 取得所得人證號類別代號
        IncomeIdTypeCode idTypeCode = (IncomeIdTypeCode) rsltMap.get("incomeIdType");
        // 所得人資料
        IncomeUser iu = facade.getIncomeUserService().findByIdentityIdFetchRelation(dbtPblWthHldgEn.getIncomeId());
        if (IncomeIdTypeCode.EMP_SALARY_ID.equals(idTypeCode)
                || IncomeIdTypeCode.EMP_ID.equals(idTypeCode)) {
            taxd.setEmpId(dbtPblWthHldgEn.getIncomeId());
            User u = facade.getUserService().findByCode(dbtPblWthHldgEn.getIncomeId());
            if (u == null)
                throw new ExpRuntimeException(ErrorCode.A20008, new String[] {
                        MessageUtils.getAccessor().getMessage("tw_com_skl_exp_kernel_model6_bo_User_code"),
                        dbtPblWthHldgEn.getIncomeId() });
            taxd.setTaxId(u.getIdentityId());
            taxd.setTaxName(u.getName());
        } else {
            taxd.setEmpId("");
            if (iu == null)
                throw new ExpRuntimeException(ErrorCode.A20008, new String[] {
                        MessageUtils.getAccessor()
                                .getMessage("tw_com_skl_exp_kernel_model6_bo_IncomeUser_identityId_2"),
                        dbtPblWthHldgEn.getIncomeId() });
            taxd.setTaxId(dbtPblWthHldgEn.getIncomeId());
            taxd.setTaxName(iu.getName());
        }
        // 如果是租賃費用的話
        ExpapplC oldEac = rm.getOldExpapplC();
        if (MiddleTypeCode.CODE_D00.getCode().equals(oldEac.getMiddleType().getCode())) {
            if (iu == null)
                throw new ExpRuntimeException(ErrorCode.A20008, new String[] {
                        MessageUtils.getAccessor()
                                .getMessage("tw_com_skl_exp_kernel_model6_bo_IncomeUser_identityId_2"),
                        dbtPblWthHldgEn.getIncomeId() });
            RentExp rexp = facade.getRentExpService().findByExpApplNoFetchRelation(oldEac.getExpApplNo());
            if (rexp == null || rexp.getRentContract() == null
                    && (rexp.getRentContract() != null && rexp.getRentContract().getAddress() == null)) {
                throw new ExpRuntimeException(ErrorCode.A20002, new String[] { MessageUtils.getAccessor().getMessage(
                        "tw_com_skl_exp_kernel_model6_bo_RentExp_rentContract") });
            }
            taxd.setHouseTaxNo(iu.getBuildingTaxNo());
            taxd.setHouseAdr(rexp.getRentContract().getAddress());
        }
        String industryCode = (String) rsltMap.get("industryCode");
        if (industryCode != null)
            taxd.setTaxbizCode(industryCode);
        taxd.setCrossIncome((BigDecimal) rsltMap.get("totalDbtAmt"));
        taxd.setWithholdingTax((BigDecimal) rsltMap.get("totalCrdtAmt"));
        String groupId = genEntryExpGroupAndUUID(expEntries);
        taxd.setGroupId(groupId);
        if (dbtPblWthHldgEn != null)
            taxd.setEntryTax(dbtPblWthHldgEn);
        taxd.setTaxRemit("1");
        taxd.setCostUnitCode(costUnitCode);
        taxd.setCostUnitName(costUnitName);
        // 存起來，待回傳
        tdList.add(taxd);
        result.put("taxDetailList", tdList);
        result.put("expEntries", expEntries);
        return result; // 回傳
    }
    
    /** 行政匯回款項，外部系統費用匯回 */
    private Map<String, Object> doProcessEacAdjustOnOutsideSystem(Map<String, Object> result, Map<String, Object> rsltMap,
            TaxDetail taxd, RemitMoney rm, String costUnitCode, String costUnitName, List<TaxDetail> tdList) {
        // "貸方"應付代扣科目的分錄
        Entry crdtPblWthHldgEn = (Entry) rsltMap.get("crdtPblWthHldgEn");
        //所得人資料分錄
        Entry incomeDataEntry= (Entry) rsltMap.get("incomeDataEntry");
        List<Entry> expEntries=((List<Entry>)rsltMap.get("expEntries"));
        //expEntries.add(crdtPblWthHldgEn);
        // 取得所得人證號類別代號
        IncomeIdTypeCode idTypeCode = IncomeIdTypeCode.getByValue(incomeDataEntry.getIncomeIdType());
        // 所得人資料
        IncomeUser iu = facade.getIncomeUserService().findByIdentityIdFetchRelation(incomeDataEntry.getIncomeId());
        if (IncomeIdTypeCode.EMP_SALARY_ID.equals(idTypeCode)
                || IncomeIdTypeCode.EMP_ID.equals(idTypeCode)) {
            taxd.setEmpId(incomeDataEntry.getIncomeId());
            User u = facade.getUserService().findByCode(incomeDataEntry.getIncomeId());
            if (u == null)
                throw new ExpRuntimeException(ErrorCode.A20008, new String[] {
                        MessageUtils.getAccessor().getMessage("tw_com_skl_exp_kernel_model6_bo_User_code"),
                        incomeDataEntry.getIncomeId() });
            taxd.setTaxId(u.getIdentityId());
            taxd.setTaxName(u.getName());
        } else {
            taxd.setEmpId("");
            if (iu == null)
                throw new ExpRuntimeException(ErrorCode.A20008, new String[] {
                        MessageUtils.getAccessor()
                                .getMessage("tw_com_skl_exp_kernel_model6_bo_IncomeUser_identityId_2"),
                                incomeDataEntry.getIncomeId() });
            taxd.setTaxId(incomeDataEntry.getIncomeId());
            taxd.setTaxName(iu.getName());
        }
        
        String industryCode = (String) rsltMap.get("industryCode");
        if (industryCode != null) {
            taxd.setTaxbizCode(industryCode);
        }
        
        taxd.setCrossIncome((BigDecimal)rsltMap.get("totalCrdtAmt")); // 給付總額 
        taxd.setWithholdingTax((BigDecimal) rsltMap.get("crdtPWHAmt")); // 扣繳稅額
        // =貸方應付代扣金額(正數)
        String groupId = genEntryExpGroupAndUUID(expEntries); // 費用分錄群組ID
        taxd.setGroupId(groupId);
        if (crdtPblWthHldgEn != null) {
            taxd.setEntryTax(crdtPblWthHldgEn);
        }
        taxd.setTaxRemit("1");
        // 存起來，待回傳
        taxd.setCostUnitCode(costUnitCode);
        taxd.setCostUnitName(costUnitName);
        tdList.add(taxd);
        result.put("expEntries", expEntries);
        result.put("taxDetailList", tdList);
        return result;
    }
    
    
    /** 行政匯回款項，補入稅款 */
    private Map<String, Object> doProcessEacAdjustOnAddTax(Map<String, Object> result, Map<String, Object> rsltMap,
            TaxDetail taxd, RemitMoney rm, String costUnitCode, String costUnitName, List<TaxDetail> tdList) {
        // "貸方"應付代扣科目的分錄
        Entry crdtPblWthHldgEn = (Entry) rsltMap.get("crdtPblWthHldgEn");
        // 取得所得人證號類別代號
        IncomeIdTypeCode idTypeCode = (IncomeIdTypeCode) rsltMap.get("crbtIdTyCode");
        // 所得人資料
        IncomeUser iu = facade.getIncomeUserService().findByIdentityIdFetchRelation(crdtPblWthHldgEn.getIncomeId());
        if (IncomeIdTypeCode.EMP_SALARY_ID.equals(idTypeCode)
                || IncomeIdTypeCode.EMP_ID.equals(idTypeCode)) {
            taxd.setEmpId(crdtPblWthHldgEn.getIncomeId());
            User u = facade.getUserService().findByCode(crdtPblWthHldgEn.getIncomeId());
            if (u == null)
                throw new ExpRuntimeException(ErrorCode.A20008, new String[] {
                        MessageUtils.getAccessor().getMessage("tw_com_skl_exp_kernel_model6_bo_User_code"),
                        crdtPblWthHldgEn.getIncomeId() });
            taxd.setTaxId(u.getIdentityId());
            taxd.setTaxName(u.getName());
        } else {
            taxd.setEmpId("");
            if (iu == null)
                throw new ExpRuntimeException(ErrorCode.A20008, new String[] {
                        MessageUtils.getAccessor()
                                .getMessage("tw_com_skl_exp_kernel_model6_bo_IncomeUser_identityId_2"),
                        crdtPblWthHldgEn.getIncomeId() });
            taxd.setTaxId(crdtPblWthHldgEn.getIncomeId());
            taxd.setTaxName(iu.getName());
        }
        // 如果是租賃費用的話
        ExpapplC oldEac = rm.getOldExpapplC();
        if (MiddleTypeCode.CODE_D00.getCode().equals(oldEac.getMiddleType().getCode())) {
            if (iu == null)
                throw new ExpRuntimeException(ErrorCode.A20008, new String[] {
                        MessageUtils.getAccessor()
                                .getMessage("tw_com_skl_exp_kernel_model6_bo_IncomeUser_identityId_2"),
                        crdtPblWthHldgEn.getIncomeId() });
            RentExp rexp = facade.getRentExpService().findByExpApplNoFetchRelation(oldEac.getExpApplNo());
            if (rexp == null || rexp.getRentContract() == null
                    && (rexp.getRentContract() != null && rexp.getRentContract().getAddress() == null)) {
                throw new ExpRuntimeException(ErrorCode.A20002, new String[] { MessageUtils.getAccessor().getMessage(
                        "tw_com_skl_exp_kernel_model6_bo_RentExp_rentContract") });
            }
            taxd.setHouseTaxNo(iu.getBuildingTaxNo());
            taxd.setHouseAdr(rexp.getRentContract().getAddress());
        }
        String industryCode = (String) rsltMap.get("industryCode");
        if (industryCode != null) {
            taxd.setTaxbizCode(industryCode);
        }
        taxd.setCrossIncome(BigDecimal.ZERO); // 給付總額 = 0
        taxd.setWithholdingTax((BigDecimal) rsltMap.get("crdtPWHAmt")); // 扣繳稅額
        // =貸方應付代扣金額(正數)
        String groupId = ""; // 費用分錄群組ID=空白
        taxd.setGroupId(groupId);
        if (crdtPblWthHldgEn != null) {
            taxd.setEntryTax(crdtPblWthHldgEn);
        }
        taxd.setTaxRemit("1");
        // 存起來，待回傳
        taxd.setCostUnitCode(costUnitCode);
        taxd.setCostUnitName(costUnitName);
        tdList.add(taxd);
        result.put("taxDetailList", tdList);
        return result;
    }

    public void createByExpapplC(ExpapplC expapplC) {
        if (expapplC == null)
            return;
        if (expapplC.getEntryGroup() == null || CollectionUtils.isEmpty(expapplC.getEntryGroup().getEntries())) {
            throw new ExpRuntimeException(ErrorCode.C10301, new String[] { expapplC.getExpApplNo(),
                    MessageUtils.getAccessor().getMessage("tw_com_skl_exp_kernel_model6_bo_ExpapplCDetail_entry") });
        }
        BigTypeCode btc = null;
        try {
            // 檢查是否要產生稅務明細資料。2009/12/25，費用調整的匯回款項不用判斷是否有123&4會計科目類別&分類
            String bigTypeCode = StringUtils.trim(expapplC.getMiddleType().getBigType().getCode());
            if (!BigTypeCode.ADJUSTMENT_CHARGE.equals(BigTypeCode.getByValue(bigTypeCode))) {
                boolean needTaxDetails = false;
                needTaxDetails = checkNeedTaxDetail(expapplC);
                if (!needTaxDetails)
                    return;
            }
            btc = BigTypeCode.getByValue(StringUtils.trim(expapplC.getMiddleType().getBigType().getCode()));
            if (MiddleTypeCode.CODE_D00.getCode().equals(expapplC.getMiddleType().getCode())) {
                RentExp rexp = facade.getRentExpService().findByExpApplNoFetchRelation(expapplC.getExpApplNo());
                if (rexp != null && rexp.isDepositForRent())
                    return;
            }
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e);
        }
        TaxDetail td = new TaxDetail();
        Map<String, Object> result = null;
        try {
            switch (btc) {
            case OFFICE_EXP:
                result = doProcessOfficeExp(expapplC, td);
                break;
            case VENDOR_EXP:
                result = doProcessVendorExp(expapplC, td);
                break;
            case APID_EXP:
                result = doProcessApidExp(expapplC, td);
                break;
            case TRVL_LRN:
                result = doProcessTrvlLrn(expapplC);
                break;
            case MEDICAL_EXP:
                result = doProcessMedicalExp(expapplC);
                break;
            case PUB_AFF_CAR:
                result = doProcessPubAffCar(expapplC);
                break;
            case IMMOV_EXP:
            	//RE201001581不動產費用改由獨立的Method進行
                result = doProcessImmovExp(expapplC, td);
                break;
            case ADJUSTMENT_CHARGE:
                result = doProcessAdjustmentCharge(expapplC);
                break;
            default:
                break;
            }
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e);
        }
        try {
            if (!result.isEmpty()) {
                doProcessCommonRuleOnExpapplC(expapplC, result);
            }
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e);
        }
    }

    /**
     * 檢查是否需要產生稅務明細資料
     * 
     * @param expapplC
     * @return
     */
    private boolean checkNeedTaxDetail(ExpapplC expapplC) {
        boolean acctClassis4 = false;
        boolean acctKindis123 = false;
        for (Entry en : expapplC.getEntryGroup().getEntries()) {
            if (AccKindTypeCode.PAY.getCode().equals(en.getAccTitle().getAccKindType().getCode())
                    || AccKindTypeCode.PAY_FOREIGNER.getCode().equals(en.getAccTitle().getAccKindType().getCode())
                    || AccKindTypeCode.NO_PAY.getCode().equals(en.getAccTitle().getAccKindType().getCode()))
                acctKindis123 = true;
            if (AccClassTypeCode.CODE_4.getCode().equals(en.getAccTitle().getAccClassType().getCode())) {
                acctClassis4 = true;
            }
        }
        if (acctClassis4 && acctKindis123)
            return true;
        return false;
    }

    // 產生EntryExpGroup的UUID資料搬到上面作
    private String genEntryExpGroupAndUUID(List<Entry> expEntries) {
        String groupId = "";
        /* 須注意，雙向關係的設定 */
        EntryExpGroup entryExpGroup = null;
        for (Entry expEn : expEntries) {
            entryExpGroup = new EntryExpGroup();
            // 費用分錄--->> 若有多個費用科目怎辦 2009/12/4,就產生多筆EntryExpGroup
            entryExpGroup.setEntry(expEn);
            if (StringUtils.isBlank(groupId))
                groupId = UUID.randomUUID().toString();
            entryExpGroup.setGroupId(groupId);
            facade.getEntryExpGroupService().create(entryExpGroup);
        }
        return groupId;
    }

    private List<TaxDetail> doProcessD00RentExp(List<TaxDetail> tdList, ExpapplC eac, String groupId,
            Entry payableWithHoldingEn, String costUnitCode, String costUnitName) {
        RentExp rexp = facade.getRentExpService().findByExpApplNoFetchRelation(eac.getExpApplNo());
        List<RentExpDetail> redList = facade.getRentExpService().findRentExpDetailByRentExp(rexp);
        TaxDetail taxd = null;
        String incomeUserId = "";
        RentContract rc = rexp.getRentContract();
        // facade.getRentContractService();
        for (RentExpDetail red : redList) {
            if (ProofTypeCode.PROOF_TYPE_D_X.getFormatCode().equals(eac.getProofType().getFormatCode())) {
                incomeUserId = red.getLessor().getLessorId();
            } else {
                incomeUserId = red.getLessor().getLessorCompId();
            }
            IncomeUser iu = facade.getIncomeUserService().findByIdentityIdFetchRelation(incomeUserId);
            // 產生分攤房屋租金的稅務明細
            if (red.getAmortizedBuildingRentAmt().compareTo(BigDecimal.ZERO) > 0) {
                taxd = new TaxDetail();
                taxd.setEmpId("");
                taxd.setTaxName(red.getLessor().getLessorName());
                taxd.setTaxId(incomeUserId);
                taxd.setCrossIncome(red.getAmortizedBuildingRentAmt());
                taxd.setWithholdingTax(red.getBuildingRentTaxAmt());
                taxd.setEntryTax(payableWithHoldingEn);
                taxd.setTaxRemit("1");
                taxd.setGroupId(groupId);
                taxd.setHouseTaxNo(iu.getBuildingTaxNo());
                taxd.setHouseAdr(rc.getAddress());
                // 2009/12/15,加上成本單位代號和成本單位名稱
                taxd.setCostUnitCode(costUnitCode);
                taxd.setCostUnitName(costUnitName);
                tdList.add(taxd);
            }
            // 產生分攤土地租金的稅務明細
            if (red.getAmortizedLandRentAmt().compareTo(BigDecimal.ZERO) > 0) {
                taxd = new TaxDetail();
                taxd.setEmpId("");
                taxd.setTaxName(red.getLessor().getLessorName());
                taxd.setTaxId(incomeUserId);
                taxd.setCrossIncome(red.getAmortizedLandRentAmt());
                taxd.setWithholdingTax(red.getLandRentTaxAmt());
                taxd.setEntryTax(payableWithHoldingEn);
                taxd.setTaxRemit("1");
                taxd.setGroupId(groupId);
                taxd.setMemo("L"); //RE201202037 房屋租金不用寫入L
                taxd.setHouseTaxNo("");  //RE201202037  土地租金不用寫入稅籍編號
                taxd.setHouseTaxNo(iu.getBuildingTaxNo());
                taxd.setHouseAdr(rc.getAddress());
                // 2009/12/15,加上成本單位代號和成本單位名稱
                taxd.setCostUnitCode(costUnitCode);
                taxd.setCostUnitName(costUnitName);
                tdList.add(taxd);
            }
        }
        return tdList;
    }

    /** 處裡匯回款項的分錄資料 */
    private Map<String, Object> doProcessRemitMoenyEntries(ExpapplC eac, List<Entry> expEntries) {
        Map<String, Object> result = new HashMap<String, Object>();
        List<Entry> crdtPblWHEns = new ArrayList<Entry>();
        Entry dbtPblWthHldgEn = null;
        Entry crdtPblWthHldgEn = null;
        IncomeIdTypeCode idTypeCode = null;
        IncomeIdTypeCode crbtIdTyCode = null;
        BigDecimal totalDbtAmt = BigDecimal.ZERO;
        BigDecimal totalCrdtAmt = BigDecimal.ZERO; // 必須是負數
        String costUnitCode = "";
        String costUnitName = "";
        //所得人資料分錄
        Entry incomeDataEntry=null;
        // 扣繳稅額 =貸方應付代扣金額(正數)
        BigDecimal crdtPWHAmt = BigDecimal.ZERO;
        /*RE201201260  靜怡 20120625 Start */
        boolean isWriteTax = false;
        /*RE201201260  靜怡 20120625 End */
        for (Entry en : eac.getEntryGroup().getEntries()) {
            // 借方應付代扣科目資料處理
            if (EntryTypeCode.TYPE_1_D.getValue().equals(en.getEntryType().getValue())
                    && facade.getAccTitleService().isIncomeTaxAccTitle(en.getAccTitle().getCode())) {
                dbtPblWthHldgEn = en;
                idTypeCode = IncomeIdTypeCode.getByValue(en.getIncomeIdType());
                totalDbtAmt = totalDbtAmt.subtract(en.getAmt());
                result.put("incomeIdType", idTypeCode);
                result.put("dbtPblWthHldgEn", dbtPblWthHldgEn);
                /*RE201201260  靜怡 20120625 Start */
                isWriteTax = true;
                /*RE201201260  靜怡 20120625 End */
            }
            if (EntryTypeCode.TYPE_1_C.getValue().equals(en.getEntryType().getValue())
                    && AccClassTypeCode.CODE_4.getCode().equals(en.getAccTitle().getAccClassType().getCode())) {
                // 匯回款項貸方科目分類為4費用的科目金額 (負數)
                result.put("industryCode", en.getIndustryCode() != null ? en.getIndustryCode() : "");
                totalCrdtAmt = totalCrdtAmt.subtract(en.getAmt());
                //RE201001509改至此計錄成本單位
                if (StringUtils.isNotBlank(en.getCostUnitCode()))
                    costUnitCode = en.getCostUnitCode();
                if (StringUtils.isNotBlank(en.getCostUnitName()))
                    costUnitName = en.getCostUnitName();
                /*RE201201260  靜怡 20120625 Start */
                isWriteTax = true;
                /*RE201201260  靜怡 20120625 End */
            }
            // 貸方應付代扣科目資料處理 // 2010/01/02, 修改借方-->>為貸方
            if (EntryTypeCode.TYPE_1_C.getValue().equals(en.getEntryType().getValue())
                    && facade.getAccTitleService().isIncomeTaxAccTitle(en.getAccTitle().getCode())) {
                crdtPblWthHldgEn = en;
                crbtIdTyCode = IncomeIdTypeCode.getByValue(en.getIncomeIdType());
                crdtPWHAmt = crdtPWHAmt.add(en.getAmt());
                crdtPblWHEns.add(crdtPblWthHldgEn);
                result.put("crdtPblWthHldgEn", crdtPblWthHldgEn);
                result.put("crbtIdTyCode", crbtIdTyCode);
            }
            // 貸方，4費用、類別代號為1或2或3
            if (EntryTypeCode.TYPE_1_C.getValue().equals(en.getEntryType().getValue())) {
                if (isNeedProcessEntry(en)) {
                    expEntries.add(en);
                }
            }
            /*RE201201260  靜怡 20130625 Start */
            //RE201001509只要分錄有所得人就抓取
            if (!isWriteTax){ 
              if(StringUtils.isNotBlank(en.getIncomeIdType())){
            	incomeDataEntry=en;
            	dbtPblWthHldgEn = en;
                idTypeCode = IncomeIdTypeCode.getByValue(en.getIncomeIdType());
                result.put("incomeIdType", idTypeCode);
                result.put("dbtPblWthHldgEn", dbtPblWthHldgEn);
              }
            }
            /*RE201201260  靜怡 20130625 End */
        }
        result.put("crdtPblWHEns", crdtPblWHEns);
       
        /*RE201201260 二代健保 靜怡 20130718 start*/
        
        //RE201800605_匯回款項修改 EC0416 20180416 start
        //RemitMoney rm = facade.getRemitMoneyService().findByExpApplNoFetchRelation(eac.getExpApplNo());
        //String repayTypeCode = rm.getPaybackType().getCode(); 
        result.put("totalDbtAmt", totalDbtAmt);// 扣繳稅額 =借方應付代扣金額(負數)
        // (負數)
        result.put("totalCrdtAmt", totalCrdtAmt);  // 給付總額 =匯回款項貸方科目分類為4費用的科目金額
        /*RE201201260 二代健保 靜怡 20130718 end*/
        //RE201800605_匯回款項修改 EC0416 20180416 end
        result.put("crdtPWHAmt", crdtPWHAmt); // 扣繳稅額 =貸方應付代扣金額(正數)
        result.put("expEntries", expEntries);
        result.put("costUnitCode", costUnitCode);
        result.put("costUnitName", costUnitName);
        //RE201001509只要分錄有所得人就傳入，用於外部系統匯回
        result.put("incomeDataEntry", incomeDataEntry);
        return result;
    }

    /** 是否需要處理該分錄(會計科目4、123) */
    private boolean isNeedProcessEntry(Entry en) {
        String actClassCode = "";
        String actKindCode = "";
        if (en.getAccTitle() != null) {
            if (en.getAccTitle().getAccClassType() != null && en.getAccTitle().getAccClassType().getCode() != null) {
                actClassCode = en.getAccTitle().getAccClassType().getCode();
            }
            if (en.getAccTitle().getAccKindType() != null && en.getAccTitle().getAccKindType().getCode() != null) {
                actKindCode = en.getAccTitle().getAccKindType().getCode();
            }
        }
        if (AccClassTypeCode.CODE_4.getCode().equals(actClassCode)) {
            if (AccKindTypeCode.PAY.getCode().equals(actKindCode)
                    || AccKindTypeCode.PAY_FOREIGNER.getCode().equals(actKindCode)
                    || AccKindTypeCode.NO_PAY.getCode().equals(actKindCode)) {
                return true;
            }
        }
        return false;
    }

    // 處理行政費用稅務明細最後的邏輯
    @SuppressWarnings("unchecked")
    private void doProcessCommonRuleOnExpapplC(ExpapplC eac, Map<String, Object> result) {
        List<TaxDetail> taxdList = (List<TaxDetail>) result.get("taxDetailList");
        List<Entry> expEntries = (List<Entry>) result.get("expEntries");
        //所得格式
        String incomeForm = "";
        //備註
        String memo = "";        
        //分錄
        Entry expEn = null;
        //所得來源類別
        String sourceKind="";
        boolean flag = false;
        // 使用者的員工代號
        String createUserId = getLoginUser().getIdentityId() != null ? getLoginUser().getIdentityId() : "";
        Calendar sysDate = Calendar.getInstance();
        for (Entry en : expEntries) {
            if (!flag && StringUtils.isNotBlank(en.getAccTitle().getIncomeForm())) {
                incomeForm = en.getAccTitle().getIncomeForm();
                //預設所得來源類別=所得格式
                sourceKind=incomeForm;
                expEn = en;
                flag = true;
            }
            //假如會計科目為租金-土地租金-一般土地租金(本)、租金-土地租金-一般土地租金(外)，需加註L
            if (AccTitleCode.GENERAL_LAND_RENT_COUNTRY.getCode().equals(en.getAccTitle().getCode())
                    || AccTitleCode.GENERAL_LAND_RENT_FOREIGN.getCode().equals(en.getAccTitle().getCode())) {
                memo = "L";
                
            }
            //假如費用大分類為醫檢費，會計科目為維持費用-勞務費-其他勞務費(92醫檢)，業別代號為8Z時，所得格式為92
            if(BigTypeCode.MEDICAL_EXP.getCode().equals(eac.getMiddleType().getBigType().getCode())){
            	if(AccTitleCode.MAINTAINEXP_92MEDICAL_OTHER_LABOUR_EXP.getCode().equals(en.getAccTitle().getCode())){
            		if(expEn.getIndustryCode().compareTo("8Z")==0){
            			incomeForm="92";
            			sourceKind="H1";
            		}
            	}
            }
            //假如費用大分類為廠商費用，會計科目為材料用品-獎勵費-獎品(本)，所得來源類別為G1
            if(BigTypeCode.VENDOR_EXP.getCode().equals(eac.getMiddleType().getBigType().getCode())){
            	if(AccTitleCode.REWARD_OTHER_AWARD_EXP.getCode().equals(en.getAccTitle().getCode())){
            		sourceKind="G1";
            		
            	}
            }//假如費用大分類為非廠商費用，會計科目為材料用品-獎勵費-獎品(本)，所得來源類別為G3
            else if(AccTitleCode.REWARD_OTHER_AWARD_EXP.getCode().equals(en.getAccTitle().getCode())){
            	sourceKind="G3";
            }//假如費用大分類為非廠商費用，會計科目為材料用品-獎勵費-其他獎金(本)，所得來源類別為G2
            else if(AccTitleCode.REWARD_OTHER_REWARD_EXP.getCode().equals(en.getAccTitle().getCode())){
            	sourceKind="G2";
            }//假如費用大分類為非廠商費用，會計科目為維持費用-勞務費-其他勞務費(9A本)，所得來源類別為H1
            else if(AccTitleCode.MAINTAINEXP_9A_OHTER_LABOR_EXP.getCode().equals(en.getAccTitle().getCode())){
            	sourceKind="H1";
            }//假如費用大分類為非廠商費用，會計科目為維持費用-勞務費-其他勞務費(9B本)，所得來源類別為H1
            else if(AccTitleCode.MAINTAINEXP_9B_OHTER_LABOR_EXP.getCode().equals(en.getAccTitle().getCode())){
            	sourceKind="H1";
            }//假如費用大分類為非廠商費用，會計科目為維持費用-勞務費-其他勞務費(92病歷調閱費)，所得來源類別為H1
            else if(AccTitleCode.MAINTAINEXP_92_OHTER_LABOR_EXP.getCode().equals(en.getAccTitle().getCode())){
            	sourceKind="H1";
            }//假如費用大分類為非廠商費用，會計科目為租金-土地租金-一般土地租金(本)，所得來源類別為H1
            else if (AccTitleCode.GENERAL_LAND_RENT_COUNTRY.getCode().equals(en.getAccTitle().getCode())){
            	sourceKind="H1";
            }//假如費用大分類為非廠商費用，會計科目為租金-房屋租金-一般房屋租金(本)，所得來源類別為H1
            else if (AccTitleCode.GENERAL_BUILDING_RENT_COUNTRY.getCode().equals(en.getAccTitle().getCode())){
            	sourceKind="H1";
            }
            //RE201503288_獎勵費(92所得)之名冊建檔及所得稅功能檢核 CU3178  2015/9/11 START
            //假如費用大分類為非廠商費用，會計科目為材料用品-獎勵費-一獎勵費，所得來源類別為G4
            else if (AccTitleCode.INCENTIE_FEE_63300703.getCode().equals(en.getAccTitle().getCode())){
            	sourceKind="G4";
            }
            //RE201503288_獎勵費(92所得)之名冊建檔及所得稅功能檢核 CU3178  2015/9/11 END
            
            
            
            if (flag && "L".equals(memo)) {
                break;
            }
        }
        for (TaxDetail taxd : taxdList) {
            // 2009/12/22,IR#1454,成本單位改由稅務明細中取得，有值才會有扣繳單位
            taxd.setWithholdId(getExpapplCWithHoldID(taxd.getCostUnitCode()));
            taxd.setIncomeForm(incomeForm);
            //RE201500288_非D00的土地租金稅務明細寫入L(defect_1089) CU3178 2015/02/26 START
            if(!eac.getMiddleType().getCode().equals("D00")){
            	taxd.setMemo(memo);
            }
            //RE201500288_非D00的土地租金稅務明細寫入L(defect_1089) CU3178 2014/02/26 END
            taxd.setSourceKind(sourceKind);
            // 付款憑單編號 pay
            taxd.setPayCertNo(eac.getSubpoena().getSubpoenaNo());
            taxd.setSubpoenaNo(eac.getSubpoena().getSubpoenaNo());
            taxd.setSubpoenaDate(eac.getSubpoena().getSubpoenaDate());
            taxd.setTaxbizCode(expEn.getIndustryCode());
            taxd.setTaxRate(expEn.getAccTitle().getTaxRate());
            taxd.setRelationCode("");
            taxd.setRelationFlag("");
            taxd.setCreateUserId(createUserId);
            taxd.setCreateDate(sysDate);
            if (StringUtils.isBlank(taxd.getId())) {
                taxd = create(taxd);
            } else {
                // 因為匯回款項的稅金匯回時，稅務明細是DB裡的資料，所以用update
                taxd = update(taxd);
            }
            // 把值還原??
            // memo = "";
        }
        // 2009/12/7,user說，要把關連設定到"費用申請單稅務明細關聯"
        eac.setTaxDetails(taxdList);
        eac = facade.getExpapplCService().update(eac);
    }

    private String getExpapplCWithHoldID(String costUnitCode) {
        // 2009/12/15,補上取得扣繳單位
        String withholdId = "";
        if (StringUtils.isNotBlank(costUnitCode)) {
            Department dep = getFacade().getDepartmentService().findByCode(costUnitCode);
            if (dep != null) {
                Area area = getFacade().getAreaService().findByZip(dep.getZip());
                if (area != null && area.getCity() != null)
                    withholdId = area.getCity().getCompId();
                else
                    logger.error("can't fetch CityData @ AreaService.findByZip & depCode=::" + costUnitCode);
            } else
                logger.error("can't find DepData @ DepartmentService.findByCode & depCode=::" + costUnitCode);
        }
        return withholdId;
    }

    private List<TaxDetail> findTaxDetailForRemitTax(ExpapplC eac) {
        StringBuffer querySql = new StringBuffer();
        Map<String, Object> params = new HashMap<String, Object>();
        querySql.append(" select distinct taxd from ExpapplC eac join eac.taxDetails taxd join fetch eac.taxDetails"
                + " where eac = :eac");
        params.put("eac", eac);
        return getDao().findByNamedParams(querySql.toString(), params);
    }

    private List<TaxDetail> findTaxDetailForRemitTaxOnExpapplB(Proof proof) {
        StringBuffer querySql = new StringBuffer();
        Map<String, Object> params = new HashMap<String, Object>();
        querySql.append(" select taxd from Proof proof join proof.taxDetails taxd join fetch proof.taxDetails"
                + " where proof = :proof");
        params.put("proof", proof);
        return getDao().findByNamedParams(querySql.toString(), params);
    }

    public void createByExpapplD(ExpapplD expapplD) {
        // D8.1.3
        if (expapplD instanceof ManualAccountAppl) {
            ManualAccountAppl appl = (ManualAccountAppl) expapplD;
            List<ManualAccountDetail> manualAccountDetails = appl.getManualAccountDetails();
            if (!CollectionUtils.isEmpty(manualAccountDetails)) {
                List<TaxDetail> taxDetails = new ArrayList<TaxDetail>();
                for (ManualAccountDetail manualAccountDetail : manualAccountDetails) {
                    List<DailyCloseBTaxDetailDto> taxDetailDtos = new ArrayList<DailyCloseBTaxDetailDto>();
                    Entry entryExp = manualAccountDetail.getEntry();
                    Entry entryTax = null;
                    AccTitle accTitle = entryExp.getAccTitle();
                    if (getFacade().getAccTitleService().isWithholdType(accTitle) && accTitle.getCode().startsWith("6")) {
                        String entryTypeValue = entryExp.getEntryType().getValue();
                        AccTitle expAccTitle = accTitle;
                        RosterDetail rosterDetail = manualAccountDetail.getRosterDetail();
                        // 找對應的稅務資料分錄
                        if (expAccTitle != null) {
                            AccTitle withHold = expAccTitle.getWithhold();
                            for (ManualAccountDetail detail : manualAccountDetails) {
                                if (detail.getManualAccountDetail() != null
                                        && detail.getManualAccountDetail().getId().equals(manualAccountDetail.getId())) {
                                    if (withHold != null
                                            && detail.getEntry().getAccTitle().getCode().equals(withHold.getCode())) {
                                        entryTax = detail.getEntry();
                                    }
                                }
                            }
                        }
                        Department costUnit = facade.getDepartmentService().findByCode(entryExp.getCostUnitCode());
                        String withholdId = getFacade().getAreaService().findByZip(costUnit.getZip()).getCity()
                                .getCompId();
                        if (rosterDetail != null) {
                            // 有使用名冊
                            if (!manualAccountDetail.isRosterUseFlag()) {
                                List<GainPerson> gainPersons = rosterDetail.getGainPersons();
                                if (!CollectionUtils.isEmpty(gainPersons)) {
                                    for (GainPerson gainPerson : gainPersons) {
                                        if (gainPerson.getGainUserId() != null) {
                                            User user = getFacade().getUserService().findByCode(
                                                    gainPerson.getGainUserId());
                                            DailyCloseBTaxDetailDto taxDetailDto = new DailyCloseBTaxDetailDto();
                                            taxDetailDto.setRosterNo(rosterDetail.getRosterNo());
                                            taxDetailDto.setEntryTax(entryTax);
                                            taxDetailDto.setEntryExp(entryExp);
                                            taxDetailDto.setAccTitle(rosterDetail.getAccTitle());
                                            if ("D".equals(entryTypeValue)) {
                                                taxDetailDto.setAmt(gainPerson.getGainAmt());
                                                taxDetailDto.setTaxAmt(gainPerson.getTaxAmt2());
                                            } else {
                                                taxDetailDto.setAmt(gainPerson.getGainAmt().negate());
                                                taxDetailDto.setTaxAmt(gainPerson.getTaxAmt2().negate());
                                            }
                                            taxDetailDto.setWithholdId(withholdId);
                                            taxDetailDto.setUserCode(user.getCode());
                                            taxDetailDto.setIncomeId(user.getIdentityId());
                                            taxDetailDto.setIncomeName(user.getName());
                                            taxDetailDtos.add(taxDetailDto);
                                        } else {
                                            DailyCloseBTaxDetailDto taxDetailDto = new DailyCloseBTaxDetailDto();
                                            taxDetailDto.setRosterNo(rosterDetail.getRosterNo());
                                            taxDetailDto.setEntryTax(entryTax);
                                            taxDetailDto.setEntryExp(entryExp);
                                            taxDetailDto.setAccTitle(rosterDetail.getAccTitle());
                                            if ("D".equals(entryTypeValue)) {
                                                taxDetailDto.setAmt(gainPerson.getGainAmt());
                                                taxDetailDto.setTaxAmt(gainPerson.getTaxAmt2());
                                            } else {
                                                taxDetailDto.setAmt(gainPerson.getGainAmt().negate());
                                                taxDetailDto.setTaxAmt(gainPerson.getTaxAmt2().negate());
                                            }
                                            taxDetailDto.setWithholdId(withholdId);
                                            taxDetailDto.setUserCode(null);
                                            taxDetailDto.setIncomeId(gainPerson.getIncomeUser().getIdentityId());
                                            taxDetailDto.setIncomeName(gainPerson.getIncomeUser().getName());
                                            taxDetailDtos.add(taxDetailDto);
                                        }
                                    }
                                }
                            }
                        } else {
                            DailyCloseBTaxDetailDto taxDetailDto = new DailyCloseBTaxDetailDto();
                            taxDetailDto.setRosterNo(null);
                            taxDetailDto.setEntryTax(entryTax);
                            taxDetailDto.setEntryExp(entryExp);
                            taxDetailDto.setAccTitle(taxDetailDto.getEntryExp().getAccTitle());
                            if ("D".equals(entryTypeValue)) {
                                taxDetailDto.setAmt(taxDetailDto.getEntryExp().getAmt());
                                taxDetailDto.setTaxAmt(taxDetailDto.getEntryTax() == null ? BigDecimal.ZERO
                                        : taxDetailDto.getEntryTax().getAmt());
                            } else {
                                taxDetailDto.setAmt(taxDetailDto.getEntryExp().getAmt().negate());
                                taxDetailDto.setTaxAmt(taxDetailDto.getEntryTax() == null ? BigDecimal.ZERO
                                        : taxDetailDto.getEntryTax().getAmt().negate());
                            }
                            taxDetailDto.setWithholdId(withholdId);
                            String userCode = "";
                            String incomeId = "";
                            String incomeName = "";
                            IncomeIdTypeCode incomeIdTypeCode = IncomeIdTypeCode.getByValue(entryExp.getIncomeIdType());
                            switch (incomeIdTypeCode) {
                            case COMP_ID:
                            case IDENTITY_ID:
                                IncomeUser incomeUser = facade.getIncomeUserService().findIncomeUser(incomeIdTypeCode,
                                        entryExp.getIncomeId());
                                if (incomeUser != null) {
                                    userCode = "";
                                    incomeId = incomeUser.getIdentityId();
                                    incomeName = incomeUser.getName();
                                }
                                break;
                            case EMP_SALARY_ID:
                            case EMP_ID:
                                User user = facade.getUserService().findByCode(entryExp.getIncomeId());
                                if (user != null) {
                                    userCode = user.getCode();
                                    incomeId = user.getIdentityId();
                                    incomeName = user.getName();
                                }
                                break;
                            }
                            taxDetailDto.setUserCode(userCode);
                            taxDetailDto.setIncomeId(incomeId);
                            taxDetailDto.setIncomeName(incomeName);
                            taxDetailDtos.add(taxDetailDto);
                        }
                        for (DailyCloseBTaxDetailDto taxDetailDto : taxDetailDtos) {
                            TaxDetail taxDetail = new TaxDetail();
                            String accKindTypeCode = taxDetailDto.getAccTitle().getAccKindType().getCode();
                            if (!(AccKindTypeCode.NORMAL.getCode().equals(accKindTypeCode) && taxDetailDto
                                    .getEntryTax() == null)) {
                                String empId = taxDetailDto.getUserCode();
                                String taxId = taxDetailDto.getIncomeId();
                                String taxName = taxDetailDto.getIncomeName();
                                String incomeForm = accTitle.getIncomeForm();
                                String houseTaxNo = "";
                                String memo = ("51".equals(incomeForm) && "".equals(houseTaxNo)) ? "L" : "";
                                String sourceKind = incomeForm;
                                String payCertNo = expapplD.getSubpoenaD().getSubpoenaNo();
                                Calendar subpoenaDate = expapplD.getSubpoenaD().getSubpoenaDate();
                                String subpoenaNo = expapplD.getSubpoenaD().getSubpoenaNo();
                                String houseAdr = "";
                                String taxbizCode = accTitle.getIncomeBiz();
                                String rosterNo = taxDetailDto.getRosterNo();
                                BigDecimal crossIncome = taxDetailDto.getAmt();
                                BigDecimal taxRate = accTitle.getTaxRate();
                                BigDecimal withholdingTax = taxDetailDto.getTaxAmt();
                                Entry expEntry = taxDetailDto.getEntryExp();
                                BigDecimal begWithholdAmt = accTitle.getBegWithholdAmt() == null ? BigDecimal.ZERO
                                        : accTitle.getBegWithholdAmt();
                                String costUnitCode = expEntry.getCostUnitCode();
                                String costUnitName = expEntry.getCostUnitName();
                                String taxRemit = (appl.getPaymentType() != null
                                        && PaymentTypeCode.D_CHECK.getCode().equals(appl.getPaymentType().getCode())
                                        && (AccKindTypeCode.PAY.getCode().equals(accTitle.getAccKindType().getCode()) || AccKindTypeCode.PAY_FOREIGNER
                                                .getCode().equals(accTitle.getAccKindType().getCode())) && (crossIncome
                                        .compareTo(begWithholdAmt) >= 0)) ? "2" : "1";
                                String createUserId = ((User) AAUtils.getLoggedInUser()).getIdentityId();
                                Calendar createDate = Calendar.getInstance();
                                taxDetail.setCostUnitCode(costUnitCode);
                                taxDetail.setCostUnitName(costUnitName);
                                taxDetail.setCreateDate(createDate);
                                taxDetail.setCreateUserId(createUserId);
                                taxDetail.setCrossIncome(crossIncome);
                                taxDetail.setEmpId(empId);
                                EntryExpGroup entryExpGroup = new EntryExpGroup();
                                entryExpGroup.setEntry(expEntry);
                                String groupId = UUID.randomUUID().toString();
                                entryExpGroup.setGroupId(groupId);
                                facade.getEntryExpGroupService().create(entryExpGroup);
                                taxDetail.setGroupId(groupId);
                                taxDetail.setEntryTax(taxDetailDto.getEntryTax());
                                taxDetail.setHouseAdr(houseAdr);
                                taxDetail.setHouseTaxNo(houseTaxNo);
                                taxDetail.setIncomeForm(incomeForm);
                                taxDetail.setMemo(memo);
                                taxDetail.setPayCertNo(payCertNo);
                                taxDetail.setRosterNo(rosterNo);
                                taxDetail.setSourceKind(sourceKind);
                                taxDetail.setSubpoenaDate(subpoenaDate);
                                taxDetail.setSubpoenaNo(subpoenaNo);
                                taxDetail.setTaxbizCode(taxbizCode);
                                taxDetail.setTaxId(taxId);
                                taxDetail.setTaxName(taxName);
                                taxDetail.setTaxRate(taxRate);
                                taxDetail.setTaxRemit(taxRemit);
                                taxDetail.setWithholdId(withholdId);
                                taxDetail.setWithholdingTax(withholdingTax);
                                taxDetail = getDao().create(taxDetail);
                                taxDetails.add(taxDetail);
                            }
                        }
                    }
                    // manualAccountDetail.setTaxDetail(taxDetail);
                }
                appl.setTaxDetails(taxDetails);
            }
        }
    }

    public void setFacade(TaxDetailFacade facade) {
        this.facade = facade;
    }

    public TaxDetailFacade getFacade() {
        return facade;
    }

    private User getLoginUser() {
        User user = this.facade.getUserService().findByPK(((User) AAUtils.getLoggedInUser()).getId());
        return user;
    }

    public List<TaxDetail> findByExpApplNo(String expApplNo) {
        return getDao().findByExpApplNo(expApplNo);
    }
}
