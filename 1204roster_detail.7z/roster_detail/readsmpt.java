package tool;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;


public class readsmpt {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		try {
			//讀欲修改後檔案
			//來源:user提供
			//需排除原始檔案中是否扣抵印花稅Y的部分(第三欄)
			//原始印花稅金額:憑證金額*0.004無條件捨去至整數位
			//差額:修改後印花稅金額-原始印花稅金額
			//欲修改檔案格式:醫檢年月(0),醫檢代號(1),憑證金額(2),原始印花稅金額(3),修改後印花稅金額(4),差額(5)			
			FileReader fr1;
			fr1 = new FileReader("d:/test/updateData.csv");
			BufferedReader br1 = new BufferedReader(fr1);
			String str1 = null;
			//暫存資料
			String [][] updateData = new String[2000][100]; 
			int c1 =0;
			while ((str1 = br1.readLine()) != null) {
				updateData[c1] = str1.split("\\,");// 分割逗號
				c1++;
			}
			
			//讀資料檔案
			//資料檔案格式:申請單id(0)、分錄id(1)、分錄金額(2)、會計科目代號(3)、醫檢代號(4)、醫檢年月(5)
			//撈件
			FileReader fr2;
			fr2 = new FileReader("d:/test/soruceData.csv");
			BufferedReader br2 = new BufferedReader(fr2);
			String str2 = null;
			//暫存資料
			String [][] sourceData = new String[2000][100]; 
			int c2 =0;
			while ((str2 = br2.readLine()) != null) {
				sourceData[c2] = str2.split("\\,");// 分割逗號
				c2++;
			}
			
			FileWriter fw1 = new FileWriter("d:/test/updatesql.txt");
			
			FileWriter fw2 = new FileWriter("d:/test/selectExpapplcsql.txt");
			
			FileWriter fw3 = new FileWriter("d:/test/selectentrycsql.txt");

			fw2.write("select * from tbexp_expappl_c where id in( \r\n");
			
			fw3.write("select * from tbexp_entry where id in( \r\n");
			
			for(int i =0;i<c1;i++){
				//申請單id
				String expId="";
				//印花稅分錄id
				String smtpId="";
				//待匯分錄id
				String realyId="";
				//原始待匯金額
				String realyAmt="";
				//修改後印花稅金額
				String updateSmtpAmt="";
				//修改後待匯金額
				String updateRealyAmt="";
				
				//欲修改檔案格式:醫檢年月(0),醫檢代號(1),憑證金額(2),原始印花稅金額(3),修改後印花稅金額(4),差額(5)
				//資料檔案格式:申請單id(0)、分錄id(1)、分錄金額(2)、會計科目代號(3)、醫檢代號(4)、醫檢年月(5)
				
				//step1:先依據醫檢年月、醫檢代號、原始印花稅金額、會計科目為"20210217(印花稅)"找到對應到的申請單id
				for(int j=0;j<c2;j++){
					if (updateData[i][0].equals(sourceData[j][5])
							&& updateData[i][1].equals(sourceData[j][4])
							&& updateData[i][3].equals(sourceData[j][2])
							&&(sourceData[j][3].equals("20210217"))) {
						//紀錄申請單id
						expId=sourceData[j][0];
					}					
				}
				
				//step2:依據找到的申請單id找到對應的印花稅分錄Id，會計科目為"20210217(印花稅)
				for(int j=0;j<c2;j++){
					if (sourceData[j][0].equals(expId)
							&&(sourceData[j][3].equals("20210217"))) {
						//紀錄印花稅分錄id
						smtpId=sourceData[j][1];
					}					
				}
				
				//step3:依據找到的申請單id找到對應的待匯分錄Id，會計科目為"20210391(待匯)
				for(int j=0;j<c2;j++){
					if (sourceData[j][0].equals(expId)
							&&(sourceData[j][3].equals("20210391"))) {
						//紀錄待匯分錄id
						realyId=sourceData[j][1];
						//紀錄原始待匯金額
						realyAmt=sourceData[j][2];
					}					
				}
				
				//step4:產生印花稅修改語法
				//修改後印花稅金額
				updateSmtpAmt=updateData[i][4];
				
				//step5:產生待匯修改語法
				//修改後待匯金額=原始待匯金額-差額
				updateRealyAmt=String.valueOf(Integer.parseInt(realyAmt)-Integer.parseInt(updateData[i][5]));
				
				System.out.println("--"+updateData[i][0]);//醫檢年月
				System.out.println("--"+updateData[i][1]);//醫檢代號
//				
//				//產生語法
//				System.out.println("UPDATE TBEXP_ENTRY SET AMT='"+updateSmtpAmt+"' WHERE ID='"+smtpId+"';");
//				
//
//				//產生語法
//				System.out.println("UPDATE TBEXP_ENTRY SET AMT='"+updateRealyAmt+"' WHERE ID='"+realyId+"';");
//				
//				//step6:產生申請單修改語法
//				System.out.println("UPDATE TBEXP_EXPAPPL_C SET STAMP_AMT='"+updateSmtpAmt+"',REALITY_AMT='"+updateRealyAmt+ "' WHERE ID='"+expId+"';");
				
				//寫檔
				fw1.write("--"+updateData[i][0]+"\r\n");
				fw1.write("--"+updateData[i][1]+"\r\n");
				fw1.write("UPDATE TBEXP_ENTRY SET AMT='"+updateSmtpAmt+"' WHERE ID='"+smtpId+"';"+"\r\n");
				fw1.write("UPDATE TBEXP_ENTRY SET AMT='"+updateRealyAmt+"' WHERE ID='"+realyId+"';"+"\r\n");
				fw1.write("UPDATE TBEXP_EXPAPPL_C SET STAMP_AMT='"+updateSmtpAmt+"',REALITY_AMT='"+updateRealyAmt+ "' WHERE ID='"+expId+"';"+"\r\n");
				
				fw2.write("'"+expId+"',\r\n");
				
				fw3.write("'"+smtpId+"',\r\n");
				fw3.write("'"+realyId+"',\r\n");


			}
			
			 fw1.flush();
			 fw1.close();
			 
			 fw2.write(");");
			 
			 fw2.flush();
			 fw2.close();
			 
			 fw3.write(");");
			 fw3.flush();
			 fw3.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
