package tool;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;


public class ReadFile {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		try {
			//讀欲比對的資料	
			FileReader fr1;
			fr1 = new FileReader("d:/test/payment.csv");
			BufferedReader br1 = new BufferedReader(fr1);
			String str1 = null;
			//暫存資料
			String [][] updateData = new String[5000][100]; 
			int c1 =0;
			while ((str1 = br1.readLine()) != null) {
				updateData[c1] = str1.split("\\,");// 分割逗號
				c1++;
			}
			
			//讀來源檔案
			FileReader fr2;
			fr2 = new FileReader("d:/test/readdisb.csv");
			BufferedReader br2 = new BufferedReader(fr2);
			String str2 = null;
			//暫存資料
			String [][] sourceData = new String[5000][100]; 
			int c2 =0;
			while ((str2 = br2.readLine()) != null) {
				sourceData[c2] = str2.split("\\,");// 分割逗號
				c2++;
			}
			boolean flag = false;
			for(int i =0;i<c1;i++){

				String expApplNo=updateData[i][3];
				String payee=updateData[i][10];

				flag = false;
				for(int j=0;j<c2;j++){
					String payment_expApplNo=sourceData[j][4];
					String payment_payee=sourceData[j][5];
					
					if(expApplNo.equals("R20201710240005")&&payment_expApplNo.equals("R20201710240005")){
						System.out.println("disb:exp_appl_no="+expApplNo+",payee="+payee);
					}
					
					if (expApplNo.equals(payment_expApplNo)&&payee.equals(payment_payee)) {
						flag=true;
					}					
				}
				
				if(!flag){
					System.out.println("disb:exp_appl_no="+expApplNo+",payee="+payee);
				}


			}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
