USE [SKL_LOAN]
GO

/****** Object:  StoredProcedure [dbo].[USP_House_QryInsCheckData]    Script Date: 2019/12/12 下午 10:06:25 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[USP_House_QryInsCheckData]
	 @DateS		VARCHAR(10)		--資料日期起
	,@DateE		VARCHAR(10)		--資料日期迄
	,@CustNo	VARCHAR(50)		--借款人戶號
	,@AgentEmpNo	VARCHAR(50)		--介紹人員工代號
	,@r_TotalNum int output	--此次查詢的總筆數

AS	
BEGIN
	--建立表格
	CREATE TABLE #Temp_Key
	( 
		 DataDate		varchar(8)--資料日期(年月日)
		,LoanKey	    varchar(100)
		,CustNo			varchar(10)--借款人戶號
		,CustName		nvarchar(70)--借款人姓名
		,CaseNo			varchar(20)--放款案號
		,ApproveDate	varchar(8)--核貸日
		,CheckAmount	varchar(18)--核貸金額
		,LMSLLD			varchar(8)--撥款日
		,LMSFLA			varchar(15)--撥款金額
		,IncomeSalary	varchar(13)--薪資收入
		,IncomeWork		varchar(13)--執行業務收入
		,IncomeBusiness	varchar(13)--營業收入
		,IncomeRant		varchar(13)--租金收入
		,IncomeInterest	varchar(13)--利息收入
		,IncomeOther	varchar(13)--其他收入
		,IncomeYear		varchar(13)--借款人年收入
		,Estimate		varchar(20)--本案推估年收入
		,AngentEmpName	nvarchar(80)--介紹人
		,AngentEmpNo	varchar(6)--介紹人員工代號
		,AngentUnitNo	varchar(6)--單位代號
	);

	--篩選資料
	insert into #Temp_Key
	select 
		a.DataDate		--資料日期(年月日)
		,a.LoanKey       -- LoanKey
		,a.CustNo			--借款人戶號
		,a.CustName		--借款人姓名
		,a.CaseNo			--放款案號
		,a.ApproveDate	--核貸日
		,a.CheckAmount	--核貸金額
		,a.LMSLLD			--撥款日
		,a.LMSFLA			--撥款金額
		,a.IncomeSalary	--薪資收入
		,a.IncomeWork		--執行業務收入
		,a.IncomeBusiness	--營業收入
		,a.IncomeRant		--租金收入
		,a.IncomeInterest	--利息收入
		,a.IncomeOther	--其他收入
		,a.IncomeYear		--借款人年收入
		,a.Estimate		--本案推估年收入
		,a.AngentEmpName	--介紹人
		,a.AngentEmpNo	--介紹人員工代號
		,a.AngentUnitNo	--單位代號
	from dbo.House_InsCheckData	a
	where 
		DATEDIFF(d, a.DataDate, CONVERT(DATETIME, @DateS)) <= 0
		AND 
		DATEDIFF(d, a.DataDate, CONVERT(DATETIME, @DateE)) >= 0	
		AND
		(a.CustNo=@CustNo or @CustNo='')
		AND
		(a.AngentEmpNo=@AgentEmpNo or @AgentEmpNo='')

	--取得總筆數
	select @r_TotalNum=count(LoanKey) from #Temp_Key
	print @r_TotalNum

	select 
		a.DataDate		--資料日期(年月日)
		,a.CustNo			--借款人戶號
		,a.CustName		--借款人姓名
		,a.CaseNo			--放款案號
		,a.ApproveDate	--核貸日
		,a.CheckAmount	--核貸金額
		,a.LMSLLD			--撥款日
		,a.LMSFLA			--撥款金額
		,a.IncomeSalary	--薪資收入
		,a.IncomeWork		--執行業務收入
		,a.IncomeBusiness	--營業收入
		,a.IncomeRant		--租金收入
		,a.IncomeInterest	--利息收入
		,a.IncomeOther	--其他收入
		,a.IncomeYear		--借款人年收入
		,a.Estimate		--本案推估年收入
		,a.AngentEmpName	--介紹人
		,a.AngentEmpNo	--介紹人員工代號
		,a.AngentUnitNo	--單位代號
	from #Temp_Key a

	drop table #Temp_Key

END


GO


