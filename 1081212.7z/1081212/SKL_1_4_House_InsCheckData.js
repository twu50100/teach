﻿var G_PAGE_SIZE = 10;
var G_List = {};

var genBox = function (Data) {

    var json = {
        boxCtrl: [

            {
                BodyForm: "form",
                Body: [
                    {
                        Row: "caption",
                        Ctrl: ["核保作業勾稽資料查詢"]
                    }
                ]
            },
            {
                BodyForm: "form",
                ID: "QryForm",
                Body: [
                     {
                         Row: "2col",
                         ColumnClass: ["required"],
                         Ctrl: [
                             "資料日期",
                             [
                                [
                                { Type: "datepicker", Name: "DateS" },
                                "至",
                                { Type: "datepicker", Name: "DateE" },

                                ]
                             ]

                         ]
                     },
                     {
                         Row: "2col",
                         Ctrl: ["借款人戶號",
                             [
                                 { Type: "text", Name: "CustNo" },
                             ]
                         ]
                     },
                     {
                         Row: "2col",
                         Ctrl: ["介紹人員工代號",
                             [
                                 { Type: "text", Name: "Agent_EmpNo" },
                             ]
                         ]
                     },
                    {
                        Row: "col",
                        RowClass: "align_center nohover",
                        Ctrl: [
                            {
                                Type: "a", Data: "查詢", Class: "button", Event: function (Arg) {
                                    Qry(Arg);
                                }
                            }
                        ]
                    },
                ]
            },
            {
                BodyForm: "contentForm",
                ID: "QryForm1",
                Body: [
                    {
                        Row: "",
                        RowClass: "nohover",
                        Ctrl: [
                            {
                                sexy: function () {
                                    var tb = $('<table id="Result" class="rwd_form"></table>');
                                    tb.SexyTable([]);
                                    return tb;
                                }
                            }
                        ]
                    }
                ]
            },
        ]
    };

    $("#insertTable").SexyBox(json);
    $("#QryForm1").addClass("hide");
    $("#QryForm2").addClass("hide");

};


var genTable = function (Arg) {
    var tb_arg = {
        theadValue: [
            [
                { Text: "資料日期" },
                { Text: "借款人戶號" },
                { Text: "借款人姓名" },
                { Text: "放款案號" },
                { Text: "核貸日" },
                { Text: "核貸金額(單位：萬元)" },
                { Text: "撥款日" },
                { Text: "撥款金額(單位：萬元)" },
                { Text: "薪資收入(單位：萬元)" },
                { Text: "執行業務收入(單位：萬元)" },
                { Text: "營業收入(單位：萬元)" },
                { Text: "租金收入(單位：萬元)" },
                { Text: "利息收入(單位：萬元)" },
                { Text: "其他收入(單位：萬元)" },
                { Text: "借款人年收入(單位：萬元)" },
                { Text: "本案推估年收入(單位：萬元)" },
                { Text: "介紹人" },
                { Text: "介紹人員工代號" },
                { Text: "單位代號" },
            ]
        ],
        tbodyValue: {
            Value: [
                  "DataDate"
                , "CustNo"
                , "CustName"
                , "CaseNo"
                , "ApproveDate"
                , "CheckAmount"
                , "LMSLLD"
                , "LMSFLA"
                , "IncomeSalary"
                , "IncomeWork"
                , "IncomeBusiness"
                , "IncomeRant"
                , "IncomeInterest"
                , "IncomeOther"
                , "IncomeYear"
                , "Estimate"
                , "AngentEmpName"
                , "AngentEmpNo"
                , "AngentUnitNo"
            ]
        },
        Data: Arg.data.ResultData
    };
    var tb = $("#Result");
    tb.empty();
    tb.SexyTable(tb_arg);
};


var Qry = function (Arg) {
    var jsonData = $.valToJson("QryForm", "QryForm");
    var validList = [
        { Field: "DateS", FieldName: "資料日期 - 起日", CheckType: "rocDate", IsEmpty: "false" },
        { Field: "DateE", FieldName: "資料日期 - 迄日", CheckType: "rocDate", IsEmpty: "false" },
    ];
    var valid = $.FormValidation(jsonData, validList);
    var errMsg = $.FormValidationErrorMessage();
    var warnMsg = $.FormValidationWarningMessage();
    //if (jsonData.ApprovedDateS === "" && jsonData.ApprovedDateE === "" && jsonData.CaseClosedDate_S === "" && jsonData.CaseClosedDate_E === "") {
    //    valid = false;
    //    errMsg.push("寫請輸入日期區間");
    //}

    if (valid) {
        $("#QryForm1").removeClass("hide")
        $("#QryForm2").removeClass("hide")
        //genTable(Arg);

        var AjaxInputObj = {
            url: "SKL_1_4_House_InsCheckData/Qry",
            data: jsonData,
            oMethod: genTable
        };
        ////call ajax
        docCore.ajax(AjaxInputObj, true, true);
    } else {
        SexyAlert("提示", errMsg.length > 0 ? errMsg.join("<br>") : warnMsg.join("<br>"), "TIP", "OKONLY");
    }
};


$(document).ready(function () {
    genBox();
});
