﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Gemfor.Mvc;
using System.Data;
using Gemfor.Util;
using Gemfor.Auth;
using App_Code;
using System.Globalization;

namespace SKL_LOAN.Controllers.Api.eLoan.InputCase.Imm
{
    public class SKL_1_4_House_InsCheckDataController : BasePageController
    {
        clsSelect CDrop = new clsSelect();
        clsDate g_clsDate = new clsDate();


        /// <summary>
        /// 核保作業勾稽資料查詢
        /// </summary>
        /// <param name="cmd">
        /// @DateS		--資料日期起
        /// @DateE		--資料日期迄
        /// @CustNo			--借款人戶號
        /// @Agent_EmpNo	--介紹人員工代號
        /// </param>
        /// <returns></returns>
        [HttpPost]
        public StdRet Qry([FromBody]SKL_1_4_House_InsCheckDataControllerCmd cmd)
        {
            StdRet ret = new StdRet();
            HashMap Hm = new HashMap();

            try
            {
                Hm.Put("ResultData", House_InsCheckData_Qry(cmd));
                ret.data = Hm;
            }
            catch (Exception e)
            {
                ret.setRc(StdRet.RC.INTERNAL_ERR, e.Message);
            }

            return ret;
        }

        private DataTable House_InsCheckData_Qry(SKL_1_4_House_InsCheckDataControllerCmd cmd)
        {
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            HashMap HmParam = new HashMap();
            HashMap HmOut = new HashMap();

            HmParam.Put("@DateS", g_clsDate.getDate_West(cmd.DateS));
            HmParam.Put("@DateE", g_clsDate.getDate_West(cmd.DateE));
            HmParam.Put("@CustNo", (cmd.CustNo == null) ? "" : cmd.CustNo);
            HmParam.Put("@AgentEmpNo", (cmd.Agent_EmpNo == null) ? "" : cmd.Agent_EmpNo);
            HmOut.Put("@r_TotalNum", "");

            ds = DBUtil.ExecSP("dbo.USP_House_QryInsCheckData", HmParam, HmOut);

            if (ds.Tables[0].Rows.Count > 0)
            {
                dt = ds.Tables[0].Copy();
            }

            return dt;
        }

        /// <summary>
        /// 傳入參數
        /// </summary>
        /// <remarks>
        /// @DateS		--資料日期起
        /// @DateE		--資料日期迄
        /// @CustNo			--借款人戶號
        /// @Agent_EmpNo	--介紹人員工代號
        /// </remarks>
        public class SKL_1_4_House_InsCheckDataControllerCmd
        {
            public string DateS = "";
            public string DateE = "";
            public string CustNo = "";
            public string Agent_EmpNo = "";
        }
    }
}